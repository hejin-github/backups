"""
因子优化模块 - IC分析、网格搜索权重优化、滚动验证、对比回测
"""
import pandas as pd
import numpy as np
from itertools import product
from factor_lib import compute_all_factors, FACTOR_FUNCTIONS


class ICFactorAnalyzer:
    """IC分析器"""

    @staticmethod
    def compute_ic(df, factor_name, forward_periods=[1, 5, 10, 20]):
        """计算因子IC值（Rank IC）"""
        factors = compute_all_factors(df)
        if factor_name not in factors.columns:
            return {}
        results = {}
        fv = factors[factor_name]
        for fp in forward_periods:
            future_ret = df["close"].pct_change(fp).shift(-fp) * 100
            valid = pd.concat([fv, future_ret], axis=1).dropna()
            if len(valid) < 10:
                results[fp] = 0
                continue
            rank_ic = valid.iloc[:, 0].rank().corr(valid.iloc[:, 1].rank())
            results[fp] = round(rank_ic, 4) if not pd.isna(rank_ic) else 0
        return results

    @staticmethod
    def compute_all_ic(df, forward_period=5):
        """计算所有因子的IC"""
        factors = compute_all_factors(df)
        future_ret = df["close"].pct_change(forward_period).shift(-forward_period) * 100
        results = {}
        for col in factors.columns:
            valid = pd.concat([factors[col], future_ret], axis=1).dropna()
            if len(valid) < 10:
                results[col] = 0
                continue
            ic = valid.iloc[:, 0].rank().corr(valid.iloc[:, 1].rank())
            results[col] = round(ic, 4) if not pd.isna(ic) else 0
        return results

    @staticmethod
    def ic_decay(df, factor_name, max_period=20):
        """IC衰减分析"""
        periods = list(range(1, max_period + 1))
        ics = []
        for p in periods:
            ic = ICFactorAnalyzer.compute_ic(df, factor_name, [p])
            ics.append(ic.get(p, 0))
        return periods, ics


class WeightOptimizer:
    """网格搜索权重优化"""

    @staticmethod
    def _score_func(df, weights, forward_period=5):
        """评分函数：加权IC值"""
        factors = compute_all_factors(df)
        future_ret = df["close"].pct_change(forward_period).shift(-forward_period) * 100
        total_ic = 0
        count = 0
        for fname, w in weights.items():
            if fname in factors.columns:
                valid = pd.concat([factors[fname], future_ret], axis=1).dropna()
                if len(valid) >= 10:
                    ic = valid.iloc[:, 0].rank().corr(valid.iloc[:, 1].rank())
                    if not pd.isna(ic):
                        total_ic += abs(ic) * w
                        count += w
        return total_ic / count if count > 0 else 0

    @staticmethod
    def grid_search(df, factor_names, forward_period=5, step=0.05):
        """网格搜索最优权重"""
        n = len(factor_names)
        best_score = -1
        best_weights = None
        for values in product(range(0, 101, int(step * 100)), repeat=n):
            total = sum(values)
            if total == 0:
                continue
            weights = {factor_names[i]: v / total for i, v in enumerate(values)}
            if max(weights.values()) > 0.5:
                continue
            score = WeightOptimizer._score_func(df, weights, forward_period)
            if score > best_score:
                best_score = score
                best_weights = weights
        return best_weights, best_score


class RollingValidator:
    """滚动验证"""

    @staticmethod
    def rolling_validate(df, strategy_class, window=252, step=63):
        """滚动回测验证"""
        results = []
        total_len = len(df)
        start = 0
        while start + window < total_len:
            train_end = start + window
            test_end = min(train_end + step, total_len)
            if test_end - train_end < 30:
                break
            train_df = df.iloc[start:train_end].reset_index(drop=True)
            test_df = df.iloc[train_end:test_end].reset_index(drop=True)
            try:
                strategy = strategy_class() if strategy_class else None
                if strategy:
                    from backtest_engine import BacktestEngine
                    engine = BacktestEngine()
                    result = engine.run(train_df, strategy)
                    train_ret = result.metrics.get("_total_return", 0)
                    result2 = engine.run(test_df, strategy)
                    test_ret = result2.metrics.get("_total_return", 0)
                    results.append({
                        "window_start": df["date"].iloc[start],
                        "window_end": df["date"].iloc[test_end - 1],
                        "train_return": train_ret,
                        "test_return": test_ret,
                    })
            except Exception:
                pass
            start += step
        return results


class FactorComparison:
    """因子对比回测"""

    @staticmethod
    def compare_factors(df, factor_names, forward_period=5):
        """对比各因子的预测能力"""
        all_ic = {}
        for fname in factor_names:
            ic = ICFactorAnalyzer.compute_ic(df, fname, [forward_period])
            all_ic[fname] = ic.get(forward_period, 0)
        return dict(sorted(all_ic.items(), key=lambda x: abs(x[1]), reverse=True))
