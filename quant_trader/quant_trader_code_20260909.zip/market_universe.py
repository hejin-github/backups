# -*- coding: utf-8 -*-
"""点位全市场选股宇宙索引 + 信号缓存构建 — 2026-08-30

输入: data/market_bars/{code}.json(全市场bar存储, 含退市, 列式)
产出:
  data/prod_pipeline_backtest/universe_{asof}.pkl
    {asof, start, price_mode, days, amount_top{day:[codes]}, turnover_top{day:[codes]},
     umax:[codes], diag:{...}}
    - amount_top/turnover_top: 逐日 top-500(降序), 候选=mirror生产 filter_universe
      (前缀白名单 + 今日名ST/退代理剔除 + price≤50; price_mode=point 用 close[D], today 用末根)
    - umax: 全部 top-500 并集(信号只对 umax 生成, 覆盖 N<=500 所有切片)
    - diag: st_in_rank(名称代理偏差量化) + gap>1(停牌诊断)
  data/market_signals/{code}.pkl   每股22策略信号数组(断点续传, 8线程)

用法:
  python market_universe.py                      # 建宇宙索引 + 信号缓存
  python market_universe.py --universe-only      # 只建索引(重跑信号很快)
  python market_universe.py --signals-only       # 只补信号
  python market_universe.py --price-mode today   # 今日价过滤变体(因素分离用)
"""
import json
import os
import sys
import time

# 清代理必须先于任何网络调用
for _k in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "http_proxy", "https_proxy", "all_proxy"):
    os.environ.pop(_k, None)
os.environ["NO_PROXY"] = "*"

import numpy as np
import pandas as pd

BASE = os.path.dirname(os.path.abspath(__file__))
BAR_DIR = os.path.join(BASE, "data", "market_bars")
META_PATH = os.path.join(BAR_DIR, "_meta.json")
SIG_DIR = os.path.join(BASE, "data", "market_signals")
OUT_DIR = os.path.join(BASE, "data", "prod_pipeline_backtest")
START_STR = "20231013"
UNIVERSE_N_MAX = 500
PRICE_CAP = 50.0
_PREFIX_OK = ("600", "601", "603", "605", "000", "001", "002", "003")


# ───────────────────────── 加载 ─────────────────────────

def load_bars(code):
    """返回 dict(code, name, st, delisted, degraded, columns) 或 None"""
    p = os.path.join(BAR_DIR, "%s.json" % code)
    if not os.path.exists(p):
        return None
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _arr(cols, key):
    a = cols.get(key)
    return np.asarray(a, dtype=float) if a else None


# ───────────────────────── 宇宙索引 ─────────────────────────

def build_universe(asof, start_str=START_STR, price_mode="point", st_mode="today"):
    """逐日 top-500(amount/turnover) + umax + 诊断. 读bar存储, 无网络.
    st_mode: today=今日名称代理剔除ST/退(mirror生产, 但重引入退市幸存者偏差);
             point=退市股(outDate已定)按其bar历史参与排序(退市前可交易), 仅当前ST(未退市)按今日名剔除.
    两种模式之差 = 幸存者偏差幅度量化."""
    from experiment_common import load_index_regimes
    regimes, idx = load_index_regimes(1001, asof)
    if idx is None:
        print("指数数据不足")
        return None
    day_ts = sorted(pd.Timestamp(d) for d in regimes if pd.Timestamp(d) >= pd.Timestamp(start_str))
    days = [d.strftime("%Y%m%d") for d in day_ts]
    day_set = set(days)
    print("交易日历: %d 日 (%s ~ %s)" % (len(days), days[0], days[-1]))

    meta = {}
    if os.path.exists(META_PATH):
        with open(META_PATH, encoding="utf-8") as f:
            meta = json.load(f)

    # 逐code载入: 日期→(close, amount, turnover) 映射 + 末根close + 退市outDate
    per_code = {}
    t0 = time.time()
    for code in sorted(meta):
        if not code.startswith(_PREFIX_OK):
            continue
        b = load_bars(code)
        if b is None or b.get("degraded") or not b.get("columns"):
            continue
        cols = b["columns"]
        dates = cols.get("date") or []
        n = len(dates)
        if n < 30:
            continue
        closes = _arr(cols, "close")
        amounts = _arr(cols, "amount")
        turnovers = _arr(cols, "turnover")
        d2i = {d: i for i, d in enumerate(dates)}
        out_date = (meta.get(code, {}).get("outDate") or "").replace("-", "")
        per_code[code] = {
            "st": bool(b.get("st")), "name": b.get("name", ""),
            "out_date": out_date,
            "last_close": float(closes[-1]) if closes is not None and len(closes) else None,
            "d2i": d2i, "closes": closes, "amounts": amounts, "turnovers": turnovers,
        }
    print("载入bar: %d 只, %.1fs" % (len(per_code), time.time() - t0))

    amount_top, turnover_top = {}, {}
    st_in_rank_days, st_in_rank_total = 0, 0
    gap_count = 0
    for d in days:
        full = []   # (code, amount, turnover, st, price_ok)
        for code, pc in per_code.items():
            i = pc["d2i"].get(d)
            if i is None:
                continue
            close_d = pc["closes"][i] if pc["closes"] is not None else np.nan
            if not np.isfinite(close_d) or close_d <= 0:
                continue
            price_ok = close_d <= PRICE_CAP if price_mode == "point" else \
                (pc["last_close"] is not None and 0 < pc["last_close"] <= PRICE_CAP)
            amt = pc["amounts"][i] if pc["amounts"] is not None else np.nan
            to = pc["turnovers"][i] if pc["turnovers"] is not None else np.nan
            # st 剔除: today=今日名代理; point=退市股(outDate已定)参与排序, 仅当前ST(未退市)剔除
            st_eff = pc["st"]
            if st_mode == "point" and pc["out_date"]:
                st_eff = False
            full.append((code, amt, to, st_eff, price_ok))
        # st_in_rank: 今日名ST若不禁会进 top-500 的数量(基于 amount, 含ST全code)
        all_amt = sorted([(c, a) for c, a, _, _, _ in full if np.isfinite(a)],
                         key=lambda x: -x[1])[:UNIVERSE_N_MAX]
        n_st = sum(1 for c, _ in all_amt if per_code[c]["st"])
        st_in_rank_total += n_st
        st_in_rank_days += 1
        # 合格(非st且价ok)排名
        elig = [(c, a, t) for c, a, t, st, ok in full if not st and ok and np.isfinite(a)]
        amount_top[d] = [c for c, _, _ in sorted(elig, key=lambda x: -x[1])[:UNIVERSE_N_MAX]]
        elig_to = [(c, t) for c, _, t in elig if np.isfinite(t)]
        turnover_top[d] = [c for c, _ in sorted(elig_to, key=lambda x: -x[1])[:UNIVERSE_N_MAX]]

    umax_set = set()
    for d in days:
        umax_set.update(amount_top[d])
        umax_set.update(turnover_top[d])
    umax = sorted(umax_set)

    # gap 诊断: 相邻bar日期间隔 >1 交易日的停牌(累计)
    day_pos = {d: i for i, d in enumerate(days)}
    for code, pc in per_code.items():
        dates = [d for d in pc["d2i"] if d in day_set]
        for a, b in zip(dates, dates[1:]):
            if day_pos[b] - day_pos[a] > 1:
                gap_count += 1

    uni = {
        "asof": pd.Timestamp(asof).strftime("%Y%m%d"),
        "start": start_str, "price_mode": price_mode, "st_mode": st_mode,
        "days": days, "amount_top": amount_top, "turnover_top": turnover_top,
        "umax": umax,
        "diag": {
            "st_in_rank_days": st_in_rank_days,
            "st_in_rank_mean": round(st_in_rank_total / st_in_rank_days, 2) if st_in_rank_days else 0,
            "st_in_rank_total": st_in_rank_total,
            "gap_count": gap_count,
            "n_codes_with_bars": len(per_code),
        },
    }
    os.makedirs(OUT_DIR, exist_ok=True)
    suf = ""
    if price_mode != "point":
        suf += "_%s" % price_mode
    if st_mode != "today":
        suf += "_ptst"
    out_path = os.path.join(OUT_DIR, "universe_%s%s.pkl" % (uni["asof"], suf))
    with open(out_path, "wb") as f:
        pickle_dump(uni, f)
    print("宇宙索引[%s/%s]: %d 日, amount top 中位 %d 只, umax=%d, 已存 %s" % (
        price_mode, st_mode,
        len(days),
        int(np.median([len(v) for v in amount_top.values()])),
        len(umax), out_path))
    print("  诊断: st_in_rank 均值 %.1f 只/日, 停牌gap累计 %d" % (
        uni["diag"]["st_in_rank_mean"], uni["diag"]["gap_count"]))
    return uni


def pickle_dump(obj, f):
    import pickle
    pickle.dump(obj, f)


# ───────────────────────── 信号缓存 ─────────────────────────

def _hist_from_bars(b):
    """bar存储 → 策略用 DataFrame(列集与 akshare 原样: 全列)"""
    cols = b["columns"]
    df = pd.DataFrame(cols)
    if "date" in df.columns:
        df["date"] = pd.to_datetime(df["date"], format="%Y%m%d")
    for c in df.columns:
        if c != "date":
            df[c] = pd.to_numeric(df[c], errors="coerce")
    return df


def _one_worker(code):
    """进程池worker: 单code信号生成→落盘. 模块顶层(Windows spawn可pickle). 幂等."""
    from paper_trading import _STRAT_INSTANCES
    b = load_bars(code)
    if b is None:
        return code, "fail", "no bar"
    try:
        hist = _hist_from_bars(b)
        sd = {}
        for sname, stg in _STRAT_INSTANCES.items():
            try:
                sdf = stg.generate_signals(hist.copy())
                if "signal" in sdf.columns:
                    sd[sname] = sdf["signal"].astype(float).values
            except Exception:
                pass
        if not sd:
            return code, "fail", "no sigs"
        with open(os.path.join(SIG_DIR, "%s.pkl" % code), "wb") as f:
            import pickle
            pickle.dump(sd, f)
        return code, "ok", None
    except Exception as e:
        return code, "fail", str(e)[:80]


def build_signals(uni, workers=8, force=False):
    """对 umax 每只: bar→DataFrame→22策略信号数组 → data/market_signals/{code}.pkl.
    幂等: 文件存在跳过(断点续传). 返回 (ok, fail).
    用进程池(非线程): 单code ~2.9s且线程GIL串行(实测8线程≈单线程),
    进程池12核≈4只/s, 3070只 ~13min."""
    from concurrent.futures import ProcessPoolExecutor
    os.makedirs(SIG_DIR, exist_ok=True)
    umax = uni["umax"]
    todo = [c for c in umax if force or not os.path.exists(os.path.join(SIG_DIR, "%s.pkl" % c))]
    print("信号目标 %d 只, 待算 %d" % (len(umax), len(todo)), flush=True)
    if not todo:
        return 0, 0
    ok = fail = 0
    with ProcessPoolExecutor(max_workers=workers) as ex:
        for i, (_, status, _) in enumerate(ex.map(_one_worker, todo), 1):
            if status == "ok":
                ok += 1
            else:
                fail += 1
            if i % (workers * 4) == 0 or i == len(todo):
                print("  信号进度: ok=%d fail=%d 总=%d/%d 剩余=%d" % (
                    ok, fail, i, len(todo), len(todo) - i), flush=True)
    return ok, fail


# ───────────────────────── 入口 ─────────────────────────

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--asof", default=None)
    ap.add_argument("--start", default=START_STR)
    ap.add_argument("--price-mode", choices=("point", "today"), default="point")
    ap.add_argument("--st-mode", choices=("today", "point"), default="today")
    ap.add_argument("--universe-only", action="store_true")
    ap.add_argument("--signals-only", action="store_true")
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    from experiment_common import _prev_trading_day
    asof = args.asof or _prev_trading_day()

    if not args.signals_only:
        uni = build_universe(asof, args.start, args.price_mode, args.st_mode)
        if uni is None:
            return
    else:
        # 复用已存宇宙索引: 选 umax 最大的(覆盖全部 screen/st-mode 变体, 一次建齐信号)
        import glob
        files = glob.glob(os.path.join(OUT_DIR, "universe_*.pkl"))
        if not files:
            print("无已存宇宙索引")
            return
        import pickle
        best = None
        for fp in files:
            with open(fp, "rb") as f:
                u = pickle.load(f)
            if best is None or len(u["umax"]) > len(best[1]["umax"]):
                best = (fp, u)
        uni = best[1]
        print("复用宇宙索引: %s (umax %d)" % (best[0], len(uni["umax"])))

    if not args.universe_only:
        t0 = time.time()
        ok, fail = build_signals(uni, args.workers, args.force)
        print("信号构建完成: ok=%d fail=%d 耗时 %.1fs" % (ok, fail, time.time() - t0))


if __name__ == "__main__":
    main()
