"""Task #11 最终回归: 单策略质控 + skip 门控 + 辩论门槛移除
(历史数据源限流中, 用注入档位覆盖路径; 蒸馏用现有 latest.txt)
"""
import sys
sys.stdout.reconfigure(encoding="utf-8")
import unittest.mock as mock
from distiller import get_bullish_stocks
from strategy_backtest import strategies_for_regime

# ── A. skip=crash → 空仓(返回[]) ──
with mock.patch("recommender.index_regime", return_value={"level": "crash", "desc": "x",
                                                           "max_sectors": 0, "weak_only": True, "skip": True}):
    r = get_bullish_stocks(min_signals=1)
    print(f"A. crash(skip) → {len(r)}只  {'✓' if r == [] else '✗ FAIL'}")
    assert r == []

# ── B. 各档位非 skip: 违禁=0, 且需有命中(数据源正常时) ──
for lvl in ["strong", "normal", "weak"]:
    allowed = set(strategies_for_regime(lvl))
    fake = {"level": lvl, "desc": "x", "max_sectors": 5, "weak_only": False, "skip": False}
    with mock.patch("recommender.index_regime", return_value=fake):
        buys = get_bullish_stocks(min_signals=1)
        viol = [b for b in buys if not any(s in allowed for s in b["strategies"])]
        single = [b for b in buys if b["signal_count"] == 1]
        print(f"B. {lvl}: allowed={len(allowed)}只策略 → {len(buys)}只股, "
              f"单策略股={len(single)}, 违禁={len(viol)}  {'✓' if not viol else '✗'}")
        assert not viol

# ── C. require_allowed=False 旧逻辑仍可用(向后兼容) ──
with mock.patch("recommender.index_regime", return_value={"level": "strong", "desc": "x",
                                                           "max_sectors": 5, "weak_only": False, "skip": False}):
    r = get_bullish_stocks(min_signals=1, require_allowed=False)
    print(f"C. require_allowed=False → {len(r)}只  ✓(兼容)")
    assert r is not None

# ── D. 导入全绿(含新改动) ──
import importlib
for m in ["app", "distiller", "debate_engine", "strategy_backtest"]:
    importlib.import_module(m)
print("D. 4模块导入 OK ✓")
print("FINAL OK")
