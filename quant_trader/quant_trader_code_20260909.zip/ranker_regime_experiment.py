# -*- coding: utf-8 -*-
"""
Stage2 主实验: 按行情(strong/normal/weak/crash)自适应选股 ranker 是否真实提升 T+1 胜率/净收益

输入: data/ranker_experiment/candidates.csv (Stage1 产物, (D,stock) 候选 + ranker 信号 + T+1收益)
      (可选 --csv 覆盖, 供 400日×300只 稳健性库)

结构:
  描述层(全窗口, in-sample, 只出报告不决策): regime×ranker 的 top1/top3 胜率/均值/中位/N
  预测层(60/40, 主判定):
    训练段每档位选 ranker(top1 均值最高) + 护栏(≥15日/≥30 pick/胜率≥50%) → data_rank_map
    测试段对照: A现基线R_twr / B全局单一最佳 / C按行情切data_rank_map / C_theory预注册 / D随机
    指标: top1/top3 胜率均值中位std + 净值/maxDD/Sharpe(无 pick 日计 0 占时间轴, 含 crash 空仓)
          毛/净两版(成本 0.20% 净版为主判据) + 配对日 bootstrap 90%CI + P(差>0) + McNemar
  判定规则(pre-registered):
    #1 净收益 mean(C) ≥ mean(A)+0.2pp 且 ≥ mean(B)+0.2pp, bootstrap 90%CI 下界>0
    #2 逐档位: 每个 C 偏离默认(R_twr)的档位 r, mean(C|r) ≥ mean(R_twr|r)+0.3pp 且测试 pick 日 ≥15
    #3 超额收益版(ret_excess)同向
    #4 风险: C 的 maxDD 不劣于 B 超过 2pp, 日报 Sharpe ≥ B
输出: data/ranker_experiment/ranker_result.json + equity_curves.csv
"""
import argparse
import hashlib
import json
import os
import sys

import numpy as np
import pandas as pd
from scipy import stats as _stats  # 仅 McNemar p 值; 无 scipy 时回退 None

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

BASE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(BASE, "data", "ranker_experiment")
DEFAULT_CSV = os.path.join(OUT_DIR, "candidates.csv")

REGIMES = ["strong", "normal", "weak", "crash"]
DEFAULT_RANKER = "R_twr"          # 现基线
COST = 0.20                       # 单笔成本 %(佣金2.5bp×2+印花税5bp+过户费0.2bp+滑点10bp)
TRAIN_FRAC = 0.6
BOOT_N = 10000
# C_theory 预注册(防过拟合主判): 理论预期 weak/crash 买回调, strong/normal 买强势
C_THEORY = {"strong": "R_exp", "normal": "R_exp", "weak": "R_rev", "crash": "skip"}


# ───────────────────────── ranker 定义 ─────────────────────────

def _rank(df, key, ascending=False, na_position="last"):
    return df.sort_values([key, "code"], ascending=[ascending, True],
                          na_position=na_position).reset_index(drop=True)


def R_twr(df):   return _rank(df, "twr20")
def R_exp(df):   return _rank(df, "avg20")
def R_chg(df):   return _rank(df, "change_pct")
def R_rev(df):   return _rank(df, "change_pct", ascending=True, na_position="first")
def R_count(df): return _rank(df, "signal_count")
def R_rnd(df):   return df.copy()  # 仅占位; 真随机走 pick_day 的种子分支


RANKERS = {"R_twr": R_twr, "R_exp": R_exp, "R_chg": R_chg, "R_rev": R_rev,
           "R_count": R_count, "R_rnd": R_rnd}


def _seed_for(day):
    return int(hashlib.md5(str(day).encode()).hexdigest()[:8], 16)


def pick_day(group, ranker):
    """候选组 → 返回 top1..top3 的毛 ret(确定性; R_rnd 用 day 种子打乱)."""
    if ranker == "R_rnd":
        rng = np.random.default_rng(_seed_for(int(group["date"].iloc[0])))
        g = group.iloc[rng.permutation(len(group))].reset_index(drop=True)
        return g.head(3)["ret"].tolist()
    return RANKERS[ranker](group).head(3)["ret"].tolist()


# ───────────────────────── 指标 ─────────────────────────

def _stats(rets):
    t = len(rets)
    if t == 0:
        return {"n": 0, "win_rate": 0.0, "mean": 0.0, "median": 0.0, "std": 0.0}
    a = np.asarray(rets, dtype=float)
    return {"n": int(t), "win_rate": round(float((a > 0).mean() * 100), 2),
            "mean": round(float(a.mean()), 4), "median": round(float(np.median(a)), 4),
            "std": round(float(a.std()), 4)}


def _nav_metrics(daily):
    arr = np.asarray(daily, dtype=float) / 100.0
    nav = np.cumprod(1 + arr)
    cummax = np.maximum.accumulate(nav)
    maxdd = float(((cummax - nav) / np.where(cummax == 0, 1, cummax)).max())
    std = arr.std(ddof=1)
    sharpe = float(arr.mean() / std * np.sqrt(252)) if std > 1e-12 else 0.0
    return {"nav": round(float(nav[-1]), 4), "maxdd": round(maxdd * 100, 2),
            "sharpe": round(sharpe, 3)}


# ───────────────────────── 核心: 配置评估 ─────────────────────────

def eval_config(test_days, day_groups, rank_map, ranker, cost):
    """rank_map: {regime: ranker} 或 None(固定 ranker)。返回 stats/净序列/nav/per_regime/day_rets。"""
    daily_g, daily_n, per_regime = [], [], {r: [] for r in REGIMES}
    day_rets = {}
    for d in test_days:
        grp = day_groups.get(d)
        regime = d_regime.get(d, "crash")
        # crash 日生产一律空仓(大盘深度破位 skip 门在上游), 所有配置该日计 0
        if regime == "crash":
            daily_g.append(0.0); daily_n.append(0.0); day_rets[d] = 0.0; continue
        rk = rank_map.get(regime) if rank_map else ranker
        if rk == "skip" or grp is None or grp.empty:
            daily_g.append(0.0); daily_n.append(0.0); day_rets[d] = 0.0; continue
        rets = pick_day(grp, rk)
        if not rets:
            daily_g.append(0.0); daily_n.append(0.0); day_rets[d] = 0.0; continue
        r = rets[0]
        daily_g.append(r); daily_n.append(r - cost); day_rets[d] = r
        per_regime[regime].append(r)
    return {"stats": _stats(daily_g), "net_stats": _stats(daily_n),
            "nav": _nav_metrics(daily_g), "nav_net": _nav_metrics(daily_n),
            "net_series": np.asarray(daily_n), "per_regime": per_regime,
            "day_rets": day_rets}


def _bootstrap_ci(c, v, seed=42):
    rng = np.random.default_rng(seed)
    diffs = np.array([float((c[ix] - v[ix]).mean())
                      for ix in [rng.integers(0, len(c), len(c)) for _ in range(BOOT_N)]])
    lo, hi = np.percentile(diffs, [5, 95])
    return {"mean_diff": round(float(diffs.mean()), 4), "ci_low": round(float(lo), 4),
            "ci_high": round(float(hi), 4), "p_gt0": round(float((diffs > 0).mean()), 4)}


# ───────────────────────── 主流程 ─────────────────────────

def load(csv):
    df = pd.read_csv(csv, dtype={"date": str, "code": str})
    df["date"] = df["date"].astype(str)
    return df


def run(csv=DEFAULT_CSV, train_frac=TRAIN_FRAC, cost=COST):
    global d_regime
    df = load(csv)
    d_regime = dict(zip(df["date"], df["regime"]))
    day_groups = {d: g for d, g in df.groupby("date")}
    all_days = sorted(day_groups.keys())
    print(f"候选行 {len(df)} | 日期 {len(all_days)} | 档位分布 "
          f"{df.groupby('regime').size().to_dict()}")

    # ── 描述层(全窗口 in-sample) ──
    desc = {}
    for regime in REGIMES:
        desc[regime] = {}
        for rk in RANKERS:
            rets = []
            for d in all_days:
                if d_regime[d] != regime:
                    continue
                grp = day_groups.get(d)
                if grp is None or grp.empty:
                    continue
                rs = pick_day(grp, rk)
                if rs:
                    rets.extend(rs[:3])
            desc[regime][rk] = _stats(rets)
    print("\n=== 描述层: regime×ranker 的 top1..top3 胜率/均值/N (in-sample, 仅出假设) ===")
    for regime in REGIMES:
        line = f"  {regime:<6}"
        for rk in RANKERS:
            s = desc[regime][rk]
            line += f"{rk[:4]} {s['win_rate']:>5.1f}%/{s['mean']:>+6.3f}({s['n']:<4})  "
        print(line)

    # ── 切分 ──
    n = len(all_days)
    split_at = all_days[int(n * train_frac)]
    train_days = [d for d in all_days if d < split_at]
    test_days = [d for d in all_days if d >= split_at]
    print(f"\n训练日 {len(train_days)} (至{split_at}) | 测试日 {len(test_days)}")

    # ── 训练段: 每档位选 ranker ──
    def _train_picks(ranker):
        by_regime = {r: [] for r in REGIMES}
        for d in train_days:
            grp = day_groups.get(d)
            if grp is None or grp.empty:
                continue
            rs = pick_day(grp, ranker)
            if rs:
                by_regime[d_regime[d]].append(rs[0])
        return by_regime

    best_per_regime = {}
    for regime in REGIMES:
        if regime == "crash":
            best_per_regime[regime] = "skip"
            continue
        tdays = sum(1 for d in train_days if d_regime[d] == regime)
        cands = [(rk, _stats(_train_picks(rk)[regime])) for rk in RANKERS
                 if len(_train_picks(rk)[regime]) >= 30]
        if tdays < 15 or not cands:
            best_per_regime[regime] = DEFAULT_RANKER   # 证据不足 → 保持现状
            continue
        best = max(cands, key=lambda x: x[1]["mean"])
        best_per_regime[regime] = best[0] if best[1]["win_rate"] >= 50.0 else DEFAULT_RANKER
    # 全局单一最佳(所有可交易档位合并 top1 均值最高; crash 生产空仓不计)
    global_best, global_best_mean = DEFAULT_RANKER, -1e9
    for rk in RANKERS:
        all_r = []
        for d in train_days:
            if d_regime[d] == "crash":
                continue
            grp = day_groups.get(d)
            if grp is None or grp.empty:
                continue
            rs = pick_day(grp, rk)
            if rs:
                all_r.append(rs[0])
        m = float(np.mean(all_r)) if all_r else -1e9
        if m > global_best_mean:
            global_best, global_best_mean = rk, m
    print("\n训练段 data_rank_map:", best_per_regime)
    print(f"训练段 全局单一最佳: {global_best} (top1均值 {global_best_mean:+.3f}%)")

    # ── 测试段对照 ──
    configs = {
        "A_现基线R_twr": eval_config(test_days, day_groups, None, "R_twr", cost),
        "B_全局单一最佳": eval_config(test_days, day_groups, None, global_best, cost),
        "C_按行情切换": eval_config(test_days, day_groups, best_per_regime, None, cost),
        "C_theory预注册": eval_config(test_days, day_groups, C_THEORY, None, cost),
        "D_随机": eval_config(test_days, day_groups, None, "R_rnd", cost),
    }
    print("\n=== 测试段 top1 (毛/净 均值·胜率 · 净值/maxDD/Sharpe) ===")
    for name, c in configs.items():
        s, ns, nv = c["stats"], c["net_stats"], c["nav_net"]
        print(f"  {name:<14} 毛 {s['mean']:+.3f}%/{s['win_rate']:>5.1f}%  净 {ns['mean']:+.3f}%/{ns['win_rate']:>5.1f}%  "
              f"nav {nv['nav']:.3f} maxDD {nv['maxdd']:.1f}% sharpe {nv['sharpe']:.2f}")

    boot_C_A = _bootstrap_ci(configs["C_按行情切换"]["net_series"],
                             configs["A_现基线R_twr"]["net_series"])
    boot_C_B = _bootstrap_ci(configs["C_按行情切换"]["net_series"],
                             configs["B_全局单一最佳"]["net_series"])
    boot_CT_A = _bootstrap_ci(configs["C_theory预注册"]["net_series"],
                              configs["A_现基线R_twr"]["net_series"])

    # McNemar(每日 top1 胜负配对, 仅双方都有 pick 的日)
    c_w = a_w = both = 0
    for d in test_days:
        ra = configs["A_现基线R_twr"]["day_rets"][d]
        rc = configs["C_按行情切换"]["day_rets"][d]
        if ra == 0 or rc == 0:
            continue
        wa, wc = ra > 0, rc > 0
        if wc and not wa: c_w += 1
        elif wa and not wc: a_w += 1
        elif wa and wc: both += 1
    chi2 = (abs(c_w - a_w) - 1) ** 2 / max(c_w + a_w, 1)
    try:
        p = float(_stats.chi2.sf(chi2, 1))
    except Exception:
        p = None
    mcnemar = {"A_win": a_w, "C_win": c_w, "both_win": both, "chi2": round(chi2, 3), "p": p}

    # 逐档位: C vs R_twr(仅偏离默认的档位检查)
    per_regime_compare = {}
    for regime in REGIMES:
        stc = _stats(configs["C_按行情切换"]["per_regime"][regime])
        sta = _stats(configs["A_现基线R_twr"]["per_regime"][regime])
        per_regime_compare[regime] = {
            "C_ranker": best_per_regime[regime],
            "C_pick_days": stc["n"], "C_mean": stc["mean"], "C_win": stc["win_rate"],
            "A_mean": sta["mean"], "A_win": sta["win_rate"],
            "diff": round(stc["mean"] - sta["mean"], 4)}

    # 超额收益版(同向核对)
    excess = _excess_compare(test_days, day_groups, best_per_regime)

    # ── 判定规则 ──
    c_net = configs["C_按行情切换"]["net_stats"]
    a_net = configs["A_现基线R_twr"]["net_stats"]
    b_net = configs["B_全局单一最佳"]["net_stats"]
    rules = {
        "#1 净收益超基线": {
            "ok": (c_net["mean"] >= a_net["mean"] + 0.2 and c_net["mean"] >= b_net["mean"] + 0.2
                   and boot_C_A["ci_low"] > 0 and boot_C_B["ci_low"] > 0),
            "detail": {"C净": c_net["mean"], "A净": a_net["mean"], "B净": b_net["mean"],
                       "CI_CvsA": [boot_C_A["ci_low"], boot_C_A["ci_high"]],
                       "CI_CvsB": [boot_C_B["ci_low"], boot_C_B["ci_high"]],
                       "pC>0vsA": boot_C_A["p_gt0"], "pC>0vsB": boot_C_B["p_gt0"]}},
        "#2 逐档位": {"ok": True, "detail": per_regime_compare},
    }
    for regime, pc in per_regime_compare.items():
        if pc["C_ranker"] != DEFAULT_RANKER:
            if pc["C_pick_days"] < 15:
                rules["#2 逐档位"]["ok"] = False
                rules["#2 逐档位"]["detail"][regime]["note"] = "测试pick日<15, 证据不足"
            elif pc["diff"] < 0.3:
                rules["#2 逐档位"]["ok"] = False
                rules["#2 逐档位"]["detail"][regime]["note"] = f"C较R_twr不足+0.3pp(diff={pc['diff']:+.2f})"
    rules["#3 超额收益同向"] = {"ok": excess["mean_diff"] > 0 and excess["ci_low"] > 0,
                           "detail": excess}
    nav_c = configs["C_按行情切换"]["nav_net"]
    nav_b = configs["B_全局单一最佳"]["nav_net"]
    rules["#4 风险约束"] = {"ok": (nav_c["maxdd"] <= nav_b["maxdd"] + 2.0
                                and nav_c["sharpe"] >= nav_b["sharpe"]),
                         "detail": {"C_maxDD": nav_c["maxdd"], "B_maxDD": nav_b["maxdd"],
                                    "C_sharpe": nav_c["sharpe"], "B_sharpe": nav_b["sharpe"]}}
    verdict = all(v["ok"] for v in rules.values())
    print("\n=== 判定规则(pre-registered) ===")
    for k, v in rules.items():
        print(f"  [{'PASS' if v['ok'] else 'FAIL'}] {k}: {json.dumps(v['detail'], ensure_ascii=False)[:200]}")

    res = {
        "meta": {"csv": csv, "train_frac": train_frac, "cost": cost, "split_at": split_at,
                 "train_days": len(train_days), "test_days": len(test_days)},
        "descriptive": desc,
        "data_rank_map_train": best_per_regime,
        "global_best_train": global_best,
        "c_theory": C_THEORY,
        "configs": {k: {"stats": v["stats"], "net_stats": v["net_stats"],
                        "nav": v["nav"], "nav_net": v["nav_net"],
                        "per_regime": {r: _stats(x) for r, x in v["per_regime"].items()}}
                    for k, v in configs.items()},
        "bootstrap": {"C_vs_A": boot_C_A, "C_vs_B": boot_C_B, "Ctheo_vs_A": boot_CT_A},
        "mcnemar": mcnemar,
        "excess_compare": excess,
        "rules": rules,
        "verdict": "PASS_支持切换" if verdict else "FAIL_不支持切换/部分支持",
    }
    os.makedirs(OUT_DIR, exist_ok=True)
    with open(os.path.join(OUT_DIR, "ranker_result.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)
    ec = pd.DataFrame({"date": test_days, **{k: pd.Series(configs[k]["net_series"])
                                             for k in configs}})
    ec.to_csv(os.path.join(OUT_DIR, "equity_curves.csv"), index=False, encoding="utf-8-sig")
    print(f"\nverdict: {res['verdict']}\n结果: {os.path.join(OUT_DIR, 'ranker_result.json')}")
    return res


def _excess_compare(test_days, day_groups, rank_map):
    c, a = [], []
    for d in test_days:
        grp = day_groups.get(d)
        regime = d_regime.get(d, "crash")
        rk_c = rank_map.get(regime)
        for label, rk in (("C", rk_c), ("A", "R_twr")):
            if regime == "crash" or rk == "skip" or grp is None or grp.empty:
                r = 0.0
            else:
                rets = pick_day(grp, rk)
                r = rets[0] if rets else 0.0
            if label == "C":
                c.append(r)
            else:
                a.append(r)
    return _bootstrap_ci(np.array(c), np.array(a), seed=7)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default=DEFAULT_CSV)
    ap.add_argument("--train-frac", type=float, default=TRAIN_FRAC)
    ap.add_argument("--cost", type=float, default=COST)
    args = ap.parse_args()
    run(csv=args.csv, train_frac=args.train_frac, cost=args.cost)
