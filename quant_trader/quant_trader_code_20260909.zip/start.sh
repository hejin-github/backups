#!/bin/bash
# QuantTrader v2.0 量化交易系统 - Bash启动脚本

echo "============================================"
echo "   QuantTrader v2.0 量化交易系统"
echo "   11个页面 | 13+1个策略 | 因子优化 | 实时监控"
echo "============================================"
echo ""

# 检查 Python
if ! command -v python &>/dev/null && ! command -v python3 &>/dev/null; then
    echo "[错误] 未检测到 Python，请先安装 Python 3.9+"
    exit 1
fi

PYTHON=$(command -v python || command -v python3)

echo "[1/2] 检查依赖..."
"$PYTHON" -m pip install -r requirements.txt -q

echo "[2/2] 启动系统..."
echo ""
echo "============================================"
echo "  ✅ 启动成功！"
echo "  请在浏览器中访问: http://localhost:8501"
echo "  按 Ctrl+C 可停止系统"
echo "============================================"
echo ""

"$PYTHON" -m streamlit run app.py
