"""Task #11 补测: 注入行情档位, 实证 get_bullish_stocks 单策略质控路径
- 注入 weak: allowed 集较大, 应有命中; 且返回股只含 allowed 策略信号
- require_allowed=False 对照(旧逻辑): 返回股可含非 allowed 策略信号
"""
import sys
sys.stdout.reconfigure(encoding="utf-8")
import unittest.mock as mock

from distiller import get_bullish_stocks
from strategy_backtest import strategies_for_regime

for lvl in ["weak", "strong"]:
    allowed = set(strategies_for_regime(lvl))
    print(f"--- 注入 level={lvl}  allowed={sorted(allowed)}")
    fake_regime = {"level": lvl, "desc": "inject", "max_sectors": 2,
                   "weak_only": (lvl == "weak"), "skip": False}
    with mock.patch("recommender.index_regime", return_value=fake_regime):
        buys = get_bullish_stocks(min_signals=1)
        single = [b for b in buys if b["signal_count"] == 1]
        viol = [b for b in buys if not any(s in allowed for s in b["strategies"])]
        print(f"  get_bullish_stocks(1): {len(buys)}只  单策略信号股: {len(single)}  违禁股: {len(viol)}")
        for b in buys[:6]:
            hit = sum(1 for s in b["strategies"] if s in allowed)
            print(f"    {b['name']}({b['code']}) 信号={b['signal_count']} 策略={b['strategies']} allowed命中={hit}")
        # 对照: 旧逻辑(不看质控)
        buys_old = get_bullish_stocks(min_signals=1, require_allowed=False)
        print(f"  [对照 require_allowed=False] {len(buys_old)}只")
        assert not viol, f"违禁! 存在无 allowed 信号的股票: {viol}"
        if single:
            print(f"  ✓ 单策略放行成立: {single[0]['name']}({single[0]['code']}) 策略={single[0]['strategies']}")
        else:
            print("  (本档位蒸馏样本内无单策略信号股)")
print("INJECT DONE")
