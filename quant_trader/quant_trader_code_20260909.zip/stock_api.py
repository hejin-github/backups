"""
股票数据接口层 — 东方财富(AKShare) + 腾讯财经双源
实时行情: AKShare → 腾讯财经(urllib直连, 绕过系统代理) → None
历史K线/板块: AKShare(需系统代理正常) → None
大盘指数: AKShare → 腾讯财经(urllib直连) → None
个股资料: AKShare → 东方财富ulist(urllib直连) → None
无模拟数据, 无DemoDataGenerator.
"""
import os
import pandas as pd
import numpy as np
from bisect import bisect_left, bisect_right
from datetime import datetime, timedelta
import time
import warnings
import json
import re
import urllib.request
import urllib.parse
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

_HAS_AKSHARE = False
try:
    import akshare as ak
    _HAS_AKSHARE = True
except ImportError:
    pass

# Windows 系统代理检测
_SYSTEM_PROXY = bool(urllib.request.getproxies())

# 东方财富可达性预检(快速检测,避免akshare长时间超时)
def _eastmoney_reachable(timeout=3):
    """快速检测东方财富API是否可达(跳过akshare的漫长重试)"""
    try:
        req = urllib.request.Request(
            "https://push2.eastmoney.com/api/qt/clist/get?"
            "pn=1&pz=1&po=1&np=1&ut=bd1d9ddb04089700cf9c27f6f7426281"
            "&fltt=2&invt=2&fid=f12&fs=m:0+t:6&fields=f12",
            headers=_EM_HEADERS,
        )
        urllib.request.urlopen(req, timeout=timeout)
        return True
    except Exception:
        return False

_EM_REACHABLE = _eastmoney_reachable()


# ==================== 进程级 TTL 行情缓存 ====================
# 首页/详情页一次渲染会反复请求相同区间的行情(推荐记录T+1补算、策略卡片等)，
# 加 TTL 缓存避免同区间重复网络请求，显著降低页面渲染耗时。
_DCACHE = {}
_DCACHE_LOCK = threading.Lock()
_DCACHE_MAX = 4000


def _cache_copy(val):
    """返回结果的副本，避免调用方原地修改污染缓存。"""
    if isinstance(val, pd.DataFrame):
        return val.copy()
    if isinstance(val, dict):
        return dict(val)
    return val


def _cached(key, ttl, fn):
    """TTL 缓存：ttl 秒内同一 key 命中直接返回缓存副本；失败(None)不缓存以便重试。"""
    now = time.time()
    with _DCACHE_LOCK:
        hit = _DCACHE.get(key)
        if hit is not None and now - hit[0] < ttl:
            return _cache_copy(hit[1])
    val = fn()
    if val is not None:
        with _DCACHE_LOCK:
            if len(_DCACHE) > _DCACHE_MAX:
                _DCACHE.clear()
            _DCACHE[key] = (time.time(), val)
    return _cache_copy(val)


# ==================== 东方财富个股查询(ulist.np/get) ====================
# 注意: push2.eastmoney.com 的 ulist.np/get 可通过 urllib 直连,
#       但 clist/get 和 82.push2 子域在部分网络环境存在 RemoteDisconnected 问题.

_EM_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Referer": "https://quote.eastmoney.com/",
}


def _em_ulist_quotes(secids):
    """通过 ulist.np/get 批量查询指定股票实时行情(urllib直连,绕过系统代理)"""
    if not secids:
        return None
    codes = ",".join(secids)
    url = (
        "https://push2.eastmoney.com/api/qt/ulist.np/get"
        f"?fltt=2&invt=2&fields=f2,f3,f4,f5,f6,f7,f8,f9,f10,f12,f14,"
        f"f15,f16,f17,f18,f20,f21,f37&secids={codes}"
    )
    req = urllib.request.Request(url, headers=_EM_HEADERS)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None
    if not data or data.get("rc") != 0:
        return None
    diff = (data.get("data") or {}).get("diff")
    if not diff:
        return None
    rows = []
    for item in diff:
        if not isinstance(item, dict):
            continue
        f12 = item.get("f12")
        if f12 is None:
            continue
        rows.append({
            "code": str(f12).zfill(6),
            "name": str(item.get("f14", "")),
            "price": item.get("f2"),
            "change_pct": item.get("f3"),
            "change": item.get("f4"),
            "volume": item.get("f5"),
            "amount": item.get("f6"),
            "amplitude": item.get("f7"),
            "turnover": item.get("f8"),
            "pe": item.get("f9"),
            "volume_ratio": item.get("f10"),
            "high": item.get("f15"),
            "low": item.get("f16"),
            "open": item.get("f17"),
            "pre_close": item.get("f18"),
            "pb": item.get("f37"),
            "total_mv": item.get("f20"),
            "float_mv": item.get("f21"),
        })
    if not rows:
        return None
    df = pd.DataFrame(rows)
    for col in ["price", "change_pct", "volume", "amount", "turnover", "pe", "pb"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
    return df


# ==================== 新浪财经历史K线(备用) ====================

_SINA_KLINE_HEADERS = {"User-Agent": "Mozilla/5.0"}
# 新浪股票代码格式
def _sina_code(code):
    c = code.replace(".SH", "").replace(".SZ", "").replace(".BJ", "").zfill(6)
    if c.startswith("6") or c.startswith("9"):
        return f"sh{c}"
    return f"sz{c}"


def _sina_historical_data(symbol, start_date, end_date):
    """新浪财经历史K线(不复权, JSON格式)"""
    symbol_clean = symbol.replace(".SH", "").replace(".SZ", "").replace(".BJ", "").zfill(6)
    scode = _sina_code(symbol_clean)

    if isinstance(start_date, str):
        start_date = pd.to_datetime(start_date)
    if isinstance(end_date, str):
        end_date = pd.to_datetime(end_date)

    # 估算需要多少天(交易日约日历日的0.7倍, 多取一些)
    est_days = int((end_date - start_date).days * 0.8) + 60
    datalen = min(max(est_days, 20), 1000)

    url = (
        "http://money.finance.sina.com.cn/quotes_service/api/json_v2.php/"
        f"CN_MarketData.getKLineData?symbol={scode}&scale=240&ma=no&datalen={datalen}"
    )
    try:
        req = urllib.request.Request(url, headers=_SINA_KLINE_HEADERS)
        with urllib.request.urlopen(req, timeout=10) as resp:
            raw = resp.read().decode("gbk")
            data = json.loads(raw)
    except Exception:
        return None

    if not data or not isinstance(data, list) or len(data) == 0:
        return None

    rows = []
    for item in data:
        try:
            d = pd.to_datetime(item["day"])
            if d < pd.to_datetime(start_date) or d > pd.to_datetime(end_date):
                continue
            rows.append({
                "date": d,
                "open": float(item["open"]),
                "close": float(item["close"]),
                "high": float(item["high"]),
                "low": float(item["low"]),
                "volume": int(float(item["volume"])),
            })
        except (KeyError, ValueError, TypeError):
            continue

    if not rows:
        return None
    df = pd.DataFrame(rows)
    df = df.sort_values("date").reset_index(drop=True)
    # 补充计算字段
    df["change_pct"] = df["close"].pct_change().fillna(0) * 100
    df["amount"] = df["volume"] * df["close"]
    return df


# ==================== 腾讯财经(urllib直连, 涵盖行情+指数) ====================

_TX_HEADERS = {"User-Agent": "Mozilla/5.0"}

# 腾讯股票代码格式转换
def _tx_code(code):
    c = code.replace(".SH", "").replace(".SZ", "").replace(".BJ", "").zfill(6)
    if c.startswith("6") or c.startswith("9"):
        return f"sh{c}"
    if c.startswith("0") or c.startswith("3"):
        return f"sz{c}"
    return f"bj{c}"


def _tx_fetch(codes_list):
    """腾讯财经批量查询, codes_list 为原始6位代码列表"""
    batch_size = 100
    rows = []
    for i in range(0, len(codes_list), batch_size):
        batch = codes_list[i:i + batch_size]
        tcodes = ",".join(_tx_code(c) for c in batch)
        url = f"http://qt.gtimg.cn/q={tcodes}"
        try:
            req = urllib.request.Request(url, headers=_TX_HEADERS)
            with urllib.request.urlopen(req, timeout=10) as resp:
                text = resp.read().decode("gbk")
        except Exception:
            continue

        for line in text.strip().split(";"):
            line = line.strip()
            if not line or "=" not in line:
                continue
            try:
                eq = line.index("=")
                val = line[eq + 1:].strip().strip('"')
                parts = val.split("~")
            except (ValueError, IndexError):
                continue
            if len(parts) < 40:
                continue
            try:
                code = parts[2].strip()
                name = parts[1].strip()
                price = float(parts[3] or 0)
                pre_close = float(parts[4] or 0)
                vol = int(parts[6] or 0) * 100  # 腾讯返回的是手, 转为股
                change_pct = float(parts[32]) if len(parts) > 32 and parts[32] else 0
                high = float(parts[33]) if len(parts) > 33 and parts[33] else 0
                low = float(parts[34]) if len(parts) > 34 and parts[34] else 0
                amount = float(parts[37]) if len(parts) > 37 and parts[37] else 0
                turnover = float(parts[38]) if len(parts) > 38 and parts[38] else 0
                pe = float(parts[39]) if len(parts) > 39 and parts[39] else 0

                # 腾讯部分版本 amount 单位为万元, 自动修正
                estimated = vol * price
                if 0 < amount < estimated * 0.01 and amount > 0:
                    amount *= 10000

                # 腾讯字段: [72]流通股本 [73]总股本 (单位:股), 用于兜底算市值
                try:
                    total_shares = float(parts[73]) if len(parts) > 73 and parts[73] else 0
                except (ValueError, TypeError, IndexError):
                    total_shares = 0
                try:
                    float_shares = float(parts[72]) if len(parts) > 72 and parts[72] else 0
                except (ValueError, TypeError, IndexError):
                    float_shares = 0

                rows.append({
                    "code": code,
                    "name": name,
                    "price": price,
                    "change_pct": change_pct,
                    "change": price - pre_close,
                    "volume": vol,
                    "amount": amount,
                    "high": high,
                    "low": low,
                    "open": float(parts[5]) if parts[5] else 0,
                    "pre_close": pre_close,
                    "turnover": turnover,
                    "pe": pe,
                    "total_shares": total_shares,
                    "float_shares": float_shares,
                })
            except (ValueError, IndexError):
                continue
    if not rows:
        return None
    df = pd.DataFrame(rows)
    for col in ["price", "change_pct", "volume", "amount", "turnover", "pe"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
    return df


# 覆盖主要 A股 的查询名单(沪深300 + 中证500主要成分 + 热门股)
_TX_FALLBACK_CODES = [
    # 银行保险
    "000001", "600000", "600015", "600016", "600036", "601009", "601166",
    "601169", "601229", "601288", "601328", "601398", "601818", "601939",
    "601988", "601998", "002142", "601318", "601601", "601628", "601336",
    "000627", "002736",
    # 证券
    "000166", "000776", "002673", "002736", "002797", "002926", "300059",
    "600030", "600061", "600155", "600369", "600621", "600837", "600958",
    "600999", "601066", "601108", "601162", "601198", "601211", "601236",
    "601375", "601377", "601555", "601688", "601878", "601990",
    # 地产基建
    "000002", "000069", "000402", "000656", "002146", "600048", "600177",
    "600325", "600340", "600376", "600383", "600466", "600606", "600657",
    "600708", "600895", "601155", "601668", "601669", "601800", "601868",
    "601390", "601186", "601618",
    # 白酒食品
    "000568", "000596", "000799", "000858", "002304", "002568", "600519",
    "600559", "600702", "600779", "600809", "603369", "603589", "600887",
    "002557", "002582", "002719", "300146", "600298", "600305", "600872",
    "600882", "603043", "603288", "603317", "603345", "603697", "603711",
    # 医药
    "000423", "000538", "000661", "000739", "000963", "002001", "002007",
    "002252", "002294", "002317", "002390", "002410", "002422", "002424",
    "002603", "002626", "002653", "002675", "002737", "002773", "002821",
    "300003", "300009", "300015", "300026", "300122", "300124", "300347",
    "300357", "300529", "300558", "300595", "300601", "300628", "300630",
    "300677", "300723", "300759", "300760", "600085", "600161", "600196",
    "600276", "600380", "600436", "600521", "600529", "600535", "600566",
    "600763", "600867", "600882", "601089", "603087", "603127", "603160",
    "603183", "603218", "603227", "603230", "603233", "603233", "603259",
    "603288", "603290", "603297", "603298", "603305", "603308", "603313",
    "603317", "603338", "603345", "603355", "603363", "603369", "603379",
    "603392", "603399", "603416", "603439", "603444", "603456", "603501",
    "603505", "603515", "603520", "603556", "603568", "603583", "603589",
    "603596", "603599", "603601", "603605", "603606", "603609", "603610",
    "603613", "603619", "603626", "603628", "603638", "603648", "603650",
    "603658", "603659", "603660", "603661", "603666", "603667", "603668",
    "603669", "603678", "603679", "603680", "603681", "603682", "603683",
    "603685", "603686", "603687", "603688", "603689", "603690", "603696",
    "603698", "603699", "603700", "603701", "603706", "603707", "603708",
    "603709", "603711", "603712", "603713", "603716", "603717", "603718",
    "603719", "603720", "603721", "603722", "603726", "603727", "603728",
    "603729", "603730", "603737", "603738", "603739", "603755", "603756",
    "603757", "603758", "603759", "603766", "603767", "603768", "603773",
    "603776", "603777", "603778", "603786", "603787", "603788", "603789",
    "603790", "603797", "603798", "603799", "603800", "603801", "603803",
    "603806", "603808", "603809", "603811", "603813", "603815", "603816",
    "603817", "603818", "603819", "603822", "603823", "603825", "603826",
    "603828", "603829", "603833", "603836", "603838", "603839", "603848",
    "603849", "603850", "603855", "603856", "603858", "603859", "603860",
    "603861", "603863", "603866", "603867", "603868", "603869", "603871",
    "603873", "603876", "603877", "603878", "603879", "603880", "603881",
    "603882", "603883", "603885", "603886", "603887", "603888", "603889",
    "603890", "603893", "603895", "603896", "603897", "603898", "603899",
    "603900", "603901", "603903", "603906", "603908", "603909", "603912",
    "603915", "603916", "603917", "603918", "603919", "603920", "603922",
    "603926", "603927", "603928", "603929", "603931", "603933", "603936",
    "603937", "603938", "603939", "603956", "603957", "603958", "603959",
    "603960", "603963", "603966", "603967", "603968", "603969", "603970",
    "603976", "603977", "603978", "603979", "603980", "603981", "603982",
    "603983", "603985", "603986", "603987", "603988", "603989", "603990",
    "603991", "603992", "603993", "603995", "603996", "603997", "603998",
    # 家电
    "000333", "000651", "002032", "002050", "002242", "002429", "002508",
    "002543", "002614", "002677", "002705", "002860", "600060", "600104",
    "600336", "600507", "600690", "600839", "600854", "601877",
    # 汽车
    "000550", "000559", "000625", "000800", "000868", "000887", "000951",
    "002074", "002085", "002126", "002196", "002239", "002265", "002283",
    "002284", "002355", "002363", "002373", "002387", "002405", "002406",
    "002434", "002448", "002454", "002466", "002472", "002488", "002501",
    "002510", "002531", "002532", "002533", "002534", "002536", "002537",
    "002540", "002541", "002542", "002547", "002549", "002550", "002551",
    "002552", "002553", "002555", "002556", "002557", "002558", "002559",
    "002560", "002561", "002563", "002564", "002565", "002567", "002568",
    "002569", "002570", "002571", "002572", "002573", "002574", "002575",
    "002576", "002577", "002578", "002579", "002580", "002581", "002582",
    "002583", "002584", "002585", "002586", "002587", "002588", "002589",
    "002590", "002591", "002592", "002593", "002594", "002595", "002596",
    "002597", "002598", "002599", "002600", "002601", "002602", "002603",
    "002604", "002605",
    # 新能源光伏
    "002459", "002460", "002466", "002709", "002756", "002759", "002812",
    "002850", "300014", "300068", "300073", "300124", "300207", "300274",
    "300316", "300432", "300450", "300457", "300476", "300496", "300502",
    "300567", "300618", "300628", "300648", "300724", "300738", "300750",
    "300751", "300763", "300769", "300772", "300775", "300776", "300777",
    "300778", "300779", "300780", "300781", "300782", "300783", "300784",
    "600438", "600732", "601012", "601615", "601865", "603185", "603212",
    "603392", "603396", "603506", "603659", "603688", "603806", "688005",
    "688006", "688007", "688008", "688009", "688012", "688015", "688016",
    "688017", "688018", "688019", "688020", "688021", "688022", "688025",
    "688026", "688028", "688029", "688030", "688033", "688036", "688037",
    "688039", "688050", "688051", "688052", "688055", "688056", "688063",
    "688065", "688066", "688068", "688070", "688071", "688072", "688073",
    "688075", "688076", "688077", "688078", "688079", "688080", "688081",
    "688082", "688083", "688085", "688086", "688087", "688088", "688089",
    "688090", "688091", "688092", "688093", "688095", "688096", "688097",
    "688098", "688099", "688100", "688101", "688102", "688103", "688105",
    "688106", "688107", "688108", "688109", "688110", "688111", "688112",
    "688113", "688114", "688115", "688116", "688117", "688118", "688119",
    "688120", "688121", "688122", "688123", "688125", "688126", "688127",
    "688128", "688129", "688131", "688133", "688135", "688136", "688137",
    "688138", "688139", "688141", "688143", "688146", "688147", "688148",
    "688149", "688150", "688151", "688152", "688153", "688155", "688156",
    "688157", "688158", "688159", "688160", "688161", "688162", "688163",
    "688165", "688166", "688167", "688168", "688169", "688170", "688171",
    "688172", "688173", "688175", "688176", "688177", "688178", "688179",
    "688180", "688181", "688182", "688183", "688184", "688185", "688186",
    "688187", "688188", "688189", "688190", "688191", "688192", "688193",
    "688195", "688196", "688197", "688198", "688199", "688200", "688201",
    "688202", "688203", "688204", "688205", "688206", "688207", "688208",
    "688209", "688210", "688211", "688212", "688213", "688215", "688216",
    "688217", "688218", "688219", "688220", "688221", "688222", "688223",
    "688225", "688226", "688227", "688228", "688229", "688230", "688231",
    "688232", "688233", "688234", "688235", "688236", "688237", "688238",
    "688239", "688240", "688244", "688246", "688247", "688248", "688249",
    "688250", "688251", "688252", "688253",
    # 半导体电子
    "000725", "002049", "002056", "002129", "002151", "002156", "002185",
    "002222", "002241", "002273", "002281", "002288", "002340", "002353",
    "002356", "002371", "002384", "002389", "002414", "002436", "002449",
    "002463", "002475", "002484", "002489", "002506", "002517", "002519",
    "002520", "002521", "002522", "002523", "002524", "002528", "002529",
    "002530", "002531", "002532", "002533", "002534", "002535", "002536",
    "002537", "002538",
    # 通信计算机
    "000063", "000066", "000158", "000503", "000555", "000561", "000566",
    "000576", "000581", "000582", "000589", "000590", "000591", "000592",
    "000593", "000595", "000596", "000597", "000598", "000599", "000600",
    "000601", "000602", "000603",
    # 资源能源
    "000629", "000630", "000651", "000655", "000657", "000658", "000659",
    "000661", "000662", "000663", "000666", "000667", "000668", "000669",
    "000670", "000671", "000672", "000676", "000677", "000678", "000679",
    "000680", "000681", "000682", "000683", "000685", "000686", "000687",
    "000688", "000689", "000690", "000691", "000692", "000693",
    # 钢铁有色
    "000708", "000709", "000717", "000723", "000725", "000728", "000729",
    "000731", "000733", "000735", "000737", "000738", "000739", "000750",
    "000751", "000752", "000753", "000755", "000756", "000757", "000758",
    "000759", "000760", "000761", "000762", "000763", "000766", "000767",
    "000768", "000769", "000776", "000777", "000778", "000779", "000780",
    "000782", "000783", "000785", "000786", "000788", "000789", "000790",
    "000791", "000792", "000793", "000795", "000796", "000797", "000798",
    "000799", "000800", "000801", "000802", "000803", "000806", "000807",
    "000809", "000810", "000811", "000812", "000813", "000815", "000816",
    "000819", "000820", "000821", "000822", "000823", "000825", "000826",
    "000828", "000829", "000830", "000831", "000836", "000837", "000838",
    "000839", "000858", "000859", "000860", "000861", "000862", "000863",
    "000868", "000875", "000876", "000877", "000878", "000880", "000881",
    "000882", "000883", "000885", "000886", "000887", "000888", "000889",
    "000890", "000892", "000893", "000895", "000897", "000898", "000899",
    "000900", "000901", "000902", "000903", "000905", "000906", "000908",
    "000909", "000910", "000911", "000912", "000913", "000915", "000917",
    "000918", "000919", "000920", "000921", "000922", "000923", "000924",
    "000925", "000926", "000927", "000928", "000929", "000930", "000931",
    "000932", "000933", "000935", "000936", "000937", "000938", "000939",
    "000948", "000949", "000950", "000951", "000952", "000953", "000955",
    "000957", "000958", "000959", "000960", "000961", "000962", "000963",
    "000966", "000967", "000968", "000969", "000970", "000971", "000972",
    "000973", "000975", "000976", "000977", "000978", "000979", "000980",
    "000983", "000985", "000987", "000988", "000989", "000990", "000993",
    "000996", "000997", "000998", "000999",
    # 军工
    "000547", "000561", "000576", "000581", "000582", "000589", "000590",
    "000591", "000592", "000597", "000599", "000600", "000601", "000603",
    "600118", "600150", "600184", "600185", "600316", "600372", "600391",
    "600399", "600456", "600482", "600685", "600705", "600760", "600862",
    "600879", "600893", "600967", "600990", "601106", "601989",
    # 化工
    "000301", "000408", "000420", "000422", "000523", "000525", "000528",
    "000530", "000531", "000532", "000533", "000534", "000535", "000536",
    "000537", "000538", "000539", "000540", "000541", "000543", "000544",
    "000545", "000546", "000547", "000548", "000550", "000551", "000552",
    "000553", "000554", "000555", "000556", "000557", "000558", "000559",
    "000560", "000561", "000562", "000563", "000564", "000565", "000566",
    "000567", "000568", "000570", "000571", "000572", "000573", "000576",
    "000581", "000582", "000583", "000584", "000585", "000586", "000587",
    "000589", "000590", "000591", "000592", "000593", "000595", "000596",
    "000597", "000598", "000599", "600141", "600160", "600176", "600309",
    "600315", "600352", "600389", "600409", "600426", "600486", "600596",
    "600623", "600688", "600699", "600727", "600731", "600740", "600746",
    "600810", "600844", "600882", "600884", "600886", "600887", "600888",
    "600889", "600900", "600901", "600903", "600905", "600908", "600908",
    "600909", "600917", "600918", "600919", "600926", "600926", "600929",
    "600933", "600936", "600939", "600941", "600956", "600958", "600959",
    "600963", "600966", "600967", "600968", "600969", "600970", "600971",
    "600973", "600975", "600976", "600977", "600979", "600982", "600983",
    "600984", "600985", "600986", "600987", "600988", "600989", "600990",
    "600991", "600992", "600993", "600995", "600996", "600997", "600999",
    # 电力公用
    "000027", "000040", "000155", "000301", "000400", "000401", "000402",
    "000403", "000404", "000405", "000406", "000407", "000408", "000409",
    "000410", "000411", "000412", "000413", "000415", "000416", "000417",
    "000418", "000419", "000420", "000421", "000422", "000423", "000425",
    "000426", "000428", "000429", "000430", "000488", "000498", "000501",
    "000502", "000503", "000504", "000505", "000506", "000507", "000509",
    "000510", "000511", "000512", "000513", "000514", "000516", "000517",
    "000518", "000519", "000520", "000521", "000522", "000523", "000524",
    "000525", "000526", "000527", "000528", "000529", "600011", "600021",
    "600023", "600025", "600027", "600098", "600101", "600116", "600131",
    "600149", "600157", "600163", "600167", "600168", "600169", "600170",
    "600171", "600172", "600173", "600176", "600177", "600178", "600179",
    "600180", "600183", "600184", "600185", "600186", "600187", "600188",
    "600189", "600190", "600191", "600192", "600193", "600195", "600196",
    "600197", "600199", "600200", "600201", "600202", "600203", "600206",
    "600207", "600208", "600209", "600210", "600211", "600212", "600213",
    "600215", "600216", "600217", "600218", "600219", "600220", "600221",
    "600222", "600223", "600225", "600226", "600227", "600228", "600229",
    "600230", "600231", "600232", "600233", "600234", "600235", "600236",
    "600237", "600238", "600239", "600240", "600241", "600242", "600243",
    "600244", "600246", "600247", "600248", "600249", "600250", "600251",
    "600252", "600253", "600255", "600256", "600257", "600258", "600259",
    "600260", "600261", "600262", "600263", "600265", "600266", "600267",
    "600268", "600269", "600270", "600271", "600272", "600273", "600276",
    "600277", "600278", "600279", "600280", "600281", "600282", "600283",
    "600284", "600285", "600286", "600287", "600288", "600289", "600290",
    "600291", "600292", "600293", "600295", "600297", "600298", "600299",
    "600300", "600301", "600302", "600303", "600305", "600306", "600307",
    "600308", "600309", "600310", "600311", "600312", "600313", "600315",
    "600316", "600317", "600318", "600319", "600320", "600321", "600322",
    "600323", "600325", "600326", "600327", "600328", "600329", "600330",
    "600331", "600332", "600333", "600335", "600336", "600337", "600338",
    "600339", "600340", "600343", "600345", "600346", "600348", "600350",
    "600351", "600352", "600353", "600354", "600355", "600356", "600358",
    "600359", "600360", "600361", "600362", "600363", "600365", "600366",
    "600367", "600368", "600369", "600370", "600371", "600372", "600373",
    "600374", "600375", "600376", "600377", "600378", "600379", "600380",
    "600381", "600382", "600383", "600385", "600386", "600387", "600388",
    "600389", "600390", "600391", "600392", "600393", "600395", "600396",
    "600397", "600398", "600399", "600400", "600403", "600405", "600406",
    "600408", "600409", "600410", "600415", "600416", "600418", "600419",
    "600420", "600421", "600422", "600423", "600425", "600426", "600428",
    "600429", "600435", "600436", "600438", "600439", "600444", "600446",
    "600448", "600449", "600452", "600455", "600456", "600458", "600459",
    "600460", "600461", "600462", "600463", "600466", "600467", "600468",
    "600469", "600470", "600475", "600476", "600477", "600478", "600479",
    "600480", "600481", "600482", "600483", "600486", "600487", "600488",
    "600489", "600490", "600491", "600493", "600495", "600496", "600497",
    "600498", "600499", "600500", "600501", "600502", "600503", "600505",
    "600506", "600507", "600508", "600509", "600510", "600511", "600512",
    "600513", "600515", "600516", "600517", "600518", "600519", "600520",
    "600521", "600522", "600523", "600525", "600526", "600527", "600528",
    "600529", "600530", "600531", "600532", "600533", "600535", "600536",
    "600537", "600538", "600539", "600540", "600543", "600545", "600546",
    "600547", "600548", "600549", "600550", "600551", "600552", "600553",
    "600555", "600556", "600557", "600558", "600559", "600560", "600561",
    "600562", "600563", "600565", "600566", "600567", "600568", "600569",
    "600570", "600571", "600572", "600573", "600575", "600576", "600577",
    "600578", "600579", "600580", "600581", "600582", "600583", "600584",
    "600585", "600586", "600587", "600588", "600589", "600590", "600592",
    "600593", "600594", "600595", "600596", "600597", "600598", "600599",
]

# 腾讯指数代码
_TX_INDICES = {
    "上证指数": "sh000001",
    "深证成指": "sz399001",
    "创业板指": "sz399006",
    "科创50": "sh000688",
    "沪深300": "sh000300",
    "中证500": "sh000905",
}


def _tx_indices():
    """腾讯财经 · 大盘指数"""
    codes = list(_TX_INDICES.values())
    url = f"http://qt.gtimg.cn/q={','.join(codes)}"
    try:
        req = urllib.request.Request(url, headers=_TX_HEADERS)
        with urllib.request.urlopen(req, timeout=10) as resp:
            text = resp.read().decode("gbk")
    except Exception:
        return None

    name_to_code = {v: k for k, v in _TX_INDICES.items()}
    rows = []
    for line in text.strip().split(";"):
        line = line.strip()
        if not line or "=" not in line:
            continue
        try:
            eq = line.index("=")
            val = line[eq + 1:].strip().strip('"')
            parts = val.split("~")
        except (ValueError, IndexError):
            continue
        if len(parts) < 35:
            continue
        try:
            tx_code = parts[0].strip() if len(parts) > 0 else ""
            name = name_to_code.get(tx_code, parts[1].strip())
            price = float(parts[3] or 0)
            change_pct = float(parts[32]) if len(parts) > 32 and parts[32] else 0
            change = float(parts[31]) if len(parts) > 31 and parts[31] else 0
            volume = int(parts[6] or 0) if len(parts) > 6 else 0
            amount = float(parts[37]) if len(parts) > 37 and parts[37] else 0
            if 0 < amount < volume * price * 0.001:
                amount *= 10000
            rows.append({
                "name": name,
                "price": price,
                "change_pct": change_pct,
                "change": change,
                "volume": volume,
                "amount": amount,
            })
        except (ValueError, IndexError):
            continue
    if not rows:
        return None
    df = pd.DataFrame(rows)
    for col in ["price", "change_pct", "change", "volume", "amount"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
    return df


# ==================== API 可用性 ====================

def check_api_available():
    try:
        req = urllib.request.Request(
            "https://push2.eastmoney.com/api/qt/ulist.np/get",
            headers={"User-Agent": "Mozilla/5.0"},
        )
        resp = urllib.request.urlopen(req, timeout=3)
        return True
    except Exception:
        pass
    try:
        req = urllib.request.Request("http://qt.gtimg.cn/q=sh000001", headers=_TX_HEADERS)
        urllib.request.urlopen(req, timeout=3)
        return True
    except Exception:
        return False


API_AVAILABLE = check_api_available()
DATA_SOURCE = "东方财富+腾讯财经 实时数据"


# ==================== 统一接口 ====================

class StockAPI:
    """A股数据API — 永远不返回模拟数据"""

    # ---------- 实时行情 ----------

    @staticmethod
    def get_realtime_quote(code):
        """单只股票实时行情 {price, change_pct, pre_close} 或 None.
        东财ulist直连 → 腾讯财经(urllib直连, 不受系统代理影响)."""
        code = str(code).replace(".SH", "").replace(".SZ", "").replace(".BJ", "").zfill(6)
        try:
            secid = ("1" if code.startswith("6") else "0") + "." + code
            df = _em_ulist_quotes([secid])
            if df is not None and not df.empty:
                row = df.iloc[0]
                p = float(row.get("price") or 0)
                if p > 0:
                    return {"price": round(p, 2), "change_pct": float(row.get("change_pct") or 0),
                            "pre_close": float(row.get("pre_close") or 0)}
        except Exception:
            pass
        try:
            df = _tx_fetch([code])
            if df is not None and not df.empty:
                row = df.iloc[0]
                p = float(row.get("price") or 0)
                if p > 0:
                    return {"price": round(p, 2), "change_pct": float(row.get("change_pct") or 0),
                            "pre_close": float(row.get("pre_close") or 0)}
        except Exception:
            pass
        return None

    @staticmethod
    def get_realtime_quotes():
        """返回全市场实时行情 DataFrame.
        优先级: AKShare(东方财富) → 腾讯财经(urllib直连) → None
        """
        # 1) AKShare (仅当无系统代理时尝试; Windows系统代理下 requests 必失败)
        if _HAS_AKSHARE and _EM_REACHABLE:
            try:
                df = ak.stock_zh_a_spot_em()
                df = df.rename(columns={
                    "代码": "code", "名称": "name", "最新价": "price",
                    "涨跌幅": "change_pct", "涨跌额": "change",
                    "成交量": "volume", "成交额": "amount",
                    "振幅": "amplitude", "最高": "high", "最低": "low",
                    "今开": "open", "昨收": "pre_close",
                    "量比": "volume_ratio", "换手率": "turnover",
                    "市盈率-动态": "pe", "市净率": "pb",
                })
                for col in ["price", "change_pct", "volume", "amount", "turnover", "pe", "pb"]:
                    if col in df.columns:
                        df[col] = pd.to_numeric(df[col], errors="coerce")
                return df
            except Exception:
                pass

        # 2) 腾讯财经 (urllib 直连, 不受系统代理影响)
        try:
            # 去重后查询(重复代码在 _TX_FALLBACK_CODES 中自动去重)
            df = _tx_fetch(sorted(set(_TX_FALLBACK_CODES)))
            if df is not None and not df.empty:
                return df
        except Exception:
            pass

        return None

    # ---------- 历史K线 ----------

    @staticmethod
    def get_historical_data(symbol, start_date=None, end_date=None, adjust="qfq", source="auto"):
        """获取个股历史K线.
        source: "auto"(AKShare前复权→新浪不复权→腾讯前复权) | "tencent"(仅腾讯前复权, 数据源恒定) | "sina" | "akshare".
        指数/回测等需要前复权一致性的场景应传 source="tencent", 避免新浪不复权与腾讯前复权混用导致除权日跳变.
        """
        if start_date is None:
            start_date = (datetime.now() - timedelta(days=365)).strftime("%Y%m%d")
        if end_date is None:
            end_date = datetime.now().strftime("%Y%m%d")
        symbol_clean = symbol.replace(".SH", "").replace(".SZ", "").replace(".BJ", "").zfill(6)

        s = start_date if isinstance(start_date, str) else start_date.strftime("%Y%m%d")
        e = end_date if isinstance(end_date, str) else end_date.strftime("%Y%m%d")

        # 0) 本地全市场库读优先(2026-09-01): data/market_bars/{code}.json (BaoStock前复权, 真实成交额)
        #    完整覆盖[s,e]直接返回(零网络); 仅缺尾部(≤7日历日)用网络补尾合并;
        #    覆盖不足回源原网络路径。degraded文件(腾讯/新浪估算)不参与(守诚实宇宙口径).
        if source == "auto" and adjust in ("qfq", None):
            local = StockAPI._read_market_bars_local(symbol_clean, s, e)
            if local is not None and not local.empty:
                return local

        # 0) 指定单源
        if source == "tencent":
            try:
                df = StockAPI._tencent_daily(symbol_clean, s, e)
                if df is not None and not df.empty:
                    return df
            except Exception:
                pass
            return None
        if source == "sina":
            try:
                df = _sina_historical_data(symbol_clean, s, e)
                if df is not None and not df.empty:
                    return df
            except Exception:
                pass
            return None
        if source == "akshare":
            try:
                if _HAS_AKSHARE:
                    df = ak.stock_zh_a_hist(
                        symbol=symbol_clean, period="daily",
                        start_date=s, end_date=e, adjust=adjust,
                    )
                    if df is not None and not df.empty:
                        df = df.rename(columns={
                            "日期": "date", "开盘": "open", "收盘": "close",
                            "最高": "high", "最低": "low", "成交量": "volume",
                            "成交额": "amount", "振幅": "amplitude",
                            "涨跌幅": "change_pct", "涨跌额": "change",
                            "换手率": "turnover",
                        })
                        df["date"] = pd.to_datetime(df["date"])
                        df = df.sort_values("date").reset_index(drop=True)
                        for col in ["open", "close", "high", "low", "volume",
                                    "amount", "change_pct", "turnover"]:
                            if col in df.columns:
                                df[col] = pd.to_numeric(df[col], errors="coerce")
                        return df
                return None
            except Exception:
                return None

        # 1) AKShare(东方财富,支持前复权)
        if _HAS_AKSHARE and _EM_REACHABLE:
            try:
                df = ak.stock_zh_a_hist(
                    symbol=symbol_clean, period="daily",
                    start_date=s, end_date=e, adjust=adjust,
                )
                if df is not None and not df.empty:
                    df = df.rename(columns={
                        "日期": "date", "开盘": "open", "收盘": "close",
                        "最高": "high", "最低": "low", "成交量": "volume",
                        "成交额": "amount", "振幅": "amplitude",
                        "涨跌幅": "change_pct", "涨跌额": "change",
                        "换手率": "turnover",
                    })
                    df["date"] = pd.to_datetime(df["date"])
                    df = df.sort_values("date").reset_index(drop=True)
                    for col in ["open", "close", "high", "low", "volume",
                                "amount", "change_pct", "turnover"]:
                        if col in df.columns:
                            df[col] = pd.to_numeric(df[col], errors="coerce")
                    return df
            except Exception:
                pass

        # 2) 新浪财经(不复权,但数据真实可用)
        try:
            df = _sina_historical_data(symbol_clean, s, e)
            if df is not None and not df.empty:
                return df
        except Exception:
            pass

        # 3) 腾讯财经(前复权日K, urllib直连; 新浪对停牌/数据缺失代码无K线时兜底)
        try:
            df = StockAPI._tencent_daily(symbol_clean, s, e)
            if df is not None and not df.empty:
                return df
        except Exception:
            pass

        return None

    @staticmethod
    def _read_market_bars_local(symbol, s, e):
        """本地全市场库读优先(2026-09-01): data/market_bars/{code}.json (BaoStock前复权).
        返回 DataFrame(列=date/open/close/high/low/volume/amount/amplitude/change_pct/change/turnover) 或 None.
        完整覆盖[s,e]→本地; 缺尾部且缺口≤7日历日→本地+akshare网络补尾; 其余→None回源网络.
        degraded(腾讯/新浪估算成交额)不参与, 守诚实宇宙口径."""
        try:
            p = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                             "data", "market_bars", f"{symbol}.json")
            if not os.path.exists(p):
                return None
            with open(p, encoding="utf-8") as f:
                d = json.load(f)
            if d.get("degraded") or not d.get("columns"):
                return None
            cols = d["columns"]
            dates = cols.get("date") or []
            if not dates:
                return None
            ld = dates[-1]  # 本地库最新日期 YYYYMMDD

            def _slice(c0, c1):
                i0 = bisect_left(dates, c0) if c0 else 0
                i1 = bisect_right(dates, c1) if c1 else len(dates)
                if i1 <= i0:
                    return None
                df = pd.DataFrame({k: v[i0:i1] for k, v in cols.items()})
                df["date"] = pd.to_datetime(df["date"])
                df = df.sort_values("date").reset_index(drop=True)
                for col in ("open", "close", "high", "low", "volume",
                            "amount", "change_pct", "turnover"):
                    if col in df.columns:
                        df[col] = pd.to_numeric(df[col], errors="coerce")
                return df

            if (dates[0] <= (s or dates[0])) and (ld >= (e or ld)):
                return _slice(s, e)
            # 缺尾部: 本地止于ld, 请求到e, 缺口≤7日历日 → 本地段 + akshare补尾(不回本地, 防递归)
            if e and ld < e and dates[0] <= (s or dates[0]) \
               and (datetime.strptime(e, "%Y%m%d") - datetime.strptime(ld, "%Y%m%d")).days <= 7:
                local_df = _slice(s, ld)
                if local_df is None:
                    return None
                tail_start = (datetime.strptime(ld, "%Y%m%d") + timedelta(days=1)).strftime("%Y%m%d")
                tail = None
                # 补尾主源=腾讯urllib直连(前复权, 不受东财封锁); 兜底=akshare(东财恢复时)
                for src in ("tencent", "akshare"):
                    try:
                        if src == "tencent":
                            t = StockAPI._tencent_daily(symbol, tail_start, e)
                        else:
                            if not _HAS_AKSHARE:
                                continue
                            t = ak.stock_zh_a_hist(symbol=symbol, period="daily",
                                                   start_date=tail_start, end_date=e, adjust="qfq")
                            if t is not None and not t.empty:
                                t = t.rename(columns={"日期": "date", "开盘": "open", "收盘": "close",
                                                      "最高": "high", "最低": "low", "成交量": "volume",
                                                      "成交额": "amount", "振幅": "amplitude",
                                                      "涨跌幅": "change_pct", "涨跌额": "change",
                                                      "换手率": "turnover"})
                        if t is not None and not t.empty:
                            t = t.sort_values("date").reset_index(drop=True)
                            if "date" in t.columns:
                                t["date"] = pd.to_datetime(t["date"])
                            tail = t
                            break
                    except Exception:
                        tail = None
                if tail is not None and not tail.empty:
                    return pd.concat([local_df, tail], ignore_index=True).drop_duplicates("date")
            return None
        except Exception:
            return None

    @staticmethod
    def get_intraday_sell_grid(symbol, date_str):
        """某交易日基准卖点 10:30 的盘中价 + 当日最后一根5分钟bar价.
        优先新浪5分钟K线(不复权), 新浪限流(HTTP 456)/失败时回退东方财富5分钟K线.
        已收盘日 close=15:00价; 当日盘中 close=最新价(T+1当天盘中也可回填10:30卖点).
        分钟数据约保留2个月, 更早或取不到返回 None. 返回 {"prices": {"10:30": 价}, "close": 价}.
        带 TTL 缓存: 当日 120s, 历史日 3600s."""
        symbol_clean0 = str(symbol).replace(".SH", "").replace(".SZ", "").replace(".BJ", "").zfill(6)
        key = ("intraday_grid", symbol_clean0, str(date_str))

        def _do():
            symbol_clean = symbol_clean0
            prefix = f"{date_str[:4]}-{date_str[4:6]}-{date_str[6:]}"
            # 1) 新浪5分钟K线(不复权)
            try:
                scode = _sina_code(symbol_clean)
                url = ("http://money.finance.sina.com.cn/quotes_service/api/json_v2.php/"
                       f"CN_MarketData.getKLineData?symbol={scode}&scale=5&ma=no&datalen=3000")
                req = urllib.request.Request(url, headers=_SINA_KLINE_HEADERS)
                with urllib.request.urlopen(req, timeout=15) as resp:
                    data = json.loads(resp.read().decode("gbk"))
                if data and isinstance(data, list):
                    day_bars = [b for b in data if str(b.get("day", "")).startswith(prefix)]
                    if day_bars:
                        day_bars.sort(key=lambda b: b["day"])
                        p1030 = None
                        for b in day_bars:
                            if str(b["day"])[11:16] == "10:30":
                                p1030 = float(b["close"])
                        close = float(day_bars[-1]["close"])  # 最后一根5分钟bar: 已收盘=15:00价, 盘中=最新价
                        if p1030 is not None and close > 0:
                            return {"prices": {"10:30": p1030}, "close": close}
            except Exception:
                pass
            # 2) 东方财富5分钟K线(akshare), 新浪456限流/失败时兜底
            try:
                if _HAS_AKSHARE:
                    df = ak.stock_zh_a_hist_min_em(
                        symbol=symbol_clean, period="5",
                        start_date=f"{prefix} 09:00:00", end_date=f"{prefix} 15:30:00", adjust="",
                    )
                    if df is not None and not df.empty:
                        day_bars = df[df["时间"].astype(str).str.startswith(prefix)]
                        if not day_bars.empty:
                            p1030 = None
                            for t, c in zip(day_bars["时间"].astype(str), day_bars["收盘"]):
                                if t[11:16] == "10:30":
                                    p1030 = float(c)
                            close = float(day_bars["收盘"].iloc[-1])
                            if p1030 is not None and close > 0:
                                return {"prices": {"10:30": p1030}, "close": close}
            except Exception:
                pass
            return None

        ttl = 120 if date_str == time.strftime("%Y%m%d") else 3600
        return _cached(key, ttl, _do)

    @staticmethod
    def get_intraday_price(symbol, date_str, time_str="10:30"):
        """取某交易日某时刻的盘中价(不复权) + 当日15:00收盘, 委托 get_intraday_sell_grid.
        返回 {"at": 时刻价, "close": 当日收盘} 或 None."""
        grid = StockAPI.get_intraday_sell_grid(symbol, date_str)
        if not grid:
            return None
        p = grid["prices"].get(time_str)
        if p is None:
            return None
        return {"at": p, "close": grid["close"]}

    # ---------- 大盘指数 ----------

    @staticmethod
    def get_major_indices():
        """大盘指数: AKShare → 腾讯财经 → None (30s TTL 缓存)"""
        key = ("major_indices",)

        def _do():
            if _HAS_AKSHARE and _EM_REACHABLE:
                try:
                    df = ak.stock_zh_index_spot_em()
                    df = df.rename(columns={
                        "名称": "name", "最新价": "price", "涨跌幅": "change_pct",
                        "涨跌额": "change", "成交量": "volume", "成交额": "amount",
                    })
                    major = ["上证指数", "深证成指", "创业板指", "科创50", "沪深300", "中证500"]
                    df = df[df["name"].isin(major)]
                    return df[["name", "price", "change_pct", "change", "volume", "amount"]].reset_index(drop=True)
                except Exception:
                    pass

            try:
                return _tx_indices()
            except Exception:
                pass
            return None

        return _cached(key, 30, _do)

    # ---------- 板块行情 ----------

    @staticmethod
    def get_sector_summary():
        """板块行情(仅东方财富, 无替代源)"""
        if _HAS_AKSHARE and _EM_REACHABLE:
            try:
                df = ak.stock_board_industry_name_em()
                df = df.rename(columns={
                    "板块名称": "sector", "最新价": "price", "涨跌幅": "change_pct",
                    "涨跌额": "change", "总成交额": "amount",
                    "上涨家数": "up_count", "下跌家数": "down_count",
                })
                df["total_count"] = df.get("up_count", 0) + df.get("down_count", 0)
                df = df.sort_values("change_pct", ascending=False).reset_index(drop=True)
                return df[["sector", "change_pct", "up_count", "down_count", "total_count", "amount"]]
            except Exception:
                pass
        return None

    # ---------- 个股资料 ----------

    @staticmethod
    def get_stock_info(symbol):
        """个股资料: AKShare → 东方财富 ulist(urllib) → 腾讯财经(urllib) → None"""
        symbol = symbol.replace(".SH", "").replace(".SZ", "").replace(".BJ", "").zfill(6)
        if _HAS_AKSHARE and _EM_REACHABLE:
            try:
                info = ak.stock_individual_info_em(symbol=symbol)
                result = {}
                for _, row in info.iterrows():
                    result[row.iloc[0]] = row.iloc[1]
                return result
            except Exception:
                pass

        # 通过 ulist.np/get 查个股实时行情
        try:
            secid_prefix = "1" if symbol.startswith("6") else "0"
            df = _em_ulist_quotes([f"{secid_prefix}.{symbol}"])
            if df is not None and not df.empty:
                row = df.iloc[0]
                return {
                    "股票代码": symbol,
                    "名称": row.get("name", ""),
                    "最新价": row.get("price"),
                    "涨跌幅": row.get("change_pct"),
                }
        except Exception:
            pass

        # 腾讯财经兜底
        try:
            tx_code = _tx_code(symbol)
            url = f"http://qt.gtimg.cn/q={tx_code}"
            req = urllib.request.Request(url, headers=_TX_HEADERS)
            with urllib.request.urlopen(req, timeout=10) as resp:
                text = resp.read().decode("gbk")
            for line in text.strip().split(";"):
                if "=" not in line:
                    continue
                eq = line.index("=")
                val = line[eq + 1:].strip().strip('"')
                parts = val.split("~")
                if len(parts) >= 40:
                    return {
                        "股票代码": symbol,
                        "名称": parts[1].strip(),
                        "最新价": float(parts[3]) if parts[3] else 0,
                        "涨跌幅": float(parts[32]) if len(parts) > 32 and parts[32] else 0,
                        "昨收": float(parts[4]) if parts[4] else 0,
                        "今开": float(parts[5]) if parts[5] else 0,
                        "最高": float(parts[33]) if len(parts) > 33 and parts[33] else 0,
                        "最低": float(parts[34]) if len(parts) > 34 and parts[34] else 0,
                        "成交量": int(parts[6] or 0) * 100,
                        "成交额": float(parts[37]) if len(parts) > 37 and parts[37] else 0,
                        "换手率": float(parts[38]) if len(parts) > 38 and parts[38] else 0,
                        "市盈率": float(parts[39]) if len(parts) > 39 and parts[39] else 0,
                    }
        except Exception:
            pass
        return None

    # ---------- 搜索 ----------

    @staticmethod
    def search_stocks(keyword):
        try:
            df = StockAPI.get_realtime_quotes()
            if df is None or df.empty:
                return pd.DataFrame()
            result = df[
                df["code"].str.contains(keyword, na=False)
                | df["name"].str.contains(keyword, na=False)
            ]
            cols = [c for c in ["code", "name", "price", "change_pct", "volume", "amount", "pe", "turnover"]
                    if c in result.columns]
            return result[cols].head(20)
        except Exception:
            return pd.DataFrame()

    # ---------- 批量历史数据 ----------

    @staticmethod
    def get_hist_data_batch(codes, start_date, end_date, max_workers=5):
        results = {}
        def fetch_one(code):
            try:
                df = StockAPI.get_historical_data(code, start_date, end_date)
                return (code, df) if df is not None and not df.empty else (code, None)
            except Exception:
                return (code, None)
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(fetch_one, code): code for code in codes}
            for future in as_completed(futures):
                try:
                    c, data = future.result()
                    if data is not None:
                        results[c] = data
                except Exception:
                    pass
        return results

    @staticmethod
    def get_data_source():
        return DATA_SOURCE

    @staticmethod
    def get_total_shares(codes):
        """取总股本(腾讯字段73, 单位股). 返回 {code: shares}. 腾讯行情稳定, 供指数做总股本权重."""
        codes = [str(c).replace(".SH", "").replace(".SZ", "").replace(".BJ", "").zfill(6)
                 for c in codes]
        codes = list(dict.fromkeys(codes))
        if not codes:
            return {}
        try:
            df = _tx_fetch(codes)
        except Exception:
            df = None
        if df is None or df.empty:
            return {}
        out = {}
        for _, row in df.iterrows():
            code = str(row.get("code", "")).zfill(6)
            try:
                ts = float(row.get("total_shares") or 0)
            except (TypeError, ValueError):
                ts = 0.0
            if ts > 0:
                out[code] = ts
        return out

    @staticmethod
    def get_market_caps(codes):
        """批量取总市值/流通市值(东财 ulist 直连, f20=总市值, f21=流通市值, 单位元).
        返回 {code: {"total_mv":..., "float_mv":..., "price":...}}; 重试3轮仍未取到的 code 不出现在结果里.
        该接口偶发丢行, 故对缺失 code 自动重试补齐."""
        codes = [str(c).replace(".SH", "").replace(".SZ", "").replace(".BJ", "").zfill(6)
                 for c in codes]
        codes = list(dict.fromkeys(codes))  # 去重保序
        if not codes:
            return {}
        out = {}
        pending = list(codes)
        for _attempt in range(3):
            if not pending:
                break
            if _attempt > 0:
                time.sleep(0.6)  # ulist 偶发整批失败, 间隔重试可绕开瞬时抖动
            secids = [("1." if c.startswith("6") else "0.") + c for c in pending]
            got = set()
            for chunk in (secids[i:i + 20] for i in range(0, len(secids), 20)):
                try:
                    df = _em_ulist_quotes(chunk)
                except Exception:
                    df = None
                if df is None or df.empty:
                    continue
                for _, row in df.iterrows():
                    code = str(row.get("code", "")).zfill(6)
                    got.add(code)
                    try:
                        tm = float(row.get("total_mv") or 0)
                    except (TypeError, ValueError):
                        tm = 0.0
                    try:
                        fm = float(row.get("float_mv") or 0)
                    except (TypeError, ValueError):
                        fm = 0.0
                    try:
                        price = float(row.get("price") or 0)
                    except (TypeError, ValueError):
                        price = 0.0
                    out[code] = {
                        "total_mv": tm if tm > 0 else None,
                        "float_mv": fm if fm > 0 else None,
                        "price": price if price > 0 else None,
                    }
            pending = [c for c in pending if c not in got]
        # 腾讯股本兜底: 东财反复失败时 总市值=现价×总股本([73]), 流通市值=现价×流通股本([72])
        if pending:
            try:
                tdf = _tx_fetch(pending)
                if tdf is not None and not tdf.empty:
                    for _, row in tdf.iterrows():
                        code = str(row.get("code", "")).zfill(6)
                        if code not in pending:
                            continue
                        try:
                            price = float(row.get("price") or 0)
                            ts = float(row.get("total_shares") or 0)
                            fs = float(row.get("float_shares") or 0)
                        except (TypeError, ValueError):
                            continue
                        if price > 0:
                            out[code] = {
                                "total_mv": round(price * ts, 2) if ts > 0 else None,
                                "float_mv": round(price * fs, 2) if fs > 0 else None,
                                "price": price,
                            }
            except Exception:
                pass
        return out

    # ---------- 行业板块 / 指数历史 ----------

    @staticmethod
    def get_industry_sectors():
        """获取行业板块列表及当日强度(新浪行业接口).
        返回 DataFrame[code,name,count,avg_change_pct,lead_code,lead_price,lead_change_pct,lead_name].
        字段含义: 平均价[3], 平均涨跌额[4], 平均涨跌幅[5], 领涨股代码[8], 领涨股现价[9], 领涨股涨幅[10], 领涨股名[12].
        """
        try:
            url = "http://vip.stock.finance.sina.com.cn/q/view/newSinaHy.php"
            req = urllib.request.Request(url, headers=_SINA_KLINE_HEADERS)
            txt = urllib.request.urlopen(req, timeout=10).read().decode("gbk", "replace")
            m = re.search(r"=\s*(\{.*\})\s*$", txt, re.S)
            if not m:
                return None
            data = json.loads(m.group(1))
        except Exception:
            return None
        rows = []
        for v in data.values():
            p = v.split(",")
            if len(p) < 13:
                continue
            def _num(x):
                try:
                    return float(x)
                except Exception:
                    return 0.0
            rows.append({
                "code": p[0].strip(),
                "name": p[1].strip(),
                "count": int(_num(p[2])),
                "avg_change_pct": round(_num(p[5]), 2),
                "lead_code": p[8].strip(),
                "lead_price": _num(p[9]),
                "lead_change_pct": round(_num(p[10]), 2),
                "lead_name": p[12].strip(),
            })
        if not rows:
            return None
        return pd.DataFrame(rows)

    @staticmethod
    def get_industry_stocks(sector_key):
        """获取某行业板块的成分股(新浪). 返回 DataFrame[code,name,price,change_pct,turnover,amount]."""
        try:
            url = ("https://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/"
                   f"Market_Center.getHQNodeData?page=1&num=300&sort=amount&asc=0&node={sector_key}")
            req = urllib.request.Request(url, headers=_SINA_KLINE_HEADERS)
            txt = urllib.request.urlopen(req, timeout=10).read().decode("utf-8", "replace")
            data = json.loads(txt)
        except Exception:
            return None
        if not data or not isinstance(data, list):
            return None
        rows = []
        for item in data:
            try:
                code = str(item.get("code", "")).replace("sh", "").replace("sz", "").strip()
                name = str(item.get("name", "")).strip()
                price = float(item.get("trade", 0) or 0)
                if not code or not name:
                    continue
                rows.append({
                    "code": code,
                    "name": name,
                    "price": round(price, 2),
                    "change_pct": round(float(item.get("changepercent", 0) or 0), 2),
                    "turnover": float(item.get("turnoverratio", 0) or 0),
                    "amount": float(item.get("amount", 0) or 0),
                })
            except (ValueError, TypeError):
                continue
        if not rows:
            return None
        return pd.DataFrame(rows)

    @staticmethod
    @staticmethod
    def _tencent_daily(symbol, start_date, end_date):
        """腾讯个股日K(前复权, urllib直连, 绕过系统代理). 返回 DataFrame[date,open,close,high,low,volume,change_pct] 或 None.
        新浪对个别停牌/数据缺失代码无K线时兜底; 行序 [日期, 开盘, 收盘, 最高, 最低, 成交量].
        600s TTL 缓存: 同区间重复请求(推荐记录T+1补算等)直接命中, 不再重复拉网."""
        key = ("tencent_daily", str(symbol), str(start_date), str(end_date))

        def _do():
            def _fmt(d):
                if isinstance(d, datetime):
                    return d.strftime("%Y-%m-%d")
                st = str(d).strip()
                if len(st) == 8 and st.isdigit():
                    return f"{st[:4]}-{st[4:6]}-{st[6:]}"
                return st
            try:
                scode = _sina_code(str(symbol).replace(".SH", "").replace(".SZ", "").replace(".BJ", "").zfill(6))
                url = (f"https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?"
                       f"param={scode},day,{_fmt(start_date)},{_fmt(end_date)},400,qfq")
                req = urllib.request.Request(url, headers=_TX_HEADERS)
                data = json.loads(urllib.request.urlopen(req, timeout=10).read().decode("utf-8"))
                node = (data.get("data") or {}).get(scode) or {}
                klines = node.get("qfqday") or node.get("day") or []
            except Exception:
                return None
            if not klines:
                return None
            rows = []
            for row in klines:
                try:
                    d = pd.to_datetime(row[0])
                    if d < pd.to_datetime(start_date) or d > pd.to_datetime(end_date):
                        continue
                    rows.append({
                        "date": d,
                        "open": float(row[1]),
                        "close": float(row[2]),
                        "high": float(row[3]),
                        "low": float(row[4]),
                        "volume": float(row[5]) if len(row) > 5 else 0,
                    })
                except (ValueError, TypeError, IndexError):
                    continue
            if not rows:
                return None
            df = pd.DataFrame(rows).sort_values("date").reset_index(drop=True)
            df["change_pct"] = df["close"].pct_change().fillna(0) * 100
            df["amount"] = df["volume"] * df["close"]
            return df

        return _cached(key, 600, _do)

    def get_index_historical_data(index="sh000001", days=120):
        """获取大盘指数历史K线(腾讯). 返回 DataFrame[date,open,close,high,low,volume].
        注意: 腾讯K线行序为 [日期, 开盘, 收盘, 最高, 最低, 成交量].
        """
        try:
            url = (f"https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?"
                   f"param={index},day,,,{int(days)},qfq")
            req = urllib.request.Request(url, headers=_TX_HEADERS)
            data = json.loads(urllib.request.urlopen(req, timeout=10).read().decode("utf-8"))
            node = (data.get("data") or {}).get(index) or {}
            klines = node.get("day") or node.get("qfqday") or []
        except Exception:
            return None
        if not klines:
            return None
        rows = []
        for row in klines:
            try:
                rows.append({
                    "date": pd.to_datetime(row[0]),
                    "open": float(row[1]),
                    "close": float(row[2]),
                    "high": float(row[3]),
                    "low": float(row[4]),
                    "volume": float(row[5]) if len(row) > 5 else 0,
                })
            except (ValueError, TypeError, IndexError):
                continue
        if not rows:
            return None
        df = pd.DataFrame(rows).sort_values("date").reset_index(drop=True)
        df["change_pct"] = df["close"].pct_change().fillna(0) * 100
        return df
