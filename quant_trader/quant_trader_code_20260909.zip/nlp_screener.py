"""
自然语言选股器
将自然语言查询转化为股票筛选条件，从全市场筛选符合条件的股票
"""
import re
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from stock_api import StockAPI


class Condition:
    """筛选条件基类"""
    def __init__(self, field, operator, value):
        self.field = field
        self.operator = operator  # gt, lt, eq, between, contains
        self.value = value

    def apply(self, df):
        raise NotImplementedError


class NumericCondition(Condition):
    """数值条件"""
    def apply(self, df):
        if self.field not in df.columns:
            return df
        if self.operator == "gt":
            return df[df[self.field] > self.value]
        elif self.operator == "gte":
            return df[df[self.field] >= self.value]
        elif self.operator == "lt":
            return df[df[self.field] < self.value]
        elif self.operator == "lte":
            return df[df[self.field] <= self.value]
        elif self.operator == "eq":
            return df[abs(df[self.field] - self.value) < 0.01]
        elif self.operator == "between":
            return df[(df[self.field] >= self.value[0]) &
                      (df[self.field] <= self.value[1])]
        return df


class TextCondition(Condition):
    """文本条件"""
    def apply(self, df):
        if self.field not in df.columns:
            return df
        if self.operator == "contains":
            return df[df[self.field].str.contains(self.value, na=False)]
        elif self.operator == "startswith":
            return df[df[self.field].str.startswith(self.value, na=False)]
        return df


class NLPScreener:
    """
    自然语言选股器
    支持的中文查询模式:
    - 涨幅大于/超过/高于 X%
    - 跌幅大于/超过/高于 X%
    - 成交量/成交额大于/超过 X亿
    - 市盈率低于/小于 X
    - 市净率低于/小于 X
    - 股价大于/低于 X元
    - 换手率大于 X%
    - 连续X天上涨/下跌
    - 行业/板块 属于 XXX
    - 最新价/涨幅/成交量 在 X 到 Y 之间
    - 涨停 / 跌停
    - 组合条件（支持空格/逗号/分号分隔）
    """

    def __init__(self):
        self.conditions = []

    def parse(self, query):
        """
        解析自然语言查询，返回条件列表
        """
        if not query or not query.strip():
            return []

        # 清理
        query = query.strip()

        # 分割多条件（支持中文逗号、分号、空格）
        parts = re.split(r'[，,、；;。\n]+', query)
        # 也支持空格分隔（但需要避免把 "大于 5%" 这种拆开）
        expanded_parts = []
        for part in parts:
            part = part.strip()
            if not part:
                continue
            # 如果包含"并且"、"而且"、"同时"等，再切分
            sub_parts = re.split(r'(?:并且|而且|同时|且)', part)
            expanded_parts.extend([sp.strip() for sp in sub_parts if sp.strip()])

        if not expanded_parts:
            expanded_parts = [q.strip() for q in parts if q.strip()]

        conditions = []
        for part in expanded_parts:
            cond = self._parse_single(part)
            if cond:
                conditions.append(cond)

        self.conditions = conditions
        return conditions

    def _parse_single(self, text):
        """解析单个条件"""
        # 1. 涨幅大于 X%
        m = re.search(r'(?:涨幅?|涨跌幅|涨|上涨|升)(?:超过|大于|高于|>=|>|不低于|≥)?\s*(\d+(?:\.\d+)?)\s*%?', text)
        if m:
            return NumericCondition("change_pct", "gt", float(m.group(1)))

        # 2. 涨幅在 X 到 Y 之间
        m = re.search(r'(?:涨幅?|涨跌幅)\s*(?:在|介于)\s*(\d+(?:\.\d+)?)\s*(?:[~\-至到])\s*(\d+(?:\.\d+)?)\s*%?', text)
        if m:
            return NumericCondition("change_pct", "between",
                                    (float(m.group(1)), float(m.group(2))))

        # 3. 跌幅大于 X%
        m = re.search(r'(?:跌幅?|跌|下跌|降)(?:超过|大于|高于|>=|>)?\s*(\d+(?:\.\d+)?)\s*%?', text)
        if m:
            return NumericCondition("change_pct", "lt", -float(m.group(1)))

        # 4. 成交量大于 X亿 或 X手
        m = re.search(r'(?:成交量|量|成交额|额|成交量|成交额)\s*(?:超过|大于|高于|>=|>|不低于|≥)?\s*(\d+(?:\.\d+)?)\s*(?:亿|手)?', text)
        if m:
            val = float(m.group(1))
            unit = m.group(2) if len(m.groups()) > 1 else ""
            if "手" in text or "量" in text[:text.find(m.group(0)) + len(m.group(0))]:
                # 成交量单位是手
                pass
            else:
                val = val * 1e8  # 亿 -> 元
            return NumericCondition("amount", "gt", val)

        # 5. 市盈率低于 X
        m = re.search(r'(?:市盈率|PE|pe)\s*(?:低于|小于|<|不超过|不高于|≤)?\s*(\d+(?:\.\d+)?)', text)
        if m:
            return NumericCondition("pe", "lt", float(m.group(1)))

        # 6. 市盈率高于 X
        m = re.search(r'(?:市盈率|PE|pe)\s*(?:超过|大于|高于|大于|>|>=)?\s*(\d+(?:\.\d+)?)', text)
        if m:
            return NumericCondition("pe", "gt", float(m.group(1)))

        # 7. 市净率低于 X
        m = re.search(r'(?:市净率|PB|pb)\s*(?:低于|小于|<|不超过|不高于|≤)?\s*(\d+(?:\.\d+)?)', text)
        if m:
            return NumericCondition("pb", "lt", float(m.group(1)))

        # 8. 股价大于/低于 X元
        m = re.search(r'(?:股价|价格|最新价|现价|价)\s*(?:超过|大于|高于|>=|>|不低于|≥)?\s*(\d+(?:\.\d+)?)\s*元', text)
        if m:
            return NumericCondition("price", "gt", float(m.group(1)))
        m = re.search(r'(?:股价|价格|最新价|现价|价)\s*(?:低于|小于|<|不超过|不高于|≤)?\s*(\d+(?:\.\d+)?)\s*元', text)
        if m:
            return NumericCondition("price", "lt", float(m.group(1)))

        # 9. 换手率大于 X%
        m = re.search(r'(?:换手率|换手)\s*(?:超过|大于|高于|>=|>)?\s*(\d+(?:\.\d+)?)\s*%?', text)
        if m:
            return NumericCondition("turnover", "gt", float(m.group(1)))

        # 10. 连续X天上涨（需要历史数据，单独处理）
        m = re.search(r'(?:连续|连)(\d+)\s*(?:天|日|个交易日)\s*(?:涨|上涨|收涨|阳线|红)', text)
        if m:
            return ("consecutive_up", int(m.group(1)))

        # 11. 连续X天下跌
        m = re.search(r'(?:连续|连)(\d+)\s*(?:天|日|个交易日)\s*(?:跌|下跌|收跌|阴线|绿)', text)
        if m:
            return ("consecutive_down", int(m.group(1)))

        # 12. 涨停
        if re.search(r'涨停', text):
            return NumericCondition("change_pct", "gte", 9.8)

        # 13. 跌停
        if re.search(r'跌停', text):
            return NumericCondition("change_pct", "lte", -9.8)

        # 14. 行业/概念/板块包含
        m = re.search(r'(?:行业|板块|概念)\s*(?:属于|是|包含|为)?\s*(\S+)', text)
        if m:
            return TextCondition("name", "contains", m.group(1))

        # 15. 涨幅小于 X%
        m = re.search(r'(?:涨幅?|涨跌幅|涨|上涨|升)(?:低于|小于|<|不超过|不高于|≤)?\s*(\d+(?:\.\d+)?)\s*%?', text)
        if m:
            return NumericCondition("change_pct", "lt", float(m.group(1)))

        return None

    def screen(self, query, top_n=50):
        """
        根据自然语言查询筛选股票
        返回: (符合条件的股票DataFrame, 解析出的条件描述)
        """
        conditions = self.parse(query)
        if not conditions:
            return pd.DataFrame(), "无法解析查询条件，请参考：涨幅大于5%，市盈率低于20"

        # 获取实时数据
        try:
            df = StockAPI.get_realtime_quotes()
        except Exception as e:
            return pd.DataFrame(), f"获取行情数据失败: {e}"

        if df.empty:
            return pd.DataFrame(), "未获取到行情数据"

        # 应用条件
        condition_descriptions = []
        consecutive_conditions = []

        for cond in conditions:
            if isinstance(cond, tuple):
                # 连续涨跌条件特殊处理
                consecutive_conditions.append(cond)
                if cond[0] == "consecutive_up":
                    condition_descriptions.append(f"连续{cond[1]}天上涨")
                else:
                    condition_descriptions.append(f"连续{cond[1]}天下跌")
                continue

            try:
                before_count = len(df)
                df = cond.apply(df)
                if len(df) < before_count:
                    condition_descriptions.append(self._cond_desc(cond))
            except Exception:
                continue

        # 处理"连续X天上涨/下跌"条件（需要额外获取历史数据）
        if consecutive_conditions:
            # 只对有行情数据的股票进行过滤
            codes = df["code"].tolist()
            historical = self._check_consecutive(codes, consecutive_conditions)
            if historical is not None:
                df = df[df["code"].isin(historical)]

        # 排序
        if "change_pct" in df.columns:
            df = df.sort_values("change_pct", ascending=False)

        result_df = df.head(top_n)

        if result_df.empty:
            return result_df, f"已解析条件: {'; '.join(condition_descriptions)}，但未找到符合条件的股票"

        return result_df, f"已解析条件: {'; '.join(condition_descriptions)}，共找到 {len(result_df)} 只股票"

    def _check_consecutive(self, codes, consecutive_conditions):
        """检查连续涨跌条件"""
        from concurrent.futures import ThreadPoolExecutor, as_completed
        import time

        end = datetime.now()
        start = end - timedelta(days=60)
        start_str = start.strftime("%Y%m%d")
        end_str = end.strftime("%Y%m%d")

        result_codes = []
        # 限制检查数量
        check_codes = codes[:100]

        def check_one(code):
            try:
                df = StockAPI.get_historical_data(code, start_str, end_str)
                if df.empty or len(df) < 20:
                    return None
                for cond_type, days in consecutive_conditions:
                    if cond_type == "consecutive_up":
                        consec = (df["close"].diff() > 0).astype(int)
                    else:
                        consec = (df["close"].diff() < 0).astype(int)
                    # 计算连续序列
                    consec_count = consec * (consec.groupby(
                        (consec == 0).cumsum()).cumsum())
                    if consec_count.iloc[-1] >= days:
                        return code
                return None
            except Exception:
                return None

        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = {executor.submit(check_one, code): code for code in check_codes}
            for future in as_completed(futures):
                try:
                    result = future.result()
                    if result:
                        result_codes.append(result)
                except Exception:
                    pass
                time.sleep(0.05)

        return result_codes if result_codes else None

    def _cond_desc(self, cond):
        """生成条件描述"""
        op_map = {
            "gt": "大于", "gte": "大于等于",
            "lt": "小于", "lte": "小于等于",
            "eq": "等于", "between": "在...之间"
        }
        field_map = {
            "change_pct": "涨幅", "price": "股价",
            "volume": "成交量", "amount": "成交额",
            "pe": "市盈率", "pb": "市净率",
            "turnover": "换手率"
        }
        field = field_map.get(cond.field, cond.field)
        op = op_map.get(cond.operator, cond.operator)
        val = cond.value
        if isinstance(val, tuple):
            return f"{field}{op}{val[0]}和{val[1]}"
        return f"{field}{op}{val}"


# 便捷函数
def quick_screen(query, top_n=50):
    """快速选股"""
    screener = NLPScreener()
    return screener.screen(query, top_n)


def format_screen_result(df, max_rows=20):
    """格式化选股结果"""
    if df.empty:
        return "未找到符合条件的股票"

    display_cols = ["code", "name", "price", "change_pct",
                    "volume", "amount", "pe", "turnover"]
    available = [c for c in display_cols if c in df.columns]

    result = df[available].head(max_rows).copy()
    # 格式化
    if "price" in result.columns:
        result["price"] = result["price"].round(2)
    if "change_pct" in result.columns:
        result["change_pct"] = result["change_pct"].round(2).astype(str) + "%"
    if "amount" in result.columns:
        result["amount"] = (result["amount"] / 1e8).round(2).astype(str) + "亿"
    if "pe" in result.columns:
        result["pe"] = result["pe"].round(2)
    if "turnover" in result.columns:
        result["turnover"] = result["turnover"].round(2).astype(str) + "%"

    result = result.rename(columns={
        "code": "代码", "name": "名称", "price": "最新价",
        "change_pct": "涨幅", "volume": "成交量",
        "amount": "成交额", "pe": "市盈率", "turnover": "换手率"
    })
    return result
