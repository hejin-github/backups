"""
回测引擎 - 模拟交易执行，计算绩效指标，生成HTML报告
"""
import pandas as pd
import numpy as np
from datetime import datetime


class BacktestResult:
    def __init__(self):
        self.metrics = {}
        self.equity_curve = None
        self.trades = []
        self.signals = None
        self.price_data = None
        self.daily_returns = None
        self.monthly_returns = None


class BacktestEngine:
    def __init__(self, initial_capital=1000000, commission_rate=0.0003,
                 stamp_tax_rate=0.001, slippage=0.001):
        self.initial_capital = initial_capital
        self.commission_rate = commission_rate
        self.stamp_tax_rate = stamp_tax_rate
        self.slippage = slippage

    # 【修复滑点】打板/接力类策略需要更高滑点
    HIGH_SLIPPAGE_KEYWORDS = ["涨停打板", "首板", "2B接力", "2b接力", "二进三",
                              "封板", "打板", "接力", "强更强", "连板", "三板", "二波"]

    def _effective_slippage(self, strategy_name):
        for kw in self.HIGH_SLIPPAGE_KEYWORDS:
            if kw in strategy_name:
                return max(self.slippage, 0.005)  # 至少0.5%
        return self.slippage

    def run(self, df, strategy, symbol="", stock_name=""):
        result = BacktestResult()
        df = df.copy()
        if df.empty or len(df) < 30:
            result.metrics["error"] = "数据不足，至少需要30个交易日"
            return result

        df = df.sort_values("date").reset_index(drop=True)
        df = strategy.generate_signals(df)
        slippage = self._effective_slippage(strategy.name)

        trades = []
        equity = [self.initial_capital]
        in_position = False
        entry_price = 0
        entry_date = None
        shares = 0
        cash = self.initial_capital
        cost = 0

        # 【修复未来函数】信号来自上一根K线 → 今日开盘价成交
        # 第0根K线无历史信号，跳过
        for i in range(len(df)):
            close_price = float(df["close"].iloc[i])
            date = df["date"].iloc[i]

            if pd.isna(close_price) or close_price <= 0:
                equity.append(equity[-1] if equity else self.initial_capital)
                continue

            # 第0根K线无法交易（无历史信号），仅跟踪净值
            if i == 0:
                current_value = cash
                equity.append(current_value)
                continue

            signal = df["signal"].iloc[i-1] if "signal" in df.columns else 0
            open_price = float(df["open"].iloc[i]) if "open" in df.columns else close_price

            if signal > 0 and not in_position:
                buy_price = open_price * (1 + slippage)
                max_shares = int(cash / buy_price / 100) * 100
                if max_shares >= 100:
                    shares = max_shares
                    entry_price = buy_price
                    entry_date = date
                    cost = shares * buy_price
                    commission = cost * self.commission_rate
                    cash -= (cost + commission)
                    in_position = True
                    trades.append({
                        "date": date, "type": "买入", "price": round(buy_price, 2),
                        "shares": shares, "amount": round(cost, 2),
                        "commission": round(commission, 2), "reason": f"信号值={signal}",
                    })

            elif signal < 0 and in_position:
                sell_price = open_price * (1 - slippage)
                revenue = shares * sell_price
                commission = revenue * self.commission_rate
                stamp_tax = revenue * self.stamp_tax_rate
                cash += (revenue - commission - stamp_tax)
                profit_val = revenue - cost - commission - stamp_tax
                profit_pct = (profit_val / cost) * 100 if cost > 0 else 0
                in_position = False
                trades.append({
                    "date": date, "type": "卖出", "price": round(sell_price, 2),
                    "shares": shares, "amount": round(revenue, 2),
                    "commission": round(commission, 2), "stamp_tax": round(stamp_tax, 2),
                    "profit": round(profit_val, 2), "profit_pct": round(profit_pct, 2),
                    "hold_days": (pd.Timestamp(date) - pd.Timestamp(entry_date)).days,
                    "reason": f"信号值={signal}",
                })
                shares = 0
                entry_price = 0

            current_value = cash + shares * close_price if in_position else cash
            equity.append(current_value)

        if in_position:
            last_price = float(df["close"].iloc[-1])
            sell_price = last_price * (1 - slippage)
            revenue = shares * sell_price
            commission = revenue * self.commission_rate
            stamp_tax = revenue * self.stamp_tax_rate
            cash += (revenue - commission - stamp_tax)
            profit_val = revenue - cost - commission - stamp_tax
            profit_pct = (profit_val / cost) * 100 if cost > 0 else 0
            trades.append({
                "date": df["date"].iloc[-1], "type": "卖出(平仓)",
                "price": round(sell_price, 2), "shares": shares,
                "amount": round(revenue, 2), "commission": round(commission, 2),
                "stamp_tax": round(stamp_tax, 2),
                "profit": round(profit_val, 2), "profit_pct": round(profit_pct, 2),
                "hold_days": (pd.Timestamp(df["date"].iloc[-1]) - pd.Timestamp(entry_date)).days,
                "reason": "回测结束平仓",
            })
            equity[-1] = cash

        equity_series = pd.Series(equity[1:], index=df["date"])
        daily_ret = equity_series.pct_change().fillna(0)
        total_return = (equity_series.iloc[-1] / self.initial_capital - 1) * 100
        days = (df["date"].iloc[-1] - df["date"].iloc[0]).days
        years = max(days / 365, 0.01)
        annual_return = ((equity_series.iloc[-1] / self.initial_capital) ** (1 / years) - 1) * 100
        rolling_max = equity_series.cummax()
        drawdown = (equity_series - rolling_max) / rolling_max * 100
        max_drawdown = drawdown.min()
        risk_free = 0.02
        excess_ret = daily_ret - risk_free / 252
        sharpe = np.sqrt(252) * excess_ret.mean() / (daily_ret.std() + 1e-10)

        if trades:
            win = [t for t in trades if t.get("profit", 0) > 0]
            loss = [t for t in trades if t.get("profit", 0) <= 0]
            win_rate = len(win) / len(trades) * 100
            avg_win = np.mean([t["profit"] for t in win]) if win else 0
            avg_loss = abs(np.mean([t["profit"] for t in loss])) if loss else 1
            profit_factor = (
                sum(t["profit"] for t in win) / max(abs(sum(t["profit"] for t in loss)), 1)
                if loss else 999
            )
        else:
            win_rate = 0
            profit_factor = 0

        total_trades = len(trades)
        avg_hold = np.mean([t.get("hold_days", 0) for t in trades if "hold_days" in t]) if trades else 0

        result.metrics = {
            "股票代码": symbol, "股票名称": stock_name,
            "策略名称": strategy.name,
            "回测区间": f"{df['date'].iloc[0].strftime('%Y-%m-%d')} ~ {df['date'].iloc[-1].strftime('%Y-%m-%d')}",
            "初始资金": f"{self.initial_capital:,.0f}",
            "最终资产": f"{equity_series.iloc[-1]:,.0f}",
            "总收益率": f"{total_return:.2f}%",
            "年化收益率": f"{annual_return:.2f}%",
            "最大回撤": f"{max_drawdown:.2f}%",
            "夏普比率": f"{sharpe:.2f}",
            "胜率": f"{win_rate:.1f}%",
            "盈亏比": f"{profit_factor:.2f}",
            "总交易次数": total_trades,
            "平均持仓天数": f"{avg_hold:.1f}",
            "收益波动率": f"{daily_ret.std() * np.sqrt(252) * 100:.2f}%",
            "_total_return": total_return, "_annual_return": annual_return,
            "_max_drawdown": max_drawdown, "_sharpe": sharpe,
            "_win_rate": win_rate, "_profit_factor": profit_factor,
        }
        result.equity_curve = equity_series
        result.trades = trades
        result.signals = df
        result.daily_returns = daily_ret
        return result

    def batch_run(self, stock_data_dict, strategy, symbols_with_names=None):
        results = {}
        for code, df in stock_data_dict.items():
            try:
                name = symbols_with_names.get(code, "") if symbols_with_names else ""
                results[code] = self.run(df, strategy, symbol=code, stock_name=name)
            except Exception:
                continue
        return results


def generate_html_report(result, output_path=None):
    """生成HTML回测报告"""
    m = result.metrics
    trades_html = ""
    for t in result.trades[:50]:
        color = "#00c853" if t.get("profit_pct", 0) > 0 else "#ff1744"
        trades_html += f"""
        <tr>
            <td style="padding:4px 8px;">{str(t['date'])[:10]}</td>
            <td style="padding:4px 8px;">{t['type']}</td>
            <td style="padding:4px 8px;">{t['price']:.2f}</td>
            <td style="padding:4px 8px;">{t.get('shares',0)}</td>
            <td style="padding:4px 8px;color:{color};">{t.get('profit_pct',0):.2f}%</td>
        </tr>"""

    html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>回测报告</title>
<style>
body {{ font-family:sans-serif; background:#0e1117; color:#e0e0e0; padding:20px; }}
h1 {{ color:#00d4ff; }}
.card {{ background:#1a1d2e; border-radius:8px; padding:16px; margin:12px 0; border:1px solid #2a2d3e; }}
.metric {{ display:inline-block; margin:8px 16px; text-align:center; }}
.metric-value {{ font-size:1.4rem; font-weight:700; color:#00d4ff; }}
.metric-label {{ font-size:0.75rem; color:#8892b0; }}
table {{ width:100%; border-collapse:collapse; }}
th {{ text-align:left; padding:8px; border-bottom:2px solid #2a2d3e; color:#8892b0; }}
td {{ padding:4px 8px; border-bottom:1px solid #1a1d2e; }}
.positive {{ color:#00c853; }} .negative {{ color:#ff1744; }}
</style></head><body>
<h1>📊 策略回测报告</h1>
<div style="color:#8892b0;margin-bottom:20px;">
    {m.get('股票代码','')} {m.get('股票名称','')} | {m.get('策略名称','')} | {m.get('回测区间','')}
</div>
<div class="card">
    <div class="metric"><div class="metric-label">总收益率</div><div class="metric-value">{m.get('总收益率','')}</div></div>
    <div class="metric"><div class="metric-label">年化收益率</div><div class="metric-value">{m.get('年化收益率','')}</div></div>
    <div class="metric"><div class="metric-label">最大回撤</div><div class="metric-value" style="color:#ff1744;">{m.get('最大回撤','')}</div></div>
    <div class="metric"><div class="metric-label">夏普比率</div><div class="metric-value">{m.get('夏普比率','')}</div></div>
    <div class="metric"><div class="metric-label">胜率</div><div class="metric-value">{m.get('胜率','')}</div></div>
    <div class="metric"><div class="metric-label">交易次数</div><div class="metric-value">{m.get('总交易次数',0)}</div></div>
</div>
<div class="card">
    <h3>交易记录 ({len(result.trades)}笔)</h3>
    <table><tr><th>日期</th><th>类型</th><th>价格</th><th>数量</th><th>盈亏%</th></tr>{trades_html}</table>
</div>
</body></html>"""

    if output_path:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
    return html
