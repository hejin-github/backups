"""
通知模块 - 浏览器桌面通知 + 聚合日报
"""
import json
import os
from datetime import datetime


def browser_notify(title, message, level="info"):
    """生成浏览器通知HTML片段"""
    colors = {
        "black_swan": "#ff1744",
        "opportunity": "#00c853",
        "warning": "#ffd600",
        "info": "#00d4ff",
    }
    color = colors.get(level, "#00d4ff")
    return f"""
    <div style="position:fixed;top:20px;right:20px;z-index:99999;
                background:#1a1d2e;border-left:4px solid {color};
                border-radius:8px;padding:12px 16px;box-shadow:0 4px 20px rgba(0,0,0,0.5);
                max-width:360px;animation:slideIn 0.3s ease;">
        <div style="color:{color};font-weight:600;font-size:0.9rem;margin-bottom:4px;">{title}</div>
        <div style="color:#8892b0;font-size:0.8rem;">{message}</div>
    </div>
    """


class DailyReport:
    """日报生成器"""

    def __init__(self, save_dir="data/daily_reports"):
        self.save_dir = save_dir
        os.makedirs(save_dir, exist_ok=True)

    def generate(self, picks_df, alerts, market_summary):
        """生成日报"""
        today = datetime.now().strftime("%Y-%m-%d")
        total_picks = len(picks_df) if picks_df is not None else 0
        top_picks = picks_df.head(10).to_dict("records") if picks_df is not None else []
        black_swans = [a for a in alerts if a["level"] == "black_swan"]
        opportunities = [a for a in alerts if a["level"] == "opportunity"]
        warnings_list = [a for a in alerts if a["level"] == "warning"]

        report = {
            "date": today,
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "market": market_summary,
            "picks": {
                "total": total_picks,
                "top10": [
                    {
                        "code": p.get("code", ""),
                        "name": p.get("name", ""),
                        "score": round(p.get("factor_score", p.get("score", 0)), 1),
                        "reason": p.get("reason", ""),
                    }
                    for p in top_picks
                ],
            },
            "alerts": {
                "black_swan": len(black_swans),
                "opportunity": len(opportunities),
                "warning": len(warnings_list),
                "total": len(alerts),
            },
        }

        filename = os.path.join(self.save_dir, f"report_{today}.json")
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2, default=str)

        return report, filename

    def format_html(self, report):
        """格式化为HTML"""
        picks = report["picks"]["top10"]
        picks_html = ""
        for p in picks:
            picks_html += f"""
            <tr>
                <td style="padding:6px 10px;border-bottom:1px solid #2a2d3e;">{p['code']}</td>
                <td style="padding:6px 10px;border-bottom:1px solid #2a2d3e;">{p['name']}</td>
                <td style="padding:6px 10px;border-bottom:1px solid #2a2d3e;">{p['score']}</td>
            </tr>"""

        alerts = report["alerts"]
        return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>量化日报 {report['date']}</title>
<style>
body {{ background:#0e1117; color:#e0e0e0; font-family:sans-serif; padding:20px; }}
h1 {{ color:#00d4ff; }}
.card {{ background:#1a1d2e; border-radius:8px; padding:16px; margin:12px 0; border:1px solid #2a2d3e; }}
table {{ width:100%; border-collapse:collapse; }}
</style></head><body>
<h1>📊 量化日报</h1>
<div style="color:#8892b0;">{report['date']} | {report['generated_at']}</div>
<div class="card">
    <h3>📋 今日精选 Top 10</h3>
    <table><tr><th>代码</th><th>名称</th><th>评分</th></tr>{picks_html}</table>
</div>
<div class="card">
    <h3>🚨 警报摘要</h3>
    <p>🚨 黑天鹅: {alerts['black_swan']} | 🎯 机会: {alerts['opportunity']} | ⚠️ 警告: {alerts['warning']}</p>
</div>
</body></html>"""
