# -*- coding: utf-8 -*-
"""收紧位置分项的突破档(近20日高+5日涨幅≤EXT_CAP才给25分, 过高判"已加速"降8分),
测陷阱档(80-90)是否消失、主推/备用/整篮是否改善、早期窗口是否被误伤.
只monkeypatch R._quality_score, 不动生产recommender; 复用缓存信号索引."""
import argparse
import os
import pickle
import collections

import numpy as np
import pandas as pd

import recommender as R
import backtest_prod_pipeline as B
from experiment_common import load_index_regimes, hist_window


# ---- 变体打分: 仅改位置分桶, 其余与 R._quality_score 完全一致 ----
def _q_variant(hist, change_pct, row, pe_map=None, code=""):
    score = 0.0
    n = len(hist)
    if n < 2:
        return 50.0
    close = hist["close"]
    last = float(close.iloc[-1])

    to = R._safe_last(hist, "turnover")
    if to is not None and to > 0:
        if 3 <= to <= 15:   score += 30
        elif 15 < to <= 25: score += 20
        elif 1 <= to < 3:   score += 14
        else:               score += 8
    else:
        score += 15

    vr = R._volume_ratio(hist)
    if vr is not None:
        if 1.2 <= vr <= 3.0: score += 20
        elif 0.8 <= vr < 1.2: score += 12
        elif vr > 3.0:        score += 6
        else:                 score += 8
    else:
        score += 10

    near_high = False
    ret5 = 0.0
    if "high" in hist.columns and n >= 20:
        recent_high = float(hist["high"].iloc[-20:].max())
    else:
        recent_high = float(close.iloc[-min(n, 20):].max())
    near_high = recent_high > 0 and last >= recent_high * 0.97
    ret5 = (last / float(close.iloc[-6]) - 1) * 100 if n >= 6 else 0
    if near_high and 0 <= ret5 <= _EXT_CAP:
        score += 25        # 真·突破启动(低位+涨幅温和)
    elif near_high and ret5 > _EXT_CAP:
        score += 8         # 已到高位且涨幅过大 = 已加速
    elif 0 <= ret5 <= 20:
        score += 18        # 健康上行
    elif ret5 < 0:
        score += 12        # 回落低吸位
    else:
        score += 8         # 已加速

    o = R._safe_last(hist, "open")
    c = R._safe_last(hist, "close")
    if o is not None and c is not None:
        if c > o: score += 15
        elif c == o: score += 8
        else: score += 5
    else:
        score += 8

    pe = R._pe_of(row, code, pe_map)
    if pe is not None and pe > 0:
        if 10 <= pe <= 80: score += 10
        elif pe > 80:      score += 6
        else:              score += 3
    else:
        score += 5

    return round(min(score, 100), 1)


_EXT_CAP = 25.0  # 运行时覆盖


def _summ(rows, label, stats):
    s = B._summarize(rows, label, stats)
    cells = []
    for role in ("主推", "备用", "any_top5"):
        a = s[role]
        cells.append((a["n"], a["win_pct"], a["mean_ret"], a["net_pnl"] or 0) if a["n"] else (0, 0, 0, 0))
    return cells, s


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--trade-days", type=int, default=300)
    ap.add_argument("--sample", type=int, default=300)
    ap.add_argument("--offset", type=int, default=0,
                    help="分析窗口向前平移的交易日数: 0=最近300日(首段), 300=更早一段样本外")
    ap.add_argument("--hist-days", type=int, default=300,
                    help="历史窗口长度(交易日): 第二段需更长以覆盖早段")
    args = ap.parse_args()

    asof = B._prev_trading_day()
    asof_s = pd.Timestamp(asof).strftime("%Y%m%d")
    pool = B._load_pool(args.sample)
    if pool is None:
        print("实时行情为空"); return
    _, idx = load_index_regimes(1001, asof)
    regimes = B._prod_regime_map(idx)
    all_days = sorted(regimes.keys())
    lo = len(all_days) - args.trade_days - args.offset
    hi = len(all_days) - args.offset
    analysis_days = set(all_days[lo:hi])
    start_str, end_str = hist_window(asof, args.hist_days)
    sigs = B._build_signal_index(pool, start_str, end_str, asof_s, force=False,
                                 cache_suffix="_h%d_o%d" % (args.hist_days, args.offset))
    print("分析窗口 %s ~ %s, 信号索引 %d 只 (hist %s~%s)" % (
        pd.Timestamp(min(analysis_days)).strftime("%Y-%m-%d"),
        pd.Timestamp(max(analysis_days)).strftime("%Y-%m-%d"), len(sigs), start_str, end_str))

    caps = [25.0, 12.0, 10.0, 8.0, 5.0]
    print("\n")
    print("  cap       | 主推 n/胜率/均值/净            | 备用 n/胜率/均值/净            | any_top5 n/胜率/均值/净        | 档分布 hi/mid/lo | 主推 前半/后半")
    global _EXT_CAP
    for cap in caps:
        _EXT_CAP = cap
        R._quality_score = _q_variant
        rows, stats = B._replay(sigs, regimes, analysis_days, True, rank_mode="quality")
        cells, s = _summ(rows, "cap=%.0f" % cap, stats)
        trad = [r for r in rows if not r["oneword"] and r["ret"] is not None]
        dist = collections.Counter()
        for r in trad:
            q = float(r["quality"])
            dist["hi" if q >= 80 else "mid" if q >= 70 else "lo"] += 1
        # 主推 前后半窗
        mainr = [r for r in rows if r["rank"] == 1 and not r["oneword"] and r["ret"] is not None]
        mdates = sorted({r["date"] for r in rows})
        half = mdates[len(mdates) // 2]
        pre = [r for r in mainr if r["date"] < half]
        post = [r for r in mainr if r["date"] >= half]
        def _w(seg):
            rr = [r["ret"] for r in seg]
            return "%.1f%%/%+.3f" % (sum(1 for x in rr if x > 0) / len(rr) * 100, sum(rr) / len(rr)) if rr else "-"
        hdr = lambda x: "%d/%s%%/%+.3f%%/%+.0f" % (x[0], x[1], x[2], x[3])
        print("  cap=%5.1f | %s | %s | %s | hi%d mid%d lo%d | 主推前半%s 后半%s" % (
            cap, hdr(cells[0]), hdr(cells[1]), hdr(cells[2]),
            dist["hi"], dist["mid"], dist["lo"], _w(pre), _w(post)))


if __name__ == "__main__":
    main()
