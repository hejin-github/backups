# -*- coding: utf-8 -*-
"""10:30 卖点复核 (2026-08-29)

对生产历史推荐(8/04-8/27)的实际 T+1 收益做卖点对比:
  买入 = T+1 开盘(真口径, 扣隔夜gap)
  卖点 A: T+1 10:30 盘中价(前复权对齐)
  卖点 B: T+1 收盘
  卖点 C: T+1 开盘即卖(=0, 仅作成本基准)
  参考 R: max(10:30, 收盘) —— 事后最优(不可交易, 仅诊断 10:30-vs-收盘 选择性损失)
带费: 佣金万2.5(最低¥5, 双边) / 印花税0.05%(卖) / 过户费万0.1(双边), 每笔¥5000本金.
判定: 10:30 是否仍优于收盘; 若 10:30 的净胜(胜率/均值/累计)不显著优于收盘, 生产可改卖收盘.
"""
import json, os
from datetime import datetime, timedelta
import pandas as pd
from scheduler import is_trading_day
from stock_api import StockAPI

RECOMMEND_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "recommendations")
COMM, STAMP, XFER = 0.00025, 0.0005, 0.00001
BUDGET = 5000.0


def next_trading_day(d):
    d = d + timedelta(days=1)
    while not is_trading_day(d):
        d += timedelta(days=1)
    return d


def net_pnl(buy, sell, budget=BUDGET):
    """整手含费净盈亏(与 app._sim_trade 同口径)"""
    try:
        buy, sell = float(buy), float(sell)
    except (TypeError, ValueError):
        return None
    if buy <= 0 or sell <= 0:
        return None
    qty = int(budget / buy / 100) * 100
    if qty <= 0:
        return None
    cost = qty * buy
    proceeds = qty * sell
    buy_fee = max(5.0, cost * COMM)
    sell_fee = max(5.0, proceeds * COMM) + proceeds * STAMP + proceeds * XFER
    return (proceeds - cost) - (buy_fee + sell_fee), qty


def main():
    today = datetime.now()
    records = []
    if os.path.isdir(RECOMMEND_DIR):
        for fname in sorted(os.listdir(RECOMMEND_DIR)):
            if not fname.endswith(".json"):
                continue
            try:
                with open(os.path.join(RECOMMEND_DIR, fname), encoding="utf-8") as f:
                    records.append(json.load(f))
            except Exception:
                continue

    rows = []   # 每条可交易pick: {date, role, code, name, buy, sell_1030, sell_close, ret_1030, ret_close, net_1030, net_close, oneword, pnl}
    skipped = {"no_hist": 0, "no_grid": 0, "oneword": 0, "t1_not_done": 0}
    for rec in records:
        date_str = rec.get("date", "")
        if not date_str:
            continue
        try:
            buy_dt = datetime.strptime(date_str, "%Y%m%d")
        except Exception:
            continue
        t1_date = next_trading_day(buy_dt)
        t1_str = t1_date.strftime("%Y%m%d")
        if t1_date.date() >= today.date():
            skipped["t1_not_done"] += 1
            continue
        for pick in rec.get("picks", []):
            code = str(pick.get("code", ""))
            if not code:
                continue
            role = pick.get("role") or "主推"
            # T+1 前复权日bar: 取开盘(买)/收盘/高低
            hist = None
            try:
                hist = StockAPI.get_historical_data(code, date_str, t1_str, adjust="qfq")
            except Exception:
                hist = None
            if hist is None or hist.empty:
                skipped["no_hist"] += 1
                continue
            hr = hist[hist["date"] == pd.to_datetime(t1_str)]
            if hr.empty:
                skipped["no_hist"] += 1
                continue
            t1_open = float(hr["open"].iloc[0])
            t1_close = float(hr["close"].iloc[0])
            t1_high = float(hr["high"].iloc[0])
            t1_low = float(hr["low"].iloc[0])
            if t1_open <= 0:
                skipped["no_hist"] += 1
                continue
            # 一字涨停开盘买不进 → 标记, 不计入卖点对比(买侧不可执行)
            oneword = (t1_high - t1_low) < 0.03 and t1_open >= t1_high - 0.005
            # 10:30 盘中价(不复权) + 当日收盘(不复权), 经前复权比对齐
            grid = None
            try:
                grid = StockAPI.get_intraday_sell_grid(code, t1_str)
            except Exception:
                grid = None
            raw_1030, raw_close = None, None
            if grid and grid.get("close", 0) > 0:
                raw_close = float(grid["close"])
                raw_1030 = (grid.get("prices") or {}).get("10:30")
            if raw_1030 is None or raw_close is None or raw_close <= 0:
                skipped["no_grid"] += 1
                continue
            qfq_1030 = raw_1030 * (t1_close / raw_close)  # 前复权对齐
            row = {
                "date": date_str, "role": role, "code": code, "name": pick.get("name", ""),
                "buy": t1_open, "sell_1030": qfq_1030, "sell_close": t1_close,
                "oneword": oneword, "qty": 0,
            }
            if oneword:
                skipped["oneword"] += 1
                rows.append(row)   # 仍记录, 但对比时排除
            else:
                rows.append(row)
    if not rows:
        print(json.dumps({"error": "no rows"}, ensure_ascii=False))
        return

    # 汇总
    def _agg(sub, label):
        if not sub:
            return {"label": label, "n": 0}
        r1030 = [r["sell_1030"] / r["buy"] - 1 for r in sub]
        rclose = [r["sell_close"] / r["buy"] - 1 for r in sub]
        p1030 = [net_pnl(r["buy"], r["sell_1030"]) for r in sub]
        pclose = [net_pnl(r["buy"], r["sell_close"]) for r in sub]
        p1030 = [p[0] for p in p1030 if p]
        pclose = [p[0] for p in pclose if p]
        beats = sum(1 for r in sub if r["sell_1030"] > r["sell_close"])
        return {
            "label": label, "n": len(sub),
            "ret_1030": round(sum(r1030) / len(r1030) * 100, 3),
            "win_1030": round(sum(1 for x in r1030 if x > 0) / len(r1030) * 100, 1),
            "ret_close": round(sum(rclose) / len(rclose) * 100, 3),
            "win_close": round(sum(1 for x in rclose if x > 0) / len(rclose) * 100, 1),
            "net_pnl_1030": round(sum(p1030), 0), "net_pnl_close": round(sum(pclose), 0),
            "mean_net_1030": round(sum(p1030) / len(p1030), 0) if p1030 else None,
            "mean_net_close": round(sum(pclose) / len(pclose), 0) if pclose else None,
            "b1030_gt_close": beats, "b_close_gt_1030": len(sub) - beats,
        }

    tradable = [r for r in rows if not r["oneword"]]
    out = {
        "asof": today.strftime("%Y%m%d"),
        "skipped": skipped,
        "n_rows_total": len(rows), "n_tradable": len(tradable),
        "all": _agg(tradable, "全部(可交易)"),
        "main": _agg([r for r in tradable if r["role"] == "主推"], "主推"),
        "backup": _agg([r for r in tradable if r["role"] == "备用"], "备用"),
        "candidate": _agg([r for r in tradable if r["role"].startswith("候选")], "候选"),
        "oneword_picks": [f'{r["date"]} {r["name"]}({r["code"]})' for r in rows if r["oneword"]],
    }
    # 明细
    out["detail"] = [
        {"date": r["date"], "role": r["role"], "code": r["code"], "name": r["name"],
         "buy": round(r["buy"], 2),
         "ret_1030_pct": round((r["sell_1030"] / r["buy"] - 1) * 100, 2),
         "ret_close_pct": round((r["sell_close"] / r["buy"] - 1) * 100, 2),
         "oneword": r["oneword"]}
        for r in rows
    ]
    with open("data/sell_point_recheck.json", "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    print("ok, tradable=%d total=%d" % (len(tradable), len(rows)))


if __name__ == "__main__":
    main()
