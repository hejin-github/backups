"""
数据加载与缓存模块
历史K线数据内存缓存，避免重复请求API
"""
import pandas as pd
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from stock_api import StockAPI

_hist_cache = {}      # {(code, start, end): DataFrame} — 已含date_str列
_cache_names = {}     # {code: name}


def get_hist_data(codes, start_date, end_date, min_len=60, max_workers=8):
    """批量获取历史数据（带内存缓存）

    返回 (hist_data: {code: DataFrame}, names: {code: str})
    hist_data中的DataFrame已包含date_str列、已reset_index
    """
    hist_data = {}
    names = {}
    need_fetch = []

    for code in codes:
        key = (code, start_date, end_date)
        if key in _hist_cache:
            hist_data[code] = _hist_cache[key]
            if code in _cache_names:
                names[code] = _cache_names[code]
        else:
            need_fetch.append(code)

    if need_fetch:
        def _f(code):
            h = StockAPI.get_historical_data(code, start_date, end_date)
            return code, h
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            fs = {executor.submit(_f, c): c for c in need_fetch}
            for f in as_completed(fs):
                try:
                    code, h = f.result()
                    if h is not None and len(h) >= min_len:
                        h["date_str"] = h["date"].dt.strftime("%Y%m%d")
                        h = h.reset_index(drop=True)
                        hist_data[code] = h
                        hname = str(h["name"].iloc[0]) if "name" in h.columns else ""
                        names[code] = hname
                        _hist_cache[(code, start_date, end_date)] = h
                        _cache_names[code] = hname
                except Exception:
                    pass

    return hist_data, names


def get_trade_dates(hist_data, trade_start=None, trade_end=None):
    """从历史数据计算交易日列表（排序、去重、过滤周末）"""
    all_dates = sorted(set(
        d for h in hist_data.values() for d in h["date_str"].values
    ))
    if trade_start is not None and trade_end is not None:
        all_dates = [
            d for d in all_dates
            if trade_start <= d <= trade_end
            and datetime.strptime(d, "%Y%m%d").weekday() < 5
        ]
    return all_dates


def clear_cache():
    """清除缓存"""
    _hist_cache.clear()
    _cache_names.clear()
