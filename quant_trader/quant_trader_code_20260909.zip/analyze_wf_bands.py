# -*- coding: utf-8 -*-
"""检查 walkforward 滚动档位在回测期间实际选择了哪一档(无前视, 逐日记录)."""
import os
import time
import backtest_prod_pipeline as B
from experiment_common import hist_window

asof = B._prev_trading_day()
asof_s = pd_t = None  # noqa
import pandas as pd
from experiment_common import load_index_regimes
asof_s = pd.Timestamp(asof).strftime("%Y%m%d")

pool = B._load_pool(300)
_, idx = load_index_regimes(1001, asof)
regimes = B._prod_regime_map(idx)
all_days = sorted(regimes.keys())
analysis_days = set(all_days[-300:])
start_str, end_str = hist_window(asof, 300)
sigs = B._build_signal_index(pool, start_str, end_str, asof_s, force=False)

# monkeypatch: 记录每日 band_stat
decisions = []
_orig = B._trailing_band_stat
def _wrap(now_d, tracker):
    st = _orig(now_d, tracker)
    decisions.append((pd.Timestamp(now_d), dict(st) if st else None))
    return st
B._trailing_band_stat = _wrap

rows, stats = B._replay(sigs, regimes, analysis_days, True, rank_mode="walkforward")

# 汇总: 分段时间内最优档选择
import collections
window = 60
start = pd.Timestamp(min(analysis_days))
end = pd.Timestamp(max(analysis_days))
print("\n===== walkforward 档位决策逐段 (每%d交易日) =====" % window)
seg_start = start
seg_hist = collections.Counter()  # band -> count of days chosen as best
chosen = []
for d, st in decisions:
    seg_hist[tuple(sorted(st.keys())) if st else ("无样本",)] += 1
    if st:
        chosen.append((max(st, key=st.get), st[max(st, key=st.get)]))
# 按整窗统计
from collections import Counter
c = Counter()
vals = collections.defaultdict(list)
for d, st in decisions:
    if st:
        best = max(st, key=st.get)
        c[best] += 1
        vals[best].append(st[best])
    else:
        c["无样本"] += 1
print("整窗最优档被选次数:", dict(c))
for band in ("mid", "lo", "hi"):
    if vals[band]:
        mean = sum(vals[band]) / len(vals[band])
        print("  当 %s 被选为最优时, 其滚动T+1均值=%.3f%% (n=%d)" % (band, mean, len(vals[band])))

# 逐段 60 交易日的最优档
print("\n逐段最优档(每60交易日):")
i = 0
while i < len(decisions):
    seg = decisions[i:i + window]
    if not seg:
        break
    seg_stat = collections.defaultdict(list)
    for d, st in seg:
        if st:
            for b, v in st.items():
                seg_stat[b].append(v)
    bests = sorted(seg_stat.items(), key=lambda kv: -sum(kv[1]) / len(kv[1]))
    s0, s1 = seg[0][0], seg[-1][0]
    line = "  %s~%s: " % (pd.Timestamp(s0).strftime("%y-%m-%d"), pd.Timestamp(s1).strftime("%y-%m-%d"))
    line += " | ".join("%s=%.2f(n%d)" % (b, sum(v) / len(v), len(v)) for b, v in bests)
    print(line)
    i += window

main_rows = [r for r in rows if r["rank"] == 1 and not r["oneword"] and r["ret"] is not None]
rets = [r["ret"] for r in main_rows]
print("walkforward主推(重跑校验): n=%d 胜率=%.1f%% 均值=%+.3f%% 净=¥%+.0f" % (
    len(rets), sum(1 for x in rets if x > 0) / len(rets) * 100, sum(rets) / len(rets),
    sum(r["pnl"] or 0 for r in main_rows)))
