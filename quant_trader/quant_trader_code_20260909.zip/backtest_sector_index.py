# -*- coding: utf-8 -*-
"""板块指数信号回测(独立脚本, 不改现有代码):
对每个"有首推板块"的推荐日, 计算 首推+备用板块指数 今日 vs 昨日 升/降 信号,
门槛对比 T+1 胜率与回撤(与上证门槛并行/组合).
样本: 08-era daily_picks(含板块信息) ∩ 推荐记录, 约9日/15笔, 小样本仅提示.
"""
import glob
import json
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta

from index_guide import load_sh_history, sector_index_for
from scheduler import _next_trading_day
from stock_api import StockAPI

BASE = os.path.dirname(os.path.abspath(__file__))
REC_DIR = os.path.join(BASE, "data", "recommendations")
PICKS_DIR = os.path.join(BASE, "data", "daily_picks")


def _ds(d):
    return d.strftime("%Y%m%d") if hasattr(d, "strftime") else str(d).replace("-", "")


def t1_day(b):
    return _next_trading_day(datetime.strptime(b, "%Y%m%d") + timedelta(days=1)).strftime("%Y%m%d")


def main_pick_dates():
    out = []
    for f in sorted(glob.glob(os.path.join(PICKS_DIR, "*.json"))):
        dt = os.path.basename(f)[:-5]
        try:
            d = json.load(open(f, encoding="utf-8"))
        except Exception:
            continue
        if d.get("main_pick"):
            out.append(dt)
    return out


def load_records():
    rows = []
    for f in sorted(glob.glob(os.path.join(REC_DIR, "*.json"))):
        try:
            d = json.load(open(f, encoding="utf-8"))
        except Exception:
            continue
        dt = str(d.get("date") or os.path.basename(f)[:-5])
        for p in d.get("picks", []):
            code = str(p.get("code") or "").strip()
            if not code:
                continue
            rows.append({
                "date": dt,
                "code": code,
                "name": p.get("name"),
                "buy": p.get("qfq_buy_price") or p.get("price"),
                "r1030": p.get("t1_1030_return"),
                "rclose": p.get("t1_return"),
            })
    return rows


def fetch_t1_lows(rows):
    need = {}
    for r in rows:
        need.setdefault(r["code"], set()).add(t1_day(r["date"]))
    start = min(r["date"] for r in rows)
    end = max(t1_day(r["date"]) for r in rows)

    def _f(code):
        try:
            df = StockAPI.get_historical_data(code, start, end, adjust="qfq", source="tencent")
        except Exception:
            return code, {}
        lows = {}
        if df is not None and not df.empty and "low" in df.columns:
            for _, r in df.iterrows():
                lows[_ds(r["date"])] = float(r["low"])
        return code, lows

    out = {}
    with ThreadPoolExecutor(max_workers=6) as ex:
        for fut in as_completed([ex.submit(_f, c) for c in need]):
            try:
                c, lows = fut.result()
            except Exception:
                continue
            for t1s in need[c]:
                out[(c, t1s)] = lows.get(t1s)
    return out


def metrics(picks):
    n = len(picks)
    if not n:
        return None
    r1030 = [p["r1030"] for p in picks if p["r1030"] is not None]
    dd = [p["dd"] for p in picks if p.get("dd") is not None]
    return {
        "n": n,
        "win": sum(1 for x in r1030 if x > 0) / n * 100,
        "avg": sum(r1030) / len(r1030) if r1030 else None,
        "med": sorted(r1030)[len(r1030) // 2] if r1030 else None,
        "n_dd": len(dd),
        "avg_dd": sum(dd) / len(dd) if dd else None,
        "max_dd": min(dd) if dd else None,
    }


def fmt(m):
    return (f"| {m['name']:<26} | {m['n']:>3} | {m['win']:>6.1f}% | {m['avg']:>6.2f}% | {m['med']:>6.2f}% | "
            f"{m['avg_dd']:>6.2f}% | {m['max_dd']:>6.2f}% |")


def main():
    rows = load_records()
    sh = load_sh_history()
    mp_dates = main_pick_dates()

    # 逐日算板块指数信号(复用 index_guide 算法, 不落盘)
    sec_sig = {}
    for dt in mp_dates:
        s = sector_index_for(dt, persist=False)
        if s:
            sec_sig[dt] = s
    if not sec_sig:
        print("无板块指数信号可用")
        return

    # 只保留 有板块信号 且 有推荐记录 的日期
    picks = []
    for r in rows:
        if r["date"] in sec_sig:
            picks.append(r)

    t1_lows = fetch_t1_lows(picks)
    for r in picks:
        low = t1_lows.get((r["code"], t1_day(r["date"])))
        r["dd"] = (low / r["buy"] - 1) * 100 if (low and r["buy"]) else None
        s = sec_sig[r["date"]]
        shs = sh.get(r["date"]) or {}
        r["sec_up"] = s.get("direction") == "up"
        r["sh_up"] = shs.get("ret_pct") is not None and shs.get("ret_pct") > 0
        r["sh_ma20"] = shs.get("above_ma20")

    lines = []
    lines.append("# 板块指数(首推+备用板块)信号回测\n")
    lines.append(f"样本: {len(picks)} 笔推荐, 覆盖 {len(set(p['date'] for p in picks))} 个有首推板块且有推荐的交易日 "
                 f"({min(sec_sig)} → {max(sec_sig)})。\n")
    lines.append("口径: 卖点=次日10:30; 买入=前复权收盘; T+1回撤=(T+1日最低/买入-1)×100。"
                 "板块指数=当日首推+备用板块全部成分股, 总股本加权, 今日vs上一交易日。\n")
    lines.append("> 小样本(约15笔), 且新浪板块成分是当前快照(存在存活偏差), 仅作方向提示。\n")
    lines.append("| 门槛 | N | 胜率10:30 | 均T+1 | 中位T+1 | 均T+1回撤 | 最大回撤 |")
    lines.append("|---|--:|--:|--:|--:|--:|--:|")

    def ev(name, gate):
        m = metrics([p for p in picks if gate(p)])
        if m:
            m["name"] = name
            lines.append(fmt(m))

    ev("无门槛(全部)", lambda p: True)
    ev("板块指数 升(今日>昨日)", lambda p: p["sec_up"])
    ev("板块指数 降(今日<昨日)", lambda p: not p["sec_up"])
    ev("上证当日上涨", lambda p: p["sh_up"])
    ev("板块升 且 上证涨", lambda p: p["sec_up"] and p["sh_up"])
    ev("板块升 且 上证>MA20", lambda p: p["sec_up"] and p["sh_ma20"])

    report = "\n".join(lines)
    with open(os.path.join(BASE, "data", "backtest_sector_index_report.md"), "w", encoding="utf-8") as f:
        f.write(report)
    print(report)
    print("\n逐日板块指数信号:")
    for dt in sorted(sec_sig):
        s = sec_sig[dt]
        names = "、".join(x["name"] for x in s["sectors"])
        print(f"  {dt}: {names} 成分{s['n_constituents']}只 chg={s['chg_pct']:+.2f}% {s['direction']}")


if __name__ == "__main__":
    main()
