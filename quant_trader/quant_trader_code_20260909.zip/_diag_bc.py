import os, sys
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')
import dragon_strategy as D, sim_t5 as S

st = D._load_store()
print("=== DRAGON store asof", st.get('asof'), 'positions', len(st.get('positions', [])), 'trades', len(st.get('trades', [])))
for t in st.get('trades', []):
    print('  ', t.get('name'), t.get('code'), 'in', t.get('entry_date'), 'out', t.get('exit_date'),
          'ret=%.2f%%' % t.get('ret_pct', 0), 'days', t.get('days_held'), t.get('tag'))

asof = S._local_latest_date()
mb = S._load_main_backup(asof)
res = mb['主推']
print("=== MAIN asof", asof, 'total=%.2f closed=%d win=%d float=%.2f' % (res['total'], res['n_closed'], res['n_win'], res['float']))
for t in res['trades']:
    print('  ', t['name'], t['code'], 'in', t['entry'], 'out', t['exit'],
          '%.2f%%' % t['ret_pct'], 'pnl=%.2f' % t['pnl'], t['tag'], '%ddays' % t['days'])

# also show open dragon positions
print("=== DRAGON open positions ===")
for p in st.get('positions', []):
    if p.get('status') == '持仓':
        print('  ', p.get('name'), p.get('code'), 'in', p.get('entry_date'), 'ep', p.get('entry_price'), 'days', p.get('days_held'))
