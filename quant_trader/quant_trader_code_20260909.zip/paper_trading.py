"""
模拟盘模块
面向未知数据的策略模拟交易。
与回测不同：从当前日期向前运行，逐日记录策略信号和买卖点。
持久化到本地，支持分析。
"""
import json, os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
from stock_api import StockAPI
from data_loader import get_hist_data, get_trade_dates
from strategies import (QiaoBangZhu, YiShunLiuGuang, ChaoGuYangJia,
                        TuiXueChaoGu, DaBan, LongTou, HuanFang,
                        HuanFangDynamic, WeiPan, KeBi, ChenXiaoQun,
                        ZhuMingCiKe, ChanLun, YeaRenDiXi, YeaRenErCiHuiCai,
                        YeaRenQiangGengQiang, AoshuWeiPan, DaMao2BJieLi,
                        ChenXiaoQunShouBan, ZuiJiuDaLa, YaoTouSanMoShi)
from collections import defaultdict
from serenity_strategy import ZiSuYe

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "paper_trading")

# 所有策略
ALL_STRATEGIES = [
    ("乔帮主·低吸反弹",   QiaoBangZhu()),
    ("一瞬流光·趋势跟踪", YiShunLiuGuang()),
    ("炒股养家·情绪接力", ChaoGuYangJia()),
    ("退学炒股·逆势交易", TuiXueChaoGu()),
    ("涨停打板·短线博弈", DaBan()),
    ("龙头战法·强者恒强", LongTou()),
    ("幻方量化·多因子改进", HuanFang()),
]

# 跟踪股票池（核心资产 + 用户关注的）
TRACK_CODES = [
    "000001", "000002", "000333", "000651", "000858", "000725",
    "002415", "002475", "002594", "300059", "300750", "600000",
    "600036", "600276", "600519", "600887", "600900", "601166",
    "601318", "601398", "603259", "688981",
    # 紫苏叶瓶颈标的
    "603186", "688720", "688629", "300100",
]


def _trade_path():
    os.makedirs(DATA_DIR, exist_ok=True)
    return os.path.join(DATA_DIR, "trades.json")


def _snapshot_path():
    return os.path.join(DATA_DIR, "snapshots.json")


def _signal_log_path():
    return os.path.join(DATA_DIR, "signal_log.json")


class PaperTradingEngine:
    """模拟盘引擎"""

    # 【修复】模拟盘添加滑点和手续费
    SLIPPAGE = 0.001        # 0.1% 滑点
    COMMISSION_RATE = 0.0003  # 万3佣金
    STAMP_TAX_RATE = 0.001    # 千1印花税

    def __init__(self):
        self.trades = []       # 已完成的交易
        self.positions = {}    # 当前持仓 {code: {entry_date, entry_price, quantity, strategy}}
        self.signal_log = []   # 每日信号日志
        self.snapshots = []    # 每日市值快照
        self._load()

    # ── 持久化 ──

    def _load(self):
        try:
            p = _trade_path()
            if os.path.exists(p):
                with open(p, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.trades = data.get("trades", [])
                    self.positions = data.get("positions", {})
        except Exception:
            self.trades = []
            self.positions = {}
        try:
            p = _snapshot_path()
            if os.path.exists(p):
                with open(p, "r", encoding="utf-8") as f:
                    self.snapshots = json.load(f)
        except Exception:
            self.snapshots = []
        try:
            p = _signal_log_path()
            if os.path.exists(p):
                with open(p, "r", encoding="utf-8") as f:
                    self.signal_log = json.load(f)
        except Exception:
            self.signal_log = []

    def _save(self):
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(_trade_path(), "w", encoding="utf-8") as f:
            json.dump({"trades": self.trades, "positions": self.positions}, f,
                      ensure_ascii=False, indent=2, default=str)
        with open(_signal_log_path(), "w", encoding="utf-8") as f:
            json.dump(self.signal_log[-2000:], f, ensure_ascii=False, indent=2, default=str)
        with open(_snapshot_path(), "w", encoding="utf-8") as f:
            json.dump(self.snapshots[-500:], f, ensure_ascii=False, indent=2, default=str)

    def get_data(self):
        """返回完整数据"""
        return {
            "trades": self.trades,
            "positions": self.positions,
            "signal_log": self.signal_log,
            "snapshots": self.snapshots,
        }

    # ── 逐日运行 ──

    def daily_run(self, date_obj=None):
        """每日运行：获取数据 → 运行策略 → 记录信号 → 处理交易"""
        if date_obj is None:
            date_obj = datetime.now()
        if date_obj.weekday() >= 5:
            return {"status": "非交易日，跳过"}

        date_str = date_obj.strftime("%Y%m%d")
        lookback = date_obj - timedelta(days=120)
        start_str = lookback.strftime("%Y%m%d")

        # 1. 获取全市场行情 + 历史数据
        quotes = StockAPI.get_realtime_quotes()
        if quotes.empty:
            return {"status": "行情数据为空"}

        results = []
        hist_cache = {}

        def process_stock(code):
            try:
                row = quotes[quotes["code"] == code]
                if row.empty:
                    return None
                r = row.iloc[0]
                name = r.get("name", "")
                price = float(r["price"]) if pd.notna(r.get("price")) else 0
                sector = str(r.get("industry", r.get("sector", "")))
                if price <= 0:
                    return None
                hist = StockAPI.get_historical_data(code, start_str, date_str)
                if hist is None or len(hist) < 30:
                    return None
                return {"code": code, "name": name, "price": price, "sector": sector,
                        "hist": hist, "hist_len": len(hist)}
            except Exception:
                return None

        codes = list(self.positions.keys()) if self.positions else TRACK_CODES
        # 也扫描全市场找新机会
        all_codes = list(set(codes + TRACK_CODES))

        with ThreadPoolExecutor(max_workers=8) as executor:
            futures = {executor.submit(process_stock, c): c for c in all_codes}
            for f in as_completed(futures):
                try:
                    res = f.result()
                    if res:
                        results.append(res)
                        hist_cache[res["code"]] = res["hist"]
                except Exception:
                    pass

        if not results:
            return {"status": "无可用数据"}

        # 2. 运行策略
        date_signals = []
        for item in results:
            code, name, price, sector = item["code"], item["name"], item["price"], item["sector"]
            hist = item["hist"]
            triggered = []
            for sname, stg in ALL_STRATEGIES:
                try:
                    sdf = stg.generate_signals(hist.copy())
                    if "signal" in sdf.columns:
                        last_sig = sdf["signal"].iloc[-1]
                        if last_sig > 0:
                            triggered.append({"strategy": sname, "signal": int(last_sig)})
                except Exception:
                    pass

            sig_count = len(triggered)
            if sig_count > 0:
                date_signals.append({
                    "date": date_str, "code": code, "name": name,
                    "price": round(price, 2), "sector": sector,
                    "signal_count": sig_count,
                    "signals": triggered,
                })

        # 3. 记录信号日志
        self.signal_log.append({
            "date": date_str,
            "signals": date_signals,
            "analyzed_at": datetime.now().strftime("%H:%M:%S"),
        })

        # 4. 处理交易信号
        new_trades = []
        signaled_codes = {s["code"] for s in date_signals}

        # 4a. 持仓股票：检查卖出信号
        for code in list(self.positions.keys()):
            pos = self.positions[code]
            if code not in signaled_codes:
                # 无信号则不操作
                continue
            sig_info = next((s for s in date_signals if s["code"] == code), None)
            if sig_info and sig_info["signal_count"] >= 3:
                # 仍有信号，继续持有
                pos["current_price"] = sig_info["price"]
                pos["last_signal_date"] = date_str
            elif sig_info and sig_info["signal_count"] <= 1:
                # 信号减弱，卖出
                exit_price = sig_info["price"] * (1 - self.SLIPPAGE)
                entry_price = float(pos.get("entry_price", 0))
                quantity = int(pos.get("quantity", 100))
                revenue = exit_price * quantity
                commission = revenue * self.COMMISSION_RATE
                stamp_tax = revenue * self.STAMP_TAX_RATE
                net_revenue = revenue - commission - stamp_tax
                cost = entry_price * quantity
                ret = ((net_revenue / cost) - 1) * 100 if cost > 0 else 0
                trade = {
                    "date": date_str, "code": code, "name": pos.get("name", ""),
                    "action": "sell", "price": round(exit_price, 2),
                    "quantity": quantity,
                    "entry_date": pos.get("entry_date", ""),
                    "entry_price": entry_price,
                    "commission": round(commission, 2),
                    "stamp_tax": round(stamp_tax, 2),
                    "revenue": round(revenue, 2),
                    "net_revenue": round(net_revenue, 2),
                    "return_pct": round(ret, 2),
                    "strategy": pos.get("strategy", ""),
                    "reason": f"信号减弱({sig_info['signal_count']}个)",
                }
                self.trades.append(trade)
                new_trades.append(trade)
                del self.positions[code]

        # 4b. 非持仓股票：检查买入信号
        for sig in date_signals:
            code = sig["code"]
            if code in self.positions:
                continue
            if sig["signal_count"] >= 2:  # 至少2个策略同时看多
                buy_price = sig["price"] * (1 + self.SLIPPAGE)
                quantity = 100
                cost = buy_price * quantity
                commission = cost * self.COMMISSION_RATE
                self.positions[code] = {
                    "entry_date": date_str,
                    "entry_price": buy_price,
                    "quantity": quantity,
                    "strategy": "+".join(s["strategy"] for s in sig["signals"][:3]),
                    "signal_count": sig["signal_count"],
                    "name": sig["name"],
                    "sector": sig.get("sector", ""),
                    "current_price": sig["price"],
                    "last_signal_date": date_str,
                }
                trade = {
                    "date": date_str, "code": code, "name": sig["name"],
                    "action": "buy", "price": round(buy_price, 2),
                    "quantity": quantity, "cost": round(cost, 2),
                    "commission": round(commission, 2),
                    "strategy": sig["signals"][0]["strategy"] if sig["signals"] else "",
                    "signal_count": sig["signal_count"],
                    "reason": f"{sig['signal_count']}个策略触发买入",
                }
                self.trades.append(trade)
                new_trades.append(trade)

        # 5. 市值快照
        total_value = 0
        pos_details = []
        for code, pos in self.positions.items():
            cur_price = pos.get("current_price", pos.get("entry_price", 0))
            mv = cur_price * pos.get("quantity", 100)
            total_value += mv
            pos_details.append({
                "code": code, "name": pos.get("name", ""),
                "entry_price": pos["entry_price"], "current_price": cur_price,
                "quantity": pos.get("quantity", 100),
                "market_value": round(mv, 2),
                "return_pct": round((cur_price / pos["entry_price"] - 1) * 100, 2),
            })
        self.snapshots.append({
            "date": date_str,
            "total_value": round(total_value, 2),
            "position_count": len(self.positions),
            "positions": pos_details,
        })

        # 6. 持久化
        self._save()

        return {
            "status": "ok",
            "date": date_str,
            "new_signals": len(date_signals),
            "new_trades": len(new_trades),
            "positions": len(self.positions),
            "total_value": round(total_value, 2),
        }

    # ---------- 历史回测 ----------

    def backtest_history(self, days=120, start_capital=100000):
        """回测历史表现：逐日模拟交易，不修改真实trades/positions"""
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        lookback_start = start_date - timedelta(days=150)

        sb = lookback_start.strftime("%Y%m%d")
        se = end_date.strftime("%Y%m%d")

        # 1. 批量预取历史数据
        hist_data = {}
        names = {}
        for code in TRACK_CODES:
            h = StockAPI.get_historical_data(code, sb, se)
            if h is not None and len(h) >= 60:
                h["date_str"] = h["date"].dt.strftime("%Y%m%d")
                hist_data[code] = h.reset_index(drop=True)
                if not h.empty:
                    names[code] = h["name"].iloc[0] if "name" in h.columns else ""

        if not hist_data:
            return {"status": "无足够历史数据", "trades": [], "equity_curve": []}

        # 2. 交易日历（所有有数据的工作日）
        all_dates = sorted(set(
            d for h in hist_data.values()
            for d in h["date_str"].values
        ))
        trade_dates = [
            d for d in all_dates
            if start_date.strftime("%Y%m%d") <= d <= end_date.strftime("%Y%m%d")
            and datetime.strptime(d, "%Y%m%d").weekday() < 5
        ]

        if len(trade_dates) < 5:
            return {"status": f"交易日太少({len(trade_dates)})", "trades": [], "equity_curve": []}

        # 3. 逐日模拟
        positions = {}       # code -> {entry_date, entry_price, quantity, strategy, name}
        trades = []          # 已完成的交易
        equity_curve = []    # 每日市值
        cash = start_capital

        def _get_day_price(code, ds):
            h = hist_data.get(code)
            if h is None:
                return None
            row = h[h["date_str"] == ds]
            if row.empty:
                return None
            return float(row["close"].iloc[0])

        # 记录初始状态
        equity_curve.append({
            "date": trade_dates[0] if trade_dates else start_date.strftime("%Y%m%d"),
            "value": round(cash, 2), "cash": round(cash, 2), "positions": 0,
        })

        for date_str in trade_dates:
            date_obj = datetime.strptime(date_str, "%Y%m%d")

            # 收集当日信号
            daily_signals = []
            for code, hist in hist_data.items():
                # 截至当日的数据
                mask = hist["date"] <= date_obj
                up_to = hist[mask].reset_index(drop=True)
                if len(up_to) < 30:
                    continue

                price = _get_day_price(code, date_str)
                if price is None or price <= 0:
                    continue

                name = names.get(code, "")

                # 运行所有策略
                triggered = []
                for sname, stg in ALL_STRATEGIES:
                    try:
                        sdf = stg.generate_signals(up_to.copy())
                        if "signal" in sdf.columns and sdf["signal"].iloc[-1] > 0:
                            triggered.append({"strategy": sname, "signal": int(sdf["signal"].iloc[-1])})
                    except Exception:
                        pass

                if triggered:
                    daily_signals.append({
                        "code": code, "name": name, "price": price,
                        "signal_count": len(triggered),
                        "signals": triggered,
                    })

            signaled_codes = {s["code"] for s in daily_signals}

            # 卖出检查
            for code in list(positions.keys()):
                pos = positions[code]
                if code in signaled_codes:
                    sig = next((s for s in daily_signals if s["code"] == code), None)
                    if sig and sig["signal_count"] >= 2:
                        pos["current_price"] = sig["price"]
                        continue
                # 信号不足或无信号 → 卖出
                exit_price = _get_day_price(code, date_str)
                if exit_price is None:
                    exit_price = pos.get("current_price", pos["entry_price"])
                exit_price *= (1 - self.SLIPPAGE)
                entry_price = float(pos["entry_price"])
                quantity = int(pos.get("quantity", 100))
                revenue = exit_price * quantity
                commission = revenue * self.COMMISSION_RATE
                stamp_tax = revenue * self.STAMP_TAX_RATE
                net_revenue = revenue - commission - stamp_tax
                cost = entry_price * quantity
                ret = ((net_revenue / cost) - 1) * 100 if cost > 0 else 0

                trades.append({
                    "date": date_str, "code": code, "name": pos.get("name", ""),
                    "action": "sell", "price": round(exit_price, 2),
                    "quantity": quantity, "entry_date": pos.get("entry_date", ""),
                    "entry_price": entry_price, "return_pct": round(ret, 2),
                    "commission": round(commission, 2), "stamp_tax": round(stamp_tax, 2),
                    "revenue": round(revenue, 2), "strategy": pos.get("strategy", ""),
                })
                cash += net_revenue
                del positions[code]

            # 买入检查
            for sig in daily_signals:
                code = sig["code"]
                if code in positions:
                    continue
                if sig["signal_count"] >= 2:
                    buy_price = sig["price"] * (1 + self.SLIPPAGE)
                    quantity = 100
                    cost_q = buy_price * quantity
                    if cost_q > cash:
                        continue
                    commission = cost_q * self.COMMISSION_RATE
                    cash -= (cost_q + commission)
                    positions[code] = {
                        "entry_date": date_str, "entry_price": buy_price,
                        "quantity": quantity, "current_price": sig["price"],
                        "strategy": "+".join(s["strategy"] for s in sig["signals"][:3]),
                        "name": sig["name"],
                    }
                    trades.append({
                        "date": date_str, "code": code, "name": sig["name"],
                        "action": "buy", "price": round(buy_price, 2),
                        "quantity": quantity, "cost": round(cost_q, 2),
                        "commission": round(commission, 2),
                        "strategy": sig["signals"][0]["strategy"] if sig["signals"] else "",
                        "signal_count": sig["signal_count"],
                    })

            # 市值快照
            total_value = cash + sum(
                pos.get("current_price", pos["entry_price"]) * pos.get("quantity", 100)
                for pos in positions.values()
            )
            equity_curve.append({
                "date": date_str, "value": round(total_value, 2),
                "cash": round(cash, 2), "positions": len(positions),
            })

        # 4. 绩效分析
        buy_trades = [t for t in trades if t["action"] == "buy"]
        sell_trades = [t for t in trades if t["action"] == "sell"]
        closed = [t for t in sell_trades if isinstance(t.get("return_pct"), (int, float))]

        wins = [t for t in closed if t["return_pct"] > 0]
        win_rate = len(wins) / len(closed) * 100 if closed else 0
        avg_ret = np.mean([t["return_pct"] for t in closed]) if closed else 0
        total_ret = sum(t["return_pct"] for t in closed) if closed else 0
        max_ret = max((t["return_pct"] for t in closed), default=0)
        min_ret = min((t["return_pct"] for t in closed), default=0)

        # 按策略分组
        strategy_perf = defaultdict(lambda: {"trades": [], "wins": 0, "total_return": 0})
        for t in closed:
            st = t.get("strategy", "未知")
            strategy_perf[st]["trades"].append(t)
            strategy_perf[st]["total_return"] += t["return_pct"]
            if t["return_pct"] > 0:
                strategy_perf[st]["wins"] += 1

        strategy_summary = []
        for st, data in strategy_perf.items():
            n = len(data["trades"])
            strategy_summary.append({
                "strategy": st, "trades": n,
                "win_rate": round(data["wins"] / n * 100, 1) if n > 0 else 0,
                "total_return": round(data["total_return"], 2),
                "avg_return": round(data["total_return"] / n, 2) if n > 0 else 0,
            })

        return {
            "status": "ok",
            "date_range": f"{trade_dates[0]} ~ {trade_dates[-1]}",
            "trading_days": len(trade_dates),
            "start_capital": start_capital,
            "final_value": round(equity_curve[-1]["value"], 2) if equity_curve else start_capital,
            "total_return_pct": round((equity_curve[-1]["value"] / start_capital - 1) * 100, 2) if equity_curve else 0,
            "total_trades": len(trades),
            "buy_count": len(buy_trades),
            "sell_count": len(sell_trades),
            "closed_trades": len(closed),
            "win_rate": round(win_rate, 1),
            "avg_return": round(avg_ret, 2),
            "total_return": round(total_ret, 2),
            "max_return": round(max_ret, 2),
            "min_return": round(min_ret, 2),
            "strategy_performance": strategy_summary,
            "trades": trades,
            "equity_curve": equity_curve,
        }

    def analyze(self):
        """分析模拟盘表现"""
        total_trades = len(self.trades)
        buy_trades = [t for t in self.trades if t["action"] == "buy"]
        sell_trades = [t for t in self.trades if t["action"] == "sell"]
        closed = [t for t in sell_trades if isinstance(t.get("return_pct"), (int, float))]

        # 胜率
        wins = [t for t in closed if t["return_pct"] > 0]
        win_rate = len(wins) / len(closed) * 100 if closed else 0

        # 收益率
        avg_ret = np.mean([t["return_pct"] for t in closed]) if closed else 0
        total_ret = sum(t["return_pct"] for t in closed) if closed else 0
        max_ret = max((t["return_pct"] for t in closed), default=0)
        min_ret = min((t["return_pct"] for t in closed), default=0)

        # 按策略分组
        strategy_perf = {}
        for t in closed:
            st = t.get("strategy", "未知")
            if st not in strategy_perf:
                strategy_perf[st] = {"trades": [], "wins": 0, "total_return": 0}
            strategy_perf[st]["trades"].append(t)
            strategy_perf[st]["total_return"] += t["return_pct"]
            if t["return_pct"] > 0:
                strategy_perf[st]["wins"] += 1

        strategy_summary = []
        for st, data in strategy_perf.items():
            n = len(data["trades"])
            strategy_summary.append({
                "strategy": st,
                "trades": n,
                "win_rate": round(data["wins"] / n * 100, 1) if n > 0 else 0,
                "total_return": round(data["total_return"], 2),
                "avg_return": round(data["total_return"] / n, 2) if n > 0 else 0,
            })

        # 当前持仓收益
        pos_returns = []
        for code, pos in self.positions.items():
            entry = pos.get("entry_price", 0)
            cur = pos.get("current_price", entry)
            ret = (cur / entry - 1) * 100 if entry > 0 else 0
            pos_returns.append({"code": code, "name": pos.get("name", ""),
                                "return_pct": round(ret, 2)})

        # 每日市值曲线
        equity_curve = []
        for s in self.snapshots:
            equity_curve.append({"date": s["date"], "value": s["total_value"]})

        return {
            "total_trades": total_trades,
            "buy_count": len(buy_trades),
            "sell_count": len(sell_trades),
            "closed_trades": len(closed),
            "win_rate": round(win_rate, 1),
            "avg_return": round(avg_ret, 2),
            "total_return": round(total_ret, 2),
            "max_return": round(max_ret, 2),
            "min_return": round(min_ret, 2),
            "current_positions": len(self.positions),
            "strategy_performance": strategy_summary,
            "position_returns": pos_returns,
            "equity_curve": equity_curve,
        }


# ═══════════════════════════════════════════════════════════
#   Agent辩论 + 对冲组合 双模式模拟对比
# ═══════════════════════════════════════════════════════════

# Agent 策略池（优化后: 仅保留10个正收益策略）
AGENT_STRATEGIES = {
    "低吸猎手":   ["野人·低吸战法", "野人·二次回踩"],
    "打板先锋":   ["野人·强更强", "大毛哥·2B接力", "摇头哥·三模式"],
    "趋势追踪者": ["炒股养家·情绪接力", "龙头战法·强者恒强", "缠论·分型中枢"],
    "量化军师":   ["幻方量化·多因子改进", "幻方量化·动态多因子"],
}

AGENT_WEIGHTS = {"低吸猎手": 1.0, "打板先锋": 1.0, "趋势追踪者": 1.0, "量化军师": 1.0}

# 策略名称 → 实例（预创建缓存，避免重复实例化）
_STRAT_INSTANCES = {
    "乔帮主·低吸反弹": QiaoBangZhu(), "一瞬流光·趋势跟踪": YiShunLiuGuang(),
    "炒股养家·情绪接力": ChaoGuYangJia(), "退学炒股·逆势交易": TuiXueChaoGu(),
    "涨停打板·短线博弈": DaBan(), "龙头战法·强者恒强": LongTou(),
    "幻方量化·多因子改进": HuanFang(), "幻方量化·动态多因子": HuanFangDynamic(),
    "尾盘选股·尾盘动量": WeiPan(), "92科比·首板挖掘": KeBi(),
    "陈小群·龙头二波": ChenXiaoQun(), "著名刺客·分歧转一致": ZhuMingCiKe(),
    "缠论·分型中枢": ChanLun(), "野人·低吸战法": YeaRenDiXi(),
    "野人·二次回踩": YeaRenErCiHuiCai(), "野人·强更强": YeaRenQiangGengQiang(),
    "奥数老师·尾盘量化": AoshuWeiPan(), "大毛哥·2B接力": DaMao2BJieLi(),
    "陈小群·首板战法": ChenXiaoQunShouBan(), "醉酒大佬·放量长上影": ZuiJiuDaLa(),
    "摇头哥·三模式": YaoTouSanMoShi(),
    "紫苏叶·瓶颈选股": ZiSuYe(),
}

_agent_vote_cache = {}        # {(code, date_str): vote_result}
_strategy_signal_cache = {}   # {code: {strategy_name: signal_array}}

# 对冲组合档位
TIERS = {
    "1w": {"name": "1万元组合", "max_amount": 10000, "max_positions": 3},
    "5k": {"name": "5000元组合", "max_amount": 5000,  "max_positions": 2},
    "2k": {"name": "2000元组合", "max_amount": 2000,  "max_positions": 2},
}

# 股票池
CODES = [
    "000001", "000002", "000333", "000651", "000858", "000725",
    "002415", "002475", "002594", "300059", "300750", "600000",
    "600036", "600276", "600519", "600887", "600900", "601166",
    "601318", "601398", "603259", "688981",
    # 紫苏叶瓶颈标的
    "603186", "688720", "688629", "300100",
]




def _get_day_agent_vote(code, hist, date_obj):
    """对单只股票在指定日期返回Agent投票结果（预计算信号数组 + 日缓存）"""
    date_str = date_obj if isinstance(date_obj, str) else date_obj.strftime("%Y%m%d")
    cache_key = (code, date_str)
    cached = _agent_vote_cache.get(cache_key)
    if cached is not None:
        return cached

    # 首次遇到该股票时，一次性预计算所有策略的全量信号数组
    if code not in _strategy_signal_cache:
        sigs = {}
        for sname, stg in _STRAT_INSTANCES.items():
            try:
                sdf = stg.generate_signals(hist.copy())
                if "signal" in sdf.columns:
                    sigs[sname] = sdf["signal"].values
            except Exception:
                pass
        _strategy_signal_cache[code] = sigs

    # 定位当日行号
    row_idx = hist[hist["date_str"] == date_str].index
    if len(row_idx) == 0:
        return None
    ri = row_idx[0]
    if ri < 29:  # 数据不足30行
        _agent_vote_cache[cache_key] = None
        return None

    # 从预计算数组中读取当日信号
    triggered = set()
    sigs = _strategy_signal_cache[code]
    for sname in _STRAT_INSTANCES:
        sig_arr = sigs.get(sname)
        if sig_arr is not None and ri < len(sig_arr) and sig_arr[ri] > 0:
            triggered.add(sname)

    agent_votes = {}
    for aname, strats in AGENT_STRATEGIES.items():
        sw = sum(1 for s in strats if s in triggered)
        agent_votes[aname] = sw > 0

    voting_agents = [a for a, v in agent_votes.items() if v]
    weighted = sum(AGENT_WEIGHTS.get(a, 1.0) for a in voting_agents)

    result = {
        "triggered_strategies": triggered,
        "voting_agents": voting_agents,
        "voting_count": len(voting_agents),
        "weighted_score": weighted,
    }
    _agent_vote_cache[cache_key] = result
    return result


# ── 方法一: Agent辩论投票法 ──

def backtest_agent_vote(days=120, start_capital=100000, hist_data=None, names=None, trade_dates=None):
    """Agent辩论投票模拟: 按Agent共识度买入, 信号减弱卖出"""
    if hist_data is None:
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        lb = start_date - timedelta(days=150)
        hist_data, names = get_hist_data(
            CODES, lb.strftime("%Y%m%d"), end_date.strftime("%Y%m%d"))
        trade_dates = get_trade_dates(
            hist_data, start_date.strftime("%Y%m%d"), end_date.strftime("%Y%m%d"))

    if not hist_data or len(trade_dates) < 5:
        return {"status": "数据不足"}

    positions = {}
    trades = []
    cash = float(start_capital)
    equity_curve = [{"date": trade_dates[0], "value": cash, "cash": cash, "positions": 0}]

    SLIP, COMM, STAMP = 0.001, 0.0003, 0.001

    def _exp_t1(code_hist, up_to):
        """截至 up_to 前一日的历史预期T+1收益(最近20日次日收益均值)"""
        hh = code_hist[code_hist["date_str"] < up_to]
        if len(hh) < 22:
            return 0.0
        closes = hh["close"].tail(21).values
        return round(float(np.mean((closes[1:] / closes[:-1] - 1) * 100)), 3)

    for i, date_str in enumerate(trade_dates):
        date_obj = datetime.strptime(date_str, "%Y%m%d")

        daily_signals = []
        if i > 0:
            prev_date_obj = datetime.strptime(trade_dates[i-1], "%Y%m%d")
            for code, hist in hist_data.items():
                row = hist[hist["date_str"] == date_str]
                if row.empty:
                    continue
                price = float(row["close"].iloc[0])
                if price <= 0:
                    continue

                # 用前一日信号决定今日交易（剔除未来函数）
                vote = _get_day_agent_vote(code, hist, prev_date_obj)
                if vote is None or vote["voting_count"] == 0:
                    continue

                daily_signals.append({
                    "code": code, "name": names.get(code, ""), "price": price,
                    "voting": vote["voting_count"], "weighted": vote["weighted_score"],
                    "expected_return": _exp_t1(hist, date_str),
                    "vote": vote,
                })

        signaled_set = {s["code"] for s in daily_signals}

        for code in list(positions.keys()):
            pos = positions[code]
            if code in signaled_set:
                sig = next(s for s in daily_signals if s["code"] == code)
                if sig["voting"] >= 1 and sig["expected_return"] > 0:
                    pos["current_price"] = sig["price"]
                    continue
            # 卖出：用当日收盘价，非缓存价
            today_row = hist_data[code][hist_data[code]["date_str"] == date_str]
            cur_p = float(today_row["close"].iloc[0]) if not today_row.empty else pos.get("current_price", pos["entry_price"])
            exit_p = cur_p * (1 - SLIP)
            qty = int(pos["quantity"])
            rev = exit_p * qty
            net = rev - rev * COMM - rev * STAMP
            cost = float(pos["entry_price"]) * qty
            ret = (net / cost - 1) * 100 if cost > 0 else 0
            trades.append({"date": date_str, "code": code, "name": pos.get("name", ""),
                          "action": "sell", "price": round(exit_p, 2),
                          "quantity": qty, "return_pct": round(ret, 2)})
            cash += net
            del positions[code]

        for sig in sorted(daily_signals, key=lambda x: x["expected_return"], reverse=True):
            if sig["code"] in positions or sig["voting"] < 1 or sig["expected_return"] <= 0:
                continue
            buy_p = sig["price"] * (1 + SLIP)
            # 仓位: 每笔用50%可用资金
            qty = max(100, int(cash * 0.50 / buy_p / 100) * 100)
            lot = buy_p * qty
            if lot > cash:
                continue
            cash -= lot + lot * COMM
            agents = "+".join(sig["vote"]["voting_agents"])
            positions[sig["code"]] = {"entry_date": date_str, "entry_price": buy_p,
                                      "quantity": qty, "current_price": sig["price"],
                                      "name": sig["name"], "reason": agents}
            trades.append({"date": date_str, "code": sig["code"], "name": sig["name"],
                          "action": "buy", "price": round(buy_p, 2), "quantity": qty})

        pv = sum(p.get("current_price", p["entry_price"]) * p["quantity"] for p in positions.values())
        equity_curve.append({"date": date_str, "value": round(cash + pv, 2),
                            "cash": round(cash, 2), "positions": len(positions)})

    sells = [t for t in trades if t["action"] == "sell" and isinstance(t.get("return_pct"), (int, float))]
    wins = [t for t in sells if t["return_pct"] > 0]
    fv = equity_curve[-1]["value"] if equity_curve else start_capital
    return {"status": "ok", "method": "Agent辩论投票", "date_range": f"{trade_dates[0]}~{trade_dates[-1]}",
            "trading_days": len(trade_dates), "start_capital": start_capital, "final_value": fv,
            "total_return_pct": round((fv / start_capital - 1) * 100, 2),
            "total_trades": len(trades), "sell_count": len(sells),
            "win_rate": round(len(wins)/len(sells)*100, 1) if sells else 0,
            "avg_return": round(np.mean([t["return_pct"] for t in sells]), 2) if sells else 0,
            "equity_curve": equity_curve, "trades": trades}


# ── 方法二: 对冲组合T+1轮动法 ──

def backtest_daily_tier(days=120, start_capital=100000, hist_data=None, names=None, trade_dates=None):
    """对冲组合: 分档位分散持仓 + Agent辩论选股 + 信号驱动持有(非强制轮动)"""
    if hist_data is None:
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        lb = start_date - timedelta(days=150)
        hist_data, names = get_hist_data(
            CODES, lb.strftime("%Y%m%d"), end_date.strftime("%Y%m%d"))
        trade_dates = get_trade_dates(
            hist_data, start_date.strftime("%Y%m%d"), end_date.strftime("%Y%m%d"))

    if not hist_data or len(trade_dates) < 5:
        return {"status": "数据不足"}

    TIER_CFG = {"1w": {"budget": 10000, "max_pos": 3},
                "5k": {"budget": 5000,  "max_pos": 2},
                "2k": {"budget": 2000,  "max_pos": 2}}
    SLIP, COMM, STAMP = 0.001, 0.0003, 0.001
    MIN_VOTES = 2
    cash = float(start_capital)
    positions = {}  # {code: {tier, entry_price, qty, current_price, name, entry_date}}
    trades = []
    eq = [{"date": trade_dates[0], "value": cash, "cash": cash, "positions": 0}]

    for i, date_str in enumerate(trade_dates):
        if i == 0:
            eq.append({"date": date_str, "value": round(cash,2), "cash": round(cash,2), "positions": 0})
            continue
        prev_ds = trade_dates[i-1]
        prev_dt = datetime.strptime(prev_ds, "%Y%m%d")

        # 当日候选（用前一日Agent投票，剔除未来函数）
        candidates = []
        for code, hist in hist_data.items():
            row = hist[hist["date_str"] == date_str]
            if row.empty:
                continue
            price = float(row["close"].iloc[0])
            if price <= 0:
                continue
            vote = _get_day_agent_vote(code, hist, prev_dt)
            if vote and vote["voting_count"] > 0:
                candidates.append({"code": code, "name": names.get(code,""), "price": price,
                                   "voting": vote["voting_count"], "weighted": vote["weighted_score"],
                                   "lot_cost": price * 100})

        sig_set = {c["code"] for c in candidates}

        # ── 卖出：信号减弱至阈值以下 ──
        for code in list(positions.keys()):
            pos = positions[code]
            hold = False
            if code in sig_set:
                c = next(x for x in candidates if x["code"] == code)
                if c["voting"] >= MIN_VOTES:
                    pos["current_price"] = c["price"]
                    hold = True
            if hold:
                continue

            today_row = hist_data[code][hist_data[code]["date_str"] == date_str]
            cur_p = float(today_row["close"].iloc[0]) if not today_row.empty else pos.get("current_price", pos["entry_price"])
            exit_p = cur_p * (1 - SLIP)
            qty = int(pos["quantity"])
            rev = exit_p * qty
            net = rev - rev*COMM - rev*STAMP
            cost = float(pos["entry_price"]) * qty
            ret = (net/cost - 1)*100 if cost > 0 else 0
            trades.append({"date": date_str, "code": code, "name": pos.get("name",""),
                          "action": "sell", "price": round(exit_p,2), "quantity": qty,
                          "return_pct": round(ret,2), "tier": pos.get("tier","")})
            cash += net
            del positions[code]

        # ── 买入：候选分配给有空间的档位 ──
        candidates.sort(key=lambda x: x["weighted"], reverse=True)
        for c in candidates:
            if c["code"] in positions:
                continue
            buy_p = c["price"] * (1 + SLIP)

            # 计算各档位当前使用量
            tier_used = {t: {"amt": sum(p["entry_price"]*p["quantity"] for p in positions.values() if p["tier"]==t),
                             "cnt": sum(1 for p in positions.values() if p["tier"]==t)} for t in TIER_CFG}

            # 找能容纳的档位并按剩余预算计算仓位
            assigned = None
            qty = 0
            lot_act = 0
            for tn in ["1w", "5k", "2k"]:
                u = tier_used[tn]
                if u["cnt"] >= TIER_CFG[tn]["max_pos"]:
                    continue
                remaining = TIER_CFG[tn]["budget"] - u["amt"]
                # 用档位剩余预算的50%，至少100股
                qty_try = max(100, int(remaining * 0.5 / buy_p / 100) * 100)
                lot_try = buy_p * qty_try
                if lot_try <= cash and qty_try >= 100:
                    assigned = tn
                    qty = qty_try
                    lot_act = lot_try
                    break
            if assigned is None:
                continue

            cash -= lot_act + lot_act*COMM
            positions[c["code"]] = {"tier": assigned, "entry_date": date_str, "entry_price": buy_p,
                                   "quantity": qty, "current_price": c["price"], "name": c["name"]}
            trades.append({"date": date_str, "code": c["code"], "name": c["name"],
                          "action": "buy", "price": round(buy_p,2), "quantity": qty, "tier": assigned})

        pv = sum(p.get("current_price",p["entry_price"])*p["quantity"] for p in positions.values())
        eq.append({"date": date_str, "value": round(cash+pv,2), "cash": round(cash,2), "positions": len(positions)})

    sells = [t for t in trades if t["action"]=="sell" and isinstance(t.get("return_pct"),(int,float))]
    wins = [t for t in sells if t["return_pct"] > 0]
    fv = eq[-1]["value"] if eq else start_capital
    return {"status": "ok", "method": "对冲组合(信号持有)", "date_range": f"{trade_dates[0]}~{trade_dates[-1]}",
            "trading_days": len(trade_dates), "start_capital": start_capital, "final_value": fv,
            "total_return_pct": round((fv/start_capital-1)*100,2),
            "total_trades": len(trades), "sell_count": len(sells),
            "win_rate": round(len(wins)/len(sells)*100,1) if sells else 0,
            "avg_return": round(np.mean([t["return_pct"] for t in sells]),2) if sells else 0,
            "equity_curve": eq, "trades": trades}


# ── 对比运行 ──

def backtest_compare(days=120, start_capital=100000):
    """运行两种方法的回测并对比（共享同一份历史数据，避免重复拉取）"""
    _agent_vote_cache.clear()
    _strategy_signal_cache.clear()
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)
    lb = start_date - timedelta(days=150)
    hist_data, names = get_hist_data(
        CODES, lb.strftime("%Y%m%d"), end_date.strftime("%Y%m%d"))
    trade_dates = get_trade_dates(
        hist_data, start_date.strftime("%Y%m%d"), end_date.strftime("%Y%m%d"))

    result1 = backtest_agent_vote(days, start_capital, hist_data, names, trade_dates)
    result2 = backtest_daily_tier(days, start_capital, hist_data, names, trade_dates)
    return {"agent_vote": result1, "daily_tier": result2}


# 全局实例
engine = PaperTradingEngine()
