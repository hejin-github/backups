# -*- coding: utf-8 -*-
"""主推/龙头 断板止盈+时间止损5日 模拟总览 — 2026-09-01

主推: 用 dragon_strategy._recompute_pos(T5纪律, 与 slot 仿真一致) 重放历史推荐.
龙头: 读取 data/dragon_positions.json live 仓(状态机推进并落盘).
备用轨已于2026-09-01关闭: 不再推荐交易/不再进模拟, 历史备用文件保留但不再重放.
数据源: 本地 market_bars(读取优先, 免网络) — 与盘后刷新联动.
费用:   每笔独立¥6,000(2026-09-02上调), 整手, 佣金万2.5(最低¥5)/印花税0.05%卖/过户费万0.1.
提醒:   detail/持仓带"操作"列(买入→次日开盘买入; 持有→连板/破5日线/时间止损理由; 卖出→断板/时间止损).
用法:   from sim_t5 import three_track_overview
"""
import json
import os
from datetime import datetime, timedelta

import pandas as pd

from stock_api import StockAPI
from scheduler import _next_trading_day, is_trading_day
from strategy_backtest import _prev_trading_day
import dragon_strategy as D

BASE = os.path.dirname(os.path.abspath(__file__))
REC_DIR = os.path.join(BASE, "data", "recommendations")
CAPITAL = 6000.0   # 单笔预算 ¥6,000(2026-09-02 上调, 便于高价股整手)
LOT = 100
COMMISSION = 0.00025
MIN_COMMISSION = 5.0
STAMP = 0.0005
TRANSFER = 0.00001
MAIN_WINRATE_MIN = 52    # 主推重放质控门槛: 仅重放 win_rate>=此值的强信号(None=不过滤); 与辩论/龙头52%一致.

def _qty(price):
    return int(CAPITAL / price / LOT) * LOT if price and price > 0 else 0


def _net(buy_px, sell_px, qty):
    """整笔净盈亏¥: 卖回款 - 卖费 - 买额 - 买费."""
    buy = buy_px * qty
    sell = sell_px * qty
    bc = max(MIN_COMMISSION, buy * COMMISSION) + buy * TRANSFER
    sc = max(MIN_COMMISSION, sell * COMMISSION) + sell * STAMP + sell * TRANSFER
    return sell - sc - buy - bc


def _entry_date(signal):
    """信号日下一交易日 = 入场日(与 T+1 模型一致)."""
    return _next_trading_day(datetime.strptime(signal, "%Y%m%d") + timedelta(days=1)).strftime("%Y%m%d")


def _local_hist(code, entry_date, asof):
    start = (datetime.strptime(entry_date, "%Y%m%d") - timedelta(days=30)).strftime("%Y%m%d")
    try:
        h = StockAPI.get_historical_data(code, start, asof, adjust="qfq")  # 本地读取优先
    except Exception:
        return None
    if h is None or h.empty:
        return h
    # 双保险: 显式传了今天(盘中)时, 裁掉 asof 之后任何bar, 与 _fetch_hist_cached 口径一致, 防盘中实时bar混入
    return h[h["date"] <= pd.Timestamp(asof)].reset_index(drop=True)


def _sell_reason(tag):
    """卖出原因(全句提醒): tag → 一句话说明为什么卖."""
    if tag == "断板":
        return "断板止盈：涨停连板中断，按纪律收盘卖出(持仓底仓当日可卖；入场当日断板依T+1顺延次日)"
    if tag == "时间止损":
        return "时间止损：持满5日，收盘卖出"
    if tag == "移动止盈":
        return "移动止盈：持仓转盈后从峰值回撤达阈值离场(让利润奔跑)"
    if tag == "止损(自适应)":
        return "自适应止损：按持仓自身波动率设回撤阈值，收盘触发离场"
    if str(tag).startswith("止损("):
        return f"破位止损：{tag[3:-1]}，收盘触发离场"
    return tag or ""


def _risk_tip(hist, days_held, asof):
    """盘中风险/回撤注意点(提示, 非强制平仓; 强制卖仅断板/时间止损).
    - 浮盈自持仓最高收盘回撤≥8% → 止盈保护提示;
    - 已破5日线 → 明日不涨停收盘离场; 持满4日 → 明日时间止损."""
    h = hist[hist["date"] <= pd.Timestamp(asof)].reset_index(drop=True)
    if h.empty:
        return ""
    try:
        days_held = int(days_held or 0)
    except (TypeError, ValueError):
        days_held = 0
    if days_held >= D.TIME_STOP:
        return ""
    if days_held == D.TIME_STOP - 1:
        return "⚠️明日时间止损到期，尾盘不封板即离场"
    try:
        entry_px = float(hist["close"].iloc[0])  # 近似锚, 仅用于回撤比率
    except (IndexError, TypeError, ValueError):
        return ""
    peak = float(h["close"].max())
    if peak > entry_px > 0:
        pull = (peak - float(h["close"].iloc[-1])) / peak * 100
        if pull >= 8:
            return f"⚠️浮盈回撤{pull:.0f}%≥8%保护线，建议尾盘主动止盈"
    close = float(h["close"].iloc[-1])
    ma5 = float(h["close"].tail(5).mean()) if len(h) >= 5 else None
    if ma5 is not None and close < ma5:
        return "⚠️已破5日线，明日不涨停收盘离场"
    return "盘中纪律：涨停打开/跌破前低即减仓，浮盈回撤≥8%止盈保护，持满5日离场"


def _hold_note(hist, days_held, asof):
    """持仓理由(提醒): 连板未断 / 破5日线 / 时间止损临近 → 一句话.
    用户要求"当日跌了但没破位 → 继续持有"这类说明, 在此体现:
    - 连板未断 → 继续持有; 今日收跌但未破5日线 → 继续持有;
    - 已破5日线 → 趋势转弱, 断板即收盘卖; 持满4日 → 明日时间止损, 明收盘卖."""
    h = hist[hist["date"] <= pd.Timestamp(asof)].reset_index(drop=True)
    try:
        days_held = int(days_held or 0)
    except (TypeError, ValueError):
        days_held = 0
    if h.empty:
        return "持有观察"
    last = h.iloc[-1]
    try:
        chg = float(last.get("change_pct") or 0)
    except (TypeError, ValueError):
        chg = None
    if chg is None and len(h) >= 2:
        chg = (float(last["close"]) / float(h.iloc[-2]["close"]) - 1) * 100
    if days_held >= D.TIME_STOP:
        return f"持满{days_held}日·时间止损，今收盘卖出"
    if days_held == D.TIME_STOP - 1:
        return f"持满{days_held}日·明日时间止损，明收盘卖出"
    if D._streak(h) >= 1:
        return f"连板未断(第{D._streak(h)}个涨停)，继续持有"
    close = float(last["close"])
    ma5 = float(h["close"].tail(5).mean()) if len(h) >= 5 else None
    if chg is not None and chg < 0:
        if ma5 is not None and close < ma5:
            return f"今日{chg:+.1f}%已破5日线({ma5:.2f})，趋势转弱，断板即收盘卖"
        if ma5 is not None:
            return f"今日{chg:+.1f}%未破5日线({ma5:.2f})，继续持有"
        return "今日下跌未破位，继续持有"
    if ma5 is not None:
        return f"今日{chg:+.1f}%收涨，站稳5日线({ma5:.2f})，继续持有"
    return "趋势正常，继续持有"


_RT_CACHE = {"key": None, "map": None}


def _today_rt_map():
    """今日实时行情 {code: 行情行}. 仅交易日·已开盘(本地时间≥09:30)才拉取, 进程内按(日期,是否开盘)缓存.
    用途: 盘中把"入场日=今天"的待买入按开盘价即时撮合记账 — 开盘后 open 已固定不抖动,
    避免"今天开盘明明已买入, 行情库未入库前页面还挂着待买入"的滞后.
    未开盘/非交易日/拉取失败 → None(调用方维持"待买入", 由盘后行情入库按常规重放结算)."""
    now = datetime.now()
    opened = now.hour * 60 + now.minute >= 570          # 09:30 开盘
    key = (now.strftime("%Y%m%d"), opened)
    if _RT_CACHE["key"] != key:
        _RT_CACHE["map"] = None
        _RT_CACHE["key"] = key
        if opened and _next_trading_day(now).strftime("%Y%m%d") == now.strftime("%Y%m%d"):
            try:
                q = StockAPI.get_realtime_quotes()
                if q is not None and not q.empty and "code" in q.columns:
                    q = q.copy()
                    q["code"] = q["code"].astype(str).str.zfill(6)
                    _RT_CACHE["map"] = {str(r["code"]): r for _, r in q.iterrows()}
            except Exception:
                _RT_CACHE["map"] = None
    return _RT_CACHE["map"]


def _today_intraday(code):
    """入场日=今天 的实时撮合价 → (开盘价, 最新价); 不可成交返回 None.
    开盘一字涨停(open/昨收≥+9.8%, 实际买不进)/停牌/无实时源/未开盘 → None, 维持待买入, 待盘后入库结算."""
    if not code:
        return None
    rt = _today_rt_map()
    if not rt or str(code) not in rt:
        return None
    r = rt[str(code)]
    try:
        o = float(r["open"])
        pc = float(r["pre_close"])
        px = float(r["price"])
    except (KeyError, TypeError, ValueError):
        return None
    if o <= 0 or pc <= 0 or o / pc - 1 >= 0.098:
        return None
    return (o, px if px > 0 else o)


def _replay_leg(picks, asof, risk_rules=True):
    """主推"交易段生命周期"重放(2026-09-02 语义升级):
    - 好股不强求去重: 同一标的持仓期内再次被推荐 → 提示"持有"(未开新仓), 不机械再买;
    - 段了结(断板/时间止损/持满5日)才计该段总收益; 平仓后再次推荐才开新段;
    - detail = 事件流(买入信号 / 持仓提醒 / 卖出结算 / 观望/跳过), 按日期升序, 供推荐记录表(前端降序);
    - 预算 ¥6,000/笔(2026-09-02 上调). 整手/费用/一字板停牌跳过等口径不变."""
    picks = sorted(picks, key=lambda p: str(p.get("signal_date", "")))
    today = datetime.now().strftime("%Y%m%d")      # 盘中实时撮合判定: 入场日=今天 且已开盘才记账
    def _disp(d):
        d = str(d or "")
        return f"{d[:4]}-{d[4:6]}-{d[6:8]}" if len(d) == 8 and d.isdigit() else d
    def _pend_op(entry):
        """待买入'操作'列: 直接写入场日期(不用"今日/明日"相对词, 随浏览时间易误读)."""
        d = _disp(entry)
        return f"{d} 开盘买入" if d else "待定(行情刷新后结算)"
    realized = 0.0
    n_closed = n_win = n_unbuy = n_open = n_noqty = pending = 0
    trades, open_pos, pending_pos = [], [], []
    evts = []                       # (seq, row); 最后按(日期,seq)排序
    _seq = 0
    legs = {}                       # code -> 未平段 {entry, entry_px, qty}
    for p in picks:
        sdate = str(p.get("signal_date", ""))
        if not p.get("code"):
            if p.get("hold"):
                _seq += 1
                evts.append((_seq, {"日期": _disp(sdate), "股票": "⏸️ 空仓观望",
                                    "角色": p.get("role") or "主推", "价格": "—",
                                    "模拟股数": "—", "模拟金额": "—", "状态": "空仓",
                                    "操作": "空仓观望", "收益": "—", "累计盈利": "—", "": "⏸️"}))
            continue
        code, name = p["code"], p.get("name", "")
        entry = _entry_date(sdate)
        base = {"日期": _disp(sdate), "股票": f"{name} ({code})",
                "角色": p.get("role") or "主推"}
        # ── 1) 该标的持仓期内(未平或信号日早于段平仓日) → 提示持有, 不重复开仓 ──
        leg = legs.get(code)
        if leg is not None:
            leg_exit = leg.get("exit_date")
            if leg_exit is None or (sdate and sdate < leg_exit):
                h_s = _local_hist(code, leg["entry"], sdate)
                try:
                    if h_s is not None and not h_s.empty:
                        o_s = D._recompute_pos_main({"code": code, "name": name,
                                                     "entry_date": leg["entry"]}, h_s, sdate)
                    else:
                        o_s = {"status": "持仓", "days_held": leg.get("days", 0)}
                except Exception:
                    o_s = {"status": "持仓", "days_held": leg.get("days", 0)}
                days = o_s.get("days_held", 0) or 0
                note = _hold_note(h_s, days, sdate) if h_s is not None else f"持有{days}日，继续持有"
                tip = _risk_tip(h_s, days, sdate) if h_s is not None else ""
                if tip:
                    note = f"{note}｜{tip}"
                _seq += 1
                evts.append((_seq, {**base, "价格": f"{leg['entry_px']:.2f}",
                                    "模拟股数": str(leg["qty"]),
                                    "模拟金额": f"¥{leg['entry_px'] * leg['qty']:,.0f}",
                                    "状态": f"持有{days}日(未开新仓)",
                                    "操作": note, "收益": "—", "累计盈利": "—", "": "📌"}))
                continue
            legs.pop(code, None)   # 段已于该信号日前平仓 → 走下方新段
        # ── 2) 直接跳过的信号(不产生段) ──
        if p.get("t1_buyable") is False or p.get("unbuy"):
            n_unbuy += 1
            _seq += 1
            evts.append((_seq, {**base, "价格": "—", "模拟股数": "—", "模拟金额": "—",
                                "状态": "一字板买不进", "操作": "一字板·跳过",
                                "收益": "—", "累计盈利": "—", "": "🔒"}))
            continue
        if entry > asof:
            # 真伪时间判定(2026-09-07): 区分三种情形 —
            #   a) 入场日=今天 → 盘中实时撮合(开盘已固定, 不等晚间入库);
            #   b) 入场日已是「已完整收盘的过去交易日」但行情库未刷到 → 「行情未入库」(滞后), 不虚报"待买入",
            #      待自动补库守护把 bar 补齐后走下方 hist 常规重放自动结算(幂等收敛);
            #   c) 未来交易日(理论不出现) → 兜底"待买入".
            if entry == today:
                intra = _today_intraday(code)
                if intra is None:
                    pending += 1
                    pending_pos.append({"name": name, "code": code, "entry": entry})
                    _seq += 1
                    evts.append((_seq, {**base, "价格": "—", "模拟股数": "—", "模拟金额": "—",
                                        "状态": "待买入", "操作": _pend_op(entry),
                                        "收益": "—", "累计盈利": "—", "": "⏳"}))
                    continue
                entry_px, mark = intra
                qty = _qty(entry_px)
                if qty == 0:
                    n_noqty += 1
                    _seq += 1
                    evts.append((_seq, {**base, "价格": "—", "模拟股数": "—", "模拟金额": "—",
                                        "状态": "预算不足1手", "操作": f"¥{CAPITAL:.0f}不足1手",
                                        "收益": "—", "累计盈利": "—", "": "💤"}))
                    continue
                pnl = _net(entry_px, mark, qty)
                n_open += 1
                note = f"今日{_disp(entry)}开盘按{entry_px:.2f}成交(实时记账)；收盘行情入库后按收盘价重结算"
                legs[code] = {"entry": entry, "entry_px": entry_px, "qty": qty,
                              "days": 1, "name": name}
                open_pos.append({"name": name, "code": code, "entry": entry,
                                 "entry_px": entry_px, "mark": mark, "days": 1,
                                 "pnl": pnl, "reason": note})
                _seq += 1
                evts.append((_seq, {**base, "价格": f"{entry_px:.2f}",
                                    "模拟股数": str(qty),
                                    "模拟金额": f"¥{entry_px * qty:,.0f}",
                                    "状态": "买入信号",
                                    "操作": f"{_disp(entry)} 开盘买入",
                                    "收益": "—", "累计盈利": "—", "": "🚀"}))
                _seq += 1
                evts.append((_seq, {**base, "日期": _disp(entry),
                                    "价格": f"{entry_px:.2f}", "模拟股数": str(qty),
                                    "模拟金额": f"¥{entry_px * qty:,.0f}",
                                    "状态": "开盘买入", "操作": f"{_disp(entry)} 开盘价成交",
                                    "收益": "—", "累计盈利": "—", "": "🎯"}))
                continue
            _rp8 = _prev_trading_day().strftime("%Y%m%d")   # 真实上一交易日(已完整收盘)
            if entry <= _rp8:
                _seq += 1
                evts.append((_seq, {**base, "价格": "—", "模拟股数": "—", "模拟金额": "—",
                                    "状态": "行情未入库",
                                    "操作": f"数据截止{_disp(asof)}·{_disp(entry)}已收盘, 补库后自动结算",
                                    "收益": "—", "累计盈利": "—", "": "🕓"}))
                continue
            pending += 1
            pending_pos.append({"name": name, "code": code, "entry": entry})
            _seq += 1
            evts.append((_seq, {**base, "价格": "—", "模拟股数": "—", "模拟金额": "—",
                                "状态": "待买入", "操作": _pend_op(entry),
                                "收益": "—", "累计盈利": "—", "": "⏳"}))
            continue
        hist = _local_hist(code, entry, asof)
        if hist is None or hist.empty:
            _seq += 1
            evts.append((_seq, {**base, "价格": "—", "模拟股数": "—", "模拟金额": "—",
                                "状态": "数据缺失", "操作": "数据缺失",
                                "收益": "—", "累计盈利": "—", "": "⚠️"}))
            continue
        try:
            out = D._recompute_pos_main({"code": code, "name": name, "entry_date": entry}, hist, asof)
        except Exception:
            continue
        if out["status"] in ("未买入(一字板)", "未买入(停牌)"):
            n_unbuy += 1
            op = "一字板·跳过" if out["status"].startswith("未买入(一字板)") else "停牌·跳过"
            _seq += 1
            evts.append((_seq, {**base, "价格": "—", "模拟股数": "—", "模拟金额": "—",
                                "状态": out["status"], "操作": op, "收益": "—",
                                "累计盈利": "—", "": "🔒"}))
            continue
        if out["status"] == "待买入":
            pending += 1
            pending_pos.append({"name": name, "code": code, "entry": entry})
            _seq += 1
            evts.append((_seq, {**base, "价格": "—", "模拟股数": "—", "模拟金额": "—",
                                "状态": "待买入", "操作": _pend_op(entry),
                                "收益": "—", "累计盈利": "—", "": "⏳"}))
            continue
        # 用本地hist同锚入场价(out.entry_price), 弃记录值: 记录的是信号时前复权锚, 与出场(今日锚)
        # 混用会因除权重锚错配(天山铝业 13.15 vs 12.85 实证). 同锚下收益率才正确.
        entry_px = float(out.get("entry_price") or p.get("qfq_buy_price") or 0)
        if entry_px <= 0:
            continue
        qty = _qty(entry_px)
        if qty == 0:
            n_noqty += 1                # ¥6000买不起1手(生产模型同判"预算够1手"才可交易)
            _seq += 1
            evts.append((_seq, {**base, "价格": "—", "模拟股数": "—", "模拟金额": "—",
                                "状态": "预算不足1手", "操作": f"¥{CAPITAL:.0f}不足1手",
                                "收益": "—", "累计盈利": "—", "": "💤"}))
            continue
        # ── 3) 开新段: 买入信号行(信号日) + 段结局(卖出结算行, 挂实际卖出日) ──
        buy_row = {**base, "价格": f"{entry_px:.2f}", "模拟股数": str(qty),
                   "模拟金额": f"¥{entry_px * qty:,.0f}",
                   "状态": "买入信号", "操作": f"{_disp(entry)} 开盘买入",
                   "收益": "—", "累计盈利": "—", "": "🚀"}
        if out["status"] == "已卖出":
            exit_d = str(out.get("exit_date", ""))
            exit_px = float(out["exit_price"])
            pnl = _net(entry_px, exit_px, qty)
            realized += pnl
            n_closed += 1
            if pnl > 0:
                n_win += 1
            tag = out.get("tag", "")
            days = out.get("days_held", 1)
            trades.append({"name": name, "code": code, "entry": entry,
                           "exit": exit_d, "ret_pct": (exit_px / entry_px - 1) * 100,
                           "pnl": pnl, "tag": tag, "days": days,
                           "reason": _sell_reason(tag)})
            # 登记该段活跃期(到 exit_date), 期间该股再被推荐 → 提示持有; 到期后自动失效
            legs[code] = {"entry": entry, "entry_px": entry_px, "qty": qty,
                          "days": days, "name": name, "exit_date": exit_d}
            _seq += 1
            evts.append((_seq, buy_row))
            _seq += 1
            evts.append((_seq, {**base, "日期": _disp(entry),
                                "价格": f"{entry_px:.2f}", "模拟股数": str(qty),
                                "模拟金额": f"¥{entry_px * qty:,.0f}",
                                "状态": "开盘买入", "操作": f"{_disp(entry)} 开盘价成交",
                                "收益": "—", "累计盈利": "—", "": "🎯"}))
            _seq += 1
            evts.append((_seq, {**base, "日期": _disp(exit_d or sdate),
                                "价格": f"{entry_px:.2f}", "模拟股数": str(qty),
                                "模拟金额": f"¥{entry_px * qty:,.0f}",
                                "状态": f"{tag}·{days}日", "操作": _sell_reason(tag),
                                "收益": f"¥{pnl:+,.2f}", "累计盈利": "—",
                                "": "✅" if pnl > 0 else "❌", "_cum": realized}))
        else:                       # 持仓(未平段) → 登记, 后续该股信号走"持有提醒"
            hist_d = hist[hist["date"] <= pd.Timestamp(asof)]
            if hist_d.empty:
                continue
            mark = float(hist_d.iloc[-1]["close"])
            pnl = _net(entry_px, mark, qty)
            n_open += 1
            note = _hold_note(hist, out.get("days_held", 0), asof)
            tip = _risk_tip(hist, out.get("days_held", 0), asof)
            if tip:
                note = f"{note}｜{tip}"
            legs[code] = {"entry": entry, "entry_px": entry_px, "qty": qty,
                          "days": out.get("days_held", 0), "name": name}
            open_pos.append({"name": name, "code": code, "entry": entry, "entry_px": entry_px,
                             "mark": mark, "days": out.get("days_held", 0), "pnl": pnl,
                             "reason": note})
            _seq += 1
            evts.append((_seq, buy_row))
            _seq += 1
            evts.append((_seq, {**base, "日期": _disp(entry),
                                "价格": f"{entry_px:.2f}", "模拟股数": str(qty),
                                "模拟金额": f"¥{entry_px * qty:,.0f}",
                                "状态": "开盘买入", "操作": f"{_disp(entry)} 开盘价成交",
                                "收益": "—", "累计盈利": "—", "": "🎯"}))
    float_pnl = sum(o["pnl"] for o in open_pos)
    # detail: 按(日期, seq)升序; 卖出结算行填累计 = 该段后已实现 + 全部持仓浮动
    evts.sort(key=lambda x: (str(x[1].get("日期", "")).replace("-", ""), x[0]))
    detail = []
    for _s, r in evts:
        if "_cum" in r:
            r["累计盈利"] = f"¥{r.pop('_cum') + float_pnl:+,.2f}"
        else:
            r.setdefault("累计盈利", "—")
        detail.append(r)
    return {"realized": realized, "float": float_pnl, "total": realized + float_pnl,
            "n_closed": n_closed, "n_win": n_win, "n_open": n_open,
            "n_unbuy": n_unbuy, "n_noqty": n_noqty, "pending": pending,
            "pending_pos": pending_pos,
            "trades": sorted(trades, key=lambda x: str(x["entry"]), reverse=True),
            "open_pos": sorted(open_pos, key=lambda x: str(x["entry"]), reverse=True),
            "detail": detail}



def _load_main_backup(asof, risk_rules=True):
    """从 data/recommendations 装载主推历史信号 → T5 重放. (2026-09-01 备用轨已关闭:
    备用不再推荐交易/不再进模拟; 历史备用文件保留(仅作记录)但不再重放, 主页只显示 主推+龙头.)
    risk_rules: 是否启用破位止损(回撤8%/破5日线); B重做后默认True, 对齐龙头9/3修复."""
    picks_main = []
    if os.path.isdir(REC_DIR):
        for fn in sorted(os.listdir(REC_DIR)):
            if not (fn.endswith(".json") and fn[:8].isdigit()):
                continue
            date = fn[:8]
            try:
                rec = json.load(open(os.path.join(REC_DIR, fn), encoding="utf-8"))
            except Exception:
                continue
            if not rec.get("picks"):
                # 空仓观望日: 主推一行, 不重放(明细表显示⏸️空仓观望)
                picks_main.append({"signal_date": date, "code": None, "name": "", "role": "主推", "hold": True})
                continue
            for p in rec.get("picks", []):
                role = p.get("role") or "主推"
                if role != "主推":
                    continue                # 备用/候选不交易(备用轨已关闭)
                # C重做: 主推选股质控 — 仅重放高胜率主推(与辩论/龙头52%门槛一致);
                # MAIN_WINRATE_MIN=None 时不过滤. 过滤 win_rate<门槛 的弱信号, 抬升模拟胜率与盈亏比
                if (MAIN_WINRATE_MIN is not None and p.get("win_rate") is not None
                        and float(p.get("win_rate") or 0) < MAIN_WINRATE_MIN):
                    continue
                picks_main.append({"signal_date": date, "code": p.get("code"),
                                   "name": p.get("name"), "role": "主推",
                                   "qfq_buy_price": p.get("qfq_buy_price"),
                                   "t1_buyable": p.get("t1_buyable")})
    return {"主推": _replay_leg(picks_main, asof, risk_rules)}


def _dragon_track(asof):
    """读取龙头 live 仓 → 同结构 summary(费用同口径重算).
    读前先按 asof 推进状态机一次(幂等): 盘后(本地库已入库到今天)允许读当日已收盘 bar 并**落盘**,
    让 data/dragon_positions.json 与展示层一致; 盘中 asof=上一交易日, 推进结果与盘面相同, 落盘无副作用."""
    store = D._load_store()
    today = datetime.now().strftime("%Y%m%d")
    try:
        store = D.update_positions(store, asof, include_today=(asof == today))
        D._save_store(store)      # 已收盘入库 → 推进结果持久化, 不再只放内存
    except Exception as e:
        print(f"[sim_t5] 龙头状态机推进/落盘失败(asof={asof}): {e}")   # 不吞错: 推进失败要可见
    realized = 0.0
    n_win = n_closed = n_open = n_unbuy = pending = 0
    trades, open_pos, pending_pos = [], [], []
    for t in store.get("trades", []):
        try:
            ep, xp = float(t["entry_price"]), float(t["exit_price"])
        except (KeyError, TypeError, ValueError):
            continue
        qty = _qty(ep)
        if qty == 0:
            continue
        pnl = _net(ep, xp, qty)
        realized += pnl
        n_closed += 1
        if pnl > 0:
            n_win += 1
        tag = t.get("tag", "")
        trades.append({"name": t.get("name", ""), "code": t.get("code", ""),
                       "entry": t.get("entry_date", ""), "exit": t.get("exit_date", ""),
                       "ret_pct": t.get("ret_pct", 0), "pnl": pnl,
                       "tag": tag, "days": t.get("days_held"), "reason": _sell_reason(tag)})
    for pos in store.get("positions", []):
        st = pos.get("status")
        if st in ("待买入",):
            pending += 1
            pending_pos.append({"name": pos.get("name", ""), "code": pos.get("code", ""),
                                "entry": pos.get("entry_date", "")})
            continue
        if st == "未买入(冻结)":
            continue            # 规则修复期一次性暂停入场(20260903), 非交易动作 → 不进统计/不进推荐记录
        if st in ("未买入(一字板)", "未买入(停牌)", "未买入(高开过滤)"):
            n_unbuy += 1
            continue
        if st == "持仓":
            ep = float(pos.get("entry_price") or 0)
            if ep <= 0:
                continue
            qty = _qty(ep)
            if qty == 0:
                continue
            hist = _local_hist(pos.get("code", ""), pos.get("entry_date", ""), asof)
            if hist is None or hist.empty:
                continue
            hist_d = hist[hist["date"] <= pd.Timestamp(asof)]
            if hist_d.empty:
                continue
            mark = float(hist_d.iloc[-1]["close"])
            pnl = _net(ep, mark, qty)
            n_open += 1
            open_pos.append({"name": pos.get("name", ""), "code": pos.get("code", ""),
                             "entry": pos.get("entry_date", ""), "entry_px": ep, "mark": mark,
                             "days": pos.get("days_held", 0), "pnl": pnl,
                             "reason": _hold_note(hist, pos.get("days_held", 0), asof)})
    float_pnl = sum(o["pnl"] for o in open_pos)
    # ── 龙头"推荐记录"detail（列结构与主推明细一致, 供首页推荐记录表渲染）──
    # 交易段生命周期事件流: 已撮合段 = 信号日(🚀买入信号) + 买入执行日(🎯开盘买入成交) + 卖出结算行(挂实际卖出日);
    # 未成交段(待买入/一字板/停牌/高开过滤) = 信号日单行; 冻结(规则修复一次性暂停入场)不进记录/统计.
    # 空仓补行: 自首个事件日起到 asof, 该交易日既无任何事件行、当前又无持仓覆盖 → 补"空仓"行,
    #           保证龙头推荐记录每个交易日都有数据.
    def _disp8(d):
        d = str(d or "")
        return f"{d[:4]}-{d[4:6]}-{d[6:8]}" if len(d) == 8 and d.isdigit() else d
    open_map = {(o["code"], o["entry"]): o for o in open_pos}
    events = []                        # (ymd, row)
    _event_days = set()
    for p in store.get("positions", []):
        code = p.get("code", "")
        st = p.get("status", "")
        if st == "未买入(冻结)":
            continue
        sdate = str(p.get("signal_date") or p.get("entry_date") or "")
        entry = str(p.get("entry_date") or sdate)
        _event_days.update([sdate, entry])

        def _push(ymd, code, name, emoji="", pnl_n=None, **kw):
            row = {"日期": _disp8(ymd), "股票": f"{name} ({code})", "角色": "龙头",
                   "价格": "—", "模拟股数": "—", "模拟金额": "—",
                   "状态": "", "操作": "—", "收益": "—", "累计盈利": "—", "": emoji}
            row.update(kw)
            if pnl_n is not None:
                row["_pnl_n"] = pnl_n
            events.append((str(ymd), row))

        name = p.get("name", "")
        if st == "待买入":
            _push(sdate, code, name, 状态="待买入",
                  操作=f"{_disp8(entry)} 开盘买入", emoji="⏳")
            continue
        if st.startswith("未买入"):
            _skip = {"未买入(一字板)": ("一字板买不进", "一字板·跳过"),
                     "未买入(停牌)": ("停牌买不进", "停牌·跳过"),
                     "未买入(高开过滤)": ("高开≥7%放弃", "高开过滤·跳过")}
            _s, _op = _skip.get(st, ("买入失败", st))
            _push(sdate, code, name, 状态=_s,
                  操作=f"{_op} · {_disp8(entry)}开盘未成交", emoji="🔒")
            continue
        # ── 已撮合段(持仓/已卖出): 信号行 + 买入执行行 ──
        try:
            ep = float(p.get("entry_price") or 0)
        except (KeyError, TypeError, ValueError):
            ep = 0.0
        if ep <= 0:
            continue
        qty = _qty(ep)
        if qty == 0:
            continue
        px, qs, amt = f"{ep:.2f}", str(qty), f"¥{ep * qty:,.0f}"
        _push(sdate, code, name, 价格=px, 模拟股数=qs, 模拟金额=amt,
              状态="买入信号", 操作=f"{_disp8(entry)} 开盘买入", emoji="🚀")
        _push(entry, code, name, 价格=px, 模拟股数=qs, 模拟金额=amt,
              状态="开盘买入", 操作=f"{_disp8(entry)} 开盘价成交", emoji="🎯")
        if st == "已卖出":
            try:
                xp = float(p["exit_price"])
            except (KeyError, TypeError, ValueError):
                continue
            pnl = _net(ep, xp, qty)
            tag = p.get("tag", "") or ""
            days = p.get("days_held")
            _push(str(p.get("exit_date") or entry), code, name,
                  价格=px, 模拟股数=qs, 模拟金额=amt,
                  状态=f"{tag}·{days}日" if tag else f"卖出·{days}日",
                  操作=f"{tag}·收盘卖" if tag else "时间止损·收盘卖",
                  收益=f"¥{pnl:+,.2f}",
                  emoji="✅" if pnl > 0 else "❌", pnl_n=pnl)
        elif st == "持仓":
            o = open_map.get((code, str(p.get("entry_date", ""))))
            if o is None or o["entry_px"] <= 0:
                continue
            _push(asof, code, name, 价格=px, 模拟股数=qs, 模拟金额=amt,
                  状态=f"持仓{o['days']}日", 操作=o.get("reason", "继续持有"),
                  收益=f"¥{o['pnl']:+,.2f}",
                  emoji="📈" if o["pnl"] > 0 else "📉")
    # 空仓补行: 无事件行且无持仓覆盖的交易日 → "空仓"(每天都有数据)
    if events:
        _hold = set()
        for o in open_pos:                        # 持仓覆盖日: 有仓 ≠ 空仓
            _hd = datetime.strptime(str(o["entry"]), "%Y%m%d")
            _ad = datetime.strptime(str(asof), "%Y%m%d")
            while _hd <= _ad:
                _hold.add(_hd.strftime("%Y%m%d"))
                _hd += timedelta(days=1)
        _cur = datetime.strptime(str(min(int(y) for y, _ in events)), "%Y%m%d")
        _end = datetime.strptime(str(asof), "%Y%m%d")
        while _cur <= _end:
            ymd = _cur.strftime("%Y%m%d")
            if is_trading_day(_cur) and ymd not in _hold and ymd not in _event_days:
                events.append((ymd, {"日期": _disp8(ymd), "股票": "—", "角色": "龙头",
                                     "价格": "—", "模拟股数": "—", "模拟金额": "—",
                                     "状态": "空仓", "操作": "无信号 · 空仓",
                                     "收益": "—", "累计盈利": "—", "": "⚪"}))
            _cur += timedelta(days=1)
    events.sort(key=lambda e: e[0])
    _run = 0.0
    for _y, r in events:                 # 累计盈利 = 到该行已实现 + 全部持仓浮动(与主推口径一致)
        if r.get("状态") == "空仓":
            continue
        p = r.pop("_pnl_n", None)
        if p is not None:
            _run += p
        r["累计盈利"] = f"¥{_run + float_pnl:+,.2f}"
    pos_rows = [r for _, r in events]
    return {"realized": realized, "float": float_pnl, "total": realized + float_pnl,
            "n_closed": n_closed, "n_win": n_win, "n_open": n_open,
            "n_unbuy": n_unbuy, "n_noqty": 0, "pending": pending,
            "pending_pos": pending_pos,
            "trades": sorted(trades, key=lambda x: x["pnl"])[-6:][::-1],
            "open_pos": sorted(open_pos, key=lambda x: x["pnl"], reverse=True)[:5],
            "detail": pos_rows}


def _local_latest_date():
    """本地 market_bars 库最新覆盖日(读 _coverage.json 的 end).
    与盘后刷新联动: 刷新入库到哪天, 总览就重放到哪天; 盘中(未刷新)自然停在上一完整交易日,
    天然无前视(腾讯补尾不会触发, 因为请求端=本地end, 本地完整覆盖)."""
    try:
        c = json.load(open(os.path.join(BASE, "data", "market_bars", "_coverage.json"), encoding="utf-8"))
        e = str(c.get("end") or "").strip()
        if len(e) == 8 and e.isdigit():
            return e
    except Exception:
        pass
    return _prev_trading_day().strftime("%Y%m%d")


def bars_freshness():
    """行情库新鲜度(2026-09-07, 供首页/引擎告警): 本地 bar 是否追平「当前理应入库的最晚交易日」.
    - asof:    _coverage.json 的 end(本地最新 bar 日);
    - want:    理应入库到的最晚日 = 交易日且已收盘(≥15:05)→今天, 否则真实上一交易日;
    - lag_days: asof→want 之间缺失的交易日数; >0 → 行情库滞后, 页面数据/结算停留在 asof, 需补库.
    滞后发生时引擎重放只"走到" asof, 非业务错误; 本函数用于让页面明确提示而非让用户误读为策略停摆.
    """
    now = datetime.now()
    asof = _local_latest_date()
    closed = is_trading_day(now) and (now.hour * 60 + now.minute) >= 15 * 60 + 5
    want = now.strftime("%Y%m%d") if closed else _prev_trading_day(now).strftime("%Y%m%d")
    if asof >= want:
        return {"ok": True, "asof": asof, "want": want, "lag_days": 0}
    lag = 0
    d = datetime.strptime(asof, "%Y%m%d")
    stop = datetime.strptime(want, "%Y%m%d")
    while d < stop:
        d += timedelta(days=1)
        if is_trading_day(d):
            lag += 1
    return {"ok": False, "asof": asof, "want": want, "lag_days": lag}


def three_track_overview(asof=None):
    """首页三策略总览: {主推, 龙头} → summary dict. (2026-09-01 备用轨已关闭, 不再进总览.)
    asof 默认 = 本地库最新覆盖日(盘后刷新入库到今天, 就重放到今天).
    ⚠️ 不要用 datetime.now(): 盘中会触发腾讯补尾拉今日实时bar当收盘, 前视泄漏+结果抖动."""
    if asof is None:
        asof = _local_latest_date()
    mb = _load_main_backup(asof)
    dr = _dragon_track(asof)
    return {"主推": mb["主推"], "龙头": dr}


if __name__ == "__main__":
    ov = three_track_overview()
    for k, v in ov.items():
        print(f"{k}: 总¥{v['total']:+,.2f} (已实现{v['realized']:+,.2f} + 浮动{v['float']:+,.2f}) "
              f"平仓{v['n_closed']}笔/赢{v['n_win']} 持仓{v['n_open']} 待买{v['pending']} 未买{v['n_unbuy']}")
