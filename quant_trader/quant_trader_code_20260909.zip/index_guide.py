# -*- coding: utf-8 -*-
"""
首页决策辅助数据:
1) 上证指数历史(持久化, 确定性 → 落盘复用, 扫描时缺失才补齐, 每天至多拉一次)
2) 板块指数(首推板块+备用板块整个板块成分股, 总股本加权, 当日生成, 今日 vs 昨日升/降)
3) 决策提示 build_guidance(仅提示, 不改推荐)

补齐入口 ensure_indices_backfilled() 挂在扫描后(定时+手动都走 background_scan._run).
"""
import json
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime

from stock_api import StockAPI

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SH_FILE = os.path.join(BASE_DIR, "data", "market_index", "sh000001.json")
SECTOR_DIR = os.path.join(BASE_DIR, "data", "sector_index")
PICKS_DIR = os.path.join(BASE_DIR, "data", "daily_picks")
SH_DAYS = 160  # 上证历史窗口(覆盖 daily_picks 全窗口 + MA20)


def _ds(d):
    return d.strftime("%Y%m%d") if hasattr(d, "strftime") else str(d).replace("-", "")


def latest_picks_date():
    """最新 daily_picks 日期(无则 None)."""
    if not os.path.isdir(PICKS_DIR):
        return None
    ds = [f[:-5] for f in os.listdir(PICKS_DIR) if f.endswith(".json")]
    return max(ds) if ds else None


# ---------- 上证历史持久化 ----------

def load_sh_raw():
    """读 {last_check_date, dates, closes}; 无/坏则 {}."""
    try:
        with open(SH_FILE, encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d.get("dates"), list) and isinstance(d.get("closes"), list) and d["dates"]:
            return d
    except Exception:
        pass
    return {}


def _save_sh_raw(payload):
    os.makedirs(os.path.dirname(SH_FILE), exist_ok=True)
    with open(SH_FILE, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)


def backfill_sh_history():
    """确定性数据 → 每天至多拉一次: last_check_date==今天则跳过, 否则整体替换并落盘."""
    today = datetime.now().strftime("%Y%m%d")
    raw = load_sh_raw()
    if raw.get("last_check_date") == today:
        return raw
    try:
        idx = StockAPI.get_index_historical_data("sh000001", SH_DAYS)
        dates, closes = [], []
        if idx is not None and not idx.empty and "close" in idx.columns:
            for _, r in idx.iterrows():
                dates.append(_ds(r["date"]))
                closes.append(float(r["close"]))
        if dates:
            raw = {"last_check_date": today, "dates": dates, "closes": closes}
            _save_sh_raw(raw)
    except Exception:
        pass
    return raw


def load_sh_history():
    """只读本地(无网络): 返回 {date: {close, ma20, ret_pct, above_ma20}}. 缺失 → {}."""
    raw = load_sh_raw()
    dates = raw.get("dates", [])
    closes = raw.get("closes", [])
    out = {}
    if not dates:
        return out
    ma20 = {}
    for i, ds in enumerate(dates):
        win = [closes[j] for j in range(max(0, i - 19), i + 1)]
        ma20[ds] = sum(win) / len(win)
    prev = None
    for i, ds in enumerate(dates):
        c = closes[i]
        out[ds] = {
            "close": c,
            "ma20": ma20[ds],
            "ret_pct": (c / prev - 1) * 100 if prev else None,
            "above_ma20": c > ma20[ds],
        }
        prev = c
    return out


# ---------- 板块指数(首推+备用板块) ----------

def _sector_keys_of(date_str):
    """该日 首推板块+备用板块 → [(key, name)], 去重跳过空key."""
    try:
        with open(os.path.join(PICKS_DIR, f"{date_str}.json"), encoding="utf-8") as f:
            d = json.load(f)
    except Exception:
        return []
    sectors = []
    seen = set()

    def _add(p):
        if not p:
            return
        k = str(p.get("sector_key") or "").strip()
        if k and k not in seen:
            seen.add(k)
            sectors.append((k, str(p.get("sector") or k)))

    _add(d.get("main_pick"))
    _add(d.get("backup_pick"))
    return sectors


def _prev_trading_day(sh_dates, date_str):
    if date_str in sh_dates:
        i = sh_dates.index(date_str)
        return sh_dates[i - 1] if i > 0 else None
    return None


def _fetch_two_days(codes, d1, d2):
    """并行取各股 [d1, d2] 前复权收盘, 返回 {code: {date: close}}."""
    out = {}

    def _f(code):
        try:
            df = StockAPI.get_historical_data(code, d1, d2, adjust="qfq", source="tencent")
        except Exception:
            return code, {}
        raw = {}
        if df is not None and not df.empty and "close" in df.columns:
            for _, r in df.iterrows():
                raw[_ds(r["date"])] = float(r["close"])
        return code, raw

    with ThreadPoolExecutor(max_workers=8) as ex:
        for fut in as_completed([ex.submit(_f, c) for c in codes]):
            try:
                c, raw = fut.result()
                out[c] = raw
            except Exception:
                continue
    return out


def sector_index_for(date_str, persist=True):
    """首推+备用板块指数: 成分=两板块全部成分股, 权重=总股本(缺失等权), 今日 vs 上一交易日.
    persist=True 落盘快照 data/sector_index/{date}.json; 缺数据/无板块 → None."""
    sectors = _sector_keys_of(date_str)
    sh = load_sh_raw()
    sh_dates = sh.get("dates", [])
    if not sectors or date_str not in sh_dates:
        return None
    prev_date = _prev_trading_day(sh_dates, date_str)
    if not prev_date:
        return None

    codes, seen = [], set()
    for key, _name in sectors:
        try:
            df = StockAPI.get_industry_stocks(key)
        except Exception:
            df = None
        if df is None or df.empty:
            continue
        for _, r in df.iterrows():
            c = str(r.get("code") or "").strip()
            if c and c not in seen:
                seen.add(c)
                codes.append(c)
    if not codes:
        return None

    shares = StockAPI.get_total_shares(codes)
    weights = {c: float(shares[c]) if shares.get(c) else 1.0 for c in codes}
    prices = _fetch_two_days(codes, prev_date, date_str)

    num = den = 0.0
    for c in codes:
        p_t = (prices.get(c) or {}).get(date_str)
        p_prev = (prices.get(c) or {}).get(prev_date)
        if p_t is None or p_prev is None or p_prev <= 0:
            continue
        w = weights[c]
        num += w * p_t
        den += w * p_prev
    if den <= 0:
        return None

    chg = (num / den - 1) * 100
    snap = {
        "date": date_str,
        "prev_date": prev_date,
        "sectors": [{"key": k, "name": n} for k, n in sectors],
        "n_constituents": len(codes),
        "chg_pct": round(chg, 3),
        "direction": "up" if chg > 0 else "down" if chg < 0 else "flat",
        "equal_weight_fallback": any(shares.get(c) is None for c in codes),
        "computed_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    if persist:
        try:
            os.makedirs(SECTOR_DIR, exist_ok=True)
            with open(os.path.join(SECTOR_DIR, f"{date_str}.json"), "w", encoding="utf-8") as f:
                json.dump(snap, f, ensure_ascii=False, indent=2)
        except Exception:
            pass
    return snap


def load_sector_index_latest():
    """读最新快照; 优先日期==最新 daily_picks 日期, 否则退回目录内最新快照(标记 stale).
    stale=True 表示非当日生成(如盘中Tencent无当日bar无法重算), 展示端附注最近一次."""
    lp = latest_picks_date()
    latest = None
    if os.path.isdir(SECTOR_DIR):
        files = [f for f in os.listdir(SECTOR_DIR) if f.endswith(".json")]
        if files:
            newest = max(files)
            try:
                with open(os.path.join(SECTOR_DIR, newest), encoding="utf-8") as f:
                    latest = json.load(f)
            except Exception:
                latest = None
    if not latest:
        return None
    latest["stale"] = bool(lp) and latest.get("date") != lp
    return latest


# ---------- 决策提示 ----------

def build_guidance(sh_sig, sector_sig):
    """组合建议(仅提示). sh_sig = load_sh_history()[最新] | None; sector_sig = 板块指数快照 | None.
    保留回测结论: 上证涨且站上MA20 → 顺势可出手; 跌破MA20 → 观望; 板块方向并行参考."""
    if sh_sig is None:
        return {"sh": "上证数据缺失", "sector": "-", "comb": "等待扫描补齐后显示", "comb_cls": ""}
    above = sh_sig.get("above_ma20")
    ret = sh_sig.get("ret_pct")
    if above:
        if ret is not None and ret >= 0:
            sh_txt = "上证站上MA20且当日上涨 → 顺势，可出手"
        else:
            sh_txt = "上证站上MA20但当日回落 → 高位谨慎"
    else:
        sh_txt = "上证跌破MA20 → 弱势，观望为主"

    if sector_sig is None:
        sec_txt = "板块指数未生成"
    else:
        d = sector_sig.get("direction")
        chg = sector_sig.get("chg_pct")
        if d == "up":
            sec_txt = f"首推/备用板块指数较昨日 +{chg:.2f}% → 板块走强"
        elif d == "down":
            sec_txt = f"首推/备用板块指数较昨日 {chg:.2f}% → 板块走弱"
        else:
            sec_txt = "板块指数较昨日持平"

    if above and sector_sig and sector_sig.get("direction") == "up":
        comb_txt, comb_cls = "上证顺势 + 板块走强 → 双信号共振，主推可加分执行", "pos"
    elif above and sector_sig and sector_sig.get("direction") == "down":
        comb_txt, comb_cls = "上证顺势但板块走弱 → 板块与大盘背离，谨慎", "neg"
    elif not above:
        comb_txt, comb_cls = "上证弱势 → 建议观望或轻仓", "neg"
    else:
        comb_txt, comb_cls = "信号中性，按推荐执行", ""
    return {"sh": sh_txt, "sector": sec_txt, "comb": comb_txt, "comb_cls": comb_cls}


def ensure_indices_backfilled():
    """扫描后补齐(定时+手动共用): 上证历史 + 最新板块指数快照. 非致命, 不阻塞扫描."""
    try:
        backfill_sh_history()
    except Exception:
        pass
    try:
        lp = latest_picks_date()
        if lp:
            sector_index_for(lp)
    except Exception:
        pass


if __name__ == "__main__":
    r = ensure_indices_backfilled()
    sh = load_sh_history()
    print("sh dates:", len(sh), "| latest:", list(sh)[-1] if sh else None)
    sec = load_sector_index_latest()
    print("sector:", json.dumps(sec, ensure_ascii=False) if sec else None)
