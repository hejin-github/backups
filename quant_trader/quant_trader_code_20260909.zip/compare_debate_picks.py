"""对比 原始辩论推荐历史 与 回放重生成 的 T+1 实际表现.

原始历史: data/debate_picks_backup_20260810/  (改动前 7.09~8.10 的记录)
重生成:   data/debate_picks/                    (用修改后引擎 7.10~8.10 回放)

T+1 计算口径与 app.py _enrich_debate_picks 完全一致:
  优先 qfq 前复权 (买入日收盘 → T+1收盘), 缺失则用 记录price/T+1收盘 兜底。
"""
import os
import sys
import json
import glob
from datetime import datetime, timedelta

import pandas as pd

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

from stock_api import StockAPI  # noqa: E402
from scheduler import _next_trading_day  # noqa: E402

BACKUP_DIR = os.path.join(ROOT, "data", "debate_picks_backup_20260810")
NEW_DIR = os.path.join(ROOT, "data", "debate_picks")

START = "20260710"
END = "20260810"


def compute_t1(code, buy_price, date_str):
    """返回 (t1_actual_return, t1_close) 或 (None, None)"""
    try:
        buy_dt = datetime.strptime(date_str, "%Y%m%d")
        t1_date = _next_trading_day(buy_dt + timedelta(days=1))
        t1_str = t1_date.strftime("%Y%m%d")
        hist = StockAPI.get_historical_data(code, date_str, t1_str, adjust="qfq")
        if hist is not None and len(hist) >= 2:
            buy_row = hist[hist["date"] == pd.to_datetime(date_str)]
            sell_row = hist[hist["date"] == pd.to_datetime(t1_str)]
            if not buy_row.empty and not sell_row.empty:
                qfq_buy = float(buy_row["close"].iloc[0])
                qfq_sell = float(sell_row["close"].iloc[0])
                if qfq_buy > 0:
                    return round((qfq_sell / qfq_buy - 1) * 100, 2), round(qfq_sell, 2)
        if buy_price and buy_price > 0:
            hist2 = StockAPI.get_historical_data(code, t1_str, t1_str)
            if hist2 is not None and not hist2.empty:
                actual_close = float(hist2["close"].iloc[-1])
                return round((actual_close / buy_price - 1) * 100, 2), round(actual_close, 2)
    except Exception:
        pass
    return None, None


def load_picks(dirpath, day):
    path = os.path.join(dirpath, f"{day}.json")
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as f:
        rec = json.load(f)
    return rec.get("consensus_buys", [])


def summarize(picks):
    """按 app 口径统计: 只算已算出的 T+1 数值, 待更新不计入"""
    n = wins = big_loss = 0
    rets = []
    for p in picks:
        t1 = p.get("t1_actual_return")
        if isinstance(t1, (int, float)):
            n += 1
            if t1 > 0:
                wins += 1
            if t1 <= -9:
                big_loss += 1
            rets.append(t1)
    return n, wins, big_loss, rets


def main():
    days = sorted({os.path.basename(p)[:8]
                   for p in glob.glob(os.path.join(BACKUP_DIR, "*.json"))})
    days = [d for d in days if START <= d <= END]

    agg_orig = [0, 0, 0, []]
    agg_new = [0, 0, 0, []]
    print(f"{'日期':<10}{'原始推荐(T+1)':<42}{'重生成推荐(T+1)':<42}")
    for day in days:
        orig = load_picks(BACKUP_DIR, day)
        new = load_picks(NEW_DIR, day)
        for p in orig:
            r, c = compute_t1(p["code"], p.get("price", 0), day)
            p["t1_actual_return"] = r
        for p in new:
            r, c = compute_t1(p["code"], p.get("price", 0), day)
            p["t1_actual_return"] = r
        no, wo, bl_o, ro = summarize(orig)
        nn, wn, bl_n, rn = summarize(new)
        agg_orig = [agg_orig[i] + v for i, v in enumerate([no, wo, bl_o, ro])]
        agg_new = [agg_new[i] + v for i, v in enumerate([nn, wn, bl_n, rn])]

        fmt = lambda r: f"{r:+.1f}" if isinstance(r, float) else "待"
        o_str = " ".join(f"{p['name'][:4]}{fmt(p.get('t1_actual_return'))}" for p in orig) or "空仓"
        n_str = " ".join(f"{p['name'][:4]}{fmt(p.get('t1_actual_return'))}" for p in new) or "空仓"
        print(f"{day:<10}{o_str[:40]:<42}{n_str[:40]:<42}")

    print("\n=== 汇总(口径: 只计已算出的 T+1, 待更新不计) ===")
    for label, agg in [("原始", agg_orig), ("重生成", agg_new)]:
        n, wins, bl, rets = agg
        win_rate = wins / n * 100 if n else 0
        avg = sum(rets) / n if n else 0
        print(f"{label:<6} 计{n:>3}只 胜率{win_rate:5.1f}% 平均T+1 {avg:+.2f}% 大面(≤-9%){bl:>2}次")


if __name__ == "__main__":
    main()
