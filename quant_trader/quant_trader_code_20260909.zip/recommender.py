"""
每日推荐引擎 — 成交额宇宙驱动(2026-08-29改)
流程: 大盘指数门控(野人式) → top-N成交额主池∪热门板块补充池 → 策略信号+硬剔除+质量评分 → 主推+备用
依据: 同批策略在top300成交额宇宙裸边+0.317%/日, 热门板块≈0 → 主宇宙切到成交额, 板块仅作补充/展示
"""
import json, os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed

from stock_api import StockAPI
from stock_universe import filter_universe
from scheduler import is_trading_day

PICKS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "daily_picks")
RECOMMEND_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "recommendations")
CACHE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "history_cache")
MIN_EXP_RETURN = 0.2      # 历史预期T+1收益(仅供展示参考, 不再作为放行/排序依据)
MIN_SECTOR_COUNT = 8
MAX_STOCKS_PER_SECTOR = 30
# 杂毛/高位 硬剔除阈值 (全部来自 盘面/资金/信息, 不掺历史收益)
MIN_PRICE = 3.0           # 价格低于该值视为仙股/退市风险区 (信息面)
MIN_DAILY_AMOUNT = 1e8    # 日成交额低于1亿元视为无流动性/庄股 (资金面, 单位:元)
MAX_TURNOVER = 25.0       # 换手率高于该值视为分歧出货 (资金面, %)
MAX_RET_10D = 40.0        # 近10日涨幅高于该值视为高位加速末端 (盘面, %)
MAX_LIMITUP_STREAK = 2    # 连板数高于该值视为断板风险 (盘面)
MAX_PE = 150.0            # 市盈率高于该值视为纯题材无业绩 (信息面)
AMOUNT_UNIVERSE_N = 150   # 候选宇宙: top-N 成交额(有数据验证的正边池), 与热门板块补充池并集
MAX_PICKS = 5             # 每日推荐只数上限: 主推+备用+候选, 跨板块分散(每板块至多1只)
STICKY_OVERRIDE_GAP = 8.0   # 早盘主选粘性: 重扫主选质量分需高出此值(或信号更多)才允许覆盖早盘选
# 噪声板块(次新股/ST/退市等, 指标失真)
_EXCLUDE_SECTOR_NAMES = ("次新", "ST", "退", "活跃", "新股", "预亏", "风险", "高送转", "昨日涨停")
# 弱势行情(指数跌破20日线)仅允许的低吸类策略
_LOW_BUY_STRATEGIES = {"野人·低吸战法", "野人·二次回踩", "乔帮主·低吸反弹",
                       "退学炒股·逆势交易", "醉酒大佬·放量长上影", "奥数老师·尾盘量化",
                       "缠论·分型中枢"}


def index_regime(index_df=None, lookback=20):
    """野人式大盘指数门控: 用上证指数 MA20/MA5 判断行情档位
    返回 dict{level, desc, max_sectors, weak_only, skip}
    """
    if index_df is None:
        index_df = StockAPI.get_index_historical_data("sh000001", days=90)
    if index_df is None or len(index_df) < 25:
        return {"level": "normal", "desc": "指数数据不可用, 按正常行情处理",
                "max_sectors": 5, "weak_only": False, "skip": False}
    close = float(index_df["close"].iloc[-1])
    ma20 = float(index_df["close"].iloc[-lookback:].mean())
    ma20_prev = float(index_df["close"].iloc[-lookback * 2:-lookback].mean()) if len(index_df) >= lookback * 2 else ma20
    ma20_slope = (ma20 / ma20_prev - 1) * 100 if ma20_prev > 0 else 0
    chg5 = (close / float(index_df["close"].iloc[-6]) - 1) * 100 if len(index_df) >= 6 else 0

    if close > ma20 * 1.01 and ma20_slope > -0.5:
        return {"level": "strong", "desc": "强势 · 指数站上20日线且走强, 可进攻",
                "max_sectors": 5, "weak_only": False, "skip": False}
    if close > ma20:
        return {"level": "normal", "desc": "正常 · 指数在20日线上方",
                "max_sectors": 5, "weak_only": False, "skip": False}
    if close > ma20 * 0.97:
        return {"level": "weak", "desc": "谨慎 · 指数跌破20日线, 控仓只做回测高胜率强势股",
                "max_sectors": 2, "weak_only": True, "skip": False}
    return {"level": "crash", "desc": "空仓观望 · 指数深度破位",
            "max_sectors": 0, "weak_only": True, "skip": True}


def _estimate_t1_return(hist, lookback=20):
    """预期T+1收益: 最近N日 D+1开盘买入→D+1收盘 的均值与胜率(open真实口径, 扣隔夜gap).
    仅供展示参考, 不作放行/排序依据(记忆: 30日T+1均值无预测力)."""
    if hist is None or len(hist) < lookback + 2:
        return 0.0, 0.0, 0
    rets = []
    for i in range(-lookback - 1, -1):
        o = hist["open"].iloc[i + 1]
        c = hist["close"].iloc[i + 1]
        if o > 0:
            rets.append((c / o - 1) * 100)
    if not rets:
        return 0.0, 0.0, 0
    win = sum(1 for r in rets if r > 0) / len(rets) * 100
    return round(float(np.mean(rets)), 3), round(win, 1), len(rets)


def _safe_last(hist, col):
    """取最近一日数值, 缺列/空/NaN 返回 None"""
    if hist is None or col not in hist.columns or hist.empty:
        return None
    try:
        v = float(hist[col].iloc[-1])
    except (TypeError, ValueError, IndexError):
        return None
    if v != v:  # NaN
        return None
    return v


def _fetch_hist_cached(code, start_str, end_str):
    """个股历史磁盘缓存(生产用, 自包含, 不依赖实验层).
    key=(code,start,end); asof=扫描日today. 与 `_append_today_bar` 配合: 缓存只含 date<今日 的
    已完成bar(盘中/盘后都冻结信号日D=上一完整交易日), 策略末根永远由当日实时bar合成, 无双bar.
    列集与 StockAPI.get_historical_data 原样保留(turnover/amplitude 等不丢). 返回 DataFrame 或 None."""
    today = datetime.now().strftime("%Y%m%d")
    os.makedirs(CACHE_DIR, exist_ok=True)
    path = os.path.join(CACHE_DIR, f"{code}_{start_str}_{end_str}.json")
    if os.path.exists(path):
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
            if data.get("asof") == today:
                df = pd.DataFrame(data["bars"])
                df["date"] = pd.to_datetime(df["date"])
                df = df[df["date"] < pd.Timestamp(today)].reset_index(drop=True)
                for col in df.columns:
                    if col != "date":
                        df[col] = pd.to_numeric(df[col], errors="coerce")
                if len(df) >= 30:
                    return df
        except Exception:
            pass
    try:
        h = StockAPI.get_historical_data(code, start_str, end_str)
    except Exception:
        return None
    if h is None or len(h) < 30:
        return None
    h = h.sort_values("date").reset_index(drop=True)
    h["date"] = pd.to_datetime(h["date"]).dt.normalize()
    h = h[h["date"] < pd.Timestamp(today)].reset_index(drop=True)
    if len(h) < 30:
        return None
    bars = h.to_dict("records")
    for b in bars:
        b["date"] = pd.Timestamp(b["date"]).strftime("%Y%m%d")
        for k, v in list(b.items()):
            if k == "date" or v is None:
                continue
            try:
                f = float(v)
                b[k] = None if f != f else f
            except (TypeError, ValueError):
                b[k] = None
    json.dump({"asof": today, "start": start_str, "end": end_str, "bars": bars},
              open(path, "w", encoding="utf-8"), ensure_ascii=False)
    return h


def _pe_of(row, code, pe_map=None):
    """信息面: 市盈率代理信号. 行内或批量map取值, 缺失返回 None"""
    pe = row.get("pe") if hasattr(row, "get") else None
    if pe is None or (isinstance(pe, float) and pe != pe):
        pe = (pe_map or {}).get(code)
    try:
        pe = float(pe)
    except (TypeError, ValueError):
        return None
    return pe if pe == pe else None


def _volume_ratio(hist):
    """今日量/5日均量 (盘面量能)"""
    if "volume" not in hist.columns or len(hist) < 6:
        return None
    try:
        v_last = float(hist["volume"].iloc[-1] or 0)
        v_prev = float(hist["volume"].iloc[-6:-1].mean() or 0)
    except (TypeError, ValueError):
        return None
    if v_prev <= 0:
        return None
    return v_last / v_prev


def _hard_reject(name, price, hist, row, pe_map=None):
    """杂毛/高位 硬剔除: 命中任一即排除(而非降权). 返回原因或 None.
    全部信号来自 盘面(涨幅/连板/量价) · 资金(成交额/换手) · 信息(价格/名称/估值)"""
    code = str(row.get("code", "") or "").strip()
    # 信息面: 仙股 / 垃圾标签
    if 0 < price < MIN_PRICE:
        return "仙股(价格<3元)"
    nm = str(name or "").upper()
    if "ST" in nm or "退" in nm:
        return "垃圾标签"
    if nm.startswith("N") or nm.startswith("C"):
        return "垃圾标签"
    close = hist["close"]
    last = float(close.iloc[-1])
    # 盘面: 高位加速末端(近10日涨幅过大)
    if len(close) >= 11:
        ret10 = (last / float(close.iloc[-11]) - 1) * 100
        if ret10 > MAX_RET_10D:
            return "高位(近10日涨%.0f%%)" % ret10
    # 盘面: 趋势破位(收盘跌破MA20 且 距20日高点回撤>10%) — 高位放量滞涨后破位
    if len(close) >= 20 and "high" in hist.columns:
        ma20 = float(close.iloc[-20:].mean())
        hi20 = float(hist["high"].iloc[-20:].max())
        if hi20 > 0 and last < ma20 and (last / hi20 - 1) * 100 < -10:
            return "趋势破位(跌破MA20)"
    # 盘面: 高位连板(断板风险)
    if "change_pct" in hist.columns:
        streak = 0
        for cp in reversed(hist["change_pct"].iloc[-6:].tolist()):
            try:
                if float(cp) >= 9.5:
                    streak += 1
                else:
                    break
            except (TypeError, ValueError):
                break
        if streak > MAX_LIMITUP_STREAK:
            return "高位连板(≥3板)"
    # 盘面: 涨停次日放量分歧(昨日涨停 + 今日未封板 + 量能放大50%) — 高位出货信号
    if "change_pct" in hist.columns and "volume" in hist.columns and len(hist) >= 2:
        try:
            cp_prev = float(hist["change_pct"].iloc[-2] or 0)
            cp_last = float(hist["change_pct"].iloc[-1] or 0)
            v_prev = float(hist["volume"].iloc[-2] or 0)
            v_last = float(hist["volume"].iloc[-1] or 0)
            if cp_prev >= 9.5 and cp_last < 9.5 and v_prev > 0 and v_last > v_prev * 1.5:
                return "涨停次日放量分歧"
        except (TypeError, ValueError):
            pass
    # 资金面: 日成交额不足(流动性/庄股)
    amt = _safe_last(hist, "amount")
    if amt is not None and 0 < amt < MIN_DAILY_AMOUNT:
        return "成交额不足(<1亿)"
    # 资金面: 换手率过高(分歧出货)
    to = _safe_last(hist, "turnover")
    if to is not None and to > MAX_TURNOVER:
        return "换手过高(>25%)"
    # 信息面: 估值异常(亏损PE<0 或 纯题材PE>150)
    pe = _pe_of(row, code, pe_map)
    if pe is not None and (pe < 0 or pe > MAX_PE):
        return "估值异常(PE=%.0f)" % pe
    return None


def _quality_score(hist, change_pct, row, pe_map=None, code=""):
    """盘面/资金质量评分 0~100. 纯量价/资金/估值, 不掺历史收益."""
    score = 0.0
    n = len(hist)
    if n < 2:
        return 50.0
    close = hist["close"]
    last = float(close.iloc[-1])

    # 资金面: 换手率 (满分30)
    to = _safe_last(hist, "turnover")
    if to is not None and to > 0:
        if 3 <= to <= 15:   score += 30
        elif 15 < to <= 25: score += 20
        elif 1 <= to < 3:   score += 14
        else:               score += 8
    else:
        score += 15

    # 资金面: 今日量能放大 (满分20)
    vr = _volume_ratio(hist)
    if vr is not None:
        if 1.2 <= vr <= 3.0: score += 20
        elif 0.8 <= vr < 1.2: score += 12
        elif vr > 3.0:        score += 6
        else:                 score += 8
    else:
        score += 10

    # 盘面: 位置/突破启动 (满分25)
    if "high" in hist.columns and n >= 20:
        recent_high = float(hist["high"].iloc[-20:].max())
    else:
        recent_high = float(close.iloc[-min(n, 20):].max())
    near_high = recent_high > 0 and last >= recent_high * 0.97
    ret5 = (last / float(close.iloc[-6]) - 1) * 100 if n >= 6 else 0
    if near_high and 0 <= ret5 <= 25:
        score += 25     # 突破启动初期
    elif 0 <= ret5 <= 20:
        score += 18     # 健康上行
    elif ret5 < 0:
        score += 12     # 回落低吸位
    else:
        score += 8      # 已加速

    # 盘面: 今日量价配合 (满分15)
    o = _safe_last(hist, "open")
    c = _safe_last(hist, "close")
    if o is not None and c is not None:
        if c > o: score += 15
        elif c == o: score += 8
        else: score += 5
    else:
        score += 8

    # 信息面: 估值合理区间 (满分10)
    pe = _pe_of(row, code, pe_map)
    if pe is not None and pe > 0:
        if 10 <= pe <= 80: score += 10
        elif pe > 80:      score += 6
        else:              score += 3
    else:
        score += 5

    return round(min(score, 100), 1)


def _load_realtime_map(quotes=None):
    """信息面+盘面数据源: 批量拉全市场实时行情, 返回
    ({code: {price,change_pct,open,high,low,volume,amount,turnover,pe}}, pe_map).
    传入预取的quotes可复用同一次全市场拉取(避免每次扫描重复拉行情). 失败 → ({}, {})."""
    try:
        q = quotes if quotes is not None else StockAPI.get_realtime_quotes()
        if q is None or q.empty:
            return {}, {}
    except Exception:
        return {}, {}
    cols = [c for c in ("price", "change_pct", "open", "high", "low",
                        "volume", "amount", "turnover", "pe") if c in q.columns]
    rowmap, pemap = {}, {}
    for _, r in q.iterrows():
        c = str(r.get("code") or "").strip()
        if not c:
            continue
        rec = {}
        for k in cols:
            v = r.get(k)
            try:
                f = float(v)
            except (TypeError, ValueError):
                f = None
            rec[k] = None if f is None or f != f else f
        rowmap[c] = rec
        pe = rec.get("pe")
        if pe is not None:
            pemap[c] = pe
    return rowmap, pemap


def _build_pe_map():
    """兼容入口: 仅返回全市场实时PE map."""
    return _load_realtime_map()[1]


def _append_today_bar(hist, row, quote):
    """历史K线末根若早于今日(盘中/盘后当日bar尚未发布), 用实时行情合成当日bar追加上去,
    使策略信号/硬剔除/质量评分都基于当日盘面, 避免打板类策略在 T-1 涨停bar上误触发.
    非交易日 / 缺实时价 / 末根已是今日 → 原样返回 (hist, False)."""
    today = datetime.now().date()
    if not is_trading_day(datetime.now()):
        return hist, False
    last_date = hist["date"].iloc[-1]
    last_date = last_date.date() if hasattr(last_date, "date") else last_date
    if last_date >= today:
        return hist, False

    price = None
    if quote and quote.get("price"):
        price = quote["price"]
    if not price:
        price = float(row.get("price") or 0)
    if price <= 0:
        return hist, False

    def _q(key):
        v = quote.get(key) if quote else None
        if v is None:
            v = row.get(key)
        try:
            return None if v is None or pd.isna(v) else float(v)
        except (TypeError, ValueError):
            return None

    change_pct = _q("change_pct") or 0.0
    open_ = _q("open")
    high = _q("high")
    low = _q("low")
    amount = _q("amount")
    turnover = _q("turnover")

    pre_close = price / (1 + change_pct / 100) if change_pct > -100 else price
    if open_ is None:
        open_ = pre_close
    if high is None:
        high = max(price, open_)
    if low is None:
        low = min(price, open_)

    h2 = hist.copy()
    # 统一量纲: 历史量若非"股"口径(amount≈volume*close 不成立, 如腾讯日K的"手"),
    # 用 amount/close 重算, 与当日量保持同一口径.
    if "amount" in h2.columns and "volume" in h2.columns:
        try:
            amt = h2["amount"].replace(0, np.nan)
            ratio = (amt / (h2["volume"] * h2["close"])).replace([np.inf, -np.inf], np.nan).dropna()
            if not ratio.empty and (ratio.median() < 0.5 or ratio.median() > 1.5):
                h2["volume"] = (amt / h2["close"]).fillna(h2["volume"])
        except Exception:
            pass

    # 当日量: 用 成交额/价格 近似(单位:股), 与历史量口径一致; 无成交额则留空(量比类条件取False → 保守)
    today_vol = amount / price if amount and amount > 0 else np.nan
    bar = {"open": open_, "close": price, "high": high, "low": low, "change_pct": change_pct}
    if "date" in h2.columns:
        bar["date"] = pd.Timestamp(today)
    if "volume" in h2.columns:
        bar["volume"] = today_vol
    if "amount" in h2.columns:
        bar["amount"] = amount if amount else np.nan
    if "turnover" in h2.columns:
        bar["turnover"] = turnover if turnover is not None else np.nan
    new_row = {c: bar.get(c, np.nan) for c in h2.columns}
    h2 = pd.concat([h2, pd.DataFrame([new_row])], ignore_index=True)
    return h2, True


def _score_stock(row, hist, allowed_strategies=None, pe_map=None, quote=None):
    """评分核心: 策略信号(盘面/资金/信息的技术化表达) → 杂毛/高位硬剔除 → 盘面资金质量评分.
    不再以历史均收益作为放行或排序依据. quote=当日实时行情dict, 用于合成当日bar, 防 T-1 末根误触发."""
    from paper_trading import _STRAT_INSTANCES
    code = str(row.get("code", "") or "").strip()
    name = str(row.get("name", "") or "").strip()
    price = float(row.get("price", 0) or 0)
    change_pct = float(row.get("change_pct", 0) or 0)
    if hist is None or len(hist) < 40:
        return None
    hist, _ = _append_today_bar(hist, row, quote)

    # 硬剔除前置(2026-08-29提速): 命中即排除, 先剔除可跳过昂贵的策略信号计算.
    # _hard_reject 只读 name/price/hist/row/pe_map, 与策略是否运行无关 → 顺序调整不改变结果.
    if _hard_reject(name, price, hist, row, pe_map):
        return None

    triggered = []
    for sname, stg in _STRAT_INSTANCES.items():
        if allowed_strategies is not None and sname not in allowed_strategies:
            continue
        try:
            sdf = stg.generate_signals(hist.copy())
            if "signal" in sdf.columns and float(sdf["signal"].iloc[-1]) > 0:
                triggered.append(sname)
        except Exception:
            pass
    if not triggered:
        return None

    q = _quality_score(hist, change_pct, row, pe_map, code)
    exp_ret, win_rate, n = _estimate_t1_return(hist)
    return {
        "code": code, "name": name, "price": round(price, 2),
        "change_pct": round(change_pct, 2),
        "strategies": triggered, "signal_count": len(triggered),
        "quality_score": q,
        "expected_return": round(exp_ret, 2), "win_rate": win_rate, "t1_samples": n,
    }


def _scan_sector(sector, start_str, end_str, allowed_strategies=None, pe_map=None, rt_map=None):
    """扫描一个板块: 成分→过滤→策略信号→杂毛剔除→质量评分排序"""
    members = StockAPI.get_industry_stocks(sector["code"])
    if members is None or members.empty:
        return []
    members = filter_universe(members)
    if members.empty:
        return []
    sort_col = "amount" if "amount" in members.columns else "price"
    members = members.sort_values(sort_col, ascending=False).head(MAX_STOCKS_PER_SECTOR)

    picks = []
    for _, row in members.iterrows():
        code = str(row["code"]).strip()
        price = float(row.get("price", 0) or 0)
        if price <= 0 or not code:
            continue
        try:
            hist = _fetch_hist_cached(code, start_str, end_str)
        except Exception:
            continue
        pick = _score_stock(row, hist, allowed_strategies, pe_map,
                            rt_map.get(code) if rt_map else None)
        if pick:
            pick["sector"] = sector["name"]
            pick["sector_key"] = sector["code"]
            picks.append(pick)
    picks.sort(key=lambda x: x["quality_score"], reverse=True)
    return picks


def _pick_key(p):
    """排序键(2026-09-01): 避开两个已被实盘/重放否定的选择偏差.
    - 质量甜点带优先: 300日重放(prod_pipeline_replay)实测 80-90档胜率~45%稳定劣化(占主推69%),
      70-80档甜点(+0.65%); 实盘85+候选均值-1.10%/胜率20%. → 70-85 优先, >85 有甜点空位时靠后.
    - 幻方独推靠后: 幻方·动态多因子是反预测排序器(高预期组实盘-1.22%), 独推(仅它一个策略)
      的候选实盘均值-0.99%/胜率25%. → 同带内 solo-幻方 排最后, 避免主推/备用命中它.
    expected_return 为 gap 高估历史口径(无预测力), 不参与任何排序."""
    q = float(p.get("quality_score", 0) or 0)
    band = 0 if 70 <= q <= 85 else (1 if q < 70 else 2)   # 甜点带>低分带>高分带
    solo_hf = bool(p.get("strategies")) and len(p["strategies"]) == 1 \
        and str(p["strategies"][0]).startswith("幻方")
    return (band, solo_hf, -q)


def _pick_top_n(all_picks, n=MAX_PICKS):
    """跨板块分散取前N(2026-08-29): 主推=排序第1; 其余按 _pick_key 贪心,
    每板块至多取1只(已有板块不重复, 避险分散); 不同板块不足n只时用剩余最高质量补足(可同板块).
    返回 list[pick] 按 _pick_key 序; 空池 → []."""
    if not all_picks:
        return []
    all_picks = sorted(all_picks, key=_pick_key)
    chosen, sectors = [], set()
    for p in all_picks:  # 第一轮: 每板块至多1只
        if len(chosen) >= n:
            break
        sec = (p.get("sector_key") or p.get("sector") or "").strip()
        if sec and sec != "全市场" and sec in sectors:
            continue
        chosen.append(p)
        if sec and sec != "全市场":
            sectors.add(sec)
    if len(chosen) < n:  # 第二轮: 不足n → 剩余最高质量补足(可同板块)
        chosen_codes = {p["code"] for p in chosen}
        for p in all_picks:
            if len(chosen) >= n:
                break
            if p["code"] in chosen_codes:
                continue
            chosen.append(p)
            chosen_codes.add(p["code"])
    return chosen


def _assemble(hot_sectors, allowed_strategies, start_str, end_str, pe_map=None, rt_map=None):
    """并行扫描热门板块, 返回 (result_sectors, all_picks); 主推/备用由 scan_daily_picks 统一决策"""
    result_sectors = []
    all_picks = []
    with ThreadPoolExecutor(max_workers=min(4, len(hot_sectors))) as ex:
        futs = {ex.submit(_scan_sector, s, start_str, end_str, allowed_strategies, pe_map, rt_map): s
                for s in hot_sectors}
        for f in as_completed(futs):
            try:
                sec = futs[f]
                picks = f.result()
            except Exception:
                continue
            if not picks:
                continue
            result_sectors.append({
                "name": sec.get("name", ""),
                "strength": round(float(sec.get("avg_change_pct", 0)), 2),
                "lead_name": sec.get("lead_name", ""),
                "lead_change_pct": round(float(sec.get("lead_change_pct", 0)), 2),
                "picks": picks[:3],
            })
            all_picks.extend(picks)
    return result_sectors, all_picks


def _fallback_scan(allowed_strategies, today, pe_map=None, rt_map=None, quotes=None):
    """板块接口失败时: 全市场池按质量评分排序. quotes: 复用已拉取的全市场行情."""
    if quotes is None:
        quotes = StockAPI.get_realtime_quotes()
    if quotes is None or quotes.empty:
        return []
    quotes = filter_universe(quotes)
    sort_col = "amount" if "amount" in quotes.columns else "price"
    quotes = quotes.sort_values(sort_col, ascending=False).head(60)
    end_str = today
    start_str = (datetime.now() - timedelta(days=120)).strftime("%Y%m%d")
    picks = []
    for _, row in quotes.iterrows():
        price = float(row.get("price", 0) or 0)
        if price <= 0:
            continue
        try:
            hist = _fetch_hist_cached(str(row["code"]), start_str, end_str)
        except Exception:
            continue
        pick = _score_stock(row, hist, allowed_strategies, pe_map,
                            (rt_map or {}).get(str(row["code"]).strip()))
        if pick:
            pick["sector"] = "全市场"
            pick["sector_key"] = ""
            picks.append(pick)
    picks.sort(key=lambda x: x["quality_score"], reverse=True)
    return picks


def _scan_stock_flat(row, allowed_strategies, pe_map, rt_map, start_str, end_str):
    """单只股票扫描(成交额宇宙用): 与 _scan_sector 内同逻辑, sector=全市场."""
    code = str(row.get("code", "") or "").strip()
    price = float(row.get("price", 0) or 0)
    if price <= 0 or not code:
        return None
    try:
        hist = _fetch_hist_cached(code, start_str, end_str)
    except Exception:
        return None
    pick = _score_stock(row, hist, allowed_strategies, pe_map,
                        (rt_map or {}).get(code))
    if pick:
        pick["sector"] = "全市场"
        pick["sector_key"] = ""
    return pick


def _scan_amount_universe(n, allowed_strategies, pe_map, rt_map, start_str, end_str, quotes=None):
    """候选宇宙主源: top-N 成交额(全市场扫描, 并行).
    数据依据(amount_limitup实验, asof=20260826): 同一批打板策略在top300成交额宇宙
    裸边 +0.317%/日(edge衰减持续走强), 而热门板块 ≈0(k=2起转负) → 生产从板块选股致负战绩,
    主宇宙应切到成交额. quotes: 复用scan_daily_picks已拉取的全市场行情, 避免重复拉取."""
    if quotes is None:
        quotes = StockAPI.get_realtime_quotes()
    if quotes is None or quotes.empty:
        return []
    quotes = filter_universe(quotes)
    sort_col = "amount" if "amount" in quotes.columns else "price"
    top = quotes.sort_values(sort_col, ascending=False).head(n)
    picks = []
    with ThreadPoolExecutor(max_workers=8) as ex:
        futs = {ex.submit(_scan_stock_flat, row, allowed_strategies, pe_map, rt_map,
                          start_str, end_str): row for _, row in top.iterrows()}
        for f in as_completed(futs):
            try:
                p = f.result()
            except Exception:
                continue
            if p:
                picks.append(p)
    return picks


def _merge_picks(hot_picks, amount_picks):
    """候选并集去重: 同code保留热门板块版本(带sector, 供主推/备用跨板块分散)."""
    by_code = {}
    for p in (hot_picks or []):
        by_code[p["code"]] = p
    for p in (amount_picks or []):
        by_code.setdefault(p["code"], p)
    return list(by_code.values())


def scan_daily_picks(force=False):
    """每日推荐: 返回 dict{regime, sectors, main_pick, backup_pick, scanned_at, date}"""
    today = datetime.now().strftime("%Y%m%d")
    cache_path = os.path.join(PICKS_DIR, f"{today}.json")
    existing = None
    if os.path.exists(cache_path):
        try:
            with open(cache_path, "r", encoding="utf-8") as f:
                existing = json.load(f)
        except Exception:
            pass
    if not force and existing:
        return existing
    os.makedirs(PICKS_DIR, exist_ok=True)

    result = {"date": today, "scanned_at": datetime.now().strftime("%H:%M:%S"),
              "regime": None, "sectors": [], "main_pick": None, "backup_pick": None,
              "fallback": False}

    regime = index_regime()
    result["regime"] = regime
    if regime.get("skip"):
        _save_picks(cache_path, result)
        return result

    from strategy_backtest import strategies_for_regime
    allowed = strategies_for_regime(regime.get("level")) if regime.get("level") else []
    if not allowed and regime.get("weak_only"):
        allowed = list(_LOW_BUY_STRATEGIES)
    allowed_set = set(allowed) if allowed else None

    # 全市场实时行情只拉一次, 供 PE/当日bar合成(rt_map) + 成交额宇宙排序/板块扫描复用
    rt_quotes = StockAPI.get_realtime_quotes()
    rt_map, pe_map = _load_realtime_map(rt_quotes)

    end_str = today
    start_str = (datetime.now() - timedelta(days=120)).strftime("%Y%m%d")

    # ── 候选宇宙: top-N 成交额(主, 实测正边池) ∪ 热门板块(补充池) ──
    amount_picks = _scan_amount_universe(AMOUNT_UNIVERSE_N, allowed_set, pe_map,
                                         rt_map, start_str, end_str, quotes=rt_quotes)

    sectors = StockAPI.get_industry_sectors()
    if sectors is None or sectors.empty:
        result["fallback"] = True
        hot_picks = _fallback_scan(allowed_set, today, pe_map, rt_map, quotes=rt_quotes)
    else:
        sectors = sectors[~sectors["name"].astype(str).str.contains("|".join(_EXCLUDE_SECTOR_NAMES), na=False)]
        sectors = sectors[sectors["count"] >= MIN_SECTOR_COUNT]
        sectors = sectors.sort_values("avg_change_pct", ascending=False)
        hot = [dict(s) for _, s in sectors.head(regime.get("max_sectors", 5)).iterrows()]
        result["sectors"], hot_picks = _assemble(hot, allowed_set, start_str, end_str, pe_map, rt_map)
    all_picks = _merge_picks(hot_picks, amount_picks)

    # 不自动续选昨日主推(continuation已移除, 2026-08-29): T+1模型每天都是新仓位,
    # 同股重新触发信号仍可作为新候选入选, 但不再有"仍达标就优先保留"的特权路径
    # (共进股份 8/14→8/17 连续重选吃 -5.66% 的教训).
    pick_list = _pick_top_n(all_picks, MAX_PICKS)
    result["pick_list"] = pick_list
    result["main_pick"] = pick_list[0] if pick_list else None
    result["backup_pick"] = pick_list[1] if len(pick_list) > 1 else None

    # 防覆盖: 新浪成分接口盘后返回 price=0 → 盘后重扫退化为空/少板块结果.
    # 当天已生成有效推荐(有主推/备用/板块)时, 空/退化重扫结果不得覆盖旧的有效结果.
    old_valid = bool(existing and (existing.get("main_pick") or existing.get("backup_pick") or existing.get("sectors")))
    new_valid = bool(result.get("main_pick") or result.get("backup_pick") or result.get("sectors"))

    # 早盘主选粘性(2026-09-08): 已存在有效主选时, 重扫结果须"显著占优"才允许覆盖, 否则保留早盘选.
    # 避免盘后/尾盘重扫把稳健早盘票换成当日涨停高潮票(如 9/3 中视传媒→德尔未来, 前者+6%后者-1%).
    if existing and old_valid and new_valid:
        _old_main = existing.get("main_pick") or {}
        _new_main = result.get("main_pick") or {}
        _old_q = float(_old_main.get("quality_score") or 0)
        _new_q = float(_new_main.get("quality_score") or 0)
        _old_sig = int(_old_main.get("signal_count") or 0)
        _new_sig = int(_new_main.get("signal_count") or 0)
        _sig_better = (_new_q >= _old_q and _new_sig > _old_sig)
        if (_new_q - _old_q) < STICKY_OVERRIDE_GAP and not _sig_better:
            return existing  # 未显著占优 → 保留早盘主选

    if old_valid and not new_valid:
        return existing

    _save_picks(cache_path, result)
    return result


def _save_picks(path, result):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2, default=str)
    except Exception:
        pass


def load_today_picks():
    """读取当日推荐缓存(若已生成)"""
    today = datetime.now().strftime("%Y%m%d")
    path = os.path.join(PICKS_DIR, f"{today}.json")
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return None


if __name__ == "__main__":
    res = scan_daily_picks(force=True)
    print("regime:", res["regime"])
    print("main_pick:", res["main_pick"])
    print("backup_pick:", res["backup_pick"])
    for s in res["sectors"]:
        print("sector:", s["name"], s["strength"], "lead:", s["lead_name"], s["lead_change_pct"],
              "picks:", [(p["name"], p["quality_score"], p["expected_return"], p["win_rate"]) for p in s["picks"]])
