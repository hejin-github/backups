# -*- coding: utf-8 -*-
"""
sector_pool_backtest.py — 板块池(生产扫描宇宙)策略样本外实验: 开盘买入真实口径 + 风险画像

回答(用户关切):
  1) 涨停打板 58.8%/+1.67%(旧收盘口径) 在 "D+1 开盘买入→收盘卖" 真实口径下是否成立?
  2) 各策略分档位的胜率/均值/中位/std/盈亏比 — 找出 "小回撤、大上涨"(正偏态) 的策略;
  3) gap 惩罚量化: 每策略 close口径 vs open口径 的差(实证 000603 记录+10.02%→真实+0.03%)。

方法(无未来函数):
  - 宇宙: 生产扫描口径 top-N by 当日成交额, asof=上一交易日;
  - 每策略每股 generate_signals → 每个 signal 日(>=WARMUP, 排除末根)记一笔:
      close_ret = close(D+1)/close(D)-1     (旧口径, 含隔夜 gap 幻影)
      open_ret  = close(D+1)/open(D+1)-1    (真实: D+1 开盘买入→D+1 收盘卖)
      buyable   = D+1 开盘非一字涨停(可成交); 一字开盘另计 unfillable
  - 按上证档位分桶; 分档位: n/胜率/均值/中位/std/盈亏比(avg_win/|avg_loss|);
  - 每策略整体: 逐日净值(有信号日取 buyable 均值, 无信号=0) → maxDD/年化Sharpe, 扣0.20%成本。

依赖腾讯行情(网络恢复后运行)。输出 data/ranker_experiment/sector_pool_result.json
"""
import json
import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

import numpy as np
import pandas as pd

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

from strategy_backtest import _prev_trading_day, _classify_regime, _load_index_for_regime
from stock_api import StockAPI
from stock_universe import filter_universe
from strategies import list_strategies, get_strategy
from experiment_common import fetch_hist_cached, CACHE_DIR

BASE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(BASE, "data", "ranker_experiment")
OUT = os.path.join(OUT_DIR, "sector_pool_result.json")
REGIMES = ["strong", "normal", "weak", "crash"]
WARMUP = 20
COST = 0.20  # 单边? 每笔 0.20%(佣金万2.5*2+印花0.05%+过户0.001%*2+滑点10bp), 与主实验一致


def _oneword_open(nxt):
    """D+1 开盘一字涨停 → 买不进."""
    o, h, l = float(nxt["open"]), float(nxt["high"]), float(nxt["low"])
    return (h - l) < 0.03 and o >= h - 0.005 and o > 0


def _stats(rets):
    """单桶统计: n/胜率/均值/中位/std/盈亏比(avg_win/|avg_loss|)."""
    if not rets:
        return None
    a = np.array(rets)
    wins, loss = a[a > 0], a[a <= 0]
    if len(wins) and len(loss):
        wl = float(wins.mean() / abs(loss.mean()))
    elif len(wins):
        wl = float("inf")
    else:
        wl = 0.0
    return {"n": len(a), "win_rate": round(100 * (a > 0).mean(), 1),
            "mean": round(float(a.mean()), 3), "median": round(float(np.median(a)), 3),
            "std": round(float(a.std()), 3),
            "avg_win": round(float(wins.mean()), 3) if len(wins) else 0.0,
            "avg_loss": round(float(loss.mean()), 3) if len(loss) else 0.0,
            "win_loss_ratio": round(float(wl), 2) if wl != float("inf") else 999.0}


def run(sample_limit=300, lookback_days=400, asof=None, cost=COST):
    if asof is None:
        asof = _prev_trading_day()
    asof_ts = pd.Timestamp(asof).normalize()
    print(f"板块池回测: top{sample_limit} by 成交额 | 窗口 {lookback_days} 交易日 | asof={asof_ts.date()}")

    # ── 宇宙: 生产扫描口径 ──
    quotes = StockAPI.get_realtime_quotes()
    if quotes is None or quotes.empty:
        print("实时行情获取失败(腾讯网络?)"); return None
    quotes = filter_universe(quotes)
    sort_col = "amount" if "amount" in quotes.columns else "price"
    sample = quotes.sort_values(sort_col, ascending=False).head(sample_limit)

    # ── 指数档位(截至 asof) ──
    idx = _load_index_for_regime(asof_ts, lookback_days)
    if idx is None:
        print("指数数据不足"); return None
    regimes = {}
    for _, row in idx.iterrows():
        if pd.isna(row["ma20"]):
            continue
        regimes[row["date"].normalize()] = _classify_regime(float(row["close"]), float(row["ma20"]))

    # ── 拉个股历史(磁盘缓存+退避) ──
    end_str = asof_ts.strftime("%Y%m%d")
    start_str = (asof_ts - pd.Timedelta(days=int(lookback_days * 1.75))).strftime("%Y%m%d")
    codes = sample["code"].tolist()
    hist_cache = {}
    for attempt, (workers, backoff) in enumerate([(8, 15), (6, 45), (4, 120)]):
        missing = [c for c in codes if c not in hist_cache]
        if not missing:
            break
        if attempt:
            print(f"退避 {backoff}s 补拉 {len(missing)} 只...")
            import time; time.sleep(backoff)
        with ThreadPoolExecutor(max_workers=workers) as ex:
            fs = {ex.submit(fetch_hist_cached, c, start_str, end_str, asof): c for c in missing}
            for f in as_completed(fs):
                try:
                    h = f.result()
                except Exception:
                    h = None
                if h is not None and len(h) >= 30:
                    hist_cache[fs[f]] = h
    print(f"个股历史: {len(hist_cache)}/{len(codes)}")

    # ── 逐策略逐股扫信号 ──
    strategies = [n for n in list_strategies() if n != "组合策略·投票系统"]
    per_sig = {s: {r: [] for r in REGIMES} for s in strategies}
    daily = {s: {} for s in strategies}  # date -> list(open_ret buyable)

    for sname in strategies:
        try:
            stg = get_strategy(sname)
        except Exception:
            continue
        if stg is None:
            continue
        for code, hist in hist_cache.items():
            try:
                sdf = stg.generate_signals(hist.copy())
            except Exception:
                continue
            if "signal" not in sdf.columns:
                continue
            sig = sdf["signal"].astype(float).values
            closes = hist["close"].astype(float).values
            opens = hist["open"].astype(float).values
            highs = hist["high"].astype(float).values
            lows = hist["low"].astype(float).values
            dates = hist["date"].values
            n = len(sig)
            for i in range(WARMUP, n - 1):
                if sig[i] <= 0 or closes[i] <= 0 or opens[i + 1] <= 0:
                    continue
                d = pd.Timestamp(dates[i]).normalize()
                rg = regimes.get(d)
                if rg is None:
                    continue
                close_ret = (closes[i + 1] / closes[i] - 1) * 100
                open_ret = (closes[i + 1] / opens[i + 1] - 1) * 100
                nxt = {"open": opens[i + 1], "high": highs[i + 1], "low": lows[i + 1]}
                buyable = not _oneword_open(nxt)
                per_sig[sname][rg].append(
                    {"c": close_ret, "o": open_ret, "buy": buyable, "d": str(d.date())})
                if buyable:
                    daily[sname].setdefault(str(d.date()), []).append(open_ret)

    # ── 聚合输出 ──
    all_dates = sorted(set().union(*[set(ds) for ds in daily.values()]))
    result = {}
    for sname in strategies:
        agg = {"regimes": {}, "close_vs_open_gap": {}, "nav": {}, "signals": 0}
        for rg in REGIMES:
            rows = per_sig[sname][rg]
            if not rows:
                agg["regimes"][rg] = None
                continue
            agg["regimes"][rg] = {
                "close口径": _stats([r["c"] for r in rows]),
                "open口径(真实)": _stats([r["o"] for r in rows]),
                "open可买(剔除一字)": _stats([r["o"] for r in rows if r["buy"]]),
                "unfillable一字": sum(1 for r in rows if not r["buy"]),
            }
            agg["close_vs_open_gap"][rg] = round(
                float(np.mean([r["c"] for r in rows]) - np.mean([r["o"] for r in rows])), 3)
        # 逐日净值(有信号日取可买 open 均值, 无信号=0) → maxDD/Sharpe
        ndates = all_dates
        vals = []
        for d in ndates:
            if d in daily[sname] and daily[sname]:
                v = float(np.mean(daily[sname][d]))
                vals.append(v - cost)
            else:
                vals.append(0.0)
        v = np.array(vals)
        navc = np.cumprod(1 + v / 100.0)
        peak = np.maximum.accumulate(navc)
        dd = ((navc - peak) / peak * 100).min() if len(navc) else 0.0
        sharpe = float(np.mean(v) / np.std(v) * np.sqrt(252)) if np.std(v) > 0 else 0.0
        agg["nav"] = {"days": len(v), "net_mean_daily": round(float(np.mean(v)), 4),
                      "maxDD": round(float(dd), 2), "sharpe": round(sharpe, 2)}
        agg["signals"] = sum(len(r) for r in per_sig[sname].values())
        result[sname] = agg

    os.makedirs(OUT_DIR, exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    # ── 打印(按信号数排序, 突出涨停打板/龙头) ──
    print(f"\n{'策略':<20}{'信号':>6} | open真实口径 全档 胜率/均值 | maxDD/sharpe | gap(close-open)")
    order = sorted(result, key=lambda x: -result[x]["signals"])
    focus = [s for s in order if any(k in s for k in ("涨停", "龙头", "首板", "打板"))]
    for sname in (focus + [s for s in order if s not in focus]):
        a = result[sname]
        oa = [g for g in a["regimes"].values() if g and g.get("open口径(真实)")]
        if not oa:
            continue
        tot = _stats(sum(([r["o"] for r in per_sig[sname][rg]] for rg in REGIMES), []))
        print(f"{sname:<20}{a['signals']:>6}{tot['win_rate']:>8.1f}%{tot['mean']:>+7.2f} | "
              f"{a['nav']['maxDD']:>6.1f}%/{a['nav']['sharpe']:>5.2f} | "
              f"{np.mean([v for v in a['close_vs_open_gap'].values()]):+.2f}pp")
    print(f"\n结果 → {OUT}")


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--sample-limit", type=int, default=300)
    ap.add_argument("--lookback-days", type=int, default=400)
    ap.add_argument("--asof", default=None)
    args = ap.parse_args()
    run(sample_limit=args.sample_limit, lookback_days=args.lookback_days, asof=args.asof)
