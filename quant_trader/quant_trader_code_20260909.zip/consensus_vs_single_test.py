# -*- coding: utf-8 -*-
"""
实验: "策略不强制共振(单策略质控)" vs "强制共振", 哪个 T+1 效果好? (样本外)

核心问题: 用户设想"策略不同共振意义不大, 只要策略本身样本外胜率高就信".
本实验把"共振"还原到它本来的含义 —— 同一只股票当日被几个策略同时看多,
对比不同 min_signals 门槛在 样本外测试集 上的 T+1 胜率/收益.

方法(与 regime_adaptive_test 同管线, 消除前视泄漏):
  1. top-by-amount 采样股票, 拉 320 日历史 + 上证指数逐日档位
  2. 每策略逐股跑信号序列, 每条 signal>0 记为 (date, stock, regime, strategy, ret, trailing_win_rate)
  3. 训练集=前60%交易日 → 各策略各档位统计(样本≥30, 胜率≥52%, 均值>0) → allowed_train(样本外)
  4. 测试集=后40%, 按 (日,股票) 聚合信号: 统计该股当日被多少策略看多(分 allowed / 全策略)
  5. 配置对比(信号级 = 每日选股前的全部通过股票, 每日选股 = 当日按过去20日T+1胜率取 top1):
       C1 单策略质控(新上线): ≥1 个 allowed 策略信号
       C2 质控池内共振:       ≥2 个 allowed 策略信号
       C3 质控池内强共振:     ≥3 个 allowed 策略信号
       C4 旧共识门(老生产):   ≥2 个任意策略信号
       C5 无门槛参照:         ≥1 个任意策略信号
输出: data/consensus_vs_single_result.json + 控制台对比表
"""
import json
import os
import sys
import numpy as np
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

from stock_api import StockAPI
from stock_universe import filter_universe
from strategies import list_strategies, get_strategy
from strategy_backtest import REGIMES, _classify_regime

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "consensus_vs_single_result.json")

TRAIN_FRAC = 0.6
MIN_TOTAL = 30
MIN_WIN = 52.0
MIN_AVG = 0.0
TOP_N_DAILY = 1


def _load_index_regimes(lookback_days=320):
    idx = None
    try:
        idx = StockAPI.get_index_historical_data("sh000001", days=lookback_days)
    except Exception:
        idx = None
    if idx is None or len(idx) < 30:
        try:
            from index_guide import load_sh_raw
            raw = load_sh_raw()
            dates, closes = raw.get("dates", []), raw.get("closes", [])
            if len(dates) >= 30:
                df = pd.DataFrame({"date": pd.to_datetime(dates), "close": closes})
                df = df.sort_values("date").reset_index(drop=True)
                idx = df
        except Exception:
            idx = None
    if idx is None or len(idx) < 30:
        return None, None
    idx = idx.sort_values("date").reset_index(drop=True)
    idx["date"] = pd.to_datetime(idx["date"])
    idx["ma20"] = idx["close"].rolling(20).mean()
    regimes = {}
    for _, row in idx.iterrows():
        if pd.isna(row["ma20"]):
            continue
        regimes[row["date"].normalize()] = _classify_regime(float(row["close"]), float(row["ma20"]))
    return regimes, idx["date"].iloc[0]


def _fetch_hist(code, start_str, end_str):
    try:
        h = StockAPI.get_historical_data(code, start_str, end_str)
        if h is not None and len(h) >= 30:
            h = h.sort_values("date").reset_index(drop=True)
            h["date"] = pd.to_datetime(h["date"])
            return code, h
    except Exception:
        pass
    return code, None


def _daily_t1_win_rate(hist, idx):
    if idx < 9:
        return None
    lo = max(0, idx - 20)
    wins, tot = 0, 0
    for i in range(lo, idx):
        b, s = float(hist["close"].iloc[i]), float(hist["close"].iloc[i + 1])
        if b > 0:
            tot += 1
            if s / b - 1 > 0:
                wins += 1
    if tot < 8:
        return None
    return wins / tot


def run(sample_limit=200, lookback_days=320):
    quotes = StockAPI.get_realtime_quotes()
    if quotes is None or quotes.empty:
        return None
    quotes = filter_universe(quotes)
    sort_col = "amount" if "amount" in quotes.columns else "price"
    quotes = quotes.sort_values(sort_col, ascending=False)
    sample = quotes.head(sample_limit)

    regimes, idx_first = _load_index_regimes(lookback_days)
    if regimes is None:
        print("指数数据不足")
        return None
    end = datetime.now()
    buf = timedelta(days=25)
    start_str = (idx_first - buf).strftime("%Y%m%d")
    end_str = end.strftime("%Y%m%d")
    print(f"指数档位日数: {len(regimes)} | 个股窗口 {start_str}~{end_str}")

    hist_cache = {}
    with ThreadPoolExecutor(max_workers=8) as ex:
        fs = {ex.submit(_fetch_hist, c, start_str, end_str): c for c in sample["code"].tolist()}
        for f in as_completed(fs):
            try:
                c, h = f.result()
                if h is not None:
                    hist_cache[c] = h
            except Exception:
                pass
    print(f"个股历史: {len(hist_cache)}/{len(sample)}")

    strategy_names = [n for n in list_strategies() if n != "组合策略·投票系统"]
    # 每条信号: (date, stock, regime, strategy, ret, trailing_win_rate)
    signals = []
    for sname in strategy_names:
        try:
            stg = get_strategy(sname)
        except Exception:
            continue
        if stg is None:
            continue
        for code, hist in hist_cache.items():
            try:
                sdf = stg.generate_signals(hist.copy())
            except Exception:
                continue
            if "signal" not in sdf.columns:
                continue
            sig = sdf["signal"].astype(float).values
            closes = hist["close"].astype(float).values
            dates = hist["date"].values
            n = len(sig)
            for i in range(20, n - 1):
                if sig[i] <= 0 or closes[i] <= 0:
                    continue
                d = pd.Timestamp(dates[i]).normalize()
                regime = regimes.get(d)
                if regime is None:
                    continue
                ret = (closes[i + 1] / closes[i] - 1) * 100
                twr = _daily_t1_win_rate(hist, i)
                signals.append((d, code, regime, sname, ret, twr))

    trade_days = sorted({d for d, *_ in signals})
    if len(trade_days) < 40:
        print(f"交易日样本过少: {len(trade_days)}")
        return None
    split_at = trade_days[int(len(trade_days) * TRAIN_FRAC)]
    train_days = {d for d in trade_days if d < split_at}
    test_days = [d for d in trade_days if d >= split_at]
    print(f"训练日 {len(train_days)} (至{split_at.date()}) | 测试日 {len(test_days)}")

    # ── 训练: allowed_train(样本外) ──
    train_bucket = {s: {r: [] for r in REGIMES} for s in strategy_names}
    for d, _c, r, sname, ret, _tw in signals:
        if d in train_days:
            train_bucket[sname][r].append(ret)
    allowed_train = {r: [] for r in REGIMES}
    for s in train_bucket:
        for r in REGIMES:
            rets = train_bucket[s][r]
            t = len(rets)
            if t < MIN_TOTAL:
                continue
            wr = sum(1 for x in rets if x > 0) / t * 100
            avg = float(np.mean(rets))
            if wr >= MIN_WIN and avg > MIN_AVG:
                allowed_train[r].append((s, avg))
    for r in REGIMES:
        allowed_train[r].sort(key=lambda x: -x[1])
        allowed_train[r] = [x[0] for x in allowed_train[r]]
    print("\n=== 训练集样本外 allowed ===")
    for r in REGIMES:
        print(f"  {r:<6}: {', '.join(allowed_train[r]) if allowed_train[r] else '(空)'}")

    # ── 测试: 按 (日,股票) 聚合 ──
    # by_ds[date][stock] = {"regime":r, "ret":ret, "twr":tw, "all":set(), "allowed":set()}
    by_ds = {}
    for d, code, r, sname, ret, tw in signals:
        if d not in test_days:
            continue
        ds = by_ds.setdefault(d, {}).setdefault(code, {"regime": r, "ret": ret, "twr": tw, "all": set(), "allowed": set()})
        ds["all"].add(sname)
        if sname in set(allowed_train[r]):
            ds["allowed"].add(sname)
    print(f"\n测试期 (日,股票) 聚合: {sum(len(v) for v in by_ds.values())} 条")

    # ── 配置评估 ──
    def _eval(name, allow_pool, min_sig):
        """allow_pool: 'all'|'allowed'; 通过 = 当日该股在池内策略信号数 >= min_sig"""
        buckets = {r: [] for r in REGIMES}
        per_day = {d: {r: [] for r in REGIMES} for d in test_days}
        for d, stocks in by_ds.items():
            for code, ds in stocks.items():
                key = "allowed" if allow_pool == "allowed" else "all"
                cnt = len(ds[key])
                if cnt < min_sig:
                    continue
                r = ds["regime"]
                buckets[r].append(ds["ret"])
                per_day[d][r].append((code, ds["ret"], ds["twr"]))
        return buckets, per_day

    def _agg(name, buckets, per_day):
        print(f"\n=== {name} ===")
        rows = {}
        all_ret, all_pick = [], []
        for r in REGIMES:
            rets = buckets[r]
            t = len(rets)
            wr = round(sum(1 for x in rets if x > 0) / t * 100, 1) if t else 0.0
            avg = round(float(np.mean(rets)), 3) if t else 0.0
            pk = []
            for d in test_days:
                pool = per_day[d][r]
                if not pool:
                    continue
                ranked = sorted(pool, key=lambda x: (x[2] is not None, x[2] if x[2] is not None else -1), reverse=True)
                pk.append(ranked[0][1])   # TOP_N_DAILY=1
            pt = len(pk)
            pwr = round(sum(1 for x in pk if x > 0) / pt * 100, 1) if pt else 0.0
            pavg = round(float(np.mean(pk)), 3) if pt else 0.0
            rows[r] = {"signal_total": t, "signal_win": wr, "signal_avg": avg,
                       "pick_total": pt, "pick_win": pwr, "pick_avg": pavg}
            print(f"  {r:<6} t={t:>5} 胜率{wr:>6.1f}% 均值{avg:>+7.3f}% | "
                  f"每日选股{pt:>4} 胜率{pwr:>6.1f}% 均值{pavg:>+7.3f}%")
            all_ret.extend(rets)
            all_pick.extend(pk)
        t = len(all_ret)
        wr = round(sum(1 for x in all_ret if x > 0) / t * 100, 1) if t else 0.0
        avg = round(float(np.mean(all_ret)), 3) if t else 0.0
        pt = len(all_pick)
        pwr = round(sum(1 for x in all_pick if x > 0) / pt * 100, 1) if pt else 0.0
        pavg = round(float(np.mean(all_pick)), 3) if pt else 0.0
        rows["_ALL"] = {"signal_total": t, "signal_win": wr, "signal_avg": avg,
                        "pick_total": pt, "pick_win": pwr, "pick_avg": pavg}
        print(f"  汇总    信号{t:>5} 胜率{wr:>6.1f}% 均值{avg:>+7.3f}% | "
              f"每日选股{pt:>4} 胜率{pwr:>6.1f}% 均值{pavg:>+7.3f}%")
        return rows

    def _run(name, pool, min_sig):
        b, p = _eval(name, pool, min_sig)
        return _agg(name, b, p)

    res = {
        "train_days": len(train_days), "test_days": len(test_days),
        "stocks": len(hist_cache), "strategies": len(strategy_names),
        "thresholds": {"min_total": MIN_TOTAL, "min_win": MIN_WIN, "min_avg": MIN_AVG},
        "allowed_train": allowed_train,
        "C1_single_allowed_ge1": _run("C1 单策略质控(新) ≥1 allowed", "allowed", 1),
        "C2_consensus_allowed_ge2": _run("C2 质控池内共振 ≥2 allowed", "allowed", 2),
        "C3_strong_allowed_ge3": _run("C3 质控池内强共振 ≥3 allowed", "allowed", 3),
        "C4_old_consensus_ge2_any": _run("C4 旧共识门 ≥2 任意策略(老生产)", "all", 2),
        "C5_all_signals_ge1": _run("C5 无门槛 ≥1 任意策略(参照)", "all", 1),
    }
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)
    print(f"\n结果已保存: {OUT}")
    return res


if __name__ == "__main__":
    run(sample_limit=200, lookback_days=320)
