@echo off
chcp 65001 >nul
title QuantTrader v2.0 量化交易系统

echo ============================================
echo    QuantTrader v2.0 量化交易系统
echo    11个页面 ^| 13+1个策略 ^| 因子优化 ^| 实时监控
echo ============================================
echo.

:: 检查 Python
py --version >nul 2>&1
if errorlevel 1 (
    echo [错误] 未检测到 Python，请先安装 Python 3.9+
    pause
    exit /b 1
)

echo [1/3] 检查依赖...
py -m pip install -r requirements.txt -q

:: 停止旧实例（防止端口冲突和模块缓存残留）
echo [2/3] 停止旧实例...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr :8501 ^| findstr LISTENING') do (
    taskkill /f /pid %%a >nul 2>&1
)
taskkill /f /im streamlit.exe >nul 2>&1
timeout /t 2 /nobreak >nul

:: 清理 Python 字节码缓存（避免旧缓存干扰）
if exist __pycache__ (
    rmdir /s /q __pycache__ >nul 2>&1
)
for /d /r . %%d in (__pycache__) do @if exist "%%d" rmdir /s /q "%%d" >nul 2>&1

echo [3/3] 启动系统...
echo.
echo ============================================
echo   ✅ 启动成功！
echo   请在浏览器中访问: http://localhost:8501
echo   按 Ctrl+C 可停止系统
echo ============================================
echo.
py app.py

pause
