"""
紫苏叶策略 — Serenity 瓶颈选股理论

核心逻辑：寻找产业链中"不起眼但决定全链条产能"的卡脖子环节。
在共识真空期、低位横盘时买入，逻辑兑现或证伪时卖出。

信号规则（技术面代理实现）：
  买入(+1) → 价格处于近6个月低位（30%分位以下）+ 低波动横盘 + 缩量
  卖出(-1) → 价格进入高位（80%分位以上）或放量破位
"""

import numpy as np


class ZiSuYe:
    """紫苏叶策略 — 产业链瓶颈环节左侧布局"""

    def __init__(self):
        self.name = "紫苏叶·瓶颈选股"

    def generate_signals(self, hist):
        df = hist.copy()
        df["signal"] = 0
        if len(df) < 60:
            return df

        close = df["close"]
        volume = df["volume"]

        # ── 6个月(约120交易日)价格区间 ──
        high_6m = close.rolling(120, min_periods=30).max()
        low_6m = close.rolling(120, min_periods=30).min()
        range_pct = (close - low_6m) / (high_6m - low_6m).replace(0, np.nan)

        # ── 波动率（横盘识别） ──
        ma20 = close.rolling(20).mean()
        std20 = close.rolling(20).std()
        volatility = std20 / ma20.replace(0, np.nan)

        # ── 成交额萎缩（共识真空期代理） ──
        vol_ma20 = volume.rolling(20).mean()
        vol_ratio = volume / vol_ma20.replace(0, np.nan)

        # ── 条件 ──
        low_vol = volatility < volatility.rolling(120, min_periods=60).median()

        buy = (range_pct < 0.35) & low_vol & (vol_ratio < 1.2)
        sell = (range_pct > 0.80) | ((close < close.shift(1)) & (vol_ratio > 1.5))

        df.loc[buy, "signal"] = 1
        df.loc[sell, "signal"] = -1
        return df
