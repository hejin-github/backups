# -*- coding: utf-8 -*-
"""🐉 龙头战法 — 生产实时版(独立于首页原推荐, 实验验证 +6~7%/月口径)

选股(dragon_full口径, 与 _tmp_dragon_regime 实验一致):
  - 实时宇宙: 全市场成交额 top-150(生产主宇宙, 实测正边池)
  - _relaxed_reject: 生产 hard_reject 放开与龙头战法矛盾的3条(连板≥3 / 换手>25 / 近10日涨>40),
    保留 ST退/仙股/破位MA20/涨停次日放量分歧/成交额<1亿/PE异常 硬剔除
  - 策略信号: 按行情质量门控 strategies_for_regime(与生产首页同框架), 至少1策略触发
  - 排序: dragon_score(龙头特征分: 连板强度/断板反包/真龙量10-30亿/换手活跃带/涨停/阳线) 降序 top5

卖出纪律(实验确认的收益引擎, 替代T+1固定卖):
  - 断板止盈: 昨涨停今日未续板 → 当日收盘卖(持有连板主升浪, 断板才走)
  - 时间止损: 持有满5个交易日仍持有 → 当日收盘卖
  - 破位止损(20260903): 持仓收盘较入场价回撤≥8% 或 跌破5日线 → 当日收盘卖
    (仅判 20260903 起持仓bar, 不重解释旧仓历史; 兜住"非涨停假龙头断板失灵拖满5日")
  - 高开过滤(20260903): 入场日开盘高开≥7% → 放弃买入(状态: 未买入(高开过滤), 不占槽)
  - 涨停硬门槛(20260903): 选股须当日涨停(change_pct≥9.5%), 滤除莲花/农发/盛达式假龙头
  - 一字板(开盘一字涨停)买不进 → 该仓作废, 不占槽位
  - 五仓模型: 每仓¥10,000, 最多5个并发仓; 无空闲槽位时今日新推荐顺延(不超买)

持仓跟踪: data/dragon_positions.json 状态机(待买入→持仓→已卖出/未买入), 幂等重放.
用法: from dragon_strategy import scan_dragon; result = scan_dragon(force=True)
"""
import json
import os
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed

import numpy as np
import pandas as pd

import recommender as R
from stock_api import StockAPI
from scheduler import _next_trading_day
from strategy_backtest import strategies_for_regime

BASE = os.path.dirname(os.path.abspath(__file__))
PICKS_DIR = os.path.join(BASE, "data", "dragon_picks")
STORE_FILE = os.path.join(BASE, "data", "dragon_positions.json")

AMOUNT_UNIVERSE_N = 150   # 实验宇宙 top-150 amount
MAX_PICKS = 5             # 每日推荐上限
MAX_SLOTS = 5             # 五仓模型
TIME_STOP = 5             # 时间止损5日(实验最优)
MIN_HIST = 40
LIMIT_PCT = 9.5           # 涨停近似口径(与 _streak/_limit 一致)
STOP_LOSS_PCT = 8.0       # 破位止损: 收盘相对入场价回撤≥8% → 当日收盘卖(20260903 修复)
MA_BREAK = 5              # 破位止损: 收盘跌破5日线 → 当日收盘卖(20260903 修复)
MAX_BUY_GAP = 7.0         # 入场日开盘高开≥7% → 放弃买入(20260903 修复)
RISK_ACTIVE_DATE = "20260903"  # 规则生效日: 高开过滤/破位止损只判该日及之后的入场与持仓bar
                               # (update_positions 幂等重放旧仓时, 9/3 之前的已发生历史不被新规则重解释)
TRAIL_WIN = 10.0       # 移动止盈触发: 持仓盈利≥10% 后转移动止盈(断板不再立即卖)
TRAIL_PCT = 8.0       # 移动止盈回撤: 从峰值回撤≥8% 才离场(让利润奔跑)

# 主推(广谱信号)专属退出: 波动率自适应(区别于龙头固定阈值, 不依赖连板断板)
MAIN_VOL_WIN = 20        # 入场前波动率估计窗口(交易日)
MAIN_VOL_FLOOR = 0.02    # 极低波动兜底, 防误触发
MAIN_TRAIL_MULT = 3.0    # 移动止盈回撤 = TRAIL_MULT * vol
MAIN_TRAIL_MIN = 0.08    # 不低于龙头(≥8%), 避免对稳健票过紧
MAIN_TRAIL_MAX = 0.20    # 高波动票上限
MAIN_STOP_HARD = 0.06    # 主推亏损段硬止损: 固定-6%(绝对), 不随波动放宽(修正高波动票被放宽到-15%扛深跌)
MAIN_BREAK_DROP = 0.05    # 动量破坏: 单日收盘大跌≥5% → 早退(替代龙头式"断板", 不依赖涨停)
MAIN_BREAK_LOOKBACK = 5   # 破位: 收盘创前N日新低 → 早退
MAIN_BREAK_GATE = 1.00    # 动量/破位早退仅在水下(≤入场)触发, 绝不剪微利/盈利票


# ───────────────────────── 龙头特征分 / 剔除(生产化) ─────────────────────────

def _streak(hist):
    """截至当前 bar 的连板数(change_pct>=9.5 连续)."""
    s = 0
    for cp in reversed(hist["change_pct"].iloc[-6:].tolist()):
        try:
            if float(cp) >= 9.5:
                s += 1
            else:
                break
        except (TypeError, ValueError):
            break
    return s


def _last(hist, col):
    try:
        v = hist[col].iloc[-1]
        return None if v is None or (isinstance(v, float) and not np.isfinite(v)) else float(v)
    except Exception:
        return None


def _dragon_score(hist_D, row, turnover_override=None):
    """龙头特征分 0~100(点位, 无前视). 与 _tmp_dragon_regime.dragon_score 同构;
    turnover 优先取实时行情(线上hist历史无换手列), 缺失走 else 兜底."""
    n = len(hist_D)
    if n < 2:
        return 50.0
    s = 0.0
    streak = _streak(hist_D)
    s += {0: 0, 1: 15, 2: 25, 3: 30, 4: 30}.get(streak, 30)          # 连板强度30
    cp_prev = float(hist_D["change_pct"].iloc[-2])
    cp_last = float(hist_D["change_pct"].iloc[-1])
    if cp_prev >= 9.5 and cp_last < 9.5:                             # 断板反包10
        s += 10 if cp_last >= 0 else 0
    amt = _last(hist_D, "amount")                                    # 真龙量10-30亿20
    if amt and amt > 0:
        b = amt / 1e8
        s += 20 if 10 <= b <= 30 else 12 if (5 <= b < 10 or 30 < b <= 50) else 6
    else:
        s += 8
    to = turnover_override if turnover_override is not None else _last(hist_D, "turnover")
    if to is not None and to > 0:                                    # 换手活跃带15-25 20
        s += 20 if 15 <= to <= 25 else 12 if (10 <= to < 15 or 25 < to <= 35) else 6
    else:
        s += 8
    if cp_last >= 9.5:                                               # 今日涨停10
        s += 10
    o, c = _last(hist_D, "open"), _last(hist_D, "close")             # 今日阳线10
    if o and c:
        s += 10 if c > o else 4
    else:
        s += 5
    return round(min(s, 100.0), 1)


def _relaxed_reject(name, price, hist, row, pe_map=None):
    """生产 hard_reject, 放开与龙头战法直接矛盾的3条: 连板≥3 / 换手>25 / 近10日涨>40.
    保留: 仙股/ST退/N名/破位MA20/涨停次日放量分歧/成交额<1亿/PE异常."""
    r = R._hard_reject(name, price, hist, row, pe_map)
    if r is None:
        return None
    if r.startswith(("高位(近10日", "高位连板", "换手过高")):
        return None
    return r


# ───────────────────────── 实时选股 ─────────────────────────

def _score_dragon_stock(row, start_str, end_str, allowed_set, pe_map, rt_map):
    code = str(row.get("code", "") or "").strip()
    name = str(row.get("name", "") or "").strip()
    price = float(row.get("price", 0) or 0)
    change_pct = float(row.get("change_pct", 0) or 0)
    if price <= 0 or not code:
        return None
    # 涨停硬过滤(20260903修复): 当日未涨停(≥9.5%)的"假龙头"不入池.
    # 曾放行 莲花控股(+2.1%)/农发种业(+3.7%)/盛达资源(-1.4%) 造成断板止损永不触发、拖满5日.
    if change_pct < LIMIT_PCT:
        return None
    try:
        hist = R._fetch_hist_cached(code, start_str, end_str)
    except Exception:
        return None
    if hist is None or len(hist) < MIN_HIST:
        return None
    hist, _ = R._append_today_bar(hist, row, rt_map.get(code))
    if _relaxed_reject(name, price, hist, row, pe_map):
        return None

    from paper_trading import _STRAT_INSTANCES
    triggered = []
    for sname, stg in _STRAT_INSTANCES.items():
        if allowed_set is not None and sname not in allowed_set:
            continue
        try:
            sdf = stg.generate_signals(hist.copy())
            if "signal" in sdf.columns and float(sdf["signal"].iloc[-1]) > 0:
                triggered.append(sname)
        except Exception:
            pass
    if not triggered:
        return None

    rt = rt_map.get(code)
    to = rt.get("turnover") if rt else None
    dg = _dragon_score(hist, row, turnover_override=to)
    q = R._quality_score(hist, change_pct, row, pe_map, code)
    exp_ret, win_rate, n = R._estimate_t1_return(hist)
    return {
        "code": code, "name": name, "price": round(price, 2),
        "change_pct": round(change_pct, 2),
        "streak": _streak(hist), "dragon_score": dg, "quality_score": q,
        "strategies": triggered, "signal_count": len(triggered),
        "expected_return": round(exp_ret, 2), "win_rate": win_rate, "t1_samples": n,
    }


def _scan_dragon_universe(today, allowed_set, pe_map, rt_map, quotes=None):
    """实时成交额 top-N 宇宙, 并行打龙头分. 与生产 _scan_amount_universe 同源."""
    if quotes is None:
        quotes = StockAPI.get_realtime_quotes()
    if quotes is None or quotes.empty:
        return []
    quotes = R.filter_universe(quotes)
    sort_col = "amount" if "amount" in quotes.columns else "price"
    top = quotes.sort_values(sort_col, ascending=False).head(AMOUNT_UNIVERSE_N)
    start_str = (datetime.now() - timedelta(days=120)).strftime("%Y%m%d")
    picks = []
    with ThreadPoolExecutor(max_workers=8) as ex:
        futs = {ex.submit(_score_dragon_stock, row, start_str, today, allowed_set,
                          pe_map, rt_map): row for _, row in top.iterrows()}
        for f in as_completed(futs):
            try:
                p = f.result()
            except Exception:
                continue
            if p:
                picks.append(p)
    picks.sort(key=lambda x: x.get("dragon_score", 0), reverse=True)
    return picks


# ───────────────────────── 持仓状态机(断板止盈+时间止损) ─────────────────────────

def _load_store():
    try:
        with open(STORE_FILE, "r", encoding="utf-8") as f:
            st = json.load(f)
        st.setdefault("positions", [])
        st.setdefault("trades", [])
        return st
    except Exception:
        return {"asof": None, "positions": [], "trades": []}


def _save_store(st):
    os.makedirs(os.path.dirname(STORE_FILE), exist_ok=True)
    with open(STORE_FILE, "w", encoding="utf-8") as f:
        json.dump(st, f, ensure_ascii=False, indent=1, default=str)


def reset_store():
    """清空持仓与交易记录(页面"重置"按钮用)."""
    _save_store({"asof": datetime.now().strftime("%Y%m%d"), "positions": [], "trades": []})


def _dates(hist):
    out = []
    for v in hist["date"]:
        ts = pd.Timestamp(v)
        out.append(ts.strftime("%Y%m%d"))
    return out


def _oneword(bar):
    hi, lo, op = float(bar["high"]), float(bar["low"]), float(bar["open"])
    return (hi - lo) < 0.03 and op >= hi - 0.005


def _recompute_pos(pos, hist, asof, risk_rules=False):
    """从 entry_date 幂等重放该仓到 asof(与实验 run_exit T5 语义一致).
    返回解析后的 dict; 触发卖出时同时给出 exit 信息供记入交易.
    risk_rules=True(龙头live, 20260903规则修复) 追加防线:
      ① 入场日开盘较昨收高开≥7% → 放弃买入(状态: 未买入(高开过滤));
      ② 持仓日收盘较入场价回撤≥8% 或 跌破5日线 → 当日收盘止损(tag: 止损(回撤8%)/止损(破5日线));
      ③ 断板判定保持优先(复盘tag口径), 破位止损作为"非涨停持仓/未断板日"的兜底.
    注: 本函数仅用于龙头(连板)轨道; 主推(广谱信号)轨道已切到独立的 _recompute_pos_main(波动率自适应退出), 不再共享此引擎."""
    hist = hist.sort_values("date").reset_index(drop=True)
    dates = _dates(hist)
    entry_dt = pos["entry_date"]
    if entry_dt > asof:
        return {"status": "待买入"}          # 入场日未到(即使hist含未来bar也保持待买入)
    try:
        e = dates.index(entry_dt)
    except ValueError:
        return {"status": "未买入(停牌)"} if asof >= entry_dt else {"status": "待买入"}
    bar_e = hist.iloc[e]
    if _oneword(bar_e):
        return {"status": "未买入(一字板)"}
    entry_price = float(bar_e["open"])

    def _limit(j):
        try:
            return float(hist["change_pct"].iloc[j]) >= LIMIT_PCT
        except (TypeError, ValueError):
            return False

    # ── 修复① 入场日开盘高开≥7% → 放弃买入(挡 敦煌8/31高开+10%追入、内蒙一机9/3高开回落 式追高)
    # 仅对 RISK_ACTIVE_DATE 起的新入场生效(旧仓历史不重解释) ──
    if risk_rules and entry_dt >= RISK_ACTIVE_DATE and e - 1 >= 0:
        prev_close = float(hist["close"].iloc[e - 1])
        if prev_close > 0:
            gap = (entry_price / prev_close - 1) * 100
            if gap >= MAX_BUY_GAP:
                return {"status": "未买入(高开过滤)", "gap_pct": round(gap, 2)}

    # ── 修复② 破位止损判定(收盘回撤8% / 收盘跌破5日线; 未断板持仓日的兜底)
    # 只判 RISK_ACTIVE_DATE 起的持仓bar(生效日前的旧仓历史不被新规则改写) ──
    def _risk_tag(j):
        if not risk_rules or dates[j] < RISK_ACTIVE_DATE:
            return None
        try:
            c = float(hist["close"].iloc[j])
        except (TypeError, ValueError):
            return None
        if c <= entry_price * (1.0 - STOP_LOSS_PCT / 100.0):
            return "回撤8%"
        if j >= MA_BREAK - 1 and c < float(hist["close"].iloc[j - MA_BREAK + 1:j + 1].mean()):
            return "破5日线"
        return None

    def _exit(j, tag, ds):
        bar = hist.iloc[j]
        return {"status": "已卖出", "tag": tag, "entry_price": entry_price,
                "exit_date": dates[j], "exit_price": float(bar["close"]), "days_held": ds}

    prev_limit = _limit(e - 1) if e - 1 >= 0 else False
    days, last = 1, entry_dt
    # ── 入场日卖信号一律顺延 (2026-09-03 口径修复: A股T+1, 当日开盘买入当日不可卖) ──
    # 入场日"断板/破位"都在当日收盘后才确认 → 最早下一交易日(e+1)收盘执行;
    # e+1 尚未覆盖(>asof) → 保持持仓, 下次推进时再卖(幂等). 杜绝 entry==exit 同日(千金/敦煌/冠农 8/31 复现).
    def _defer_exit(tag):
        if e + 1 < len(dates) and dates[e + 1] <= asof:
            return _exit(e + 1, tag, 2)     # 持仓两交易日(入场日+次日)收盘卖
        return {"status": "持仓", "entry_price": entry_price, "days_held": 1,
                "last_check": entry_dt}
    # 入场日即断板(昨=信号日涨停, 今未续板): 断板当日收盘才确认 → 顺延次日收盘卖
    if prev_limit and not _limit(e):
        return _defer_exit("断板")
    rtag = _risk_tag(e)                      # 入场日破位兜底(收盘信息, 同样顺延次日卖)
    if rtag:
        return _defer_exit(f"止损({rtag})")
    prev_limit = _limit(e)
    peak = entry_price
    trailing = False
    for j in range(e + 1, len(dates)):
        d = dates[j]
        if d > asof:
            break
        days += 1
        c = float(hist["close"].iloc[j])
        if c > peak:
            peak = c
        # 移动止盈激活: 峰值浮盈≥TRAIL_WIN 即转移动止盈(让利润奔跑),
        # 不要求"恰好在断板日且当日收盘仍≥+10%"(否则冲高+30%回撤到+8%断板会漏激活, 直接按断板卖)
        if entry_price > 0 and (peak / entry_price - 1) * 100 >= TRAIL_WIN:
            trailing = True
        if prev_limit and not _limit(j):     # 断板
            if trailing:                     # 移动止盈中: 断板不立即卖, 继续等回撤达标
                prev_limit = _limit(j)
                last = d
                continue
            return _exit(j, "断板", days)    # 小赚/微亏断板 → 按纪律收盘卖
        rtag = _risk_tag(j)                  # 破位止损兜底(收盘回撤8% / 破5日线)
        if rtag:
            return _exit(j, f"止损({rtag})", days)
        if trailing and peak > 0 and (peak - c) / peak * 100 >= TRAIL_PCT:
            return _exit(j, "移动止盈", days)
        if days >= TIME_STOP:                # 时间止损(5日)
            return _exit(j, "时间止损", days)
        prev_limit = _limit(j)
        last = d
    return {"status": "持仓", "entry_price": entry_price, "days_held": days, "last_check": last}


def _est_vol(hist, e, win=MAIN_VOL_WIN):
    """入场前 win 根收益率滚动 std(日), 作为该持仓自身波动率估计(小数). 异常/样本不足 → 兜底值."""
    lo = max(0, e - win)
    try:
        closes = hist["close"].iloc[lo:e].astype(float).values
        if len(closes) < 5:
            return MAIN_VOL_FLOOR
        rets = np.diff(closes) / closes[:-1]
        v = float(np.std(rets))
        return max(v, MAIN_VOL_FLOOR)
    except Exception:
        return MAIN_VOL_FLOOR


def _recompute_pos_main(pos, hist, asof):
    """主推(广谱信号策略)退出引擎 — 2026-09-09 调优版:
    
    退出条件(优先级自上而下):
      1. 动量破位早退(替代原"断板", 不依赖涨停): 单日收盘大跌≥5% 或 收盘创入场以来新低,
         且仅在水下(≤入场×1.02)触发 → 浅亏早走, 复制断板早退收益但更稳健.
      2. 移动止盈(波动率自适应·让利润奔跑): 浮盈峰值≥激活阈值后转移动止盈, 从峰值回撤≥trail_pct离场;
         trail_pct随持仓自身波动率自适应(8%~20%), 高波动票给更宽缰绳.
      3. 硬止损(亏损段更紧, 固定不随波动放宽): 收盘较入场回撤≥6% 即离场
         (修正原"随波动放宽到15%"导致高波动票扛深跌的缺陷, 如 002229).
      4. 时间止损: 满5交易日离场.
    与 _recompute_pos(龙头·连板断板口径)完全分离; T+1(循环从e+1起)/一字板跳过 口径一致."""
    hist = hist.sort_values("date").reset_index(drop=True)
    dates = _dates(hist)
    entry_dt = pos["entry_date"]
    if entry_dt > asof:
        return {"status": "待买入"}
    try:
        e = dates.index(entry_dt)
    except ValueError:
        return {"status": "未买入(停牌)"} if asof >= entry_dt else {"status": "待买入"}
    bar_e = hist.iloc[e]
    if _oneword(bar_e):
        return {"status": "未买入(一字板)"}
    entry_price = float(bar_e["open"])

    vol = _est_vol(hist, e)
    trail_pct = min(MAIN_TRAIL_MAX, max(MAIN_TRAIL_MIN, MAIN_TRAIL_MULT * vol))
    trail_act = max(0.06, trail_pct * 0.6)   # 峰值浮盈达此值转移动止盈

    def _exit(j, tag, ds):
        bar = hist.iloc[j]
        return {"status": "已卖出", "tag": tag, "entry_price": entry_price,
                "exit_date": dates[j], "exit_price": float(bar["close"]), "days_held": ds}

    peak = entry_price
    trailing = False
    days = 1
    last = entry_dt
    for j in range(e + 1, len(dates)):
        d = dates[j]
        if d > asof:
            break
        days += 1
        c = float(hist["close"].iloc[j])
        if c > peak:
            peak = c
        if entry_price > 0 and (peak / entry_price - 1) >= trail_act:
            trailing = True
        # 1) 动量破位早退(仅水下触发, 绝不剪盈利票)
        if days >= 2 and entry_price > 0:
            prev_c = float(hist["close"].iloc[j - 1])
            day_drop = c / prev_c - 1
            look_lo = float(hist["close"].iloc[e:j].min())   # 入场以来最低收盘
            if (day_drop <= -MAIN_BREAK_DROP or c <= look_lo) and c <= entry_price * MAIN_BREAK_GATE:
                return _exit(j, "动量破位", days)
        # 3) 硬止损(固定-6%, 不随波动放宽)
        if entry_price > 0 and c <= entry_price * (1.0 - MAIN_STOP_HARD):
            return _exit(j, "止损(硬-6%)", days)
        # 2) 移动止盈(自适应奔跑)
        if trailing and peak > 0 and (peak - c) / peak >= trail_pct:
            return _exit(j, "移动止盈", days)
        # 4) 时间止损
        if days >= TIME_STOP:
            return _exit(j, "时间止损", days)
        last = d
    return {"status": "持仓", "entry_price": entry_price, "days_held": days, "last_check": last}


def update_positions(store, asof, include_today=False, risk_rules=True):
    """推进所有活跃仓到 asof; 卖出 → 记入 trades(幂等).
    include_today=True: 允许读 asof 当日已收盘 bar(盘后刷新入库后调用), 让状态机看到当天断板/时间止损;
    默认 False 走 _fetch_hist_cached 的盘中冻结口径(只到 date<今日), 防实时 bar 前视.
    risk_rules=True(20260903修复, 默认): 高开≥7%放弃买入 + 回撤8%/破5日线止损, 透传给 _recompute_pos."""
    active = [p for p in store["positions"] if p["status"] in ("待买入", "持仓")]
    if not active:
        return store
    end_str = asof
    # 回看窗口须≥30行(约30个交易日), 30日历天仅~22交易日 → hist 会 None 导致仓永不推进
    start_str = (datetime.strptime(asof, "%Y%m%d") - timedelta(days=60)).strftime("%Y%m%d")
    for pos in active:
        code = pos["code"]
        try:
            if include_today:
                hist = StockAPI.get_historical_data(code, start_str, end_str)
                if hist is None or len(hist) < 30:
                    continue
                hist = hist.sort_values("date").reset_index(drop=True)
                hist["date"] = pd.to_datetime(hist["date"]).dt.normalize()
                hist = hist[hist["date"] <= pd.Timestamp(asof)].reset_index(drop=True)
            else:
                hist = R._fetch_hist_cached(code, start_str, end_str)
        except Exception:
            continue
        if hist is None or hist.empty:
            continue
        out = _recompute_pos(pos, hist, asof, risk_rules=risk_rules)
        if out["status"] == "未买入(停牌)" and pos["entry_date"] > asof:
            continue  # 入场日未到, 保持待买入
        # 落回状态
        pos.update({k: v for k, v in out.items() if k != "tag"})
        if out["status"] == "已卖出":
            pos["tag"] = out["tag"]
            pos["exit_date"] = out["exit_date"]
            pos["exit_price"] = round(out["exit_price"], 2)
            ret = (out["exit_price"] / out["entry_price"] - 1) * 100 if out["entry_price"] else 0
            pos["ret_pct"] = round(ret, 2)
            trade = {"code": code, "name": pos.get("name", ""),
                     "entry_date": pos["entry_date"], "entry_price": round(out["entry_price"], 2),
                     "exit_date": out["exit_date"], "exit_price": round(out["exit_price"], 2),
                     "ret_pct": round(ret, 2), "days_held": out["days_held"], "tag": out["tag"],
                     "closed_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
            store["trades"].append(trade)
            store["trades"] = store["trades"][-300:]
    return store


# ───────────────────────── 每日龙头扫描入口 ─────────────────────────

def _regime_allowed(regime):
    level = regime.get("level")
    allowed = strategies_for_regime(level) if level else []
    if not allowed and regime.get("weak_only"):
        allowed = list(R._LOW_BUY_STRATEGIES)
    return set(allowed) if allowed else None


def scan_dragon(force=False):
    """龙头战法每日扫描: ①推进持仓(断板/时间止损卖出→释放槽位) ②今日选股(龙头分排序)
    ③新推荐入仓(仅空闲槽位, 明日开盘买入) ④落盘 data/dragon_picks/{date}.json.
    返回 result dict."""
    today = datetime.now().strftime("%Y%m%d")
    os.makedirs(PICKS_DIR, exist_ok=True)
    today_path = os.path.join(PICKS_DIR, f"{today}.json")
    if not force and os.path.exists(today_path):
        try:
            with open(today_path, "r", encoding="utf-8") as f:
                cached = json.load(f)
            if cached.get("pick_list") is not None:
                return cached
        except Exception:
            pass

    store = _load_store()
    store = update_positions(store, today)
    active = [p for p in store["positions"] if p["status"] in ("待买入", "持仓")]
    free = max(0, MAX_SLOTS - len(active))

    regime = R.index_regime()
    result = {"date": today, "scanned_at": datetime.now().strftime("%H:%M:%S"),
              "regime": regime.get("level"), "free_slots": free,
              "active_positions": len(active), "note": "入池需当日涨停 · 次日开盘买入 · 高开≥7%放弃 · 断板止盈 / 回撤8%止损 / 破5日线止损 / 时间止损5日"}
    if regime.get("skip"):
        result["pick_list"] = []
        store["asof"] = today
        _save_store(store)
        with open(today_path, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=1, default=str)
        return result

    allowed_set = _regime_allowed(regime)
    result["allowed_strategies"] = sorted(allowed_set) if allowed_set else None

    rt_quotes = StockAPI.get_realtime_quotes()
    rt_map, pe_map = R._load_realtime_map(rt_quotes)
    picks = _scan_dragon_universe(today, allowed_set, pe_map, rt_map, quotes=rt_quotes)
    result["pick_list"] = picks[:MAX_PICKS]
    result["main_pick"] = picks[0] if picks else None
    result["backup_pick"] = picks[1] if len(picks) > 1 else None

    # 新推荐入仓(仅空闲槽位; 同代码已有活跃仓则跳过)
    active_codes = {p["code"] for p in store["positions"] if p["status"] in ("待买入", "持仓")}
    added = 0
    for p in picks:
        if added >= free:
            break
        if p["code"] in active_codes:
            continue
        # 交易日盘中/盘后扫描时 _next_trading_day(含当天) 会返回今天 → 待买入当天即被
        # include_today 推进按当日开盘前视成交; 此处必须用严格下一个交易日(从明天起找).
        store["positions"].append({
            "code": p["code"], "name": p["name"], "signal_date": today,
            "entry_date": _next_trading_day((datetime.now().date() + timedelta(days=1))).strftime("%Y%m%d"),
            "status": "待买入",
        })
        active_codes.add(p["code"])
        added += 1
    result["added"] = added
    store["asof"] = today
    _save_store(store)

    result["positions"] = [p for p in store["positions"] if p["status"] in ("待买入", "持仓")]
    result["trades"] = store["trades"][-30:][::-1]
    with open(today_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=1, default=str)
    return result


def load_dragon_today():
    today = datetime.now().strftime("%Y%m%d")
    p = os.path.join(PICKS_DIR, f"{today}.json")
    if os.path.exists(p):
        try:
            with open(p, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return None


def load_dragon_store():
    return _load_store()


if __name__ == "__main__":
    import sys
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    res = scan_dragon(force=True)
    print(json.dumps(res, ensure_ascii=False, indent=1, default=str)[:4000])
