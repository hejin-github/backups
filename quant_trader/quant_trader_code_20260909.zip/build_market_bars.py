# -*- coding: utf-8 -*-
"""诚实点位全市场bar存储构建 — 2026-08-30

一次性建库: 全市场~5900只(含退市~300只)日K 20231013~asof → data/market_bars/{code}.json
列式存储(省内存), 幂等原子写(断点续传), 前缀白名单防B股/非标.

数据源分级:
  1) BaoStock query_history_k_data_plus(真实 amount+turnover, 前复权, 覆盖退市股,
     自有TCP协议不受东财IP封锁影响) — 2026-08-30实测: 枚举与akshare一致, 量级正确
  2) 东方财富 stock_zh_a_hist(恢复后同真实, 备用)
  3) 回退 腾讯/新浪(amount=volume×close 估算, 无turnover) → 标 degraded=true, 不参与排序
枚举用 SSE/SZSE stock_info_a_code_name + 退市表(实测不受东财封锁影响).

用法:
  python build_market_bars.py --pilot 200        # 试点: 抽样200只含退市/各板块
  python build_market_bars.py                    # 全量
  python build_market_bars.py --force            # 重拉(默认跳过已存在文件)
  python build_market_bars.py --end 20260828     # 覆盖asof(测试用)
输出: data/market_bars/{code}.json + _meta.json + _coverage.json
"""
import json
import os
import sys
import threading
import time
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

# 必须先于任何 requests/urllib 网络调用清代理(Windows系统代理阻断akshare)
for _k in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "http_proxy", "https_proxy", "all_proxy"):
    os.environ.pop(_k, None)
os.environ["NO_PROXY"] = "*"

import pandas as pd

BASE = os.path.dirname(os.path.abspath(__file__))
BAR_DIR = os.path.join(BASE, "data", "market_bars")
META_PATH = os.path.join(BAR_DIR, "_meta.json")
COVERAGE_PATH = os.path.join(BAR_DIR, "_coverage.json")
LOCK_PATH = os.path.join(BAR_DIR, "_refresh.lock")
LOCK_STALE_SECONDS = 7200  # 刷新锁超过该时长未更新视为上次刷新进程中断的残留(正常增量刷新全程活跃)

START_STR = "20231013"
# 生产 filter_universe 允许的主板前缀(沪 600/601/603/605 + 深 000/001/002/003)
_PREFIX_OK = ("600", "601", "603", "605", "000", "001", "002", "003")
_KLINE_COLS = ("date", "open", "close", "high", "low", "volume",
               "amount", "amplitude", "change_pct", "change", "turnover")


def _ensure_dir():
    os.makedirs(BAR_DIR, exist_ok=True)


# ───────────────────────── 枚举(SSE/SZSE, 不受东财封锁) ─────────────────────────

def enumerate_codes(ak):
    """返回 {code: {"name": str, "delisted": bool, "st": bool}}.
    stock_info_a_code_name 列名即 code/name; 退市列表列名中文, 按位置取第一列=代码, 第二列=简称."""
    out = {}
    try:
        a = ak.stock_info_a_code_name()
        for _, r in a.iterrows():
            code = str(r["code"]).strip().zfill(6)
            name = str(r["name"]).strip()
            out[code] = {"name": name, "delisted": False}
    except Exception as e:
        print("枚举 stock_info_a_code_name 失败:", type(e).__name__, str(e)[:120], flush=True)
    for fn in (getattr(ak, "stock_info_sh_delist", None), getattr(ak, "stock_info_sz_delist", None)):
        try:
            d = fn()
            if d is None or d.empty:
                continue
            cols = list(d.columns)
            ccol, ncol = cols[0], cols[1]
            for _, r in d.iterrows():
                code = str(r[ccol]).strip().zfill(6)
                name = str(r[ncol]).strip()
                prev = out.get(code, {})
                out[code] = {"name": name, "delisted": True,
                             "prev_name": prev.get("name", "")}
        except Exception as e:
            print("枚举退市表失败:", type(e).__name__, str(e)[:120], flush=True)
    # ST/退 标记(今日名称代理, 生产 filter_universe 同口径)
    for code, rec in out.items():
        nm = rec.get("name", "").upper()
        rec["st"] = ("ST" in nm) or ("退" in nm)
    return out


def filter_eligible(meta):
    """前缀白名单(生产 filter_universe 的主板集合等价口径). 返回过滤后 code 列表."""
    return sorted(c for c, r in meta.items() if c.startswith(_PREFIX_OK))


# ───────────────────────── 单只抓取 ─────────────────────────

def _num_col(df, col):
    if col not in df.columns:
        return None
    return df[col].astype(float).tolist()


# ───────────────────────── BaoStock 主数据源(真实amount+turnover, 不受东财封锁) ─────────────────────────

_BS_LOCK = threading.Lock()
_BS_READY = {"ok": False}


def _bs_ensure_login():
    """BaoStock 全局socket连接, 加锁串行(非线程安全). 幂等."""
    with _BS_LOCK:
        if _BS_READY["ok"]:
            return True
        try:
            import baostock as bs
            lg = bs.login()
            if lg.error_code == "0":
                _BS_READY["ok"] = True
                return True
        except Exception:
            pass
    return False


def _fetch_one_bs(code, start_str, end_str, min_rows=30):
    """BaoStock 前复权日K: 真实 amount+turnover, 覆盖退市股, 剔停牌日(tradestatus=0).
    返回 {columns:{...}} akshare口径或 None. 列序=date,open,high,low,close,preclose,volume,amount,turn,pctChg,tradestatus.
    min_rows: 小窗增量用 1(尾部几天); 全量/初建仍 30."""
    if not _bs_ensure_login():
        return None
    import baostock as bs
    bscode = ("sh." if code.startswith(("6", "9")) else "sz.") + code

    def _d(s):
        return "%s-%s-%s" % (s[:4], s[4:6], s[6:8])

    try:
        with _BS_LOCK:
            rs = bs.query_history_k_data_plus(
                bscode, "date,open,high,low,close,preclose,volume,amount,turn,pctChg,tradestatus",
                start_date=_d(start_str), end_date=_d(end_str), frequency="d", adjustflag="2")
            rows = []
            while (rs.error_code == "0") and rs.next():
                rows.append(rs.get_row_data())
    except Exception:
        return None
    if not rows:
        return None
    dates, o, h, l, c, v, a, t, pct, chg, amp = [], [], [], [], [], [], [], [], [], [], []
    for r in rows:
        if r[10] == "0":                       # 停牌日剔除(akshare qfq同无停牌bar)
            continue
        try:
            oo, hh, ll, cc = float(r[1]), float(r[2]), float(r[3]), float(r[4])
            pre = float(r[5])
            vv = float(r[6]) / 100.0           # 股→手(akshare口径)
            aa, tt, pp = float(r[7]), float(r[8]), float(r[9])
        except (TypeError, ValueError):
            continue
        if cc <= 0 or pre <= 0:
            continue
        dates.append(r[0].replace("-", ""))
        o.append(oo); h.append(hh); l.append(ll); c.append(cc)
        v.append(vv); a.append(aa); t.append(tt); pct.append(pp)
        chg.append(cc - pre)
        amp.append((hh - ll) / pre * 100)
    if len(dates) < min_rows:
        return None
    return {"start": dates[0], "end": dates[-1], "n": len(dates),
            "columns": {"date": dates, "open": o, "close": c, "high": h, "low": l,
                        "volume": v, "amount": a, "amplitude": amp,
                        "change_pct": pct, "change": chg, "turnover": t}}


def _fetch_one(ak, code, start_str, end_str, source="ak"):
    """返回 {columns: {...}} 或 None(失败).
    source: bs=BaoStock真实 / ak=东财真实 / tx=腾讯估算 / sina=新浪估算."""
    try:
        if source == "bs":
            return _fetch_one_bs(code, start_str, end_str)
        if source == "ak":
            df = ak.stock_zh_a_hist(symbol=code, period="daily",
                                    start_date=start_str, end_date=end_str, adjust="qfq")
            if df is None or df.empty:
                return None
            df = df.rename(columns={
                "日期": "date", "开盘": "open", "收盘": "close", "最高": "high",
                "最低": "low", "成交量": "volume", "成交额": "amount",
                "振幅": "amplitude", "涨跌幅": "change_pct", "涨跌额": "change",
                "换手率": "turnover"})
            cols = _KLINE_COLS
        else:
            # 腾讯/新浪经 stock_api(不复权 → 与ak前复权口径不同, 仅degraded兜底)
            from stock_api import StockAPI
            df = StockAPI.get_historical_data(code, start_str, end_str, source=source)
            if df is None or df.empty:
                return None
            cols = tuple(c for c in _KLINE_COLS if c in df.columns)
    except Exception:
        return None
    try:
        df = df.sort_values("date").reset_index(drop=True)
        df["date"] = pd.to_datetime(df["date"]).dt.strftime("%Y%m%d")
    except Exception:
        return None
    columns = {c: _num_col(df, c) for c in cols}
    n = len(df)
    if n < 30 or not columns.get("date"):
        return None
    return {"start": columns["date"][0], "end": columns["date"][-1], "n": n,
            "columns": columns}


def _atomic_write(path, payload):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False)
    os.replace(tmp, path)


def _bar_path(code):
    return os.path.join(BAR_DIR, "%s.json" % code)


def _bs_outdate_map():
    """BaoStock stock_basic type=1 → {code: outDate or ''}. 用于跳过窗口外退市股(无窗口内bar, 拉取纯浪费)."""
    if not _bs_ensure_login():
        return {}
    import baostock as bs
    out = {}
    try:
        with _BS_LOCK:
            rs = bs.query_stock_basic()
            rows = []
            while (rs.error_code == "0") and rs.next():
                rows.append(rs.get_row_data())
        f = rs.fields
        i_code, i_out, i_type = f.index("code"), f.index("outDate"), f.index("type")
        for r in rows:
            if r[i_type] == "1":
                out[r[i_code][3:]] = r[i_out] or ""
    except Exception:
        return {}
    return out


# ───────────────────────── 抓取调度(分级退避) ─────────────────────────

def _is_fresh(code):
    """已存在且非degraded(东财真成交额) → 视为完成. degraded文件东财恢复后须重拉."""
    p = _bar_path(code)
    if not os.path.exists(p):
        return False
    try:
        with open(p, encoding="utf-8") as f:
            return not json.load(f).get("degraded")
    except Exception:
        return False


def _fetch_all(ak, codes, meta, start_str, end_str, workers=8):
    """幂等断点续传: 仅跳过非degraded已存在文件(degraded=腾讯/新浪估算, 待东财恢复重拉真数据).
    返回 (ok, degraded, failed) 计数."""
    ok = deg = fail = 0
    todo = [c for c in codes if not _is_fresh(c)]
    print("待抓 %d 只(已完成 %d)" % (len(todo), len(codes) - len(todo)), flush=True)

    def _one(code):
        info = meta.get(code, {})
        # 主源1: BaoStock(真实amount+turnover, 不受东财封锁)
        res = _fetch_one(ak, code, start_str, end_str, "bs")
        if res is not None:
            return code, "ok", res, "bs"
        # 主源2: 东财(若恢复, 同真实)
        for attempt in range(4):                       # 分级退避
            res = _fetch_one(ak, code, start_str, end_str, "ak")
            if res is not None:
                return code, "ok", res, "ak"
            time.sleep(2 * (attempt + 1) + (3 if attempt else 0))
        # 降级源(标 degraded, 不参与排序)
        for src in ("tx", "sina"):
            res = _fetch_one(ak, code, start_str, end_str, src)
            if res is not None:
                res["source"] = src
                return code, "degraded", res, src
        return code, "fail", None, ""

    while todo:
        batch = todo[:min(workers * 4, len(todo))]
        todo = todo[len(batch):]
        # 高失败率 → 降并发
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = {ex.submit(_one, c): c for c in batch}
            for f in as_completed(futs):
                try:
                    code, status, res, src = f.result()
                except Exception as e:
                    code, status, res, src = futs[f], "fail", None, str(e)[:60]
                if res is not None:
                    rec = {"name": meta.get(code, {}).get("name", ""),
                           "delisted": bool(meta.get(code, {}).get("delisted")),
                           "st": bool(meta.get(code, {}).get("st")),
                           "source": src, "degraded": status == "degraded",
                           "rows": res["n"], "range": [res["start"], res["end"]]}
                    _atomic_write(_bar_path(code),
                                  {"code": code, "name": rec["name"],
                                   "delisted": rec["delisted"], "st": rec["st"],
                                   "degraded": rec["degraded"], "source": src,
                                   "start": res["start"], "end": res["end"],
                                   "columns": res["columns"]})
                    if status == "ok":
                        ok += 1
                    else:
                        deg += 1
                else:
                    fail += 1
        print("  进度: ok=%d degraded=%d fail=%d 剩余=%d" % (ok, deg, fail, len(todo)), flush=True)
        # 整批失败率过高(东财封锁加深) → 拉长批次间隔
        batch_n = len(batch)
        if batch_n and (fail + deg) / batch_n > 0.7:
            print("  高失败率, 暂停 %ds 避封..." % 30, flush=True)
            time.sleep(30)
    return ok, deg, fail


# ───────────────────────── 每日盘后增量刷新(2026-09-01) ─────────────────────────

def _sub_days(ymd, n):
    """YYYYMMDD 前推 n 自然日(跨周末/节假日由 baostock 自行跳过停牌)."""
    from datetime import datetime, timedelta
    return (datetime.strptime(ymd, "%Y%m%d") - timedelta(days=n)).strftime("%Y%m%d")


def _fetch_one_ak_tail(code, start_str, end_str):
    """东财 qfq 增量窗口(小窗, 允许<30行), 与 BaoStock qfq 同前复权口径, 作 BaoStock 不可用时的兜底.
    返回 {columns:{...}} 或 None. 失败/空/脏数据 → None(交由 refresh 保留旧文件)."""
    import akshare as ak
    try:
        df = ak.stock_zh_a_hist(symbol=code, period="daily",
                                start_date=start_str, end_date=end_str, adjust="qfq")
    except Exception:
        return None
    if df is None or df.empty:
        return None
    df = df.rename(columns={
        "日期": "date", "开盘": "open", "收盘": "close", "最高": "high",
        "最低": "low", "成交量": "volume", "成交额": "amount",
        "振幅": "amplitude", "涨跌幅": "change_pct", "涨跌额": "change",
        "换手率": "turnover"})
    try:
        df = df.sort_values("date").reset_index(drop=True)
        df["date"] = pd.to_datetime(df["date"]).dt.strftime("%Y%m%d")
        columns = {c: _num_col(df, c) for c in _KLINE_COLS}
    except Exception:
        return None
    if not columns.get("date") or len(columns["date"]) < 1:
        return None
    return {"start": columns["date"][0], "end": columns["date"][-1],
            "n": len(columns["date"]), "columns": columns}


def _append_tail(code, old_end, end_str, meta, source="bs"):
    """增量追加一只: 用 [old_end-6日, end_str] 小窗拉尾部 + 末3根 overlap 校验复权锚点.
    - overlap 收盘完全一致(无除权) → 仅追加新bar, 旧文件前复权口径不变(无需全量重拉)
    - overlap 有错位(期间除权, qfq 系数重锚) → 回退全量重拉, 保证内部一致
    - 新增/缺失文件 → 全量重拉(START_STR 起)
    source: bs=BaoStock(默认主源) / ak=东财qfq(兜底, 同前复权口径, 不污染序列)
    返回新的完整 {columns:{...}} 或 None(保留旧文件)."""
    def _fetch_full():
        return _fetch_one_bs(code, START_STR, end_str) if source == "bs" else _fetch_one_ak_tail(code, START_STR, end_str)
    def _fetch_win():
        win = _sub_days(old_end, 6)
        return _fetch_one_bs(code, win, end_str, min_rows=1) if source == "bs" else _fetch_one_ak_tail(code, win, end_str)
    if not os.path.exists(_bar_path(code)) or not old_end:
        return _fetch_full()
    res = _fetch_win()
    if res is None:
        return None
    try:
        with open(_bar_path(code), encoding="utf-8") as f:
            old = json.load(f)
        oc = dict(zip(old["columns"]["date"], old["columns"]["close"]))
    except Exception:
        return _fetch_full()
    rc = dict(zip(res["columns"]["date"], res["columns"]["close"]))
    overlap = [d for d in list(oc) if d in rc][-3:]          # 旧末3个交易日
    mis = any(abs(oc[d] - rc[d]) > 0.001 for d in overlap)
    if mis:                                                   # 除权错位 → 全量重拉
        return _fetch_full()
    new_rows = [i for i, d in enumerate(res["columns"]["date"]) if d > old_end]
    if not new_rows:
        return None                                           # 无新bar(停牌), 不动旧文件
    merged = {k: old["columns"][k][:] for k in old["columns"]}
    for k in merged:
        merged[k] += [res["columns"][k][i] for i in new_rows]
    return {"start": merged["date"][0], "end": merged["date"][-1],
            "n": len(merged["date"]), "columns": merged}


def _lock_pid_dead():
    """锁文件内记录的 pid 进程是否已不存在(被杀/断电残留). 读不到/解析失败保守返回 False(按活着处理)."""
    import re as _re
    try:
        with open(LOCK_PATH, encoding="utf-8") as f:
            txt = f.read() or ""
        m = _re.search(r"pid=(\d+)", txt)
        if not m:
            return False
        pid = int(m.group(1))
        os.kill(pid, 0)          # 0号信号仅探测存活; 进程不存在抛 OSError
        return False
    except OSError:
        return True
    except Exception:
        return False


def refresh_daily(end_str=None):
    """盘后增量刷新全市场库: 只处理 end < end_str 的股票(其余幂等跳过).
    - 主源固定 BaoStock(真实amount+turnover, 不受东财封锁); 失败保留旧文件(不降级, 守诚实口径)
    - 增量追加尾部小窗(快): 每日只需拉最近几天, 非 700 日全量
    - overlap 校验检测除权复权错位 → 仅错位股全量重拉(保内部一致)
    - 新上市/枚举新增自动补齐; 当日停牌股 bar 止于前一交易日(次日刷新自动补)
    用法: python build_market_bars.py --refresh   (或 from build_market_bars import refresh_daily)
    """
    import akshare as ak
    from strategy_backtest import _prev_trading_day
    from scheduler import is_trading_day
    if end_str is None:
        # 默认 end: 已收盘的交易日入库今天, 盘中/非交易日只到上一交易日 — 让首页总览当天盘后就能看到今天bar
        now = datetime.now()
        closed = is_trading_day(now) and (now.hour * 60 + now.minute) >= 15 * 60 + 5
        end_str = now.strftime("%Y%m%d") if closed else _prev_trading_day(now).strftime("%Y%m%d")
    _ensure_dir()
    # 重入守卫: 已有刷新在跑(如首页自动触发) → 直接跳过, 防两进程抢baostock/互写损坏
    try:
        fd = os.open(LOCK_PATH, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        with os.fdopen(fd, "w") as f:
            f.write("pid=%s start=%s\n" % (os.getpid(), end_str))
    except OSError:
        # 死锁自愈: 上次刷新进程若中途被中断(被杀/断电)会残留锁, 导致以后所有刷新被永久跳过.
        # 判据1(强): 锁内 pid 进程已不存在 → 立即视为残留删除重试(比只靠 mtime 快得多);
        # 判据2(兜底): 锁文件很久未被触碰(正常刷新全程活跃) → 视为过期残留, 清除后重试一次.
        try:
            if _lock_pid_dead():
                print("发现死锁(pid已不存在), 清除后重试: %s" % LOCK_PATH, flush=True)
                try:
                    os.remove(LOCK_PATH)
                except OSError:
                    pass
                try:
                    fd = os.open(LOCK_PATH, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                except OSError:
                    print("已有盘后刷新在跑, 本实例跳过(锁 %s)" % LOCK_PATH, flush=True)
                    return 0, 0
                with os.fdopen(fd, "w") as f:
                    f.write("pid=%s start=%s\n" % (os.getpid(), end_str))
            elif os.path.getmtime(LOCK_PATH) < time.time() - LOCK_STALE_SECONDS:
                print("发现过期刷新锁(%s), 清除后重试" % LOCK_PATH, flush=True)
                try:
                    os.remove(LOCK_PATH)
                except OSError:
                    pass
                fd = os.open(LOCK_PATH, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                with os.fdopen(fd, "w") as f:
                    f.write("pid=%s start=%s\n" % (os.getpid(), end_str))
            else:
                print("已有盘后刷新在跑, 本实例跳过(锁 %s)" % LOCK_PATH, flush=True)
                return 0, 0
        except OSError:
            print("已有盘后刷新在跑, 本实例跳过(锁 %s)" % LOCK_PATH, flush=True)
            return 0, 0
    try:
        meta = enumerate_codes(ak)
        with open(META_PATH, "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=1)
        eligible = filter_eligible(meta)
        todo = []
        for c in eligible:
            p = _bar_path(c)
            old_end = None
            if os.path.exists(p):
                try:
                    with open(p, encoding="utf-8") as f:
                        old_end = json.load(f).get("end")
                except Exception:
                    old_end = None
            if old_end and old_end >= end_str:
                continue
            todo.append((c, old_end))
        n_full = sum(1 for _, oe in todo if not oe)
        print("盘后刷新: 合格 %d 只, 待补 %d 只(含全量 %d) 至 %s" % (
            len(eligible), len(todo), n_full, end_str), flush=True)
        if not todo:
            return 0, 0
        ok = fail = fail_before = 0
        start = time.time()

        def _one(code, old_end):
            # 主源 BaoStock; 失败(如 BaoStock 抽风/停服)回退东财 qfq 兜底(同前复权口径, 不污染序列);
            # 杜绝「单源全失败 → 整库停摆一天(典型如 2026-09-08)」.
            res = _append_tail(code, old_end, end_str, meta, "bs")
            src_used = "bs" if res is not None else None
            if res is None:
                res = _append_tail(code, old_end, end_str, meta, "ak")
                if res is not None:
                    src_used = "ak"
            if res is None:
                return code, False
            # 原子写: 防杀进程/并发留下截断文件(读侧会自愈, 但守干净)
            _atomic_write(_bar_path(code),
                          {"code": code, "name": meta.get(code, {}).get("name", ""),
                           "delisted": bool(meta.get(code, {}).get("delisted")),
                           "st": bool(meta.get(code, {}).get("st")),
                           "degraded": False, "source": src_used,
                           "start": res["start"], "end": res["end"],
                           "columns": res["columns"]})
            return code, True

        while todo:
            batch = todo[:min(8 * 4, len(todo))]
            todo = todo[len(batch):]
            with ThreadPoolExecutor(max_workers=8) as ex:
                futs = {ex.submit(_one, c, oe): (c, oe) for c, oe in batch}
                for f in as_completed(futs):
                    try:
                        _, success = f.result()
                    except Exception:
                        success = False
                    if success:
                        ok += 1
                    else:
                        fail += 1
            print("  进度: ok=%d fail=%d 剩余=%d (%.1fs)" % (ok, fail, len(todo), time.time() - start), flush=True)
            # 批次失败率过高(baostock节流窗口) → 停30s等窗口过(原全量构建验证过的避封节奏)
            if batch and (fail - fail_before) / len(batch) > 0.6:
                print("  高失败率, 暂停30s避封...", flush=True)
                time.sleep(30)
            fail_before = fail
        # 更新覆盖率报告(供读优先层/校验)
        try:
            build_coverage(meta, eligible)
        except Exception as e:
            print("覆盖率报告更新失败:", str(e)[:80], flush=True)
        print("盘后刷新完成: ok=%d fail=%d(保留旧文件) 耗时 %.1fs" % (ok, fail, time.time() - start), flush=True)
        return ok, fail
    finally:
        try:
            os.remove(LOCK_PATH)
        except OSError:
            pass


def build_coverage(meta, codes):
    """逐日有数据股票数 + 板块/退市/ST 统计. 读bar文件date列."""
    import collections
    per_day = collections.Counter()
    for code in codes:
        p = _bar_path(code)
        if not os.path.exists(p):
            continue
        try:
            with open(p, encoding="utf-8") as f:
                d = json.load(f)
            dates = d["columns"].get("date") or []
            for dd in dates:
                per_day[dd] += 1
        except Exception:
            pass
    n_st = sum(1 for c in codes if meta.get(c, {}).get("st"))
    n_delisted = sum(1 for c in codes if meta.get(c, {}).get("delisted"))
    report = {
        "start": min(per_day) if per_day else None,
        "end": max(per_day) if per_day else None,
        "total_days": len(per_day),
        "eligible_codes": len(codes),
        "st": n_st, "delisted": n_delisted,
        "min_stocks_per_day": min(per_day.values()) if per_day else 0,
        "max_stocks_per_day": max(per_day.values()) if per_day else 0,
        "avg_stocks_per_day": round(sum(per_day.values()) / len(per_day), 1) if per_day else 0,
        "last_day_sample": {dd: per_day[dd] for dd in sorted(per_day)[-5:]},
    }
    with open(COVERAGE_PATH, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=1)
    return report


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--pilot", type=int, default=0, help="试点抽样数(含退市/各板块)")
    ap.add_argument("--start", default=START_STR)
    ap.add_argument("--end", default=None, help="默认=上一交易日")
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--refresh", action="store_true",
                    help="盘后增量刷新模式: 只重拉 end<end_str 的股票(BaoStock主源, 幂等)")
    args = ap.parse_args()

    if args.refresh:
        refresh_daily(end_str=args.end)
        return

    import akshare as ak
    from experiment_common import _prev_trading_day
    end_str = args.end or pd.Timestamp(_prev_trading_day()).strftime("%Y%m%d")

    _ensure_dir()
    print("枚举全市场...", flush=True)
    meta = enumerate_codes(ak)
    eligible = filter_eligible(meta)
    # BaoStock outDate 合并: 跳过窗口外退市股(无窗口内bar, 拉取纯浪费)
    od = _bs_outdate_map()
    n_pre_win = 0
    for c in eligible:
        o = od.get(c, "")
        if o:
            meta[c]["outDate"] = o
            if o.replace("-", "") < args.start:
                n_pre_win += 1
    print("枚举 %d 只, 主板合格 %d 只 (ST %d, 退市 %d), 窗口外退市跳过 %d" % (
        len(meta), len(eligible),
        sum(1 for c in eligible if meta[c]["st"]),
        sum(1 for c in eligible if meta[c]["delisted"]), n_pre_win), flush=True)

    with open(META_PATH, "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=1)

    # 抓取目标 = 主板合格 - 窗口外退市(窗口内退市保留: 幸存者偏差修正核心)
    def _in_window(c):
        o = meta[c].get("outDate", "")
        return not (o and o.replace("-", "") < args.start)

    codes = [c for c in eligible if _in_window(c)]
    if args.pilot:
        # 抽样: 主板样本 + 退市样本 + 已知热门大票, 覆盖各板块
        import random
        random.seed(42)
        n_del = max(2, int(args.pilot * 0.04))
        delist_codes = [c for c in codes if meta[c]["delisted"]]
        if len(delist_codes) > n_del:
            delist_codes = random.sample(delist_codes, n_del)
        rest = [c for c in codes if c not in set(delist_codes)]
        hot = [c for c in ("600519", "000858", "601318", "002594", "603259")
               if c in codes]
        pick = [c for c in hot]
        remaining = args.pilot - len(pick) - len(delist_codes)
        if remaining > 0:
            pick += random.sample([c for c in rest if c not in pick], min(remaining, len(rest)))
        pick += delist_codes
        codes = sorted(set(pick))
        print("试点: %d 只(含退市 %d 只)" % (len(codes), len(delist_codes)), flush=True)

    if args.force:
        for c in codes:
            p = _bar_path(c)
            if os.path.exists(p):
                os.remove(p)

    t0 = time.time()
    ok, deg, fail = _fetch_all(ak, codes, meta, args.start, end_str, args.workers)
    print("\n抓取完成: ok=%d degraded=%d fail=%d 耗时 %.1fs" % (ok, deg, fail, time.time() - t0))

    cov = build_coverage(meta, codes)
    print("覆盖率: %d 日, 每日股票数 min=%d avg=%.0f max=%d, ST=%d 退市=%d" % (
        cov["total_days"], cov["min_stocks_per_day"], cov["avg_stocks_per_day"],
        cov["max_stocks_per_day"], cov["st"], cov["delisted"]))
    print("结果已存:", BAR_DIR)


# ───────────────────────── 自动补库守护(2026-09-07) ─────────────────────────
# 背景: 行情库原来只靠外部手动触发 refresh_daily, 服务进程被杀/停摆后库会永久落后,
# 而首页重放以 _coverage.end 为 asof → 表现为"昨日该结算的标的仍待买入/数据缺失".
# 守护: 服务内 daemon 线程持续检查, 落后即后台起独立子进程增量补库(幂等, 自带锁+死锁自愈).
_GUARD_STATE_PATH = os.path.join(BAR_DIR, "_bars_guard_state.json")


def _coverage_end():
    try:
        c = json.load(open(COVERAGE_PATH, encoding="utf-8"))
        e = str(c.get("end") or "").strip()
        return e if (len(e) == 8 and e.isdigit()) else ""
    except Exception:
        return ""


def _bars_guard_tick(cooldown_seconds, force=False):
    """单次检查: 本地库落后于「当前理应入库的最晚交易日」则后台启动一次增量刷新.
    目标日 = 交易日且已收盘(≥15:05)→今天(入库今日收盘bar); 否则→真实上一交易日(补历史完整bar,
    即使盘中/非交易日/服务重启后追上被杀期间遗漏, 均无前视).
    force=True → 跳过冷却(首页「手动补库」按钮), 库已追平时仍不重复跑.
    返回 True=本次已发起刷新."""
    import subprocess
    from strategy_backtest import _prev_trading_day
    from scheduler import is_trading_day
    now = datetime.now()
    closed = is_trading_day(now) and (now.hour * 60 + now.minute) >= 15 * 60 + 5
    want = now.strftime("%Y%m%d") if closed else _prev_trading_day(now).strftime("%Y%m%d")
    end = _coverage_end()
    if end and end >= want:
        return False
    st = {}
    try:
        st = json.load(open(_GUARD_STATE_PATH, encoding="utf-8"))
    except Exception:
        pass
    # 冷却: 同一 want 近期刚发起过(子进程可能仍在跑/被杀待下轮) → 等待, 避免空转重复枚举
    if not force and st.get("want") == want and time.time() - st.get("ts", 0) < cooldown_seconds:
        return False
    try:
        with open(_GUARD_STATE_PATH, "w", encoding="utf-8") as f:
            json.dump({"want": want, "ts": time.time()}, f, ensure_ascii=False)
    except Exception:
        pass
    log_path = os.path.join(BASE, "_bars_refresh_%s.log" % want)
    try:
        log = open(log_path, "a", encoding="utf-8", buffering=1)
    except Exception:
        log = None
    cmd = [sys.executable, "-X", "utf8", "-u", os.path.abspath(__file__),
           "--refresh", "--end", want]
    print("[bars_guard] 行情库落后(end=%s want=%s) → 自动补库" % (end or "∅", want), flush=True)
    try:
        subprocess.Popen(cmd, cwd=BASE, stdout=log, stderr=log,
                         creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception as e:
        print("[bars_guard] 启动补库失败: %s" % (e,), flush=True)
        return False
    return True


def start_bars_guard(interval_seconds=300, cooldown_seconds=3600):
    """行情库自动补库守护(daemon 线程, 由 app 启动时挂上):
    - 每 interval 秒检查一次 _coverage.end 是否追平;
    - 落后(盘后少今天 / 盘中与盘前少此前已收盘交易日, 如上次刷新被杀/服务停摆) → 后台独立子进程增量补库,
      不阻塞主服务渲染, 不污染进程内 baostock/akshare 连接;
    - refresh 自带 O_EXCL 文件锁 + 死锁自愈(锁内 pid 已死自动清锁重试), 与手动/多实例刷新互斥;
    - 同一落后目标冷却 cooldown 秒再试, 长时间失败避免空转."""
    def _loop():
        while True:
            try:
                _bars_guard_tick(cooldown_seconds)
            except Exception:
                pass
            time.sleep(interval_seconds)
    t = threading.Thread(target=_loop, daemon=True, name="bars-guard")
    t.start()
    return t


if __name__ == "__main__":
    main()
