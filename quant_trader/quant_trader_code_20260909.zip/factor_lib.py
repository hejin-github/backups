"""
技术因子库 - 13个技术因子计算
用于策略评分、因子分析、IC计算
"""
import pandas as pd
import numpy as np


def momentum_factor(df, period=20):
    """动量因子: 过去N日收益率"""
    return df["close"].pct_change(period) * 100


def ma_factor(df, fast=5, slow=20):
    """均线因子: 快慢均线比值"""
    ma_fast = df["close"].rolling(fast).mean()
    ma_slow = df["close"].rolling(slow).mean()
    return (ma_fast / ma_slow - 1) * 100


def volatility_factor(df, period=20):
    """波动率因子: 过去N日收益率标准差"""
    return df["close"].pct_change().rolling(period).std() * 100


def bollinger_factor(df, period=20):
    """布林带因子: 价格在布林带中的位置"""
    mid = df["close"].rolling(period).mean()
    std = df["close"].rolling(period).std()
    upper = mid + 2 * std
    lower = mid - 2 * std
    return (df["close"] - lower) / (upper - lower + 1e-10) * 100


def rsi_factor(df, period=14):
    """RSI因子"""
    delta = df["close"].diff()
    gain = delta.where(delta > 0, 0).rolling(period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(period).mean()
    rs = gain / (loss + 1e-10)
    return 100 - (100 / (1 + rs))


def volume_factor(df, period=20):
    """量价因子: 成交量相对均量的变化"""
    vol_ma = df["volume"].rolling(period).mean()
    return (df["volume"] / vol_ma - 1) * 100


def macd_factor(df):
    """MACD因子: MACD柱状图强度"""
    ema12 = df["close"].ewm(span=12, adjust=False).mean()
    ema26 = df["close"].ewm(span=26, adjust=False).mean()
    diff = ema12 - ema26
    dea = diff.ewm(span=9, adjust=False).mean()
    bar = 2 * (diff - dea)
    return bar


def kdj_factor(df, period=9):
    """KDJ因子: J值"""
    low_n = df["low"].rolling(period).min()
    high_n = df["high"].rolling(period).max()
    rsv = (df["close"] - low_n) / (high_n - low_n + 1e-10) * 100
    k = rsv.ewm(com=2, adjust=False).mean()
    d = k.ewm(com=2, adjust=False).mean()
    j = 3 * k - 2 * d
    return j


def turnover_factor(df, period=5):
    """换手率因子: 换手率变化"""
    if "turnover" in df.columns:
        return df["turnover"].diff(period)
    return pd.Series(0, index=df.index)


def amplitude_factor(df, period=5):
    """振幅因子: 平均振幅"""
    if "amplitude" in df.columns:
        return df["amplitude"].rolling(period).mean()
    high_low = (df["high"] - df["low"]) / df["close"] * 100
    return high_low.rolling(period).mean()


def volume_price_factor(df, period=20):
    """量价配合因子: 价格上涨时放量，下跌时缩量"""
    ret = df["close"].pct_change()
    vol_change = df["volume"].pct_change()
    vp = ret * vol_change  # 正数表示量价配合
    return vp.rolling(period).mean() * 100


def atr_factor(df, period=14):
    """ATR因子: 平均真实波幅"""
    tr = pd.concat([
        df["high"] - df["low"],
        (df["high"] - df["close"].shift(1)).abs(),
        (df["low"] - df["close"].shift(1)).abs(),
    ], axis=1).max(axis=1)
    return tr.rolling(period).mean()


def obv_factor(df, period=20):
    """OBV因子: 能量潮"""
    obv = (df["volume"] * np.sign(df["close"].diff()).fillna(0)).cumsum()
    obv_ma = obv.rolling(period).mean()
    return (obv - obv_ma) / (obv_ma + 1e-10) * 100


FACTOR_FUNCTIONS = {
    "动量": momentum_factor,
    "均线": ma_factor,
    "波动率": volatility_factor,
    "布林带": bollinger_factor,
    "RSI": rsi_factor,
    "量价": volume_factor,
    "MACD": macd_factor,
    "KDJ": kdj_factor,
    "换手率": turnover_factor,
    "振幅": amplitude_factor,
    "量价配合": volume_price_factor,
    "ATR": atr_factor,
    "OBV": obv_factor,
}


def compute_all_factors(df):
    """计算所有因子，返回因子DataFrame"""
    df = df.copy()
    results = {}
    for name, func in FACTOR_FUNCTIONS.items():
        try:
            results[name] = func(df)
        except Exception:
            results[name] = pd.Series(np.nan, index=df.index)
    return pd.DataFrame(results)


def compute_factor_returns(df, factor_name, period=5):
    """计算因子收益: 因子值与未来N日收益的相关性"""
    factor = FACTOR_FUNCTIONS.get(factor_name, momentum_factor)(df)
    future_ret = df["close"].pct_change(period).shift(-period) * 100
    valid = pd.concat([factor, future_ret], axis=1).dropna()
    if len(valid) < 10:
        return 0, 0
    corr = valid.iloc[:, 0].corr(valid.iloc[:, 1])
    return corr, len(valid)
