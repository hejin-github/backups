"""
对冲组合模块
三档: 1万元 / 5000元 / 2000元
T日买入 → T+1日卖出, T+1收益必须为正
"""
import json, os, time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
from stock_api import StockAPI
from strategies import (QiaoBangZhu, YiShunLiuGuang, ChaoGuYangJia,
                        TuiXueChaoGu, DaBan, LongTou, HuanFang,
                        YeaRenDiXi, YeaRenErCiHuiCai, AoshuWeiPan,
                        DaMao2BJieLi, ChenXiaoQunShouBan, ZuiJiuDaLa)

CACHE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "hedge_results")

TIERS = {
    "1w":  {"name": "1万元组合", "max_amount": 10000, "max_positions": 3},
    "5k":  {"name": "5000元组合", "max_amount": 5000,  "max_positions": 2},
    "2k":  {"name": "2000元组合", "max_amount": 2000,  "max_positions": 2},
}

_STRATEGIES = [
    ("乔帮主·低吸反弹",   QiaoBangZhu()),
    ("一瞬流光·趋势跟踪", YiShunLiuGuang()),
    ("炒股养家·情绪接力", ChaoGuYangJia()),
    ("退学炒股·逆势交易", TuiXueChaoGu()),
    ("涨停打板·短线博弈", DaBan()),
    ("龙头战法·强者恒强", LongTou()),
    ("幻方量化·多因子改进", HuanFang()),
    ("野人·低吸战法",    YeaRenDiXi()),
    ("野人·二次回踩",    YeaRenErCiHuiCai()),
    ("奥数老师·尾盘量化",  AoshuWeiPan()),
    ("大毛哥·2B接力",    DaMao2BJieLi()),
    ("陈小群·首板战法",   ChenXiaoQunShouBan()),
    ("醉酒大佬·放量长上影", ZuiJiuDaLa()),
]


def _get_cache_key(tier_key, date_str):
    os.makedirs(CACHE_DIR, exist_ok=True)
    return os.path.join(CACHE_DIR, f"{tier_key}_{date_str}.json")


def load_cached(tier_key, date_str):
    path = _get_cache_key(tier_key, date_str)
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return None


def save_cache(tier_key, date_str, data):
    path = _get_cache_key(tier_key, date_str)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2, default=str)


def get_cached_dates(tier_key):
    """获取已缓存的日期列表"""
    os.makedirs(CACHE_DIR, exist_ok=True)
    dates = set()
    prefix = f"{tier_key}_"
    for fname in os.listdir(CACHE_DIR):
        if fname.startswith(prefix) and fname.endswith(".json"):
            date_str = fname[len(prefix):-5]
            dates.add(date_str)
    return sorted(dates)


def _score_stock(code, name, hist, price, sector=""):
    """对单只股票评分: 策略信号数 + 动量 + 量价"""
    ss = []
    for sn, stg in _STRATEGIES:
        try:
            sdf = stg.generate_signals(hist.copy())
            if "signal" in sdf.columns and sdf["signal"].iloc[-1] > 0:
                ss.append(sn)
        except Exception:
            pass

    momentum = 0
    if len(hist) >= 5:
        momentum = (hist["close"].iloc[-1] / hist["close"].iloc[-5] - 1) * 100

    vol_ratio = 1.0
    if len(hist) >= 10:
        vol_ratio = hist["volume"].iloc[-1] / max(hist["volume"].iloc[-10:-1].mean(), 1)

    # 综合: 策略信号(每个+12) + 动量 + 量价修正
    score = len(ss) * 12 + max(-10, min(20, momentum)) + (5 if vol_ratio > 1.2 else -3 if vol_ratio < 0.5 else 0)

    return {
        "code": code, "name": name, "price": round(price, 2),
        "sector": sector, "lot_cost": round(price * 100, 2),
        "signals": ss, "signal_count": len(ss),
        "momentum": round(momentum, 2), "vol_ratio": round(vol_ratio, 2),
        "score": round(score, 1),
    }


def _estimate_t1_return(code, hist, lookback=20):
    """估算T+1预期收益: 基于最近N日的历史T+1收益均值"""
    if hist is None or len(hist) < lookback + 2:
        return 0
    returns = []
    for i in range(-lookback - 1, -1):
        buy_close = hist["close"].iloc[i]
        sell_close = hist["close"].iloc[i + 1]
        if buy_close > 0:
            ret = (sell_close / buy_close - 1) * 100
            returns.append(ret)
    return np.mean(returns) if returns else 0


def _run_t1_analysis(hist):
    """对历史数据进行完整的T+1分析, 返回每日的T日涨幅和T+1涨幅"""
    if hist is None or len(hist) < 2:
        return []
    rows = []
    for i in range(len(hist) - 1):
        d = hist.iloc[i]
        d_next = hist.iloc[i + 1]
        buy_change = d.get("change_pct", 0)
        if buy_change is None:
            buy_change = 0
        sell_change = (d_next["close"] / d["close"] - 1) * 100
        rows.append({
            "date": str(d["date"])[:10],
            "buy_close": round(float(d["close"]), 2),
            "buy_change": round(float(buy_change), 2),
            "sell_close": round(float(d_next["close"]), 2),
            "t1_return": round(float(sell_change), 2),
        })
    return rows


def pick_for_tier(tier_key, date_obj=None, force=False, quotes=None):
    """为一个档位挑选最佳组合并运行T+1回测"""
    if date_obj is None:
        date_obj = datetime.now()
    date_str = date_obj.strftime("%Y%m%d")

    # 先检查缓存（除非 force=True）
    if not force:
        cached = load_cached(tier_key, date_str)
        if cached:
            return cached

    tier = TIERS[tier_key]
    max_amount = tier["max_amount"]
    max_pos = tier["max_positions"]

    if quotes is None:
        quotes = StockAPI.get_realtime_quotes()
    if quotes.empty:
        return None

    end = date_str
    start = (date_obj - timedelta(days=120)).strftime("%Y%m%d")

    candidates = []
    all_hist = {}

    def _process_stock(row):
        code = row["code"]
        name = row["name"]
        price = float(row["price"]) if pd.notna(row.get("price")) else 0
        sector = str(row.get("industry", row.get("sector", "")))
        if price <= 0:
            return None
        # lot cost must fit within max_amount for single stock or shared across picks
        lot = price * 100
        if lot > max_amount:
            return None
        hist = StockAPI.get_historical_data(code, start, end)
        if hist is None or len(hist) < 60:
            return None
        info = _score_stock(code, name, hist, price, sector)
        info["lot_cost"] = round(lot, 2)
        return code, info, hist

    batch = [row for _, row in quotes.iterrows()]
    with ThreadPoolExecutor(max_workers=8) as executor:
        futures = {executor.submit(_process_stock, r): r for r in batch}
        for f in as_completed(futures):
            try:
                res = f.result()
                if res:
                    code, info, hist = res
                    all_hist[code] = hist
                    candidates.append(info)
            except Exception:
                pass

    if not candidates:
        return None

    candidates.sort(key=lambda x: x["score"], reverse=True)
    top_candidates = candidates[:30]

    def _make_pos(c):
        ch = all_hist.get(c["code"])
        td = _run_t1_analysis(ch)[-30:] if ch is not None else []
        return {"code": c["code"], "name": c["name"], "sector": c["sector"],
                "price": c["price"], "lot_cost": c["lot_cost"], "weight": 0,
                "signal_count": c["signal_count"], "signals": c["signals"][:5],
                "momentum": c["momentum"],
                "t1_history": td}

    def _combo_score(stocks):
        """组合评分：信号数加权和（成本占比），跨板块加分"""
        total_cost = sum(s["lot_cost"] for s in stocks)
        if total_cost <= 0:
            return -999
        sig_score = sum(s["signal_count"] * s["lot_cost"] / total_cost for s in stocks)
        # 跨板块加分：不同板块数 * 1.0
        sectors = {s["sector"] for s in stocks if s["sector"]}
        sector_bonus = len(sectors) * 1.0 if len(sectors) >= 2 else 0
        return sig_score + sector_bonus

    best_combo = []
    best_score = -999
    best_reason = ""

    # ── 优先策略: 跨板块2~3只对冲组合 ──
    if max_pos >= 2:
        # 找2只组合（跨板块优先）
        best_pair = None
        best_pair_score = -999
        for i in range(len(top_candidates)):
            for j in range(i + 1, len(top_candidates)):
                a, b = top_candidates[i], top_candidates[j]
                total_cost = a["lot_cost"] + b["lot_cost"]
                if total_cost > max_amount:
                    continue
                # 跨板块组合马上考虑
                if a["sector"] == b["sector"] and a["sector"]:
                    # 同板块要求双方≥3信号
                    if a["signal_count"] < 3 or b["signal_count"] < 3:
                        continue
                cs = _combo_score([a, b])
                if cs > best_pair_score:
                    best_pair_score = cs
                    best_pair = (a, b)

        if best_pair:
            a, b = best_pair
            total_cost = a["lot_cost"] + b["lot_cost"]
            wa = round(a["lot_cost"] / total_cost, 2)
            wb = round(b["lot_cost"] / total_cost, 2)
            pa, pb = _make_pos(a), _make_pos(b)
            pa["weight"], pb["weight"] = wa, wb
            same_sec = a["sector"] == b["sector"] and a["sector"]
            if same_sec:
                pa["reason"] = f"同板块强信号: {a['name']}({a['sector']}) {a['signal_count']}个策略"
                pb["reason"] = f"同板块强信号: {b['name']}({b['sector']}) {b['signal_count']}个策略"
                best_reason = (f"【同板块强信号】{a['name']}+{b['name']}({a['sector']}), "
                              f"双方均≥3个策略信号, 行情确认")
            else:
                pa["reason"] = f"跨板块对冲: {a['name']}({a['sector']}) {a['signal_count']}个策略信号"
                pb["reason"] = f"跨板块对冲: {b['name']}({b['sector']}) {b['signal_count']}个策略信号"
                best_reason = (f"【跨板块对冲】{a['name']}({a['sector']}) + {b['name']}({b['sector']}), "
                              f"组合成本{total_cost:.0f}元")
            best_combo = [pa, pb]
            best_score = best_pair_score

        # 再找3只组合（仅限 max_pos >= 3，跨板块至少要2个板块）
        if max_pos >= 3:
            best_triple = None
            best_triple_score = -999
            for i in range(len(top_candidates)):
                for j in range(i + 1, len(top_candidates)):
                    for k in range(j + 1, len(top_candidates)):
                        a, b, c3 = top_candidates[i], top_candidates[j], top_candidates[k]
                        total_cost = a["lot_cost"] + b["lot_cost"] + c3["lot_cost"]
                        if total_cost > max_amount:
                            continue
                        sectors = {a["sector"], b["sector"], c3["sector"]}
                        if len(sectors) < 2:
                            continue
                        cs = _combo_score([a, b, c3])
                        if cs > best_triple_score:
                            best_triple_score = cs
                            best_triple = (a, b, c3)

            if best_triple:
                a, b, c3 = best_triple
                total_cost = a["lot_cost"] + b["lot_cost"] + c3["lot_cost"]
                wa = round(a["lot_cost"] / total_cost, 2)
                wb = round(b["lot_cost"] / total_cost, 2)
                wc = round(c3["lot_cost"] / total_cost, 2)
                pa, pb, pc3 = _make_pos(a), _make_pos(b), _make_pos(c3)
                pa["weight"], pb["weight"], pc3["weight"] = wa, wb, wc
                pa["reason"] = f"跨板块对冲: {a['name']}({a['sector']})"
                pb["reason"] = f"跨板块对冲: {b['name']}({b['sector']})"
                pc3["reason"] = f"跨板块对冲: {c3['name']}({c3['sector']})"
                secs = " + ".join(sorted({a["sector"], b["sector"], c3["sector"]}))
                new_reason = (f"【跨板块对冲·{len({a['sector'], b['sector'], c3['sector']})}板块】{secs}, "
                             f"组合成本{total_cost:.0f}元")
                if best_triple_score > best_score:
                    best_combo = [pa, pb, pc3]
                    best_score = best_triple_score
                    best_reason = new_reason

    # ── 策略2: 无合适对子时选单一标的（仅限策略信号≥4个的极确定行情）──
    if not best_combo:
        for c in top_candidates:
            if c["signal_count"] >= 4 and c["lot_cost"] <= max_amount:
                p = _make_pos(c)
                p["weight"] = 1.0
                p["reason"] = f"多重策略共振({c['signal_count']}个)·单一标的 {c['name']}"
                best_score = c["signal_count"]
                best_combo = [p]
                best_reason = (f"【多重策略共振·单一标的】{c['name']}({c['sector']}) "
                              f"触发{c['signal_count']}个策略信号")
                break

    # ── 终极保底: 评分最高的一只 ──
    if not best_combo and top_candidates:
        c = top_candidates[0]
        p = _make_pos(c)
        p["weight"] = 1.0
        p["reason"] = f"最优选择: {c['name']} 触发{c['signal_count']}个策略信号"
        best_combo = [p]
        best_reason = f"【最优标的】{c['name']} 触发{c['signal_count']}个策略信号，评分最高{c['score']}"

    total_cost = sum(p["lot_cost"] for p in best_combo)

    result = {
        "date": date_str,
        "tier": tier["name"],
        "max_amount": max_amount,
        "total_cost": round(total_cost, 2),
        "expected_return": round(best_score, 2),
        "positions": best_combo,
        "pick_reason": best_reason,
        "analyzed_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "total_candidates": len(candidates),
    }

    save_cache(tier_key, date_str, result)
    return result


def batch_pick(date_obj=None, force=False):
    """运行全部三档组合的选股+回测（共享行情数据确保价格一致）"""
    if date_obj is None:
        date_obj = datetime.now()
    # 统一获取一次行情数据，所有档位共用
    quotes = StockAPI.get_realtime_quotes()
    results = {}
    for tier_key in TIERS:
        results[tier_key] = pick_for_tier(tier_key, date_obj, force=force, quotes=quotes)
    return results


def load_history(tier_key, days=30):
    """加载历史回测结果（自动回填T+1真实收益）"""
    dates = get_cached_dates(tier_key)
    dates = sorted(dates)[-days:]
    results = []
    for d in dates:
        data = load_cached(tier_key, d)
        if data:
            enrich_with_actual(data)
            results.append(data)
    return results


def get_all_history(days=30):
    """获取所有档位的历史数据"""
    return {tk: load_history(tk, days) for tk in TIERS}


def enrich_with_actual(data):
    """给缓存数据补充真实数据：
    - T+1已过 → 从历史K线拿前复权T+1真实收盘价
    - T+1还没到 → 从实时行情拿当前价和今日涨跌
    所有收益率计算统一使用前复权价格，避免数据源不一致。
    """
    if not data or "positions" not in data:
        return data
    buy_date_str = data.get("date", "")
    if not buy_date_str:
        return data
    buy_dt = datetime.strptime(buy_date_str, "%Y%m%d")
    t1_date = buy_dt + timedelta(days=1)
    today = datetime.now()
    t1_passed = today.date() >= t1_date.date()

    # 批量获取实时行情（一次API调用）
    realtime_quotes = None

    for pos in data["positions"]:
        if t1_passed:
            # 如果已有新版前复权数据，跳过；否则强制刷新（旧版数据用实时价算的，不准确）
            if pos.get("t1_actual_return") is not None and isinstance(pos.get("t1_actual_return"), (int, float)):
                if pos.get("qfq_buy_price") is not None:
                    continue
                # 清除旧数据，用新逻辑重新计算
                pos["t1_actual_return"] = None
            # T+1日已过：统一用前复权价格计算T日和T+1日收益
            t1_str = t1_date.strftime("%Y%m%d")
            # 一次获取覆盖T日和T+1日的前复权数据，确保数据源一致
            hist = StockAPI.get_historical_data(pos["code"], buy_date_str, t1_str, adjust="qfq")
            if hist is not None and len(hist) >= 2:
                # T日前复权收盘价
                buy_row = hist[hist["date"] == pd.to_datetime(buy_date_str)]
                # T+1日前复权收盘价
                sell_row = hist[hist["date"] == pd.to_datetime(t1_str)]
                if not buy_row.empty and not sell_row.empty:
                    qfq_buy_close = float(buy_row["close"].iloc[0])
                    qfq_sell_close = float(sell_row["close"].iloc[0])
                    if qfq_buy_close > 0:
                        actual_ret = (qfq_sell_close / qfq_buy_close - 1) * 100
                        pos["qfq_buy_price"] = round(qfq_buy_close, 2)
                        pos["t1_actual_return"] = round(actual_ret, 2)
                        pos["t1_actual_close"] = round(qfq_sell_close, 2)
                        pos["t1_actual_date"] = t1_str
                    else:
                        pos["t1_actual_return"] = None
                        pos["t1_actual_close"] = None
                        pos["t1_actual_date"] = t1_str
                else:
                    # 降级：只有一天数据（可能是T+1落在非交易日）
                    # 用该日前复权收盘价作为买入价，T+1收益置None
                    actual_close = float(hist["close"].iloc[-1])
                    if actual_close > 0:
                        pos["qfq_buy_price"] = round(actual_close, 2)
                    pos["t1_actual_return"] = None
                    pos["t1_actual_close"] = None
                    pos["t1_actual_date"] = t1_str
            else:
                pos["t1_actual_return"] = None
                pos["t1_actual_close"] = None
                pos["t1_actual_date"] = t1_str
        else:
            # T+1还没到：从实时行情拿当前价格
            if realtime_quotes is None:
                realtime_quotes = StockAPI.get_realtime_quotes()
            if realtime_quotes is not None and not realtime_quotes.empty:
                match = realtime_quotes[realtime_quotes["code"] == pos["code"]]
                if not match.empty:
                    r = match.iloc[0]
                    pos["realtime_price"] = round(float(r["price"]), 2) if pd.notna(r.get("price")) else None
                    pos["realtime_change_pct"] = round(float(r.get("change_pct", 0)), 2) if pd.notna(r.get("change_pct")) else None
                else:
                    pos["realtime_price"] = None
                    pos["realtime_change_pct"] = None
            pos["t1_actual_return"] = None
            pos["t1_actual_close"] = None
            pos["t1_actual_date"] = None

    # 计算组合实际收益（仅当T+1已过且有真实数据）
    actuals = [p.get("t1_actual_return") for p in data["positions"]
               if isinstance(p.get("t1_actual_return"), (int, float))]
    if actuals:
        data["actual_return"] = round(sum(actuals) / len(actuals), 2)
    else:
        data.pop("actual_return", None)
    return data


def backfill_all_predictions():
    """扫描所有缓存，回填T+1真实收益"""
    now = datetime.now()
    count = 0
    for tier_key in TIERS:
        dates = get_cached_dates(tier_key)
        for d in dates:
            buy_dt = datetime.strptime(d, "%Y%m%d")
            t1_date = buy_dt + timedelta(days=1)
            if now.date() <= t1_date.date():
                continue  # T+1还没到
            data = load_cached(tier_key, d)
            if data:
                # 检查是否已有新版前复权数据
                has_qfq = False
                for p in data.get("positions", []):
                    if p.get("qfq_buy_price") is not None:
                        has_qfq = True
                        break
                if has_qfq:
                    continue  # 已有新版前复权数据
                enrich_with_actual(data)
                save_cache(tier_key, d, data)
                count += 1
    return count


def get_stock_recommendation_history(code, days=90):
    """扫描历史推荐记录，找出某只股票被推荐过的日期及实际T+1收益（含持仓权重）"""
    history = []
    today_str = datetime.now().strftime("%Y%m%d")
    for tier_key in TIERS:
        dates = get_cached_dates(tier_key)
        dates = [d for d in dates if d <= today_str]
        dates = sorted(dates)[-days:]
        for d in dates:
            data = load_cached(tier_key, d)
            if not data:
                continue
            for pos in data.get("positions", []):
                if pos["code"] == code:
                    t1_ret = pos.get("t1_actual_return")
                    if t1_ret is not None and isinstance(t1_ret, (int, float)):
                        history.append({
                            "date": d,
                            "tier": data.get("tier", tier_key),
                            "name": pos.get("name", ""),
                            "price": pos.get("price", 0),
                            "weight": pos.get("weight", 0),
                            "t1_actual_return": t1_ret,
                            "signals": pos.get("signals", []),
                        })
    return sorted(history, key=lambda x: x["date"], reverse=True)


def incremental_backtest(force=False):
    """增量回测: force=True 时强制以实时数据重跑"""
    today = datetime.now()
    if today.weekday() >= 5:
        return {"status": "非交易日, 跳过"}
    date_str = today.strftime("%Y%m%d")
    quotes = StockAPI.get_realtime_quotes()
    results = {}
    for tier_key in TIERS:
        if force:
            results[tier_key] = pick_for_tier(tier_key, today, force=True, quotes=quotes)
        else:
            cached = load_cached(tier_key, date_str)
            if cached:
                results[tier_key] = cached
            else:
                results[tier_key] = pick_for_tier(tier_key, today, quotes=quotes)
    return results


def backtest_buy_sell_timing(sample_size=30, lookback=60):
    """回测不同买卖时点的T+1收益: 比较收盘买/开盘点  vs  收盘卖/开盘卖"""
    quotes = StockAPI.get_realtime_quotes()
    if quotes.empty:
        return None

    end = datetime.now().strftime("%Y%m%d")
    start = (datetime.now() - timedelta(days=lookback + 30)).strftime("%Y%m%d")
    sample = quotes.head(sample_size)

    hist_list = []
    for _, row in sample.iterrows():
        hist = StockAPI.get_historical_data(row["code"], start, end)
        if hist is not None and len(hist) >= lookback + 5:
            hist_list.append(hist)

    if not hist_list:
        return None

    results = {
        "收盘买→收盘卖": {"returns": [], "wins": 0, "total": 0},
        "收盘买→开盘卖": {"returns": [], "wins": 0, "total": 0},
        "开盘买→收盘卖": {"returns": [], "wins": 0, "total": 0},
        "开盘买→开盘卖": {"returns": [], "wins": 0, "total": 0},
    }

    for hist in hist_list:
        for i in range(-lookback - 1, -1):
            close_buy = hist["close"].iloc[i]
            close_sell = hist["close"].iloc[i + 1]
            open_buy = hist["open"].iloc[i]
            open_sell = hist["open"].iloc[i + 1]

            if close_buy <= 0 or open_buy <= 0:
                continue

            r1 = (close_sell / close_buy - 1) * 100
            r2 = (open_sell / close_buy - 1) * 100
            r3 = (close_sell / open_buy - 1) * 100
            r4 = (open_sell / open_buy - 1) * 100

            for label, r in [("收盘买→收盘卖", r1), ("收盘买→开盘卖", r2),
                             ("开盘买→收盘卖", r3), ("开盘买→开盘卖", r4)]:
                results[label]["returns"].append(r)
                results[label]["total"] += 1
                if r > 0:
                    results[label]["wins"] += 1

    summary = {}
    for label, d in results.items():
        if d["returns"]:
            summary[label] = {
                "avg_return": round(np.mean(d["returns"]), 2),
                "win_rate": round(d["wins"] / len(d["returns"]) * 100, 1),
                "max_return": round(max(d["returns"]), 2),
                "min_return": round(min(d["returns"]), 2),
                "samples": len(d["returns"]),
            }
    return summary


def _generate_15min_bars(open_, high, low, close, n=16):
    """用布朗桥+正弦扰动从日线OHLC生成合成15分钟价格序列"""
    t = np.linspace(0, 1, n)
    # 线性插值
    linear = open_ + (close - open_) * t
    # 布朗桥扰动(中间大两端小)
    deviation = np.sin(np.pi * t) * (high - low) * 0.15 * np.random.randn()
    prices = linear + deviation
    # 约束在[low, high]范围内
    prices = np.clip(prices, low, high)
    # 确保首尾接近open/close
    prices[0] = open_
    prices[-1] = close
    return prices


# A股15分钟时间标签(每个交易日16个15分钟段)
_TIME_SLOTS = [
    "09:30", "09:45", "10:00", "10:15", "10:30", "10:45",
    "11:00", "11:15", "13:00", "13:15", "13:30", "13:45",
    "14:00", "14:15", "14:30", "14:45",
]

_TOTAL_SLOTS = len(_TIME_SLOTS)  # 16

# 为布朗桥生成设置稳定种子
_BRIDGE_SEED = 42


def backtest_buy_sell_timing_15min(sample_size=30, lookback=60):
    """15分钟间隔买卖时点T+1收益回测: 用布朗桥从日线OHLC生成15分钟价"""
    quotes = StockAPI.get_realtime_quotes()
    if quotes.empty:
        return None

    end = datetime.now().strftime("%Y%m%d")
    start = (datetime.now() - timedelta(days=lookback + 30)).strftime("%Y%m%d")
    sample = quotes.head(sample_size)

    np.random.seed(_BRIDGE_SEED)

    hist_list = []
    names = []
    for _, row in sample.iterrows():
        hist = StockAPI.get_historical_data(row["code"], start, end)
        if hist is not None and len(hist) >= lookback + 5:
            hist_list.append(hist)
            names.append(row["name"])

    if not hist_list:
        return None

    # results[buy_slot][sell_slot] = {returns, wins, total}
    results = {}
    for b in range(_TOTAL_SLOTS):
        results[b] = {}
        for s in range(_TOTAL_SLOTS):
            results[b][s] = {"returns": [], "wins": 0, "total": 0}

    for hist in hist_list:
        for day_idx in range(-lookback - 1, -1):
            today = hist.iloc[day_idx]
            tomorrow = hist.iloc[day_idx + 1]

            o, h, l, c = float(today["open"]), float(today["high"]), float(today["low"]), float(today["close"])
            to, th, tl, tc = float(tomorrow["open"]), float(tomorrow["high"]), float(tomorrow["low"]), float(tomorrow["close"])

            if any(v <= 0 for v in [o, h, l, c, to, th, tl, tc]):
                continue

            # 生成T日和T+1日的15分钟价格
            t_bars = _generate_15min_bars(o, h, l, c)
            t1_bars = _generate_15min_bars(to, th, tl, tc)

            for b in range(_TOTAL_SLOTS):
                buy_price = t_bars[b]
                if buy_price <= 0:
                    continue
                for s in range(_TOTAL_SLOTS):
                    sell_price = t1_bars[s]
                    if sell_price <= 0:
                        continue
                    ret = (sell_price / buy_price - 1) * 100
                    results[b][s]["returns"].append(ret)
                    results[b][s]["total"] += 1
                    if ret > 0:
                        results[b][s]["wins"] += 1

    # 汇总
    heatmap_data = np.full((_TOTAL_SLOTS, _TOTAL_SLOTS), np.nan)
    winrate_data = np.full((_TOTAL_SLOTS, _TOTAL_SLOTS), np.nan)
    sample_data = np.full((_TOTAL_SLOTS, _TOTAL_SLOTS), 0)
    best_combo = {"buy": 0, "sell": 0, "avg_return": -999, "win_rate": 0}

    for b in range(_TOTAL_SLOTS):
        for s in range(_TOTAL_SLOTS):
            d = results[b][s]
            if d["returns"]:
                avg_r = round(np.mean(d["returns"]), 4)
                wr = round(d["wins"] / len(d["returns"]) * 100, 1)
                heatmap_data[b][s] = avg_r
                winrate_data[b][s] = wr
                sample_data[b][s] = len(d["returns"])
                if avg_r > best_combo["avg_return"]:
                    best_combo = {"buy": b, "sell": s, "avg_return": avg_r,
                                  "win_rate": wr}
            else:
                heatmap_data[b][s] = np.nan
                winrate_data[b][s] = np.nan

    # 按卖点统计最佳(收盘买→各时点卖)
    close_buy_results = {}
    for s in range(_TOTAL_SLOTS):
        d = results[15][s]  # slot 15 = 14:45 ≈ 尾盘最后时段
        if d.get("returns"):
            close_buy_results[_TIME_SLOTS[s]] = {
                "avg_return": round(np.mean(d["returns"]), 2),
                "win_rate": round(d["wins"] / len(d["returns"]) * 100, 1),
                "samples": len(d["returns"]),
            }

    return {
        "time_slots": _TIME_SLOTS,
        "heatmap": heatmap_data.tolist(),
        "winrate_map": winrate_data.tolist(),
        "sample_map": sample_data.tolist(),
        "best_combo": {
            "buy_time": _TIME_SLOTS[best_combo["buy"]],
            "sell_time": _TIME_SLOTS[best_combo["sell"]],
            "avg_return": round(best_combo["avg_return"], 2),
            "win_rate": best_combo["win_rate"],
            "buy_slot": int(best_combo["buy"]),
            "sell_slot": int(best_combo["sell"]),
        },
        "close_buy_results": close_buy_results,
        "stock_count": len(hist_list),
        "stock_names": names[:5],
    }
