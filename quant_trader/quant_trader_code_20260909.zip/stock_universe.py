"""
选股范围过滤 — 全模块统一使用
规则：
- 排除科创板(688)
- 排除创业板(300/301)
- 排除北交所(4xx/8xx)
- 排除 ST / *ST / 退市
- 排除一手(100股)超过5000元的股票（即价格 > 50 元）
"""
MAX_LOT_COST = 5000


def is_eligible(code, name="", price=0):
    """判断单只股票是否在可选范围内"""
    code = str(code or "").strip().zfill(6)
    name = str(name or "").strip()
    try:
        price = float(price)
    except (TypeError, ValueError):
        price = 0

    if code.startswith("688"):   # 科创板
        return False
    if code.startswith(("300", "301")):  # 创业板
        return False
    if code.startswith(("4", "8")):      # 北交所 / 老三板
        return False
    if "ST" in name.upper() or "退" in name:  # ST / 退市
        return False
    if price > MAX_LOT_COST / 100:       # 一手 > 5000 元
        return False
    return True


def filter_universe(df):
    """过滤行情/成分股 DataFrame（需含 code / name / price 列）"""
    if df is None or df.empty:
        return df
    mask = df.apply(lambda r: is_eligible(r.get("code"), r.get("name", ""), r.get("price", 0)), axis=1)
    return df[mask].reset_index(drop=True)
