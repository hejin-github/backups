# -*- coding: utf-8 -*-
"""
turnover_cost_experiment.py — 降换手/控成本实验: 多日持有 vs T+1 全换对净值/回撤的影响 (预注册)

回答: 0.20%/天的往返成本是生产口径最大的摩擦来源 (walkforward all 臂 open真实日均仅 +0.022%,
      成本≈吃掉 raw edge 大半)。把同一批信号改成"持有 H 天后才换仓"(换手降到 1/H,
      成本摊薄 0.20%/H 每天), 省下的成本能否抵消失掉的新鲜边?

方法(与 sector_pool_walkforward 同骨架, 无前视泄漏):
  - 宇宙 = top-N 成交额(默认 300) 或 生产热门板块成分池; asof=上一交易日; 共享磁盘缓存;
  - 信号日 D 的池 = 任一策略 signal>0 且 D+1 开盘可买(一字过滤) 的股票;
  - 阶梯持仓(ladder): 每个信号日 D 开一仓, D+1 开盘买入, 持有 H 个交易日(至 close[D+H]),
    资本按活跃持仓数均分; 成本只在开仓日付一次 0.20%×(新开仓数/活跃数);
  - H=1 退化为现有 T+1 全换日净值(可对账 walkforward all 臂); 另算 NOCOST-T1(cost=0) 隔离 raw edge;
  - 公共窗口 = 信号日 D 满足 D+H_max 完整落在 asof 内, 保证每 arm 都有完整路径;
  - 配对 bootstrap 1万次 SEED=42 → 90%CI + P(>0); NAV/maxDD/Sharpe 同 _nav_stats;
  - edge 衰减曲线: 全池逐日 forward 累计收益(open 口径, H=1..H_max), 诊断新鲜边死在几天后。

预注册判定(先写死, 跑完不改):
  #1 成本拖累量化(必报): NOCOST-T1 vs T1 日均差(pp)/cum差(pp)/maxDD差; 应≈0.20%/天。
  #2 多日持有净胜: ∃ H∈{2,3,5,10}: mean(H) ≥ mean(T1)+0.1pp 且 bootstrap 90%CI 下界>0。
  #3 风险不恶化: 该 H 的 maxDD ≤ T1 maxDD+2pp 且 Sharpe ≥ T1 Sharpe。
  #4 逐档位(报备): 每档位位置级 H vs T1 日当量均值差; crash 档多日持有大概率更差, n<15 证据不足。
  综合: #2 且 #3 同 H 通过 → SUPPORT 降换手(H*); 否则维持 T+1 全换。
输出: data/ranker_experiment/turnover_cost_{universe}_{pool}.json
"""
import argparse
import json
import os
import sys
from bisect import bisect_left, bisect_right
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed

import numpy as np
import pandas as pd

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

from stock_api import StockAPI
from stock_universe import filter_universe
from strategies import list_strategies, get_strategy
from experiment_common import fetch_hist_cached, hist_window, load_index_regimes
from strategy_backtest import _prev_trading_day
from sector_pool_walkforward import _build_hot_sector_universe, _bootstrap_diff, _nav_stats, _stats
from sector_pool_backtest import _oneword_open

BASE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(BASE, "data", "ranker_experiment")
WARMUP = 20
COST = 0.20
H_MAX = 10
HORIZONS = [2, 3, 5, 10]
BOOT_N = 10000
SEED = 42
REGIMES = ["strong", "normal", "weak", "crash"]
LIMITUP_NAME = "涨停打板·短线博弈"


def _stock_bars(hist):
    """hist DataFrame → (sorted_dates, sbar{date:(o,c,h,l)}, closes_by_date)."""
    dates = list(pd.to_datetime(hist["date"]).dt.normalize())
    opens = [float(x) for x in hist["open"]]
    closes = [float(x) for x in hist["close"]]
    highs = [float(x) for x in hist["high"]]
    lows = [float(x) for x in hist["low"]]
    sbar = {}
    for i, d in enumerate(dates):
        sbar[d] = (opens[i], closes[i], highs[i], lows[i])
    return dates, sbar


def _close_at(dates, sbar, t):
    """股票在交易日 t 的最后收盘(≤t, 停牌 carry)。返回价格或 None."""
    pos = bisect_right(dates, t) - 1
    if pos < 0:
        return None
    return sbar[dates[pos]][1]


def _build_forward(code, dpos, dates, sbar, idx_days, hmax):
    """信号日 D(=idx_days[dpos]) 起 H_max 日 open 口径路径。
    返回 (buyable, day_rets[0..H_max-1], cum_fwd[0..H_max-1])。
    day_rets[k] = 持有第 k+1 交易日收益(第0天 open→close, 其余 close→close, 停牌 carry=0)
    cum_fwd[k]  = 从 open[D+1] 买入至 close[D+1+k] 的累计收益(open 口径, 含 carry)。
    不可买(无 bar/一字/无完整路径)返回 (False, None, None)。"""
    entry_pos = dpos + 1
    if entry_pos + hmax - 1 >= len(idx_days):
        return False, None, None
    t_entry = idx_days[entry_pos]
    bar = sbar.get(t_entry)
    if bar is None or bar[0] <= 0:
        return False, None, None
    o, c, _h, _l = bar
    if _oneword_open({"open": o, "high": _h, "low": _l}):
        return False, None, None
    day_rets = np.zeros(hmax)
    cum_fwd = np.zeros(hmax)
    day_rets[0] = (c / o - 1.0) * 100.0
    cum_fwd[0] = (c / o - 1.0) * 100.0
    prev = c
    for k in range(1, hmax):
        c_now = _close_at(dates, sbar, idx_days[entry_pos + k])
        if c_now is None:
            c_now = prev
        r = (c_now / prev - 1.0) if prev > 0 else 0.0
        day_rets[k] = r * 100.0
        cum_fwd[k] = (c_now / o - 1.0) * 100.0
        prev = c_now
    return True, day_rets, cum_fwd


def _simulate(positions_by_entry, H, cost, grid_positions):
    """阶梯持仓日净值。positions_by_entry: {entry_idx: [position,...]}, 每个 position:
    {entry: idx, rets: np.array(长度 H, 持有逐日收益)}。
    grid_positions: 要计算的 idx 范围(range(first_entry, last+1))。
    返回 {idx_day: 日净收益%}. 成本在开仓日收: 0.20%×(新开仓数/当日活跃数)。"""
    active = []
    daily = {}
    for t_idx in grid_positions:
        opened = positions_by_entry.get(t_idx, [])
        active.extend(opened)
        n_active = len(active)
        if n_active == 0:
            daily[t_idx] = 0.0
            continue
        day_rets = [p["rets"][t_idx - p["entry"]] for p in active]
        n_new = len(opened)
        ret = float(np.mean(day_rets)) - cost * (n_new / n_active)
        daily[t_idx] = round(ret, 6)
        # 到期(持有满 H 天): entry+ H-1 == t_idx → 移除
        active = [p for p in active if t_idx - p["entry"] < H - 1]
    return daily


def run(sample_limit=300, lookback_days=400, asof=None, universe="amount",
        pool="all", hot_sectors=5, horizons=None, cost=COST, hmax=H_MAX):
    if asof is None:
        asof = _prev_trading_day()
    asof_ts = pd.Timestamp(asof).normalize()
    horizons = horizons or HORIZONS
    print(f"降换手/控成本: universe={universe} pool={pool} | 窗口 {lookback_days} 日 | "
          f"asof={asof_ts.date()} | 成本{cost}%/往返 | 持有H∈{horizons} | H_max={hmax}")

    # ── 宇宙 ──
    if universe == "hot_sector":
        codes, hot = _build_hot_sector_universe(max_sectors=hot_sectors)
        if not codes:
            print("热门板块接口失败/空池"); return None
        print(f"热门板块({len(hot)}): " + "、".join(f"{s.get('name')}({s.get('avg_change_pct',0):+.2f}%)" for s in hot))
    else:
        quotes = StockAPI.get_realtime_quotes()
        if quotes is None or quotes.empty:
            print("实时行情获取失败(腾讯网络?)"); return None
        quotes = filter_universe(quotes)
        sort_col = "amount" if "amount" in quotes.columns else "price"
        sample = quotes.sort_values(sort_col, ascending=False).head(sample_limit)
        codes = sample["code"].tolist()
    print(f"宇宙 {len(codes)} 只")

    regimes, idx = load_index_regimes(lookback_days, asof)
    if idx is None:
        print("指数数据不足"); return None
    idx_days = sorted(regimes.keys())
    print(f"指数档位日: {len(idx_days)}")

    # ── 拉个股历史(共享缓存) ──
    start_str, end_str = hist_window(asof_ts, lookback_days)
    hist_cache = {}

    def _pass(cands, workers):
        got = {}
        with ThreadPoolExecutor(max_workers=workers) as ex:
            fs = {ex.submit(fetch_hist_cached, c, start_str, end_str, asof): c for c in cands}
            for f in as_completed(fs):
                try:
                    h = f.result()
                except Exception:
                    h = None
                if h is not None and len(h) >= 30:
                    got[fs[f]] = h
        return got

    hist_cache.update(_pass(codes, 8))
    for backoff in (15, 45, 120):
        missing = [c for c in codes if c not in hist_cache]
        if not missing:
            break
        print(f"缺失 {len(missing)}, 退避 {backoff}s 补拉...")
        import time
        time.sleep(backoff)
        hist_cache.update(_pass(missing, 6))
    print(f"个股历史: {len(hist_cache)}/{len(codes)}")

    # ── 信号扫描 → sig_map[D] = {code: set(snames)} ──
    strategies = [n for n in list_strategies() if n != "组合策略·投票系统"]
    sig_map = defaultdict(lambda: defaultdict(set))
    for sname in strategies:
        try:
            stg = get_strategy(sname)
        except Exception:
            continue
        if stg is None:
            continue
        for code, hist in hist_cache.items():
            try:
                sdf = stg.generate_signals(hist.copy())
            except Exception:
                continue
            if "signal" not in sdf.columns:
                continue
            sig = sdf["signal"].astype(float).values
            closes = hist["close"].astype(float).values
            dates = pd.to_datetime(hist["date"]).dt.normalize().values
            n = len(sig)
            for i in range(WARMUP, n - 1):
                if sig[i] <= 0 or closes[i] <= 0:
                    continue
                d = pd.Timestamp(dates[i])
                if d not in regimes:
                    continue
                sig_map[d][code].add(sname)
    sig_days = sorted(sig_map.keys())
    print(f"信号日: {len(sig_days)} | 信号条数: {sum(len(v) for v in sig_map.values())}")

    # ── 公共窗口: D + H_max 完整落在 asof 内 → 所有 arm 同开仓日集合 ──
    def _dpos(d):
        return bisect_left(idx_days, d)

    common_sig = [d for d in sig_days if _dpos(d) + hmax < len(idx_days)]
    common_set = set(common_sig)
    print(f"公共窗口信号日(完整{hmax}日路径): {len(common_sig)}")

    # ── 预计算每 (D, code) 的 forward 路径(仅公共窗口) ──
    # fwd_map[D] = {code: (day_rets, cum_fwd)}  (只存可买股票)
    fwd_map = defaultdict(dict)
    stock_dates = {c: _stock_bars(h)[0] for c, h in hist_cache.items()}
    stock_bars = {c: _stock_bars(h)[1] for c, h in hist_cache.items()}
    for d in common_sig:
        dpos = _dpos(d)
        for code in sig_map[d]:
            ok, day_rets, cum_fwd = _build_forward(code, dpos, stock_dates[code],
                                                    stock_bars[code], idx_days, hmax)
            if ok:
                fwd_map[d][code] = (day_rets, cum_fwd)
    print(f"可建仓信号日: {len(fwd_map)}")

    # ── 池规则: all / limitup ──
    def _pool_codes(d):
        codes_d = list(sig_map[d].keys())
        if pool == "limitup":
            return [c for c in codes_d if LIMITUP_NAME in sig_map[d][c]]
        return codes_d

    # ── 位置构建(每个 arm 用同一位置集, 仅持有 H 不同) ──
    # positions[arm_key] = positions_by_entry: entry_idx -> [position,...]
    def _build_positions(H):
        pb = defaultdict(list)
        for d in sorted(fwd_map.keys()):
            entry_pos = _dpos(d) + 1
            pool_codes = [c for c in _pool_codes(d) if c in fwd_map[d]]
            if not pool_codes:
                continue
            pool_day = np.stack([fwd_map[d][c][0] for c in pool_codes]).mean(axis=0)  # 池逐日收益
            pb[entry_pos].append({"entry": entry_pos, "rets": pool_day[:H]})
        return pb

    first_entry = min(_dpos(d) for d in fwd_map) + 1
    grid = range(first_entry, len(idx_days))
    grid_days = [idx_days[i] for i in grid]

    arms = {}
    for H in [1] + horizons:
        pb = _build_positions(H)
        arms[f"H{H}"] = _simulate(pb, H, cost, grid)
    arms["NOCOST_T1"] = _simulate(_build_positions(1), 1, 0.0, grid)

    # ── 对账: recon_t1 = walkforward all 臂(全信号日, 按信号日 keying, cost 0.20) ──
    def _entry_open_ret(code, d, idx_days, sbar):
        """信号日 d → D+1 开盘买入→收盘卖出 open 真实收益(不可买返回 None)."""
        dpos = _dpos(d)
        if dpos + 1 >= len(idx_days):
            return None
        bar = sbar.get(idx_days[dpos + 1])
        if bar is None or bar[0] <= 0:
            return None
        o, c, _h, _l = bar
        if _oneword_open({"open": o, "high": _h, "low": _l}):
            return None
        return (c / o - 1.0) * 100.0

    recon = {}
    for d in sig_days:  # 全窗口, 与 walkforward 一致
        rets = [_entry_open_ret(c, d, idx_days, stock_bars[c])
                for c in _pool_codes(d)]
        rets = [r for r in rets if r is not None]
        recon[d] = round(float(np.mean(rets)) - cost, 6) if rets else 0.0
    arms["recon_t1"] = recon

    # ── edge 衰减曲线(公共窗口, 池=all 或 limitup 全股票) ──
    decay = defaultdict(list)  # k -> list(cum_fwd)
    for d in sorted(fwd_map.keys()):
        for code in _pool_codes(d):
            if code not in fwd_map[d]:
                continue
            for k in range(hmax):
                decay[k].append(float(fwd_map[d][code][1][k]))
    edge = [{"horizon": k + 1, "cum_mean": round(float(np.mean(decay[k])), 3),
             "n": len(decay[k])} for k in sorted(decay)]

    # ── 结果统计 ──
    def _arm_daykey(k):
        """arm 日 key 统一为 'YYYY-MM-DD'; 网格臂 key=int 索引, recon 臂 key=Timestamp."""
        return str(k.date()) if isinstance(k, pd.Timestamp) else str(idx_days[k].date())

    result = {"meta": {"asof": asof_ts.strftime("%Y%m%d"), "universe": universe, "pool": pool,
                       "sample_limit": sample_limit, "hot_sectors": hot_sectors,
                       "lookback_days": lookback_days, "stocks": len(hist_cache),
                       "signal_days": len(sig_days), "common_sig_days": len(common_sig),
                       "cost": cost, "hmax": hmax, "horizons": horizons,
                       "thresholds": {"#2_win_pp": 0.1, "#3_maxDD_penalty_pp": 2.0},
                       "note": "阶梯持仓: 开仓日D+1开盘买入, 持有H交易日; 成本开仓日付一次0.20%×(新开仓/活跃数); "
                               "公共窗口保证所有arm同开仓日集合; open真实口径, 一字过滤, 停牌carry=0"},
              "daily": {k: {_arm_daykey(i): v for i, v in vv.items()} for k, vv in arms.items()}}
    for arm, daily in arms.items():
        vals = list(daily.values())
        result[arm] = {**_stats(vals), **_nav_stats({i: v for i, v in enumerate(vals)})}

    # 配对对比(同一日历网格, 补齐0)
    comp = {}
    t1_arr = np.array([arms["H1"].get(i, 0.0) for i in grid], float)
    for H in horizons:
        h_arr = np.array([arms[f"H{H}"].get(i, 0.0) for i in grid], float)
        m, lo, hi, p = _bootstrap_diff(h_arr, t1_arr)
        comp[f"H{H}_vs_T1"] = {"mean_diff_pp": m, "ci90": [lo, hi], "p_gt0": p}
    noco = np.array([arms["NOCOST_T1"].get(i, 0.0) for i in grid], float)
    m, lo, hi, p = _bootstrap_diff(noco, t1_arr)
    comp["NOCOST_vs_T1"] = {"mean_diff_pp": m, "ci90": [lo, hi], "p_gt0": p}
    result["comparisons"] = comp

    # ── 成本拖累 #1 ──
    drag = {"mean_pp": round(float(np.mean(noco) - np.mean(t1_arr)), 3),
            "cum_diff_pp": round(result["NOCOST_T1"]["cum_pct"] - result["H1"]["cum_pct"], 2),
            "maxDD_diff_pp": round(result["NOCOST_T1"]["maxDD"] - result["H1"]["maxDD"], 2)}
    result["cost_drag"] = drag

    # ── 逐档位 #4(位置级日当量) ──
    per_regime = {r: {} for r in REGIMES}
    for d in sorted(fwd_map.keys()):
        rg = regimes[d]
        pool_codes = [c for c in _pool_codes(d) if c in fwd_map[d]]
        if not pool_codes:
            continue
        cum = np.stack([fwd_map[d][c][1] for c in pool_codes]).mean(axis=0)  # 池累计
        for H in [1] + horizons:
            if H <= hmax:
                pos_cum = float(cum[H - 1]) - cost / H  # 该仓 H 日累计净(摊薄成本)
                daily_eq = pos_cum / H
            else:
                continue
            per_regime[rg].setdefault(H, []).append(daily_eq)
    result["per_regime"] = {r: {f"H{H}": {"mean_daily_eq": round(float(np.mean(per_regime[r][H])), 4),
                                          "n": len(per_regime[r][H])} if per_regime[r].get(H) else None
                                  for H in [1] + horizons} for r in REGIMES}
    result["edge_decay"] = edge

    # ── 预注册判定 ──
    v = {}
    v["#1_cost_drag"] = drag
    best = None
    for H in horizons:
        c = comp[f"H{H}_vs_T1"]
        if result[f"H{H}"]["mean"] >= result["H1"]["mean"] + 0.1 and c["ci90"][0] > 0:
            if best is None or result[f"H{H}"]["mean"] > result[best]["mean"]:
                best = f"H{H}"
    v["#2_multi_day_wins"] = bool(best)
    v["#2_best_H"] = best
    risk_ok = False
    if best:
        risk_ok = (result[best]["maxDD"] <= result["H1"]["maxDD"] + 2.0
                   and result[best]["sharpe"] >= result["H1"]["sharpe"])
    v["#3_risk_ok"] = risk_ok
    v["#4_regime"] = "报备明细见 per_regime (crash 档多日持有大概率更差, n<15 证据不足)"
    v["conclusion"] = f"SUPPORT 降换手: 改多日持有 {best}" if (best and risk_ok) else \
        "维持 T+1 全换 (省下的成本不抵丢失的新鲜边)"
    result["verdict"] = v

    out_path = os.path.join(OUT_DIR, f"turnover_cost_{universe}_{pool}.json")
    os.makedirs(OUT_DIR, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    # ── 打印 ──
    print("\nedge 衰减曲线(全池 open口径累计 forward, 公共窗口):")
    print("  " + " | ".join(f"k={e['horizon']} {e['cum_mean']:+.3f}% n={e['n']}" for e in edge))
    print("\n各臂日净值(公共窗口, 已扣成本, 无仓=0):")
    for arm in ["NOCOST_T1", "H1"] + [f"H{h}" for h in horizons] + ["recon_t1"]:
        r = result[arm]
        print(f"  {arm:<10} mean={r['mean']:+.3f}% win={r['win_rate']}% | "
              f"maxDD={r['maxDD']:+.1f}% sharpe={r['sharpe']} cum={r['cum_pct']:+.1f}% n={r['n']}")
    print("\n配对 bootstrap(H − T1, 同一日历网格):")
    for H in horizons:
        c = comp[f"H{H}_vs_T1"]
        print(f"  H{H}−T1 {c['mean_diff_pp']:+.3f}pp CI90[{c['ci90'][0]:+.3f},{c['ci90'][1]:+.3f}] P(>0)={c['p_gt0']}")
    c = comp["NOCOST_vs_T1"]
    print(f"  NOCOST−T1 {c['mean_diff_pp']:+.3f}pp CI90[{c['ci90'][0]:+.3f},{c['ci90'][1]:+.3f}] P(>0)={c['p_gt0']}")
    print(f"\n成本拖累#1: NOCOST−T1 日均 {drag['mean_pp']:+.3f}pp | cum差 {drag['cum_diff_pp']:+.2f}pp "
          f"| maxDD差 {drag['maxDD_diff_pp']:+.2f}pp")
    print(f"判定: #2={v['#2_multi_day_wins']}(best={best}) #3={risk_ok} → {v['conclusion']}")
    print(f"对账参考: walkforward all 臂 open真实/0.20成本 → 日均+0.022% win52.5% "
          f"maxDD-12.7% sharpe0.33 cum+6.3% (本次 recon_t1 见上表)")
    print(f"结果 → {out_path}")
    return result


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--sample-limit", type=int, default=300)
    ap.add_argument("--lookback-days", type=int, default=400)
    ap.add_argument("--asof", default=None)
    ap.add_argument("--universe", choices=["amount", "hot_sector"], default="amount")
    ap.add_argument("--pool", choices=["all", "limitup"], default="all")
    ap.add_argument("--hot-sectors", type=int, default=5)
    ap.add_argument("--cost", type=float, default=COST)
    ap.add_argument("--hmax", type=int, default=H_MAX)
    ap.add_argument("--horizons", default="2,3,5,10",
                    help="逗号分隔的持有日数, 如 '2,3,5,10'")
    args = ap.parse_args()
    horizons = [int(x) for x in args.horizons.split(",") if x.strip()]
    run(sample_limit=args.sample_limit, lookback_days=args.lookback_days, asof=args.asof,
        universe=args.universe, pool=args.pool, hot_sectors=args.hot_sectors,
        horizons=horizons, cost=args.cost, hmax=args.hmax)
