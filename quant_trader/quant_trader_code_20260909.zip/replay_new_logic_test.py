# -*- coding: utf-8 -*-
"""
回放实验: 按"新逻辑"(单策略质控) 在首页已有日期的数据上选股, 对比旧逻辑(强制共振≥2任意)
胜率/收益各提升多少.

方法(walk-forward, 无前视泄漏):
  1. top-by-amount 采样股票, 拉 320 日历史 + 上证指数逐日档位
  2. 每策略逐股信号 → 每条信号 (date, stock, strategy, ret, trailing_win_rate, regime)
  3. 首页日期 = data/daily_picks + data/recommendations 的文件名交易日
  4. 对每个首页日期 D(升序):
       - allowed 集 = 只用 date<D 的记录按档位统计(样本≥30,胜率≥52%,均值>0)
       - 新逻辑: D 日被 ≥1 个 allowed 策略看多的股票
       - 旧逻辑: D 日被 ≥2 个任意策略看多的股票
       - 每日选股: 各自候选中按该股过去20日T+1胜率取 top1
  5. 汇总信号级 + 每日选股级 的 T+1 胜率/均值; 附首页实际记录(t1_1030)参照
输出: data/replay_new_logic_result.json
"""
import json
import os
import sys
import glob
import numpy as np
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

from stock_api import StockAPI
from stock_universe import filter_universe
from strategies import list_strategies, get_strategy
from strategy_backtest import REGIMES, _classify_regime

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "data", "replay_new_logic_result.json")

MIN_TOTAL = 30
MIN_WIN = 52.0
MIN_AVG = 0.0


def _load_index_regimes(lookback_days=320):
    idx = None
    try:
        idx = StockAPI.get_index_historical_data("sh000001", days=lookback_days)
    except Exception:
        idx = None
    if idx is None or len(idx) < 30:
        try:
            from index_guide import load_sh_raw
            raw = load_sh_raw()
            dates, closes = raw.get("dates", []), raw.get("closes", [])
            if len(dates) >= 30:
                df = pd.DataFrame({"date": pd.to_datetime(dates), "close": closes})
                df = df.sort_values("date").reset_index(drop=True)
                idx = df
        except Exception:
            idx = None
    if idx is None or len(idx) < 30:
        return None, None
    idx = idx.sort_values("date").reset_index(drop=True)
    idx["date"] = pd.to_datetime(idx["date"])
    idx["ma20"] = idx["close"].rolling(20).mean()
    regimes = {}
    for _, row in idx.iterrows():
        if pd.isna(row["ma20"]):
            continue
        regimes[row["date"].normalize()] = _classify_regime(float(row["close"]), float(row["ma20"]))
    return regimes, idx["date"].iloc[0]


def _fetch_hist(code, start_str, end_str):
    try:
        h = StockAPI.get_historical_data(code, start_str, end_str)
        if h is not None and len(h) >= 30:
            h = h.sort_values("date").reset_index(drop=True)
            h["date"] = pd.to_datetime(h["date"])
            return code, h
    except Exception:
        pass
    return code, None


def _daily_t1_win_rate(hist, idx):
    if idx < 9:
        return None
    lo = max(0, idx - 20)
    wins, tot = 0, 0
    for i in range(lo, idx):
        b, s = float(hist["close"].iloc[i]), float(hist["close"].iloc[i + 1])
        if b > 0:
            tot += 1
            if s / b - 1 > 0:
                wins += 1
    if tot < 8:
        return None
    return wins / tot


def _home_dates():
    """首页已有日期的交易日集合(YYYYMMDD)"""
    dates = set()
    for sub in ("daily_picks", "recommendations"):
        for fp in glob.glob(os.path.join(BASE, "data", sub, "*.json")):
            dates.add(os.path.basename(fp)[:8])
    return dates


def _recorded_home_picks():
    """首页实际记录的推荐 t1_1030_return 列表(参照行, 行业板块驱动口径)"""
    rets = []
    for fp in sorted(glob.glob(os.path.join(BASE, "data", "recommendations", "*.json"))):
        try:
            data = json.load(open(fp, encoding="utf-8"))
        except Exception:
            continue
        for p in data.get("picks", []):
            r = p.get("t1_1030_return")
            if r is not None:
                rets.append(float(r))
    return rets


def run(sample_limit=200, lookback_days=320):
    quotes = StockAPI.get_realtime_quotes()
    if quotes is None or quotes.empty:
        return None
    quotes = filter_universe(quotes)
    sort_col = "amount" if "amount" in quotes.columns else "price"
    quotes = quotes.sort_values(sort_col, ascending=False)
    sample = quotes.head(sample_limit)

    regimes, idx_first = _load_index_regimes(lookback_days)
    if regimes is None:
        print("指数数据不足")
        return None
    end = datetime.now()
    start_str = (idx_first - timedelta(days=25)).strftime("%Y%m%d")
    end_str = end.strftime("%Y%m%d")
    print(f"指数档位日数: {len(regimes)} | 个股窗口 {start_str}~{end_str}")

    hist_cache = {}
    with ThreadPoolExecutor(max_workers=8) as ex:
        fs = {ex.submit(_fetch_hist, c, start_str, end_str): c for c in sample["code"].tolist()}
        for f in as_completed(fs):
            try:
                c, h = f.result()
                if h is not None:
                    hist_cache[c] = h
            except Exception:
                pass
    print(f"个股历史: {len(hist_cache)}/{len(sample)}")

    strategy_names = [n for n in list_strategies() if n != "组合策略·投票系统"]
    # 每条信号: (date, stock, strategy, ret, twr, regime)
    signals = []
    for sname in strategy_names:
        try:
            stg = get_strategy(sname)
        except Exception:
            continue
        if stg is None:
            continue
        for code, hist in hist_cache.items():
            try:
                sdf = stg.generate_signals(hist.copy())
            except Exception:
                continue
            if "signal" not in sdf.columns:
                continue
            sig = sdf["signal"].astype(float).values
            closes = hist["close"].astype(float).values
            dates = hist["date"].values
            n = len(sig)
            for i in range(20, n - 1):
                if sig[i] <= 0 or closes[i] <= 0:
                    continue
                d = pd.Timestamp(dates[i]).normalize()
                regime = regimes.get(d)
                if regime is None:
                    continue
                ret = (closes[i + 1] / closes[i] - 1) * 100
                twr = _daily_t1_win_rate(hist, i)
                signals.append((d, code, sname, ret, twr, regime))
    print(f"信号总数: {len(signals)}")

    # ── 首页日期 ──
    home_dates = _home_dates()
    home_days = sorted(d for d in {pd.Timestamp(x).normalize() for x in home_dates}
                       if d in regimes)
    print(f"首页已有交易日(在档位数据内): {len(home_days)}")
    if len(home_days) < 5:
        print("首页日期过少, 无法回放")
        return None

    # ── 按 (date, stock) 聚合信号 ──
    # sig_by_ds[date][stock] = {"regime":r, "ret":ret, "twr":tw, "strategies":set}
    sig_by_ds = {}
    for d, code, sname, ret, twr, r in signals:
        ds = sig_by_ds.setdefault(d, {}).setdefault(
            code, {"regime": r, "ret": ret, "twr": twr, "strategies": set()})
        ds["strategies"].add(sname)

    # ── walk-forward: 允许集只取 date<D ──
    # 预构建 按日 的允许集(需按档位聚合)
    all_days = sorted(sig_by_ds.keys())
    # 前缀聚合: 每过一天把当天记录加入 bucket
    # bucket[strategy][regime] = list(ret)  截止到"前一日"
    bucket = {s: {r: [] for r in REGIMES} for s in strategy_names}
    allowed_cache = {}  # date -> allowed per regime

    def _allowed_now():
        out = {r: [] for r in REGIMES}
        for s in strategy_names:
            for r in REGIMES:
                rets = bucket[s][r]
                t = len(rets)
                if t < MIN_TOTAL:
                    continue
                wr = sum(1 for x in rets if x > 0) / t * 100
                avg = float(np.mean(rets))
                if wr >= MIN_WIN and avg > MIN_AVG:
                    out[r].append((s, avg))
        for r in REGIMES:
            out[r].sort(key=lambda x: -x[1])
            out[r] = [x[0] for x in out[r]]
        return out

    idx_by_day = {d: i for i, d in enumerate(all_days)}
    for i, d in enumerate(all_days):
        allowed_cache[d] = _allowed_now()
        for code, ds in sig_by_ds[d].items():
            for sname in ds["strategies"]:
                bucket[sname][ds["regime"]].append(ds["ret"])

    # ── 回放首页日期 ──
    def _stats(rets):
        t = len(rets)
        if t == 0:
            return {"total": 0, "win_rate": 0.0, "avg": 0.0}
        wr = round(sum(1 for x in rets if x > 0) / t * 100, 1)
        avg = round(float(np.mean(rets)), 3)
        return {"total": t, "win_rate": wr, "avg": avg}

    new_sig, old_sig = [], []
    new_pick, old_pick = [], []
    rows = []
    for D in home_days:
        lvl = regimes[D]
        allowed = set(allowed_cache.get(D, {}).get(lvl, []))
        stocks = sig_by_ds.get(D, {})
        new_cand, old_cand = [], []
        for code, ds in stocks.items():
            n_allowed = sum(1 for s in ds["strategies"] if s in allowed)
            if n_allowed >= 1:
                new_cand.append((code, ds["ret"], ds["twr"]))
            if len(ds["strategies"]) >= 2:
                old_cand.append((code, ds["ret"], ds["twr"]))
        def _top1(cands):
            if not cands:
                return None
            ranked = sorted(cands, key=lambda x: (x[2] is not None, x[2] if x[2] is not None else -1), reverse=True)
            return ranked[0][1]
        pn, po = _top1(new_cand), _top1(old_cand)
        for c in new_cand:
            new_sig.append(c[1])
        for c in old_cand:
            old_sig.append(c[1])
        if pn is not None:
            new_pick.append(pn)
        if po is not None:
            old_pick.append(po)
        rows.append({
            "date": D.strftime("%Y%m%d"), "level": lvl,
            "allowed_count": len(allowed),
            "new_cand": len(new_cand), "old_cand": len(old_cand),
            "new_pick_ret": round(pn, 2) if pn is not None else None,
            "old_pick_ret": round(po, 2) if po is not None else None,
        })

    recorded = _recorded_home_picks()

    res = {
        "stocks": len(hist_cache), "strategies": len(strategy_names),
        "home_days_evaluated": len(home_days),
        "thresholds": {"min_total": MIN_TOTAL, "min_win": MIN_WIN, "min_avg": MIN_AVG},
        "new_logic_ge1_allowed": {
            "signal": _stats(new_sig), "daily_pick": _stats(new_pick)},
        "old_logic_ge2_any": {
            "signal": _stats(old_sig), "daily_pick": _stats(old_pick)},
        "recorded_home_picks_t1_1030": _stats(recorded),
        "daily_rows": rows,
    }
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)

    print("\n=== 首页日期回放汇总 ===")
    for name, s, p in (("新逻辑 ≥1 allowed", new_sig, new_pick),
                       ("旧逻辑 ≥2 任意", old_sig, old_pick)):
        ss, pp = _stats(s), _stats(p)
        print(f"  {name:<16} 信号{ss['total']:>5} 胜率{ss['win_rate']:>6.1f}% 均值{ss['avg']:>+7.3f}% | "
              f"每日选股{pp['total']:>3} 胜率{pp['win_rate']:>6.1f}% 均值{pp['avg']:>+7.3f}%")
    rr = _stats(recorded)
    print(f"  首页实际记录(t1_1030)      {rr['total']:>5} 胜率{rr['win_rate']:>6.1f}% 均值{rr['avg']:>+7.3f}%  (参照)")

    # 提升量
    ss, pp = _stats(new_sig), _stats(new_pick)
    so, po = _stats(old_sig), _stats(old_pick)
    print(f"\n新逻辑 vs 旧逻辑:")
    print(f"  信号级  胜率 {so['win_rate']}%→{ss['win_rate']}% (+{ss['win_rate']-so['win_rate']:.1f}pp)  "
          f"均值 {so['avg']:+.3f}%→{ss['avg']:+.3f}% (+{ss['avg']-so['avg']:.3f}pp)")
    print(f"  选股级  胜率 {po['win_rate']}%→{pp['win_rate']}% (+{pp['win_rate']-po['win_rate']:.1f}pp)  "
          f"均值 {po['avg']:+.3f}%→{pp['avg']:+.3f}% (+{pp['avg']-po['avg']:.3f}pp)")
    print(f"\n结果已保存: {OUT}")
    return res


if __name__ == "__main__":
    run(sample_limit=200, lookback_days=320)
