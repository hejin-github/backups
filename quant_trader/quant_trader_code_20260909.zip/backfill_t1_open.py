# -*- coding: utf-8 -*-
"""一次性数据回填: 将历史推荐记录中"D收盘兜底买价"的T+1收益修正为"T+1开盘买"真口径.

背景: app.py 旧版在 T+1 盘中回填且当日bar未入API时, qfq_buy 兜底用D收盘(高估隔夜gap),
且"已有t1_return就跳过"锁死了错误值. 本脚本用与 app.py 修复后相同的算法就地纠正:
  - 有T+1 bar → qfq_buy=T+1开盘, metric=t1_open, 重算 t1_return/t1_1030_return;
  - 一字涨停(开盘=最高) → t1_buyable=False;
  - 始终重算(幂等), 不因 metric 已标 t1_open 而跳过(此前一版曾误写T+2, 需覆盖).
幂等可重复运行.
"""
import glob
import json
import os
import sys
from datetime import datetime, timedelta

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import pandas as pd

from scheduler import _next_trading_day
from stock_api import StockAPI

BASE = os.path.dirname(os.path.abspath(__file__))
REC = os.path.join(BASE, "data", "recommendations")
BAR_CACHE = os.path.join(BASE, "data", "history_cache", "t1_open_fix_bars.json")

_bar_cache = {}
if os.path.exists(BAR_CACHE):
    try:
        _bar_cache = json.load(open(BAR_CACHE, encoding="utf-8"))
    except Exception:
        _bar_cache = {}


def _t1_bar(code, date_str, t1_str, today_str):
    """拉 T+1 bar, 返回 (open, close, high, low) 或 None. 带缓存+重试."""
    key = f"{code}_{t1_str}"
    if key in _bar_cache:
        v = _bar_cache[key]
        return tuple(v) if v else None
    for attempt in range(4):
        try:
            hist = StockAPI.get_historical_data(code, date_str, today_str, adjust="qfq")
            if hist is not None and not hist.empty:
                row = hist[pd.to_datetime(hist["date"]).dt.strftime("%Y%m%d") == t1_str]
                if not row.empty:
                    r = row.iloc[0]
                    v = [round(float(r["open"]), 4), round(float(r["close"]), 4),
                         round(float(r["high"]), 4), round(float(r["low"]), 4)]
                    _bar_cache[key] = v
                    with open(BAR_CACHE, "w", encoding="utf-8") as f:
                        json.dump(_bar_cache, f)
                    return tuple(v)
        except Exception:
            pass
    _bar_cache[key] = None
    return None


def _correct_pick(pick, date_str, today_str):
    """按修正算法重算单只pick, 返回是否变化."""
    t1 = _next_trading_day(datetime.strptime(date_str, "%Y%m%d") + timedelta(days=1))
    t1_str = t1.strftime("%Y%m%d")
    if datetime.now().date() <= t1.date():
        return False  # T+1 未到, 不改(盘中待收盘)
    code = pick.get("code", "")
    got = _t1_bar(code, date_str, t1_str, today_str)
    if got is None:
        return False  # T+1 bar 拉不到, 保持原样(下次app再试)
    t1_open, t1_close, t1_high, t1_low = got
    if t1_open <= 0:
        return False
    oneword = (t1_high - t1_low) < 0.03 and t1_open >= t1_high - 0.005
    changed = False
    if pick.get("qfq_buy_price") != round(t1_open, 2):
        pick["qfq_buy_price"] = round(t1_open, 2)
        changed = True
    if pick.get("qfq_buy_metric") != "t1_open":
        pick["qfq_buy_metric"] = "t1_open"
        changed = True
    nr = round((t1_close / t1_open - 1) * 100, 2)
    if pick.get("t1_return") != nr:
        pick["t1_return"] = nr
        changed = True
    if pick.get("sell_price") != round(t1_close, 2):
        pick["sell_price"] = round(t1_close, 2)
        changed = True
    t30 = pick.get("t1_1030_price")
    if isinstance(t30, (int, float)) and t1_open > 0:
        nr30 = round((t30 / t1_open - 1) * 100, 2)
        if pick.get("t1_1030_return") != nr30:
            pick["t1_1030_return"] = nr30
            changed = True
    if oneword and pick.get("t1_buyable") is not False:
        pick["t1_buyable"] = False
        changed = True
    return changed


def main():
    today_str = datetime.now().strftime("%Y%m%d")
    fixed_files = 0
    fixed_picks = 0
    for fp in sorted(glob.glob(os.path.join(REC, "*.json"))):
        try:
            rec = json.load(open(fp, encoding="utf-8"))
        except Exception:
            continue
        date_str = rec.get("date", "")
        if not date_str:
            continue
        rec_changed = False
        for pick in rec.get("picks", []):
            if _correct_pick(pick, date_str, today_str):
                rec_changed = True
                fixed_picks += 1
        if rec_changed:
            with open(fp, "w", encoding="utf-8") as f:
                json.dump(rec, f, ensure_ascii=False, indent=2, default=str)
            fixed_files += 1
            print(f"已纠正 {fp.split(os.sep)[-1]}")
    print(f"\n完成: {fixed_files} 个文件, {fixed_picks} 只pick已按T+1开盘买口径纠正")


if __name__ == "__main__":
    main()
