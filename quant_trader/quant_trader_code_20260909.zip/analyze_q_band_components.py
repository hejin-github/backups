# -*- coding: utf-8 -*-
"""拆解质量分陷阱档(80-90)成分:
逐pick重算打分5分项(换手/量能/位置/量价/PE), 按档聚合 + 按(档×触发策略)聚合,
回答: 陷阱档是"策略毒"还是"打分器给动量过度加分". 只读现有replay+信号索引, 不重跑回测."""
import json
import os
import pickle
import collections
import numpy as np
import pandas as pd

import recommender as R

OUT_DIR = "data/prod_pipeline_backtest"
REPLAY = os.path.join(OUT_DIR, "replay_20260828.json")
SIGS = os.path.join(OUT_DIR, "signals_20260828_300.pkl")
_LABEL = "门控·质量基线"


def _q_breakdown(hist, row, code):
    """镜像 R._quality_score 的5分项拆解. 返回 dict(各分项得分+原始值+总分) 或 None."""
    n = len(hist)
    if n < 2:
        return None
    close = hist["close"]
    last = float(close.iloc[-1])
    score = 0.0
    out = {"to_pts": None, "vr_pts": None, "pos_pts": None, "px_pts": None, "pe_pts": None,
           "to": None, "vr": None, "ret5": None, "near_high": None, "up": None, "pe": None}

    to = R._safe_last(hist, "turnover")
    if to is not None and to > 0:
        pts = 30 if 3 <= to <= 15 else 20 if 15 < to <= 25 else 14 if 1 <= to < 3 else 8
        score += pts
        out["to_pts"], out["to"] = pts, to
    else:
        score += 15
        out["to_pts"] = 15

    vr = R._volume_ratio(hist)
    if vr is not None:
        pts = 20 if 1.2 <= vr <= 3.0 else 12 if 0.8 <= vr < 1.2 else 6 if vr > 3.0 else 8
        score += pts
        out["vr_pts"], out["vr"] = pts, vr
    else:
        score += 10
        out["vr_pts"] = 10

    if "high" in hist.columns and n >= 20:
        recent_high = float(hist["high"].iloc[-20:].max())
    else:
        recent_high = float(close.iloc[-min(n, 20):].max())
    near_high = recent_high > 0 and last >= recent_high * 0.97
    ret5 = (last / float(close.iloc[-6]) - 1) * 100 if n >= 6 else 0
    if near_high and 0 <= ret5 <= 25:
        pts = 25
    elif 0 <= ret5 <= 20:
        pts = 18
    elif ret5 < 0:
        pts = 12
    else:
        pts = 8
    score += pts
    out["pos_pts"], out["near_high"], out["ret5"] = pts, near_high, ret5

    o = R._safe_last(hist, "open")
    c = R._safe_last(hist, "close")
    if o is not None and c is not None:
        pts = 15 if c > o else 8 if c == o else 5
        score += pts
        out["px_pts"], out["up"] = pts, c > o
    else:
        score += 8
        out["px_pts"] = 8

    pe = R._pe_of(row, code, None)
    if pe is not None and pe > 0:
        pts = 10 if 10 <= pe <= 80 else 6 if pe > 80 else 3
        score += pts
        out["pe_pts"], out["pe"] = pts, pe
    else:
        score += 5
        out["pe_pts"] = 5

    out["score"] = round(min(score, 100), 1)
    return out


def _band(q):
    return "hi" if q >= 80 else "mid" if q >= 70 else "lo"


def main():
    with open(REPLAY, encoding="utf-8") as f:
        res = json.load(f)
    rows = res[_LABEL + "_rows"]
    print("基线 pick 总数:", len(rows))

    with open(SIGS, "rb") as f:
        sigs = pickle.load(f)
    print("信号索引个股数:", len(sigs))

    # 预构建 per-code 日期→位置 索引
    idx_map = {}
    for code, si in sigs.items():
        dates = pd.to_datetime(si["hist"]["date"]).dt.normalize()
        idx_map[code] = {pd.Timestamp(d): i for i, d in enumerate(dates)}

    recs = []
    mismatch = 0
    for r in rows:
        if r["oneword"] or r["ret"] is None:
            continue
        code, date = r["code"], pd.Timestamp(r["date"]).normalize()
        si = sigs[code]
        i = idx_map[code].get(date)
        if i is None:
            continue
        hist_D = si["hist"].iloc[:i + 1]
        row = {"code": code, "name": r["name"], "price": r["buy"], "change_pct": 0.0}
        bd = _q_breakdown(hist_D, row, code)
        if bd is None:
            continue
        if abs(bd["score"] - float(r["quality"])) > 0.11:
            mismatch += 1
        fired = [s for s, arr in si["sigs"].items()
                 if arr is not None and i < len(arr) and arr[i] > 0]
        recs.append({**r, "bd": bd, "fired": fired, "band": _band(float(r["quality"]))})
    print("成分复算与存储分一致: %d 条不一致" % mismatch)
    print("可交易pick(去一字板):", len(recs))

    bands = collections.OrderedDict((b, [x for x in recs if x["band"] == b])
                                    for b in ("hi", "mid", "lo"))

    # ============ 表1: 按档 胜率/均值 + 分项均分 ============
    print("\n===== 按档: 胜率/均值 + 打分5分项均分 =====")
    hdr = "  %-4s %5s %6s %7s | %s" % ("档", "n", "胜率%", "均值%", " ".join(
        "%6s" % c for c in ("换手", "量能", "位置", "量价", "PE", "总分")))
    print(hdr)
    for b, sub in bands.items():
        rets = [x["ret"] for x in sub]
        win = sum(1 for x in rets if x > 0) / len(rets) * 100
        mean = sum(rets) / len(rets)
        pts = {k: np.mean([x["bd"][k] for x in sub]) for k in
               ("to_pts", "vr_pts", "pos_pts", "px_pts", "pe_pts")}
        q = np.mean([x["quality"] for x in sub])
        print("  %-4s %5d %6.1f %7.3f | %6.1f %6.1f %6.1f %6.1f %6.1f %6.1f" % (
            b, len(sub), win, mean, pts["to_pts"], pts["vr_pts"], pts["pos_pts"],
            pts["px_pts"], pts["pe_pts"], q))

    # 原始值视角
    print("\n===== 按档: 原始值(换手/量比/5日涨幅/贴高率/阳线率) =====")
    for b, sub in bands.items():
        tos = [x["bd"]["to"] for x in sub if x["bd"]["to"] is not None]
        vrs = [x["bd"]["vr"] for x in sub if x["bd"]["vr"] is not None]
        r5s = [x["bd"]["ret5"] for x in sub]
        print("  %-4s 换手中位=%5.2f 量比中位=%5.2f 5日涨幅均值=%+5.2f%% 贴20d高=%4.0f%% 阳线=%4.0f%%"
              % (b, np.median(tos) if tos else 0, np.median(vrs) if vrs else 0,
                 np.mean(r5s), np.mean([1 if x["bd"]["near_high"] else 0 for x in sub]) * 100,
                 np.mean([1 if x["bd"]["up"] else 0 for x in sub]) * 100))

    # ============ 表2: 陷阱档 vs 甜点档 策略构成 ============
    print("\n===== 档内触发策略Top(计数), 及该策略在此档的胜率/均值 =====")
    for b in ("hi", "mid"):
        sub = bands[b]
        scnt = collections.Counter()
        for x in sub:
            for s in x["fired"]:
                scnt[s] += 1
        print("\n-- %s 档 (n=%d), 前6策略:" % (b, len(sub)))
        for s, cnt in scnt.most_common(6):
            sx = [x for x in sub if s in x["fired"]]
            rets = [x["ret"] for x in sx]
            win = sum(1 for x in rets if x > 0) / len(rets) * 100
            print("    %-22s 触发%4d (%.0f%%) 该档内胜率=%5.1f%% 均值=%+6.3f%%" % (
                s, cnt, cnt / len(sub) * 100, win, sum(rets) / len(rets)))

    # ============ 表3: hi档 前后半窗稳定性 ============
    sub = bands["hi"]
    half = len(sub) // 2
    print("\n===== hi档(80-90) 前后半窗对照 =====")
    for tag, seg in (("前一半", sub[:half]), ("后一半", sub[half:])):
        rets = [x["ret"] for x in seg]
        win = sum(1 for x in rets if x > 0) / len(rets) * 100
        tos = [x["bd"]["to"] for x in seg if x["bd"]["to"] is not None]
        vrs = [x["bd"]["vr"] for x in seg if x["bd"]["vr"] is not None]
        r5s = [x["bd"]["ret5"] for x in seg]
        print("  %s n=%3d 胜率=%5.1f%% 均值=%+6.3f%% | 换手中位=%4.2f 量比中位=%4.2f 5日涨=%+5.2f%%"
              % (tag, len(seg), win, sum(rets) / len(rets),
                 np.median(tos) if tos else 0, np.median(vrs) if vrs else 0,
                 np.mean(r5s)))

    # ============ 表4: hi档内 是否存在会赢的子集(按位置分项) ============
    print("\n===== hi档内部按'位置分项'再分层(看是否有赢家子集) =====")
    for pos in (25, 18, 12, 8):
        seg = [x for x in sub if x["bd"]["pos_pts"] == pos]
        if not seg:
            continue
        rets = [x["ret"] for x in seg]
        win = sum(1 for x in rets if x > 0) / len(rets) * 100
        print("  hi档内 pos_pts=%2d (n=%3d) 胜率=%5.1f%% 均值=%+6.3f%%" % (
            pos, len(seg), win, sum(rets) / len(rets)))


if __name__ == "__main__":
    main()
