# -*- coding: utf-8 -*-
"""独立回测(不改现有代码): 以"买入日"的上证指数信号 + 选股池指数信号 做门槛,
比较 无门槛 / 各门槛 下 历史推荐 T+1 胜率 与 T+1 回撤.

口径:
- 推荐记录: data/recommendations/{date}.json (含 主推/备用; 旧记录无 role)
- T+1 卖点: 10:30 基准(t1_1030_return) 为主, T+1收盘(t1_return) 为对照
- 买入基准: qfq_buy_price(买入日前复权收盘)
- T+1 回撤: (T+1日qfq最低价 / qfq_buy - 1) × 100   # 全天最低, 是"买入后最差浮亏"的上界
- 门槛信号都是买入日收盘可得的(无未来函数): 上证当日涨跌/站上MA20, 选股池指数当日涨跌/高于基点100

注意: 样本极小(28笔), 结论仅供参考, 不作统计显著。
"""
import glob
import json
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta

from scheduler import _next_trading_day
from stock_api import StockAPI

BASE = os.path.dirname(os.path.abspath(__file__))
REC_DIR = os.path.join(BASE, "data", "recommendations")
POOL_INDEX_FILE = os.path.join(BASE, "data", "pool_index", "pool_index.json")
REPORT_FILE = os.path.join(BASE, "data", "backtest_index_gate_report.md")


def _ds(d):
    return d.strftime("%Y%m%d") if hasattr(d, "strftime") else str(d).replace("-", "")


def load_picks():
    rows = []
    for f in sorted(glob.glob(os.path.join(REC_DIR, "*.json"))):
        try:
            d = json.load(open(f, encoding="utf-8"))
        except Exception:
            continue
        dt = str(d.get("date") or os.path.basename(f)[:-5])
        for p in d.get("picks", []):
            code = str(p.get("code") or "").strip()
            if not code:
                continue
            rows.append({
                "date": dt,
                "code": code,
                "name": p.get("name"),
                "role": p.get("role"),
                "buy": p.get("qfq_buy_price") or p.get("price"),
                "r1030": p.get("t1_1030_return"),
                "rclose": p.get("t1_return"),
            })
    rows.sort(key=lambda r: (r["date"], r["code"]))
    return rows


def load_sh_signal():
    """上证(真实点位) → {date: {close, ma20, ret_pct, above_ma20}}"""
    idx = StockAPI.get_index_historical_data("sh000001", 200)
    closes = {}
    for _, r in idx.iterrows():
        closes[_ds(r["date"])] = float(r["close"])
    dates = sorted(closes)
    ma20 = {}
    for i, ds in enumerate(dates):
        win = [closes[dates[j]] for j in range(max(0, i - 19), i + 1)]
        ma20[ds] = sum(win) / len(win)
    out, prev = {}, None
    for ds in dates:
        c = closes[ds]
        ret = (c / prev - 1) * 100 if prev else None
        out[ds] = {"close": c, "ma20": ma20[ds], "ret_pct": ret, "above_ma20": c > ma20[ds]}
        prev = c
    return out


def load_pool_signal():
    """选股池指数 → {date: {idx, ret_pct, above100}}"""
    try:
        d = json.load(open(POOL_INDEX_FILE, encoding="utf-8"))
    except Exception:
        return {}
    out, prev = {}, None
    for ds, v in zip(d.get("dates", []), d.get("pool_index", [])):
        ret = (v / prev - 1) * 100 if prev else None
        out[ds] = {"idx": v, "ret_pct": ret, "above100": v > 100}
        prev = v
    return out


def t1_day(buy_date_str):
    dt = datetime.strptime(buy_date_str, "%Y%m%d")
    return _next_trading_day(dt + timedelta(days=1)).strftime("%Y%m%d")


def fetch_t1_lows(rows):
    """每只股票只抓一次前复权日K, 取各 T+1 日最低价. 返回 {(code, t1): low or None}."""
    start = min(r["date"] for r in rows)
    end = max(t1_day(r["date"]) for r in rows)
    need = {}
    for r in rows:
        need.setdefault(r["code"], set()).add(t1_day(r["date"]))

    def _f(code):
        try:
            df = StockAPI.get_historical_data(code, start, end, adjust="qfq", source="tencent")
        except Exception:
            return code, {}
        lows = {}
        if df is not None and not df.empty and "low" in df.columns:
            for _, r in df.iterrows():
                lows[_ds(r["date"])] = float(r["low"])
        return code, lows

    out = {}
    with ThreadPoolExecutor(max_workers=6) as ex:
        for fut in as_completed([ex.submit(_f, c) for c in need]):
            try:
                code, lows = fut.result()
            except Exception:
                continue
            for t1s in need[code]:
                out[(code, t1s)] = lows.get(t1s)
    return out


def attach_signals(rows, sh, pool):
    t1_lows = fetch_t1_lows(rows)
    out = []
    for r in rows:
        s = sh.get(r["date"]) or {}
        p = pool.get(r["date"]) or {}
        t1 = t1_day(r["date"])
        low = t1_lows.get((r["code"], t1))
        dd = (low / r["buy"] - 1) * 100 if (low and r["buy"]) else None
        r2 = dict(r)
        r2.update({
            "sh_ret": s.get("ret_pct"),
            "sh_above_ma20": s.get("above_ma20"),
            "sh_close": s.get("close"),
            "pool_ret": p.get("ret_pct"),
            "pool_above100": p.get("above100"),
            "dd": dd,
        })
        out.append(r2)
    return out


def metrics(picks):
    n = len(picks)
    if not n:
        return None
    w1030 = sum(1 for p in picks if p["r1030"] is not None and p["r1030"] > 0)
    wclose = sum(1 for p in picks if p["rclose"] is not None and p["rclose"] > 0)
    r1030 = [p["r1030"] for p in picks if p["r1030"] is not None]
    dd = [p["dd"] for p in picks if p.get("dd") is not None]
    return {
        "n": n,
        "win1030": w1030 / n * 100,
        "winclose": wclose / n * 100,
        "avg1030": sum(r1030) / len(r1030) if r1030 else None,
        "med1030": sorted(r1030)[len(r1030) // 2] if r1030 else None,
        "n_dd": len(dd),
        "avg_dd": sum(dd) / len(dd) if dd else None,
        "max_dd": min(dd) if dd else None,
        "deep_dd": sum(1 for x in dd if x <= -3) / len(dd) * 100 if dd else None,
    }


def evaluate(picks, gates):
    out = []
    for name, gate in gates:
        m = metrics([p for p in picks if gate(p)])
        if m:
            out.append({"name": name, **m})
    return out


def fmt_row(m):
    return (
        f"| {m['name']:<22} | {m['n']:>3} | {m['win1030']:>6.1f}% | {m['winclose']:>6.1f}% | "
        f"{m['avg1030']:>6.2f}% | {m['med1030']:>6.2f}% | "
        f"{m['avg_dd']:>6.2f}% | {m['max_dd']:>6.2f}% | {m['deep_dd']:>5.1f}% |"
    )


def main():
    rows = load_picks()
    sh = load_sh_signal()
    pool = load_pool_signal()
    picks = attach_signals(rows, sh, pool)

    HDR = "| 门槛 | N | 胜率10:30 | 胜率T+1收 | 均10:30 | 中位10:30 | 均T+1回撤 | 最大回撤 | 深回撤<-3% |"
    SEP = "|---|--:|--:|--:|--:|--:|--:|--:|--:|"

    lines = []
    lines.append("# 选股门槛回测（上证指数 + 选股池指数）\n")
    lines.append(f"样本: {len(picks)} 笔推荐 ({len(set(r['date'] for r in picks))} 个推荐日, "
                 f"{datetime.now().strftime('%Y-%m-%d')} 计算)\n")
    lines.append("口径: 卖点=次日10:30(主)/次日收盘(对照); 买入=前复权收盘; "
                 "T+1回撤=(T+1日最低/买入-1)×100。门槛均用买入日收盘可得信号(无未来函数)。\n")
    lines.append("> 样本极小(28笔)，数字只是提示，不是统计结论。\n")

    all_picks = picks
    era08 = [p for p in picks if p["pool_ret"] is not None]

    lines.append("\n## 面板A · 全部推荐(20260710→20260819, N=%d)\n" % len(all_picks))
    lines.append(HDR)
    lines.append(SEP)
    gates_a = [
        ("无门槛(全部)", lambda p: True),
        ("上证当日上涨", lambda p: p["sh_ret"] is not None and p["sh_ret"] > 0),
        ("上证站上MA20", lambda p: bool(p["sh_above_ma20"])),
        ("上证涨 且 站上MA20", lambda p: p["sh_ret"] is not None and p["sh_ret"] > 0 and bool(p["sh_above_ma20"])),
        ("对照: 上证当日下跌", lambda p: p["sh_ret"] is not None and p["sh_ret"] < 0),
        ("对照: 上证跌破MA20", lambda p: p["sh_above_ma20"] is False),
    ]
    for m in evaluate(all_picks, gates_a):
        lines.append(fmt_row(m))

    lines.append("\n## 面板B · 仅选股池指数窗口(20260804→20260819, N=%d) — 主推+备用\n" % len(era08))
    lines.append(HDR)
    lines.append(SEP)
    gates_b = [
        ("无门槛(全部)", lambda p: True),
        ("上证当日上涨", lambda p: p["sh_ret"] is not None and p["sh_ret"] > 0),
        ("上证站上MA20", lambda p: bool(p["sh_above_ma20"])),
        ("选股池指数当日上涨", lambda p: p["pool_ret"] is not None and p["pool_ret"] > 0),
        ("选股池指数>基点100", lambda p: bool(p["pool_above100"])),
        ("上证涨 且 池指涨", lambda p: p["sh_ret"] is not None and p["sh_ret"] > 0 and p["pool_ret"] is not None and p["pool_ret"] > 0),
        ("上证>MA20 且 池指涨", lambda p: bool(p["sh_above_ma20"]) and p["pool_ret"] is not None and p["pool_ret"] > 0),
    ]
    for m in evaluate(era08, gates_b):
        lines.append(fmt_row(m))

    zhutui = [p for p in era08 if p["role"] == "主推"]
    lines.append("\n## 面板C · 选股池指数窗口 · 仅主推(N=%d)\n" % len(zhutui))
    lines.append(HDR)
    lines.append(SEP)
    gates_c = [
        ("无门槛(全部主推)", lambda p: True),
        ("上证当日上涨", lambda p: p["sh_ret"] is not None and p["sh_ret"] > 0),
        ("选股池指数当日上涨", lambda p: p["pool_ret"] is not None and p["pool_ret"] > 0),
        ("上证涨 且 池指涨", lambda p: p["sh_ret"] is not None and p["sh_ret"] > 0 and p["pool_ret"] is not None and p["pool_ret"] > 0),
    ]
    for m in evaluate(zhutui, gates_c):
        lines.append(fmt_row(m))

    report = "\n".join(lines)
    with open(REPORT_FILE, "w", encoding="utf-8") as f:
        f.write(report)
    print(report)


if __name__ == "__main__":
    main()
