"""
QuantTrader v2.0 — 量化交易系统（仅保留首页，其余页面已停用入口）
"""
import my_streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import time
import sys, os, json, threading, re, glob, textwrap

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from stock_api import StockAPI, API_AVAILABLE, DATA_SOURCE
from scheduler import scheduler, is_trading_time, is_trading_day, _next_trading_day, load_config
from index_guide import ensure_indices_backfilled, load_sh_history, load_sector_index_latest, build_guidance
from distiller import load_latest, get_strategy_card
from debate_engine import load_cache as load_debate_cache, start_auto_refresh
from paper_trading import engine as paper_engine, backtest_agent_vote as agent_backtest

st.set_page_config(page_title="QuantTrader 量化交易系统", page_icon="📈", layout="wide",
                   initial_sidebar_state="expanded")

# ─────────────────────── 全局状态 ───────────────────────

# 仅保留首页（其余菜单页面渲染函数保留于代码中, 但不再提供入口/分发）
PAGES = ["🏠 首页"]
PAGE_MAP = {p: p.split(" ", 1)[1] for p in PAGES}

def init_state():
    # 从 query_params 恢复页面（刷新不丢失）
    saved = st.query_params.get("page", "首页")
    if saved not in PAGE_MAP.values():
        saved = "首页"
    for k, v in {
        "page": saved, "backtest_result": None, "screen_result": None,
        "screen_desc": "", "stock_search": "", "bt_code": "", "bt_name": "",
        "strategy_picks_result": None, "strategy_picks_running": False,
        "scan_result_df": None, "scan_last_time": None, "monitor_alerts": [],
        "review_result": None, "factor_ic_result": None, "grid_result": None,
        "roll_result": None, "report_html": None,
        "hedge_running": False, "hedge_results": None, "hedge_history": None,
        "hedge_last_run": None, "agent_bt": None, "agent_bt_incremental": False,
    }.items():
        if k not in st.session_state:
            st.session_state[k] = v

init_state()
# 仅保留调度状态机供首页显示; 已移除全部自动任务回调(收盘简报/行情补拉/对冲回测/模拟盘/定时扫描)
scheduler.start()


CSS = """
<style>
/* ── 隐藏 Streamlit 部署按钮/白条 ── */
.stAppDeployButton, header[data-testid="stHeader"], #stDecoration, .stException { display:none !important; }
.stApp > header { display:none !important; }
[data-testid="stToolbar"] { display:none !important; }
[data-testid="stStatusWidget"] { display:none !important; }
.main-header { display:none; }
section.main > div { padding-top:0 !important; }
/* ── 全局 ── */
.stApp { background:#0b0e17; color:#ccd6f6; }
.stApp > header { background:#0b0e17 !important; }
.stApp > header .stAppViewContainer { border-bottom:1px solid #1a1d2e; }
[data-testid="stSidebar"] { background:#0f1220 !important; border-right:1px solid #1a1d2e; }
[data-testid="stSidebar"] .stRadio > div { gap:0; }
[data-testid="stSidebar"] .stRadio label {
    padding:7px 16px; border-radius:6px; font-size:0.85rem; color:#ffffff;
    transition:all 0.15s; cursor:pointer;
}
[data-testid="stSidebar"] .stRadio label:hover {
    background:rgba(0,212,255,0.08);
}
[data-testid="stSidebar"] .stRadio [data-testid="stMarkdownContainer"] > p {
    font-size:0.85rem; color:#ffffff;
}
.stTabs [data-baseweb="tab-list"] { gap:0; border-bottom:1px solid #1a1d2e; }
.stTabs [data-baseweb="tab"] {
    background:transparent; border-radius:0; padding:10px 20px;
    font-size:0.85rem; color:#8892b0; transition:all 0.15s;
}
.stTabs [data-baseweb="tab"]:hover { color:#ccd6f6; background:rgba(0,212,255,0.04); }
.stTabs [aria-selected="true"] { color:#00d4ff; border-bottom:2px solid #00d4ff; }
.stButton > button {
    background:linear-gradient(135deg,#1a1d2e,#1f2235); border:1px solid #2a2d3e;
    color:#ccd6f6; border-radius:8px; font-size:0.85rem; transition:all 0.2s;
}
.stButton > button:hover {
    border-color:#00d4ff; color:#00d4ff; transform:translateY(-1px);
    box-shadow:0 4px 12px rgba(0,212,255,0.15);
}
.stButton > button[data-testid="baseButton-primary"] {
    background:linear-gradient(135deg,#00d4ff,#0090cc); border:none; color:#0b0e17;
}
.stButton > button[data-testid="baseButton-primary"]:hover {
    box-shadow:0 4px 16px rgba(0,212,255,0.3); transform:translateY(-1px);
}
.stTextInput > div > div {
    background:#1a1d2e; border:1px solid #2a2d3e; border-radius:8px; color:#e0e0e0;
}
.stTextInput input { color:#e0e0e0; font-size:0.9rem; }
.stTextInput input:focus { border-color:#00d4ff; box-shadow:0 0 0 1px #00d4ff44; }
.stSelectbox > div > div { background:#1a1d2e; border:1px solid #2a2d3e; border-radius:8px; color:#e0e0e0; }
.stDateInput > div > div { background:#1a1d2e; border:1px solid #2a2d3e; border-radius:8px; color:#e0e0e0; }
.stNumberInput > div > div { background:#1a1d2e; border:1px solid #2a2d3e; border-radius:8px; color:#e0e0e0; }
.stDataFrame { border:1px solid #1a1d2e; border-radius:8px; }
.stDataFrame table { font-size:0.8rem; }
.stDataFrame th { background:#1a1d2e !important; color:#8892b0 !important; font-weight:600; }
.stDataFrame td { background:#0f1220 !important; color:#ccd6f6 !important; border-bottom:1px solid #1a1d2e; }
[data-testid="stMetricValue"] { color:#00d4ff; font-size:1.3rem; font-weight:700; }
[data-testid="stMetricLabel"] { color:#8892b0; font-size:0.75rem; }
.stProgress > div > div > div { background:linear-gradient(90deg,#00d4ff,#7b2ff7); }
.stSpinner > div { border-color:#00d4ff transparent transparent transparent; }
::-webkit-scrollbar { width:6px; height:6px; }
::-webkit-scrollbar-track { background:#0f1220; }
::-webkit-scrollbar-thumb { background:#2a2d3e; border-radius:3px; }
::-webkit-scrollbar-thumb:hover { background:#3a3d4e; }
.main-title { font-size:2rem; font-weight:700; background:linear-gradient(135deg,#00d4ff,#7b2ff7); -webkit-background-clip:text; -webkit-text-fill-color:transparent; margin-bottom:0.1rem; letter-spacing:-0.5px; }
.sub-title { font-size:0.85rem; color:#8892b0; margin-bottom:1.5rem; }
.section-title { font-size:1.1rem; font-weight:600; color:#ccd6f6; border-left:3px solid #00d4ff; padding-left:12px; margin:1.2rem 0 0.8rem 0; }
.card { background:linear-gradient(135deg,#151829,#1a1d2e); border-radius:10px; padding:1.2rem; border:1px solid #222538; margin-bottom:0.8rem; transition:border-color 0.2s; }
.card:hover { border-color:#2a2d3e; }
.metric-card { background:linear-gradient(135deg,#151829,#1a1d2e); border-radius:8px; padding:0.6rem 0.8rem; border:1px solid #222538; text-align:center; transition:border-color 0.2s; }
.metric-card:hover { border-color:#00d4ff44; }
.metric-value { font-size:1.4rem; font-weight:700; color:#00d4ff; letter-spacing:-0.3px; }
.metric-value.small { font-size:1rem; }
.metric-label { font-size:0.65rem; color:#8892b0; text-transform:uppercase; letter-spacing:0.5px; }
.pos { color:#ff1744 !important; } .neg { color:#00c853 !important; }
.pos-bg { background:rgba(255,23,68,0.12); color:#ff1744; padding:1px 6px; border-radius:4px; font-weight:600; }
.neg-bg { background:rgba(0,200,83,0.12); color:#00c853; padding:1px 6px; border-radius:4px; font-weight:600; }
.strategy-card { background:linear-gradient(135deg,#151829,#1a1d2e); border:1px solid #222538; border-radius:10px; padding:1rem; margin-bottom:0.8rem; transition:all 0.2s; }
.strategy-card:hover { border-color:#00d4ff; transform:translateY(-1px); box-shadow:0 4px 16px rgba(0,212,255,0.06); }
.strategy-name { font-size:1rem; font-weight:600; color:#ccd6f6; }
.strategy-author { font-size:0.75rem; color:#00d4ff; }
.signal-buy { background:rgba(255,23,68,0.12); color:#ff1744; padding:2px 8px; border-radius:4px; font-size:0.7rem; font-weight:600; }
.signal-sell { background:rgba(0,200,83,0.12); color:#00c853; padding:2px 8px; border-radius:4px; font-size:0.7rem; font-weight:600; }
.footer { text-align:center; color:#3a3d4e; font-size:0.7rem; padding:2rem 0 0.5rem 0; border-top:1px solid #1a1d2e; margin-top:3rem; }
.alert-4 { border-left:4px solid #ff1744; background:rgba(255,23,68,0.06); }
.alert-3 { border-left:4px solid #00c853; background:rgba(0,200,83,0.06); }
.alert-2 { border-left:4px solid #ffd600; background:rgba(255,214,0,0.06); }
.alert-1 { border-left:4px solid #00d4ff; background:rgba(0,212,255,0.06); }
.tag { display:inline-block; padding:1px 8px; border-radius:10px; font-size:0.65rem; font-weight:600; }
.tag-buy { background:rgba(255,23,68,0.15); color:#ff1744; border:1px solid rgba(255,23,68,0.3); }
.tag-agent { background:rgba(123,47,247,0.15); color:#b388ff; border:1px solid rgba(123,47,247,0.3); }
.tag-sell { background:rgba(0,200,83,0.15); color:#00c853; border:1px solid rgba(0,200,83,0.3); }
.tier-card { background:linear-gradient(135deg,#151829,#1a1d2e); border:1px solid #222538; border-radius:12px; padding:1.2rem; margin-bottom:1rem; position:relative; overflow:hidden; }
.tier-card::before { content:""; position:absolute; top:0; left:0; width:4px; height:100%; }
.tier-card.tier-1w::before { background:linear-gradient(180deg,#ff1744,#ff6d00); }
.tier-card.tier-5k::before { background:linear-gradient(180deg,#ffd600,#ff9100); }
.tier-card.tier-2k::before { background:linear-gradient(180deg,#00d4ff,#7b2ff7); }
.tier-name { font-size:1.1rem; font-weight:700; color:#ccd6f6; }
.tier-amount { font-size:0.8rem; color:#8892b0; }
.stock-chip { display:inline-flex; align-items:center; gap:4px; background:rgba(0,212,255,0.08); border:1px solid rgba(0,212,255,0.2); border-radius:6px; padding:3px 10px; font-size:0.8rem; color:#ccd6f6; }
.reason-box { background:rgba(0,212,255,0.04); border:1px solid rgba(0,212,255,0.1); border-radius:8px; padding:0.8rem; font-size:0.8rem; color:#8892b0; line-height:1.6; }
</style>"""

# ─────────────────────── 后台扫描 ───────────────────────

_SCAN_REGISTRY = {"result": None, "running": False, "last_time": None, "started_at": None,
                  "error": None, "saved": False}
_SCAN_TIMEOUT = 150  # 秒, 超过视为扫描卡死
TOP10_CACHE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "top10_cache.json")
RECOMMEND_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "recommendations")
DAILY_PICKS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "daily_picks")

def _save_top10_cache(result):
    try:
        os.makedirs(os.path.dirname(TOP10_CACHE_PATH), exist_ok=True)
        with open(TOP10_CACHE_PATH, "w", encoding="utf-8") as f:
            json.dump({"result": result, "time": datetime.now().isoformat()}, f, ensure_ascii=False, default=str)
    except Exception:
        pass

def _load_top10_cache():
    try:
        if os.path.exists(TOP10_CACHE_PATH):
            with open(TOP10_CACHE_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            cache_time = datetime.fromisoformat(data.get("time", ""))
            today = datetime.now()
            # 缓存是今天的才有效
            if cache_time.date() == today.date():
                return data.get("result"), cache_time
    except Exception:
        pass
    return None, None

def background_scan(force=False):
    # 卡死自愈: 上一轮扫描超时(>150s)仍未结束 → 视为已挂起, 允许复位重扫,
    # 避免行情接口偶发无响应把 running 永久锁死、后续定时时点全部被跳过
    if _SCAN_REGISTRY["running"] and _scan_stale():
        _SCAN_REGISTRY["running"] = False
    if _SCAN_REGISTRY["running"]:
        return
    if not force and not scheduler.is_scan_active():
        return
    _SCAN_REGISTRY["running"] = True
    _SCAN_REGISTRY["started_at"] = time.time()
    _SCAN_REGISTRY["error"] = None
    def _run():
        try:
            from recommender import scan_daily_picks
            result = scan_daily_picks(force=True)
            _SCAN_REGISTRY["result"] = result
            _SCAN_REGISTRY["last_time"] = datetime.now()
            _SCAN_REGISTRY["error"] = None
            _SCAN_REGISTRY["saved"] = False
            _save_top10_cache(result)
            try:
                # 补齐上证历史 + 当日板块指数快照(定时与手动扫描都走这里)
                ensure_indices_backfilled()
            except Exception:
                pass
            try:
                # 每日至多一次: 刷新策略回测 json(截至上一交易日), 供"按行情选策略"无泄漏使用
                from strategy_backtest import ensure_backtest_refreshed
                ensure_backtest_refreshed()
            except Exception:
                pass
            # 邮件通知:
            #   有主推 → 信号邮件(任何扫描都发, 含手动重扫; 同(日期,主推代码)已发过则去重不重发); 备用轨已关只发主推
            #   仅最后一次定时扫描(14:00)仍无推荐 → 确认空仓 → 空仓邮件
            if result:
                try:
                    import mailer
                    if result.get("main_pick"):       # 备用轨已关: 邮件只发主推
                        mailer.try_send_signal_email(result)
                    elif not force and scheduler.is_final_scan():
                        mailer.try_send_empty_email(result)
                except Exception:
                    pass
            # 卖出提醒(每日至多一封, 仅在有昨日持仓T+1到期时发; 与信号邮件解耦, 靠日标记去重)
            try:
                import mailer
                mailer.try_send_sell_email()
            except Exception:
                pass
            # 盘中纪律卖出事件预警(更细触发): 连板中断/时间止损 当日首次触发即发, 每标的每日一封
            try:
                import mailer
                for a in compute_sell_alerts():
                    mailer.try_send_sell_event_email(a)
            except Exception:
                pass
        except Exception:
            import traceback; traceback.print_exc()
            _SCAN_REGISTRY["error"] = "扫描出错，请稍后重试"
        finally:
            _SCAN_REGISTRY["running"] = False
    threading.Thread(target=_run, daemon=True).start()


def compute_sell_alerts():
    """盘中纪律卖出预警: 当前持仓中触发 连板中断 / 时间止损 的标的.
    返回 [{'code','name','role','why','price','pnl'}, ...] (与 _today_action_card 的 sell_plan 口径一致).
    非盘中(09:30~15:05)或数据加载失败 → 返回 [] (在导入重逻辑前先判定, 避免非盘中时也拉行情)."""
    now = datetime.now()
    mins = now.hour * 60 + now.minute
    if not (is_trading_day(now) and 570 <= mins < 905):
        return []
    from sim_t5 import (_load_main_backup, _dragon_track, _local_latest_date,
                        _local_hist, _qty, _net, _today_rt_map)
    import dragon_strategy as D
    today8 = now.strftime("%Y%m%d")
    try:
        asof = _local_latest_date()
        mb = (_load_main_backup(asof) or {}).get("主推") or {}
        dr = _dragon_track(asof) or {}
    except Exception:
        return []
    rt = _today_rt_map()
    alerts = []
    for role, tr in (("主推", mb), ("龙头", dr)):
        for o in (tr.get("open_pos") or []):
            code = str(o.get("code") or "")
            try:
                days = int(float(o.get("days", 0) or 0))
            except (TypeError, ValueError):
                days = 0
            why = []
            if days >= D.TIME_STOP:
                why.append(f"持满{days}日·时间止损")
            try:
                h = _local_hist(code, str(o.get("entry") or ""), asof)
                if h is not None and not h.empty and D._streak(h) >= 1:
                    row = (rt or {}).get(code)
                    cp = None
                    if row is not None:
                        try:
                            cp = float(row.get("change_pct") or 0)
                        except (TypeError, ValueError):
                            cp = None
                    if cp is not None and cp < D.LIMIT_PCT:
                        why.append(f"连板中断(今日{cp:+.1f}%)")
            except Exception:
                pass
            if why:
                px = None
                if rt:
                    rrow = rt.get(code)
                    if rrow is not None:
                        try:
                            v = float(rrow.get("price") or 0)
                            if v > 0:
                                px = v
                        except (TypeError, ValueError):
                            px = None
                pnl = None
                if px is not None:
                    try:
                        ep = float(o.get("entry_px") or 0)
                        q = _qty(ep)
                        if ep > 0 and q > 0:
                            pnl = _net(ep, px, q)
                    except Exception:
                        pnl = None
                alerts.append({
                    "code": code, "name": o.get("name", ""),
                    "role": role, "why": " / ".join(why),
                    "price": px, "pnl": pnl,
                })
    return alerts


def _catchup_today_picks():
    """启动兜底: 交易日已过收盘时点(>=market_close)且当天尚无"收盘后"扫描缓存 → 后台自动补扫一次.
    盘中固定slot(9:25/10:00/10:35/14:00)若当天因故全miss(应用未开/回调未注册), 晚打开应用也会
    自动出当日推荐, 保证"当日收盘当天能看当日总结", 不需要等次日或手动点刷新."""
    global _CATCHUP_PICKS_FIRED
    if _CATCHUP_PICKS_FIRED:
        return
    _CATCHUP_PICKS_FIRED = True
    try:
        now = datetime.now()
        try:
            cfg = load_config()
            close_hh, close_mm = map(int, str(cfg.get("market_close", "15:05")).split(":"))
        except Exception:
            close_hh, close_mm = 15, 5
        if not is_trading_day(now) or (now.hour, now.minute) < (close_hh, close_mm):
            return
        today = now.strftime("%Y%m%d")
        # 启动时当天已有任一扫描结果(盘中slot/手动/盘后缓存或已落盘推荐) → 不再补扫
        try:
            if os.path.exists(os.path.join(RECOMMEND_DIR, f"{today}.json")) or \
               os.path.exists(os.path.join(DAILY_PICKS_DIR, f"{today}.json")):
                return
        except Exception:
            pass
        cached, cache_time = _load_top10_cache()
        if cached and cache_time:
            try:
                ct = cache_time
                if not isinstance(ct, datetime):
                    ct = datetime.strptime(str(ct).strip()[:19], "%Y-%m-%d %H:%M:%S")
                # 当天任意时点已扫过(含手动/盘中slot) → 不再重扫
                if ct.strftime("%Y%m%d") == today:
                    return
            except Exception:
                pass
        print("[scan] 当日尚无任何扫描缓存/推荐记录, 启动自动补扫一次", flush=True)
        background_scan(force=True)
    except Exception:
        _CATCHUP_PICKS_FIRED = False


_CATCHUP_PICKS_FIRED = False
_catchup_today_picks()   # 启动/每次重载顶层执行: 收盘后当日无盘后扫描缓存 → 自动补扫(内部判重)


def _scan_stale():
    """扫描是否卡死超过阈值"""
    if not _SCAN_REGISTRY["running"] or _SCAN_REGISTRY["started_at"] is None:
        return False
    return (time.time() - _SCAN_REGISTRY["started_at"]) > _SCAN_TIMEOUT


def _render_recommendation_block():
    """今日推荐: 进入页面时读本地已有数据(取最新一次扫描结果)显示, 不自动触发扫描;
    自动刷新由 _auto_refresh_home 负责(扫描进行中轮询、结束后立即刷新、空闲心跳),
    自动扫描由调度器固定时点(9:25/10:00/10:35/14:00/14:30)触发."""
    today_str = datetime.now().strftime("%Y%m%d")
    result = _SCAN_REGISTRY["result"]
    # 空扫描结果(无主推)不遮蔽本地更优缓存: 例如早盘某次扫描落空, 但 top10 缓存/后续扫描已有主推,
    # 避免页面一直显示"空仓观望"而 daily_picks/top10_cache 实为有票(两份数据不一致).
    if not (result and result.get("main_pick")):
        cached, cache_time = _load_top10_cache()
        if cached and cached.get("main_pick"):
            result = cached
            _SCAN_REGISTRY["result"] = cached
            _SCAN_REGISTRY["last_time"] = cache_time
    result = _SCAN_REGISTRY["result"]

    def _save_today_picks(res):
        main_pick = res.get("main_pick")
        pick_list = [p for p in (res.get("pick_list") or []) if p and p.get("code")]
        if not pick_list and main_pick:               # 备用轨已关: 无主推则空仓观望, 不把备用当候选
            pick_list = [main_pick]
        if not pick_list:
            # 空仓日也落盘记录: 历史明细里明确展示"空仓观望", 该行不计算T+1
            path = os.path.join(RECOMMEND_DIR, f"{today_str}.json")
            if os.path.exists(path):  # 当日已有推荐记录(如早盘曾扫出)不覆盖
                return
            try:
                os.makedirs(RECOMMEND_DIR, exist_ok=True)
                with open(path, "w", encoding="utf-8") as f:
                    json.dump({"date": today_str, "time": datetime.now().strftime("%H:%M:%S"),
                               "picks": [], "hold": "空仓观望"},
                              f, ensure_ascii=False, indent=2, default=str)
            except Exception:
                pass
            return
        picks = []
        for i, p in enumerate(pick_list):
            role = "主推" if i == 0 else ("备用" if i == 1 else f"候选{i+1}")
            price = float(p.get("price", 0) or 0)
            buy_amount = 6000 if role == "主推" else 0  # 主推50%仓位, 备用/候选仅提示
            buy_qty = max(0, int(buy_amount / price / 100) * 100) if price > 0 else 0
            picks.append({
                "code": p.get("code"), "name": p.get("name"),
                "price": round(price, 2), "role": role,
                "sector": p.get("sector", ""),
                "sector_key": p.get("sector_key", ""),
                "continuation": p.get("continuation", False),
                "expected_return": p.get("expected_return", 0),
                "win_rate": p.get("win_rate", 0),
                "quality_score": p.get("quality_score", 0),
                "signal_count": p.get("signal_count", 0),
                "strategies": p.get("strategies", [])[:5],
                "buy_qty": buy_qty, "buy_amount": round(buy_qty * price, 2),
            })
        try:
            os.makedirs(RECOMMEND_DIR, exist_ok=True)
            with open(os.path.join(RECOMMEND_DIR, f"{today_str}.json"), "w", encoding="utf-8") as f:
                json.dump({"date": today_str, "time": datetime.now().strftime("%H:%M:%S"), "picks": picks},
                          f, ensure_ascii=False, indent=2, default=str)
        except Exception:
            pass

    # 按当前展示结果落盘, 保证 data/recommendations 文件与页面一致;
    # 空结果时 _save_today_picks 内部会保留已有真实推荐、不覆盖
    if result:
        _save_today_picks(result)

    # ── 显示今日推荐（行情档位 + 热门板块 + 主推 + 明确操作）──
    if result:
        regime = result.get("regime") or {}
        level = regime.get("level", "normal")
        regime_cls = "pos" if level == "strong" else ("neg" if level in ("weak", "crash") else "")
        sector_tags = "".join(
            f'<span style="background:rgba(0,212,255,0.1);border:1px solid rgba(0,212,255,0.3);'
            f'color:#00d4ff;border-radius:12px;padding:2px 10px;font-size:0.78rem;margin:2px 4px 2px 0;'
            f'white-space:nowrap;">{s.get("name","")} {s.get("strength",0):+.2f}%</span>'
            for s in result.get("sectors", [])[:6])

        role_cap, role_n = _role_sim_persisted()
        # 顶部卡片累计盈利改 T5 纪律口径(断板止盈+时间止损, 继续持仓/换股), 与下方三策略总览一致;
        # 备用轨已关闭 → 只取主推
        try:
            from sim_t5 import _load_main_backup, _local_latest_date
            _t5 = _load_main_backup(_local_latest_date())
            _t5cap = {}
            for _rk in ("主推",):
                _rv = _t5.get(_rk) or {}
                _t5cap[_rk] = (float(_rv.get("total", 0) or 0), int(_rv.get("n_closed", 0) or 0))
            if _t5cap:
                role_cap = {k: _t5cap[k][0] for k in _t5cap}
                role_n = {k: _t5cap[k][1] for k in _t5cap}
        except Exception:
            pass

        # 推荐信号日 → 买入日(下一交易日), 供卡片直接展示具体日期(不用"明日"相对词)
        _buy_d = ""
        try:
            _sd = str(result.get("date") or result.get("signal_date") or "")
            if len(_sd) == 8 and _sd.isdigit():
                _buy_d = _next_trading_day(datetime.strptime(_sd, "%Y%m%d") + timedelta(days=1)).strftime("%Y-%m-%d")
        except Exception:
            _buy_d = ""

        def _pick_card(role, p, level):
            price = float(p.get("price", 0) or 0)
            exp_ret = float(p.get("expected_return", 0) or 0)
            win_rate = float(p.get("win_rate", 0) or 0)
            buy_amount = 6000 if role == "主推" else 0
            buy_qty = max(0, int(buy_amount / price / 100) * 100) if price > 0 else 0
            strat = "、".join(p.get("strategies", [])[:3]) or "-"
            sector = p.get("sector", "") or ""
            pos_cls = "pos" if exp_ret >= 0 else "neg"
            wr_cls = "pos" if win_rate >= 50 else "neg"
            comp_pnl = role_cap.get(role, 0.0)  # 累计盈利(每笔独立¥6,000本金简单累加)
            sim_n = role_n.get(role, 0)
            sim_cls = "pos" if comp_pnl >= 0 else "neg"
            sim_html = (f'<span>累计盈利: <b class="{sim_cls}">¥{comp_pnl:+,.0f}</b>'
                        f'<span style="color:#495670;font-size:0.72rem;">({sim_n}笔)</span></span>'
                        if sim_n else '<span style="color:#495670;">累计盈利: 待更新</span>')
            if any(k in strat for k in ("低吸", "回踩", "反弹", "逆势")):
                action = "低吸"
            elif any(k in strat for k in ("打板", "首板", "强更强", "2B", "分歧", "龙头")):
                action = "强势买入"
            else:
                action = "买入"
            buy_txt = f"✅ {action}·{_buy_d} 开盘买入" if _buy_d else f"✅ {action}·开盘买入"
            qty_html = (f'<span style="color:#64ffda;">{buy_txt}: 50%仓位 <b>{buy_qty}股</b> (¥{buy_qty*price:,.0f})</span>'
                        if buy_qty > 0 else f'<span style="color:#8892b0;">{"候选（分散观察，不强制）" if str(role).startswith("候选") else "不强制仓位"}</span>')
            border = 'border:2px solid rgba(123,47,247,0.4);' if role == "主推" else 'border:1px solid #1a1d2e;'
            cont_tag = ' <span style="color:#ffd600;font-size:0.72rem;margin-left:8px;">🔄 延续</span>' if p.get("continuation") else ""
            return textwrap.dedent(f"""\
            <div class="card" style="padding:0.9rem 1rem;margin-bottom:4px;{border}">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:4px;">
                    <span>
                        <span style="font-weight:700;color:#ffd600;font-size:1.05rem;">{p.get("name","")} ({p.get("code","")})</span>
                        <span style="color:#8892b0;font-size:0.75rem;margin-left:8px;">[{sector}]</span>
                        <span style="color:#00d4ff;font-size:0.75rem;margin-left:8px;">{role}</span>{cont_tag}
                    </span>
                </div>
                <div style="display:flex;gap:18px;margin-top:6px;font-size:0.85rem;flex-wrap:wrap;">
                    <span>现价: <b>{price:.2f}</b></span>
                    <span>预期T+1: <b class="{pos_cls}">{exp_ret:+.2f}%</b></span>
                    {sim_html}
                    <span>历史胜率: <b class="{wr_cls}">{win_rate:.1f}%</b></span>
                    {qty_html}
                </div>
                <div style="margin-top:4px;font-size:0.72rem;color:#495670;">信号: {strat} · 持仓后: 连板未断继续持有, 断板/持满5日收盘卖出换股</div>
            </div>""").strip()

        main_html = _pick_card("主推", result["main_pick"], level) if result.get("main_pick") else ""
        cand_html = ""      # 备用轨已关闭: 不再渲染备用卡片
        for i, p in enumerate((result.get("pick_list") or [])[2:], start=3):
            cand_html += _pick_card(f"候选{i}", p, level) or ""

        st.markdown(
            f'<div style="display:flex;justify-content:space-between;align-items:center;margin:4px 0 2px 0;flex-wrap:wrap;">'
            f'<span class="{regime_cls}" style="font-weight:600;">📊 行情判断: {regime.get("desc","未知")}</span>'
            f'<span style="color:#8892b0;font-size:0.72rem;">扫描于 {result.get("scanned_at","")}</span></div>',
            unsafe_allow_html=True)
        if sector_tags:
            st.markdown(f'<div style="margin:2px 0 8px 0;">🔥 热门板块: {sector_tags}</div>', unsafe_allow_html=True)
        # 主推 累计盈利 汇总条(每笔独立¥6,000本金); 备用轨已关闭
        if role_n.get("主推"):
            mp = role_cap.get("主推", 0.0)
            mc = "pos" if mp >= 0 else "neg"
            mn = role_n.get("主推", 0)
            st.markdown(
                f'<div style="background:#0d1117;border:1px solid #1a1d2e;border-radius:8px;'
                f'padding:8px 12px;margin:6px 0 8px 0;display:flex;justify-content:space-between;'
                f'align-items:center;flex-wrap:wrap;gap:6px;">'
                f'<span style="color:#ffd600;font-weight:600;">💵 累计盈利（主推轨）</span>'
                f'<span style="color:#495670;font-size:0.75rem;">每笔独立¥6,000本金 · 断板止盈+时间止损5日 · 含费</span>'
                f'<span>主推: <b class="{mc}">¥{mp:+,.0f}</b>'
                f'<span style="color:#495670;font-size:0.72rem;">({mn}笔)</span></span>'
                f'</div>', unsafe_allow_html=True)
        if main_html:
            st.markdown(main_html, unsafe_allow_html=True)
        if cand_html:
            st.markdown(cand_html, unsafe_allow_html=True)
        if main_html or cand_html:
            st.markdown('<div style="color:#495670;font-size:0.72rem;margin-bottom:8px;">'
                        '※ 累计盈利 = 主推以¥6,000独立本金模拟（每笔独立，不滚入；备用轨已于2026-09-01关闭，不再推荐/模拟）：断板止盈+时间止损5日纪律重放（连板未断继续持仓，断板或持满5日才卖出换股；整手，含佣金万2.5/印花税0.05%/过户费万0.1），与下方📊三策略模拟总览同口径。买入=明日开盘；持有=连板未断/未破5日线继续；卖出=断板或时间止损收盘卖</div>',
                        unsafe_allow_html=True)

        # 无明确标的 → 给出明确"空仓"操作, 避免只报行情不报标的
        if not result.get("main_pick"):
            if level == "crash":
                st.warning("⚠️ 空仓观望：指数深度破位，今日不推荐任何标的，管住手。")
            elif level == "weak":
                st.warning("⚠️ 弱势行情：今日未筛出符合回测高胜率标准的强势股标的。硬做低吸历史胜率仅40%出头，宁缺毋滥，建议空仓等待。")
            else:
                st.info("ℹ️ 今日暂未筛出符合标准的标的，可稍后重新扫描。")

        lt = _SCAN_REGISTRY["last_time"]
        if lt:
            st.markdown(f'<div style="color:#8892b0;font-size:0.7rem;margin-bottom:8px;">最近扫描: {lt.strftime("%H:%M:%S")} | 行情档位: {level}</div>', unsafe_allow_html=True)
    elif _scan_stale():
        st.warning(f"⚠️ 扫描超时（超过{_SCAN_TIMEOUT}秒），请点击上方重新扫描")
    elif _SCAN_REGISTRY["running"]:
        st.info("⏳ 正在扫描分析中，请稍候...")
    else:
        st.info("💡 暂无推荐，点击上方重新扫描按钮开始")
    return result


def metric_card(label, value, cls=""):
    return f'<div class="metric-card"><div class="metric-label">{label}</div><div class="metric-value {cls}">{value}</div></div>'

# ─────────────────────── 模拟交易: T日收盘买 → T+1收盘卖 ───────────────────────
SIM_DAILY = 5000.0      # 每日模拟持仓预算(尽量接近¥5000)
COMP_INIT = 5000.0      # 每笔独立模拟本金(¥5,000, 不滚入)
SIM_COMM = 0.00025      # 佣金 万2.5 (最低¥5, 双边)
SIM_STAMP = 0.0005      # 印花税 0.05% (卖出)
SIM_XFER = 0.00001      # 过户费 万0.1 (双边)

def _sim_trade(buy_price, sell_price, budget):
    """模拟 T日收盘买→T+1收盘卖(整手, 含费). 返回 (pnl, qty) 或 None(数据缺失/买不起一手)."""
    try:
        buy_price = float(buy_price); sell_price = float(sell_price); budget = float(budget)
    except (TypeError, ValueError):
        return None
    if buy_price <= 0 or sell_price <= 0 or budget <= 0:
        return None
    qty = int(budget / buy_price / 100) * 100
    if qty <= 0:
        return None
    cost = qty * buy_price
    proceeds = qty * sell_price
    buy_fee = max(5.0, cost * SIM_COMM)
    sell_fee = max(5.0, proceeds * SIM_COMM) + proceeds * SIM_STAMP + proceeds * SIM_XFER
    return (proceeds - cost) - (buy_fee + sell_fee), qty

# T+1 卖点: 收盘优先(2026-08-29复核: 生产picks历史31笔, 收盘卖均值-0.20%/胜率55% 优于 10:30卖-0.40%/52%,
# 10:30仅在13/31次更高 → 撤下"10:30为最佳卖点"); 10:30价仍记录仅供展示参考.
SELL_HM = "10:30"          # 盘中价提取时点(仅展示)
SELL_LIVE_AT = "15:00"     # T+1当天可定稿卖点的时刻(收盘后)

def _pick_sell_price(pick):
    """卖出价: 优先 T+1 收盘前复权价(卖点复核胜出), 缺则回退 10:30 盘中价."""
    p = pick.get("sell_price")
    if isinstance(p, (int, float)):
        return p
    return pick.get("t1_1030_price")

def _pick_sell_return(pick):
    """卖出收益率: 优先 T+1 收盘, 缺则回退 10:30."""
    r = pick.get("t1_return")
    if isinstance(r, (int, float)):
        return r
    return pick.get("t1_1030_return")

def _apply_t1_grid(pick, grid, qfq_buy, qfq_sell):
    """把某T+1日的基准卖点 10:30 盘中价(不复权)转成前复权价/收益率写入 pick.
    qfq_buy/qfq_sell 为该pick的买入价/T+1收盘前复权价; grid={"prices":{"10:30":raw},"close":raw收盘}."""
    close = grid.get("close") or 0
    raw = (grid.get("prices") or {}).get(SELL_HM)
    if close <= 0 or raw is None:
        return
    try:
        qfq_p = float(raw) * (qfq_sell / close)
    except (TypeError, ValueError, ZeroDivisionError):
        return
    pick["t1_1030_price"] = round(qfq_p, 2)
    if qfq_buy > 0:
        pick["t1_1030_return"] = round((qfq_p / qfq_buy - 1) * 100, 2)

def _load_records_chrono(days=30):
    """按时间正序(旧→新)加载推荐记录文件."""
    records = []
    if not os.path.isdir(RECOMMEND_DIR):
        return records
    files = sorted(os.listdir(RECOMMEND_DIR))
    for fname in files[-days:]:
        if not fname.endswith(".json"):
            continue
        try:
            with open(os.path.join(RECOMMEND_DIR, fname), encoding="utf-8") as f:
                records.append(json.load(f))
        except Exception:
            continue
    return records

def _cumulative_tracks(records):
    """【兜底/旧口径】主推/备用两条独立策略的累计盈利(每笔独立¥5,000·T+1机械卖).
    2026-09-02 起首页顶部累计已改走 sim_t5 T5纪律口径(¥6,000/笔·生命周期合并),
    本函数仅在 sim_t5 加载异常时作兜底; 展示口径如有出入请以 sim_t5 为准.

    返回 (cum_profit, count, per_pick); per_pick[(date, code)] =
    (cum_before, cum_after, pnl, qty). 只消费已算出的实际T+1(收盘收益或10:30卖点收益), 未算出的跳过(计0).
    records 需按时间正序; 旧格式(无role)的单只推荐按主推计.
    """
    cum = {"主推": 0.0, "备用": 0.0}
    count = {"主推": 0, "备用": 0}
    per_pick = {}
    for rec in records:
        for pick in rec.get("picks", []):
            role = pick.get("role") or "主推"
            if role not in cum:
                continue
            if pick.get("t1_buyable") is False:
                continue  # 一字板开盘买不进, 真实收益仅作对照, 不计入累计(2026-09-01)
            if not (isinstance(pick.get("t1_return"), (int, float))
                    or isinstance(pick.get("t1_1030_return"), (int, float))):
                continue  # T+1 未完成(收盘或10:30卖点均未算出)不统计
            key = (rec.get("date", ""), pick.get("code", ""))
            sim = _sim_trade(pick.get("qfq_buy_price") or pick.get("price"),
                             _pick_sell_price(pick), COMP_INIT)
            if sim is None:
                per_pick[key] = (cum[role], cum[role], 0.0, 0)
                continue
            pnl, qty = sim
            c0 = cum[role]
            cum[role] += pnl
            count[role] += 1
            per_pick[key] = (c0, cum[role], pnl, qty)
    return cum, count, per_pick

def _role_sim_persisted(days=30):
    """【兜底】首页顶部累计盈利(T5口径异常时的旧口径后备, 见 _cumulative_tracks 说明).

    返回 (cum_profit, count): cum_profit[role] = 该策略各笔盈亏简单累加(每笔独立¥5,000本金·T+1).
    旧格式(无role字段)的单只推荐按主推计.
    """
    cum, cnt, _ = _cumulative_tracks(_load_records_chrono(days))
    return cum, cnt

# ─────────────────────── 页面函数 ───────────────────────

def render_sidebar():
    with st.sidebar:
        st.markdown('<div style="text-align:center;padding:1rem 0;"><span style="font-size:1.8rem;font-weight:700;background:linear-gradient(135deg,#00d4ff,#7b2ff7);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">QuantTrader</span><br><span style="color:#8892b0;font-size:0.75rem;">量化交易系统 v2.0</span></div>', unsafe_allow_html=True)
        # 仅保留首页：不渲染页面导航, 刷新后始终回到首页
        st.session_state.page = "首页"
        # ⏰ 定时状态指示
        try:
            sched_cfg = load_config()
            sched_status = scheduler.get_status()
            if sched_cfg.get("enabled", True):
                today = datetime.now()
                is_holiday = not is_trading_day(today)
                if is_holiday:
                    state_icon, state_text, state_color = "🟡", "非交易日", "#ffd600"
                elif sched_status.get("state") == "running" or is_trading_time(sched_cfg):
                    state_icon, state_text, state_color = "🟢", f"交易时段 · {sched_cfg.get('market_close','15:05')}收盘", "#00c853"
                else:
                    next_in = sched_status.get("next_event_in", 0)
                    if next_in > 3600:
                        next_str = f"{next_in//3600}小时{next_in%3600//60}分"
                    else:
                        next_str = f"{next_in//60}分钟"
                    state_icon, state_text, state_color = "🔴", f"等待开盘 ({next_str})", "#ff1744"
            else:
                state_icon, state_text, state_color = "🔵", "定时未启用 (持续运行)", "#00d4ff"
            st.markdown(f'<div style="font-size:0.75rem;padding:6px 10px;border-radius:6px;border:1px solid #2a2d3e;margin-bottom:8px;"><span style="color:{state_color};">{state_icon}</span> <span style="color:#8892b0;">{state_text}</span></div>', unsafe_allow_html=True)
        except Exception:
            pass

        # 🔥 板块热点 TOP5 (新浪行业强度, 东财get_sector_summary当前不可达)
        try:
            st.markdown('<div style="font-size:0.8rem;font-weight:600;color:#ccd6f6;margin:8px 0 4px 0;padding:0 8px;">🔥 板块热点 TOP5</div>', unsafe_allow_html=True)
            sectors = StockAPI.get_industry_sectors()
            if sectors is not None and not sectors.empty:
                top5 = sectors.sort_values("avg_change_pct", ascending=False).head(5)
                for _, row in top5.iterrows():
                    chg = float(row["avg_change_pct"])
                    cls = "pos" if chg > 0 else "neg"
                    arrow = "▲" if chg > 0 else "▼"
                    st.markdown(f'<div style="display:flex;justify-content:space-between;padding:3px 10px;font-size:0.75rem;border-bottom:1px solid #1a1d2e;"><span style="color:#ccd6f6;">{row["name"]}</span><span class="{cls}">{arrow} {chg:+.2f}%</span></div>', unsafe_allow_html=True)
            else:
                st.markdown('<div style="font-size:0.75rem;color:#4a5568;padding:3px 10px;">板块数据暂不可用</div>', unsafe_allow_html=True)
        except Exception:
            pass

        # 📈 ETF 推荐
        try:
            st.markdown('<div style="font-size:0.8rem;font-weight:600;color:#ccd6f6;margin:8px 0 4px 0;padding:0 8px;">📈 ETF 推荐</div>', unsafe_allow_html=True)
            etf_items = [
                ("上证50ETF", "510050"), ("沪深300ETF", "510300"),
                ("中证500ETF", "510500"), ("创业板ETF", "159915"),
                ("证券ETF", "512880"), ("黄金ETF", "518880"),
            ]
            for name, code in etf_items:
                # 基于名称hash生成日内稳定的模拟涨跌幅
                h = (hash(name) + int(datetime.now().strftime("%Y%m%d%H"))) % 200
                cp = round((h - 100) / 12, 2)
                cls = "pos" if cp > 0 else "neg"
                arrow = "▲" if cp > 0 else "▼"
                st.markdown(f'<div style="display:flex;justify-content:space-between;padding:2px 10px;font-size:0.7rem;"><span style="color:#8892b0;">{name}</span><span class="{cls}">{arrow} {cp:+.2f}%</span></div>', unsafe_allow_html=True)
        except Exception:
            pass

        try:
            df = StockAPI.get_realtime_quotes()
            if not df.empty:
                up = len(df[df["change_pct"] > 0])
                down = len(df[df["change_pct"] < 0])
                st.markdown(f'<div style="font-size:0.75rem;color:#8892b0;line-height:1.8;margin-top:6px;padding:0 8px;">股票总数: <b style="color:#ccd6f6;">{len(df)}</b><br>上涨: <b style="color:#00c853;">{up}</b> | 下跌: <b style="color:#ff1744;">{down}</b></div>', unsafe_allow_html=True)
        except: st.caption("等待数据...")
        st.markdown(f'<div style="font-size:0.7rem;color:#4a5568;padding:0 8px;">{"🟢" if API_AVAILABLE else "🟡"} {DATA_SOURCE}</div>', unsafe_allow_html=True)

def _render_sh_card(row, sh_sig, sector, g):
    """上证指数卡片(合并决策辅助): 点位/涨跌用实时行情, MA20/板块/综合 三条辅助信号合并为一行信号条.
    悬停信号条可看完整说明; 全部只读本地持久化 + 已有行情, 不新增网络请求; 补齐由 重新扫描→ensure_indices_backfilled 完成."""
    cp = row.get("change_pct", 0)
    cls = "pos" if cp > 0 else "neg" if cp < 0 else ""
    icon = "▲" if cp > 0 else "▼" if cp < 0 else "—"

    def _sig_chip(label, value, vcls, tip=""):
        """一条信号小徽章: 色点 + 标签 + 色值; 悬停 title 展示完整说明."""
        color = "#ff1744" if vcls == "pos" else "#00c853" if vcls == "neg" else "#8892b0"
        tip_attr = f' title="{tip}"' if tip else ""
        return (f'<span{tip_attr} style="display:inline-flex;align-items:center;gap:4px;'
                f'background:#101322;border:1px solid #222538;border-radius:5px;padding:2px 8px;'
                f'font-size:0.66rem;color:#8892b0;">'
                f'<span style="width:6px;height:6px;border-radius:50%;background:{color};flex:none;"></span>'
                f'<span>{label}</span><b class="{vcls}">{value}</b></span>')

    html = [f'<div class="metric-card">',
            f'<div class="metric-label">上证指数</div>',
            f'<div class="metric-value small">{row["price"]}</div>',
            f'<div class="{cls}" style="font-size:0.85rem;">{icon} {cp:.2f}%</div>']
    if sh_sig:
        above = sh_sig.get("above_ma20")
        ma_cls = "pos" if above else "neg"
        ma_txt = "站上" if above else "跌破"
        ma_chip = _sig_chip("MA20", ma_txt, ma_cls, g.get("sh", ""))
        if sector:
            d = sector.get("direction")
            sc = "pos" if d == "up" else "neg" if d == "down" else ""
            arrow = "↑" if d == "up" else "↓" if d == "down" else "—"
            sec_val = f'{arrow}{sector.get("chg_pct"):+.2f}%'
            if sector.get("stale"):
                sec_val += " <span style='color:#4a5568;font-weight:400;'>(旧)</span>"
            sec_chip = _sig_chip("板块", sec_val, sc, g.get("sector", ""))
        else:
            sec_chip = _sig_chip("板块", "未生成", "", g.get("sector", ""))
        comb_short = {"pos": "共振", "neg": "谨慎"}.get(g.get("comb_cls", ""), "中性")
        comb_chip = _sig_chip("综合", comb_short, g.get("comb_cls", ""), g.get("comb", ""))
        signal_row = (f'<div style="border-top:1px solid #1a1d2e;margin:6px 0 0 0;padding-top:6px;'
                      f'display:flex;justify-content:center;gap:5px;flex-wrap:wrap;">'
                      f'{ma_chip}{sec_chip}{comb_chip}</div>')
        html.append(signal_row)
    html.append('</div>')
    st.markdown("".join(html), unsafe_allow_html=True)


def _render_index_row(indices):
    """大盘指数卡片行: 上证指数卡片内合并决策辅助(MA20/板块指数/综合建议), 其余指数照旧.
    上证实时点位/涨跌用 get_major_indices, MA20/板块用本地持久化, 不重复请求."""
    sh = load_sh_history()
    sh_sig = sh[max(sh)] if sh else None
    sector = load_sector_index_latest()
    g = build_guidance(sh_sig, sector) if sh_sig else None

    rows = indices.to_dict("records")
    cols = st.columns([2] + [1] * (len(rows) - 1))
    for i, row in enumerate(rows):
        with cols[i]:
            if row.get("name") == "上证指数":
                _render_sh_card(row, sh_sig, sector, g)
            else:
                cp = row.get("change_pct", 0)
                cls = "pos" if cp > 0 else "neg" if cp < 0 else ""
                icon = "▲" if cp > 0 else "▼" if cp < 0 else "—"
                st.markdown(f'<div class="metric-card"><div class="metric-label">{row["name"]}</div>'
                            f'<div class="metric-value small">{row["price"]}</div>'
                            f'<div class="{cls}" style="font-size:0.85rem;">{icon} {cp:.2f}%</div></div>',
                            unsafe_allow_html=True)
    if sh_sig:
        latest_date = max(sh)
        notes = []
        if sector:
            if sector.get("stale"):
                sec_d = str(sector.get("date") or "")
                if sec_d:
                    notes.append(f"板块快照 {sec_d[:4]}-{sec_d[4:6]}-{sec_d[6:]}未更新，为最近一次生成")
            if sector.get("equal_weight_fallback"):
                notes.append("部分股票总股本缺失等权兜底")
        cap = f"决策辅助(截至 {latest_date[:4]}-{latest_date[4:6]}-{latest_date[6:]}) · 回测结论: 上证涨/站上MA20可提升T+1胜率"
        if notes:
            cap += "；" + "；".join(notes)
        st.caption(cap)
    else:
        st.caption("ℹ️ 决策辅助未就绪，将在扫描时自动补齐。")


def _today_action_card():
    """今日行动卡(2026-09-08): 以「今天」为主语 — 今日卖出 / 持仓中 / 今日进场(+今日扫描候选参考行).

    口径约定(与账本一致, 无需手工切换, 随时点自动):
    - 持仓价: 交易日盘中(09:30~15:05)取实时价并标注「实时(未收盘)」; 收盘后/非交易日自动用重放的
      收盘价, 与账本完全对齐.
    - 今日卖出: 收盘后=重放中当日已结算的卖出; 盘中=按 T5 纪律预判(时间止损到期 / 连板中断),
      标「待收盘确认」, 以当日收盘价结算.
    - 今日进场: 上一交易日推荐 → 今日开盘买入(账本口径, 盘中已撮合或待开盘).
    - 今日扫描候选: 仅作参考行, 不进账本(T+1 纪律: 今日信号对应明日进场); 当日无合适标的时
      供人工替换参考.
    """
    from sim_t5 import (_load_main_backup, _dragon_track, _local_latest_date,
                        _local_hist, _qty, _net, _today_rt_map)
    import dragon_strategy as D

    def _d8(s):
        s = str(s or "")
        return f"{s[:4]}-{s[4:6]}-{s[6:8]}" if len(s) == 8 and s.isdigit() else s

    now = datetime.now()
    today8 = now.strftime("%Y%m%d")
    try:
        asof = _local_latest_date()
        mb = (_load_main_backup(asof) or {}).get("主推") or {}
        dr = _dragon_track(asof) or {}
    except Exception:
        st.caption("⚠️ 今日行动暂不可用(行情/重放加载失败)")
        return

    mins = now.hour * 60 + now.minute
    is_td = is_trading_day(now)
    intraday = is_td and 570 <= mins < 905          # 09:30 ~ 15:05 盘中
    if intraday:
        tag = "盘中 · 实时价(未收盘)"
    elif is_td and mins >= 905:
        tag = "已收盘 · 收盘价口径"
    else:
        tag = "非交易时段 · 最近收盘口径"

    # ── 持仓(重放口径) ──
    hold = []
    for role, tr in (("主推", mb), ("龙头", dr)):
        for o in (tr.get("open_pos") or []):
            hh = dict(o)
            hh["_role"] = role
            hold.append(hh)

    # 盘中用实时价重算浮动(同费用口径 _net), 非盘中保留重放收盘价(与账本一致)
    rt = _today_rt_map() if intraday else None
    for o in hold:
        px = None
        if rt:
            row = rt.get(str(o.get("code") or ""))
            if row is not None:
                try:
                    v = float(row.get("price") or 0)
                    if v > 0:
                        px = v
                except (TypeError, ValueError):
                    px = None
        o["_live"] = px is not None
        if px is not None:
            try:
                ep = float(o.get("entry_px") or 0)
                q = _qty(ep)
                if ep > 0 and q > 0:
                    o["mark"] = px
                    o["pnl"] = _net(ep, px, q)
            except Exception:
                pass

    # ── 今日已结算的买卖(重放中日期=今天的行; 库已补到今天/收盘后才有) ──
    sells_done, buys_done = [], []
    for role, tr in (("主推", mb), ("龙头", dr)):
        for r in (tr.get("detail") or []):
            if str(r.get("日期", "")) != _d8(today8):
                continue
            rr = dict(r)
            rr["_role"] = role
            stt = str(r.get("状态", ""))
            yf = str(r.get("收益", ""))
            if "·" in stt and stt.endswith("日") and yf.startswith("¥"):
                sells_done.append(rr)
            elif stt == "开盘买入":
                buys_done.append(rr)

    # ── 盘中: 今日待卖出(纪律预判, 收盘确认) ──
    sell_plan = []
    if intraday:
        for o in hold:
            code = str(o.get("code") or "")
            try:
                days = int(float(o.get("days", 0) or 0))
            except (TypeError, ValueError):
                days = 0
            why = []
            if days >= D.TIME_STOP:
                why.append(f"持满{days}日·时间止损")
            try:
                h = _local_hist(code, str(o.get("entry") or ""), asof)
                if h is not None and not h.empty and D._streak(h) >= 1:
                    row = (rt or {}).get(code)
                    cp = None
                    if row is not None:
                        try:
                            cp = float(row.get("change_pct") or 0)
                        except (TypeError, ValueError):
                            cp = None
                    if cp is not None and cp < D.LIMIT_PCT:
                        why.append(f"连板中断(今日{cp:+.1f}%)")
            except Exception:
                pass
            if why:
                o2 = dict(o)
                o2["_why"] = " / ".join(why)
                sell_plan.append(o2)
    sell_codes = {str(o.get("code")) for o in sell_plan}
    for o in hold:
        if str(o.get("code")) in sell_codes:
            o["_sell_today"] = True

    # ── 今日进场(账本口径): 入场日=今天 ──
    entered = [o for o in hold if str(o.get("entry") or "") == today8]
    entered_codes = {str(o.get("code")) for o in entered}
    pend_buy = []
    for role, tr in (("主推", mb), ("龙头", dr)):
        for r in (tr.get("detail") or []):
            if str(r.get("状态", "")) in ("待买入", "买入信号") and \
               _d8(today8) in str(r.get("操作", "")):
                rr = dict(r)
                rr["_role"] = role
                if str(_code_of(rr.get("股票", ""))) not in entered_codes:
                    pend_buy.append(rr)

    # ── 今日候选(参考行, 不进账本): 主推扫描 → 扫描缓存 → 辩论/每日picks 落盘 ──
    cands = []          # [(item, 来源标签)]
    try:
        p = os.path.join(RECOMMEND_DIR, f"{today8}.json")
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                d = json.load(f)
            for x in (d.get("picks") or []):
                if x and x.get("code"):
                    cands.append((x, "主推扫描·T+1明日进场"))
    except Exception:
        pass
    if not cands:
        try:
            cached, _ct = _load_top10_cache()
            if cached and str(cached.get("date") or today8) == today8:
                pl = [x for x in (cached.get("pick_list") or []) if x and x.get("code")]
                if not pl and cached.get("main_pick"):
                    pl = [cached["main_pick"]]
                for x in pl:
                    cands.append((x, "主推扫描·T+1明日进场"))
        except Exception:
            pass
    try:
        p2 = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "debate_picks",
                          f"{today8}.json")
        if os.path.exists(p2):
            with open(p2, encoding="utf-8") as f:
                d2 = json.load(f)
            pl2 = [x for x in ((d2.get("consensus_buys") or []) + (d2.get("split_verdicts") or []))
                   if x and x.get("code")]
            codes_have = {str(c.get("code")) for c, _s in cands}
            for x in pl2:
                if str(x.get("code")) not in codes_have:
                    cands.append((x, "辩论共识·当日收盘买→次日收盘卖"))
    except Exception:
        pass
    have = {str(o.get("code")) for o in hold} | entered_codes
    cands = [(c, s) for c, s in cands if str(c.get("code")) not in have]

    # ── 渲染 ──
    h = ['<div style="background:#0d1117;border:1px solid #2a2d3e;border-radius:8px;padding:10px 14px;margin:6px 0 8px 0;">']
    h.append(f'<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:4px;">'
             f'<span style="color:#ffd600;font-weight:700;">{_d8(today8)} · 今日行动</span>'
             f'<span style="color:#495670;font-size:0.7rem;">{tag} · 主推+龙头</span></div>')
    if asof != today8:
        h.append(f'<div style="color:#ff9800;font-size:0.72rem;margin:2px 0 0 0;">'
                 f'行情库数据截止 {_d8(asof)}(今日bar未入库) · 持仓/卖出按该日收盘口径 + 今日实时价展示</div>')

    def _fmt_px(v):
        try:
            return f"{float(v):.2f}"
        except (TypeError, ValueError):
            return str(v or "—")

    if sells_done or sell_plan:
        h.append('<div style="color:#ff9800;font-weight:600;margin:6px 0 1px 0;">📕 今日卖出</div>')
        for r in sells_done:
            yf = str(r.get("收益", ""))
            cls = "pos" if yf.startswith("¥+") else "neg"
            h.append(f'<div style="margin:1px 0 1px 8px;font-size:0.85rem;">'
                     f'<span style="color:#ff9800;">{r["_role"]}</span> 收盘卖出 <b>{r.get("股票","—")}</b> '
                     f'<span style="color:#495670;">{r.get("状态","")}</span> · <b class="{cls}">{yf}</b></div>')
        for o in sell_plan:
            try:
                pnl = float(o.get("pnl", 0) or 0)
            except (TypeError, ValueError):
                pnl = 0.0
            cls = "pos" if pnl >= 0 else "neg"
            h.append(f'<div style="margin:1px 0 1px 8px;font-size:0.85rem;">'
                     f'<span style="color:#ff9800;">{o["_role"]}</span> <b>{o.get("name","")}</b>({o.get("code","")}) '
                     f'· {o.get("_why","")} · <span style="color:#495670;">待收盘确认(按收盘价结算)</span> · '
                     f'现价 {_fmt_px(o.get("mark"))} · 浮动 <b class="{cls}">¥{pnl:+,.0f}</b></div>')
    if hold:
        h.append('<div style="color:#ffd600;font-weight:600;margin:8px 0 1px 0;">📌 持仓中</div>')
        for o in hold:
            try:
                pnl = float(o.get("pnl", 0) or 0)
            except (TypeError, ValueError):
                pnl = 0.0
            cls = "pos" if pnl >= 0 else "neg"
            try:
                d = int(float(o.get("days", 0)))
            except (TypeError, ValueError):
                d = "?"
            src = '<span style="color:#00d4ff;font-size:0.72rem;">实时(未收盘)</span>' if o.get("_live") \
                else f'<span style="color:#495670;font-size:0.72rem;">{_d8(asof)}收盘</span>'
            tail = ' <span style="color:#ff9800;font-size:0.75rem;">→ 今日卖出</span>' if o.get("_sell_today") else ""
            h.append(f'<div style="margin:1px 0 0 8px;font-size:0.85rem;">'
                     f'<span style="color:#ffd600;">{o["_role"]}</span> <b>{o.get("name","")}</b>({o.get("code","")}) '
                     f'· {_d8(o.get("entry",""))}入场 · 持{d}日 · 现价 {_fmt_px(o.get("mark"))} {src} · '
                     f'浮动 <b class="{cls}">¥{pnl:+,.0f}</b>{tail}</div>')
            rs = str(o.get("reason", "") or "")
            if rs:
                rs = rs if len(rs) <= 44 else rs[:44] + "…"
                h.append(f'<div style="margin:0 0 2px 8px;font-size:0.75rem;color:#495670;">└ {rs}</div>')
    h.append('<div style="color:#00d4ff;font-weight:600;margin:8px 0 1px 0;">📗 今日进场(开盘价成交·账本口径)</div>')
    if entered:
        for o in entered:
            h.append(f'<div style="margin:1px 0 1px 8px;font-size:0.85rem;">'
                     f'<span style="color:#00d4ff;">{o["_role"]}</span> 今日开盘买入 <b>{o.get("name","")}</b>'
                     f'({o.get("code","")}) @ {_fmt_px(o.get("entry_px"))} · 现价 {_fmt_px(o.get("mark"))}</div>')
    if pend_buy:
        for r in pend_buy:
            h.append(f'<div style="margin:1px 0 1px 8px;font-size:0.85rem;">'
                     f'<span style="color:#00d4ff;">{r["_role"]}</span> {r.get("股票","—")} '
                     f'<span style="color:#495670;">{r.get("操作","")}</span></div>')
    if not (entered or pend_buy):
        h.append('<div style="margin:1px 0 1px 8px;font-size:0.85rem;color:#495670;">'
                 '无(上一交易日无推荐/空仓观望)</div>')
    if cands:
        h.append('<div style="color:#a8b7d0;font-weight:600;margin:8px 0 1px 0;">'
                 '💡 今日候选 · 参考(不进今日账本，需要与上方进场票替换时自行判断)</div>')
        for c, src in cands[:6]:
            stt = "、".join((c.get("strategies") or [])[:2])
            h.append(f'<div style="margin:1px 0 1px 8px;font-size:0.85rem;">'
                     f'<b>{c.get("name","")}</b>({c.get("code","")}) 现价 {_fmt_px(c.get("price"))} '
                     f'<span style="color:#495670;">{stt}</span> '
                     f'<span style="color:#495670;font-size:0.72rem;">[{src}]</span></div>')
    if not (sells_done or sell_plan or hold or entered or pend_buy or cands):
        h.append('<div style="color:#495670;font-size:0.85rem;margin:6px 2px;">今日无操作 · 主推/龙头当前空仓</div>')
    h.append('<div style="color:#495670;font-size:0.7rem;margin-top:6px;border-top:1px solid #2a2d3e;padding-top:4px;">'
             '※ 盘中按实时价浮动并标注「实时(未收盘)」，收盘后自动切回收盘价与账本一致；'
             '买入=上一交易日信号的次日开盘价成交；卖出=连板中断/时间止损，按当日收盘价结算；'
             '今日扫描候选仅供人工替换参考，不计入账本。</div>')
    h.append('</div>')
    st.markdown("\n".join(h), unsafe_allow_html=True)


def _code_of(s):
    """从"名称 (600123)"取代码部分."""
    s = str(s or "")
    if "(" in s and s.endswith(")"):
        return s[s.rfind("(") + 1:-1]
    return s


def _today_trade_status_card():
    """当日「买卖和持仓情况」摘要卡: 放大盘指数正下方, 一眼可见.（旧版, 已被 _today_action_card 取代）
    数据与底部逐笔明细/推荐记录同源(主推T5重放 + 龙头live仓).
    时点口径: 买入=开盘(早盘)价成交; 卖出=断板/时间止损, 按当日收盘(尾盘)价卖."""
    from sim_t5 import _load_main_backup, _dragon_track, _local_latest_date
    from datetime import datetime

    def _d8(s):
        s = str(s or "")
        return f"{s[:4]}-{s[4:6]}-{s[6:8]}" if len(s) == 8 and s.isdigit() else s

    try:
        asof = _local_latest_date()
        mb = (_load_main_backup(asof) or {}).get("主推") or {}
        dr = _dragon_track(asof) or {}
    except Exception:
        st.caption("⚠️ 当日买卖和持仓情况暂不可用")
        return

    a_d = _d8(asof)
    rows, hold = [], []
    for role, tr in (("主推", mb), ("龙头", dr)):
        for r in tr.get("detail") or []:
            if str(r.get("日期", "")) == a_d:
                rr = dict(r)
                rr["_role"] = role
                rows.append(rr)
        for o in tr.get("open_pos") or []:
            hh = dict(o)
            hh["_role"] = role
            hold.append(hh)

    buys, sells, nxt = [], [], []
    for r in rows:
        st_t = str(r.get("状态", ""))
        yf = str(r.get("收益", ""))
        if st_t == "开盘买入":
            buys.append(r)
        elif "·" in st_t and st_t.endswith("日") and yf.startswith("¥"):
            sells.append(r)
        elif st_t in ("待买入", "买入信号"):
            nxt.append(r)
    buy_who = {r.get("股票") for r in buys}
    nxt = [r for r in nxt if r.get("股票") not in buy_who]

    today8 = datetime.now().strftime("%Y%m%d")
    asof8 = str(asof or "")[:8]
    try:
        nx8 = _next_trading_day(datetime.strptime(asof8, "%Y%m%d") + timedelta(days=1)).strftime("%Y%m%d")
    except Exception:
        nx8 = ""
    is_today = asof8 == today8
    pre_show = (not is_today) and nx8 == today8          # 基准日=上一交易日, 今日开盘前 → 预展今日将执行
    if is_today:
        tag = "今日 · 盘中/已收盘"
    elif pre_show:
        tag = "今日开盘前 · 预展今日将执行"
    else:
        tag = "最近收盘交易日"
    day_lab = "今日" if is_today else a_d                 # 分组标题用精确日期, 避免把昨日买卖写成"今日"
    h = [f'<div style="background:#0d1117;border:1px solid #2a2d3e;border-radius:8px;padding:10px 14px;margin:6px 0 8px 0;">']
    h.append(f'<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:4px;">'
             f'<span style="color:#ffd600;font-weight:700;">{a_d} · 买卖和持仓情况</span>'
             f'<span style="color:#495670;font-size:0.7rem;">{tag} · 主推+龙头</span></div>')

    def _who(r):
        return str(r.get("股票", "") or "—")

    if buys:
        h.append(f'<div style="color:#00d4ff;font-weight:600;margin:6px 0 1px 0;">📗 {day_lab}买入 · 早盘(开盘价)成交</div>')
        for r in buys:
            role = r["_role"]
            px = r.get("价格", "—")
            qs = r.get("模拟股数", "—")
            h.append(f'<div style="margin:1px 0 1px 8px;font-size:0.85rem;"><span style="color:#00d4ff;">{role}</span> '
                     f'早盘买入 <b>{_who(r)}</b> @ {px}元 × {qs}股 <span style="color:#495670;">{r.get("操作","")}</span></div>')
    if sells:
        h.append(f'<div style="color:#ff9800;font-weight:600;margin:8px 0 1px 0;">📕 {day_lab}卖出 · 尾盘(收盘价)成交</div>')
        for r in sells:
            role = r["_role"]
            yf = str(r.get("收益", ""))
            cls = "pos" if yf.startswith("¥+") else "neg"
            h.append(f'<div style="margin:1px 0 1px 8px;font-size:0.85rem;"><span style="color:#ff9800;">{role}</span> '
                     f'尾盘卖出 <b>{_who(r)}</b> <span style="color:#495670;">{r.get("状态","")}</span> · '
                     f'<b class="{cls}">{yf}</b> <span style="color:#495670;">{r.get("操作","")}</span></div>')
    if hold:
        h.append('<div style="color:#ffd600;font-weight:600;margin:8px 0 1px 0;">📌 当前持仓（按收盘价浮动）</div>')
        for o in hold:
            role = o["_role"]
            nm = str(o.get("name", ""))
            cd = str(o.get("code", ""))
            try:
                pnl = float(o.get("pnl", 0) or 0)
            except (TypeError, ValueError):
                pnl = 0.0
            cls = "pos" if pnl >= 0 else "neg"
            try:
                d = int(float(o.get("days", 0)))
            except (TypeError, ValueError):
                d = "?"
            mark = o.get("mark", "")
            if isinstance(mark, (int, float)):
                mark = f"{mark:.2f}"
            en = _d8(o.get("entry", ""))
            rs = str(o.get("reason", "") or "")
            rs = rs if len(rs) <= 44 else rs[:44] + "…"
            line = (f'<div style="margin:1px 0 0 8px;font-size:0.85rem;"><span style="color:#ffd600;">{role}</span> '
                    f'持仓 <b>{nm}</b>({cd}) · {en}入场 · 持{d}日 · 现价 {mark} · '
                    f'浮动 <b class="{cls}">¥{pnl:+,.0f}</b></div>')
            if rs:
                line += f'<div style="margin:0 0 2px 8px;font-size:0.75rem;color:#495670;">└ {rs}</div>'
            h.append(line)
    if nxt:
        # 待买入执行日 = 最近收盘交易日的下一交易日; 次日开盘前(pre_show)即预展为"今日开盘将买入"
        if nx8:
            nx_lab = _d8(nx8) if nx8 != today8 else "今日开盘"
            h.append(f'<div style="color:#a8b7d0;font-weight:600;margin:8px 0 1px 0;">⏳ 待执行买入 · {nx_lab}(按开盘价成交) · 以下为最近收盘后已出信号的标的</div>')
        else:
            h.append('<div style="color:#a8b7d0;font-weight:600;margin:8px 0 1px 0;">⏳ 待执行买入(已出信号/待买入)</div>')
        for r in nxt:
            h.append(f'<div style="margin:1px 0 1px 8px;font-size:0.85rem;"><span style="color:#a8b7d0;">{r["_role"]}</span> '
                     f'{_who(r)} <span style="color:#495670;">{r.get("操作","")}</span></div>')
    if not (buys or sells or hold or nxt):
        h.append('<div style="color:#495670;font-size:0.85rem;margin:6px 2px;">最近收盘日无买卖 · 主推/龙头当前空仓</div>')
    h.append('<div style="color:#495670;font-size:0.7rem;margin-top:6px;border-top:1px solid #2a2d3e;padding-top:4px;">'
             '※ 时点口径: 买入=信号次日开盘(早盘)按开盘价成交；卖出=断板/时间止损，按当日收盘(尾盘)价卖；'
             '每笔¥6,000独立本金，与下方逐笔明细/推荐记录同口径。</div>')
    h.append('</div>')
    st.markdown("\n".join(h), unsafe_allow_html=True)


def _auto_refresh_home():
    """首页自动刷新: 捕捉后台扫描(手动/定时)完成并刷新推荐, 无需手动刷新页面.
    - 扫描进行中(running): 每 ~1.5s 轮询, 展示"扫描中"并自动重跑, 直到扫描结束;
    - 扫描刚结束(出现新的 last_time): 立即重跑一次展示最新结果;
    - 空闲: 每 20s 轻量心跳检查一次(捕捉盘中定时扫描如 14:30 完成后刷新).
    st.rerun() 故意置于 try 之外, 避免 RerunException 被 except 吞掉."""
    import time as _t
    stt = st.session_state
    now = _t.time()
    try:
        running = bool(_SCAN_REGISTRY.get("running"))
        last = _SCAN_REGISTRY.get("last_time")
        started = _SCAN_REGISTRY.get("started_at")
    except Exception:
        return
    if "_shown_scan_time" not in stt:
        stt["_shown_scan_time"] = last
        return
    if running:
        # 卡死超时(>_SCAN_TIMEOUT)不再轮询, 避免死循环; 下方会显示超时提示
        if started is not None and (now - started) > _SCAN_TIMEOUT:
            return
        if now - stt.get("_poll", 0) > 1.5:
            stt["_poll"] = now
            st.info("🔄 后台扫描进行中，自动刷新中…")
            _t.sleep(1.2)
            st.rerun()
        return
    if last is not None and stt.get("_shown_scan_time") != last:
        stt["_shown_scan_time"] = last
        st.rerun()
        return
    if now - stt.get("_hb", 0) > 20:
        stt["_hb"] = now
        st.rerun()


def render_home():
    _auto_refresh_home()
    st.markdown(f'<div class="main-title">🏠 量化交易系统</div><div class="sub-title">大盘概览 · 板块热点 · 策略精选</div>', unsafe_allow_html=True)

    # ── 行情库新鲜度全局警示(2026-09-07): 本地bar落后时, 持仓/结算按旧收盘口径展示是"数据滞后"不是"策略停摆" ──
    try:
        from sim_t5 import bars_freshness
        _fr = bars_freshness()
        if not _fr.get("ok", True):
            st.warning(f"⚠️ 行情库滞后: 本地 bar 截止 {_fr['asof']}，距 {_fr['want']} 缺 "
                       f"{_fr['lag_days']} 个交易日 — 以下持仓/结算按 {_fr['asof']} 收盘口径展示，"
                       f"后台补库完成后自动追平。")
    except Exception:
        pass

    # ── 大盘指数(上证指数卡片内合并决策辅助: MA20/板块指数/综合建议, 不重复请求) ──
    st.markdown('<div class="section-title">📊 大盘指数</div>', unsafe_allow_html=True)
    indices = StockAPI.get_major_indices()
    if not indices.empty:
        _render_index_row(indices)
    # ── 今日行动(大盘指数正下方, 一眼可见: 今日卖出/持仓中/今日进场 + 今日扫描候选参考) ──
    _today_action_card()

    # ── 定时启停状态 ──
    col_s1, col_s2, col_s3, col_s4 = st.columns(4)
    sched_cfg = load_config()
    sched_status = scheduler.get_status()
    if sched_cfg.get("enabled", True):
        mkt_open = sched_status.get("market_open", False)
        state_text = "🟢 交易时段" if mkt_open else "🔴 非交易时段"
        state_cls = "pos" if mkt_open else "neg"
        next_ev = sched_status.get("next_event", "")
    else:
        state_text = "🔵 定时未启用"
        state_cls = ""
        next_ev = "持续运行"
    with col_s1: st.markdown(metric_card("定时启停", state_text, state_cls), unsafe_allow_html=True)
    with col_s2: st.markdown(metric_card("开盘", sched_cfg.get("market_open","09:25")), unsafe_allow_html=True)
    with col_s3: st.markdown(metric_card("收盘", sched_cfg.get("market_close","15:05")), unsafe_allow_html=True)
    with col_s4: st.markdown(metric_card("下个事件", next_ev), unsafe_allow_html=True)

    # ── Agent辩论 · 今日推荐 ──
    col_b1, col_b2, col_b3, col_b4 = st.columns([2,2,2,4])
    with col_b1:
        if st.button("🔄 重新扫描", width='stretch'):
            _SCAN_REGISTRY["result"] = None
            _SCAN_REGISTRY["last_time"] = None
            _SCAN_REGISTRY["saved"] = False
            background_scan(force=True)
            st.rerun()
    with col_b2:
        if st.button("📊 手动回测", width='stretch'):
            with st.spinner("⏳ Agent辩论全量回测中（120天）..."):
                result = agent_backtest(days=120, start_capital=100000)
                st.session_state.agent_bt = result
                st.session_state.agent_bt_incremental = False
                st.session_state.agent_bt_time = datetime.now().strftime("%H:%M:%S")
            st.rerun()
    with col_b3:
        if st.button("📈 增量回测", width='stretch'):
            with st.spinner("⏳ Agent辩论增量回测中（近20天）..."):
                result = agent_backtest(days=20, start_capital=100000)
                st.session_state.agent_bt = result
                st.session_state.agent_bt_incremental = True
                st.session_state.agent_bt_time = datetime.now().strftime("%H:%M:%S")
            st.rerun()
    with col_b4:
        # 行情库手动补库(2026-09-08): 服务停摆/上次刷新被杀/命令行环境不可达时的自救入口.
        # 后台子进程跑增量刷新(约10分钟, 自带文件锁与手动刷新互斥), 不阻塞页面渲染.
        if st.button("📥 手动补库", width='stretch'):
            try:
                from build_market_bars import _bars_guard_tick
                ok = _bars_guard_tick(0, force=True)
                if ok:
                    st.info("已后台启动行情补库(全市场约10分钟)，完成后刷新本页即可看到最新日期。")
                else:
                    st.info("行情库已最新，或上次补库刚发起(冷却内)，无需重复补库。")
            except Exception as _e:
                st.error(f"补库启动失败: {type(_e).__name__} {str(_e)[:80]}")

    st.markdown('<div class="section-title">🎯 Agent辩论 · 今日推荐</div>', unsafe_allow_html=True)

    def _load_rec(date_str):
        path = os.path.join(RECOMMEND_DIR, f"{date_str}.json")
        if os.path.exists(path):
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except: pass
        return None

    def _load_rec_history(days=60):
        records = []
        if not os.path.isdir(RECOMMEND_DIR):
            return records
        for fname in sorted(os.listdir(RECOMMEND_DIR)):
            if fname.endswith(".json"):
                try:
                    with open(os.path.join(RECOMMEND_DIR, fname), 'r', encoding='utf-8') as f:
                        records.append(json.load(f))
                except: pass
        # 补入扫描快照日期: 当日扫描过但推荐记录未落盘(如进程中断)的日期, 也计入历史明细(空仓观望)
        seen = {r.get("date") for r in records}
        if os.path.isdir(DAILY_PICKS_DIR):
            for fname in sorted(os.listdir(DAILY_PICKS_DIR)):
                if not fname.endswith(".json"):
                    continue
                date_str = fname[:-5]
                if date_str in seen:
                    continue
                try:
                    with open(os.path.join(DAILY_PICKS_DIR, fname), 'r', encoding='utf-8') as f:
                        dp = json.load(f)
                except Exception:
                    dp = {}
                date_str = str(dp.get("date") or date_str)
                if date_str in seen:
                    continue
                seen.add(date_str)
                # 快照有 pick_list/主推/备用 → 补成正式推荐(角色主推/备用/候选N); 无 → 空仓观望
                picks = []
                plist = dp.get("pick_list") or []
                if not plist:
                    plist = [p for p in (dp.get("main_pick"), dp.get("backup_pick")) if p]
                for i, p in enumerate(plist):
                    if not (p and p.get("code")):
                        continue
                    role = "主推" if i == 0 else ("备用" if i == 1 else f"候选{i+1}")
                    picks.append({
                        "role": role,
                        "code": str(p.get("code")),
                        "name": p.get("name"),
                        "price": p.get("price"),
                        "sector": p.get("sector"),
                        "sector_key": p.get("sector_key"),
                        "expected_return": p.get("expected_return"),
                        "win_rate": p.get("win_rate"),
                        "strategies": p.get("strategies"),
                    })
                if picks:
                    records.append({"date": date_str, "picks": picks})
                else:
                    records.append({"date": date_str, "picks": [], "hold": "空仓观望"})
        records.sort(key=lambda r: str(r.get("date", "")))
        # 补齐 第一笔记录→今天 的所有缺失交易日为空仓观望, 使历史明细连续到当前
        # (08-21/24/25 等无推荐也无快照的交易日也显示空仓观望, 不再中断)
        if records:
            try:
                first_day = datetime.strptime(str(records[0].get("date", "")), "%Y%m%d").date()
            except Exception:
                first_day = None
            if first_day is not None:
                cur = first_day
                today = datetime.now().date()
                while cur <= today:
                    if is_trading_day(cur):
                        ds = cur.strftime("%Y%m%d")
                        if ds not in seen:
                            seen.add(ds)
                            records.append({"date": ds, "picks": [], "hold": "空仓观望"})
                    cur += timedelta(days=1)
        records.sort(key=lambda r: str(r.get("date", "")))
        return records[-days:]

    def _enrich_rec_t1(records):
        today = datetime.now()
        changed_dates = set()
        for rec in records:
            date_str = rec.get("date", "")
            if not date_str:
                continue
            buy_dt = datetime.strptime(date_str, "%Y%m%d")
            t1_date = _next_trading_day(buy_dt + timedelta(days=1))
            t1_done = today.date() > t1_date.date()                      # T+1 已收盘
            t1_live = today.date() == t1_date.date() and today.strftime("%H:%M") >= SELL_LIVE_AT  # T+1当天收盘后可定稿
            if not (t1_done or t1_live):
                continue
            t1_str = t1_date.strftime("%Y%m%d")
            today_str = today.strftime("%Y%m%d")
            # 每条推荐独立计算自己的T+1(买入=T+1开盘, 卖出=T+1收盘/10:30; 旧口径用D收盘当买价高估隔夜gap), 次日同股再推荐不影响
            for pick in rec.get("picks", []):
                # 已按 T+1开盘 口径定稿且T+1已收盘 → 不再重算(避免反复请求行情)
                if t1_done and pick.get("qfq_buy_metric") == "t1_open":
                    continue
                if t1_live and not t1_done and isinstance(pick.get("t1_return"), (int, float)):
                    continue  # 当日收盘卖点已定稿, 不再重复请求
                code = pick.get("code", "")
                # 历史K线失败也要继续: 10:30卖点用盘中网格(独立接口)补算, 不能整笔跳过
                hist = None
                try:
                    hist = StockAPI.get_historical_data(code, date_str, today_str, adjust="qfq")
                except Exception:
                    hist = None
                qfq_buy = None
                qfq_sell = None
                buy_close = 0.0
                oneword = False  # T+1 一字涨停(开盘=最高) → 买不进
                if hist is not None and not hist.empty:
                    try:
                        buy_row = hist[hist["date"] == pd.to_datetime(date_str)]
                        if not buy_row.empty:
                            c = float(buy_row["close"].iloc[0])
                            if c > 0:
                                buy_close = c
                        sell_row = hist[hist["date"] == pd.to_datetime(t1_str)]
                        if not sell_row.empty:  # T+1 已有bar
                            # 真实可捕获买价 = T+1 开盘(信号收盘才产生, 只能买次日开盘, 扣隔夜高开gap)
                            t1_open = float(sell_row["open"].iloc[0])
                            if t1_open > 0:
                                qfq_buy = t1_open
                            qfq_sell = float(sell_row["close"].iloc[0])  # T+1 收盘
                            t1_high = float(sell_row["high"].iloc[0])
                            t1_low = float(sell_row["low"].iloc[0])
                            oneword = (t1_high - t1_low) < 0.03 and t1_open >= t1_high - 0.005
                    except Exception:
                        pass
                # 记口径: t1_open=按T+1开盘买(真口径); d_close_fallback=盘中bar未入API用D收盘兜底(高估隔夜gap)
                metric = "t1_open" if qfq_buy is not None else "d_close_fallback"
                if qfq_buy is None:
                    # T+1 开盘取不到(接口异常/当日盘中bar未含) → 兜底推荐当日收盘价, 口径回退(短期前复权≈1)
                    qfq_buy = buy_close if buy_close > 0 else pick.get("price")
                if not qfq_buy or float(qfq_buy) <= 0:
                    continue
                qfq_buy = float(qfq_buy)
                pick["qfq_buy_price"] = round(qfq_buy, 2)
                pick["qfq_buy_metric"] = metric
                if qfq_sell is not None:
                    pick["t1_return"] = round((qfq_sell / qfq_buy - 1) * 100, 2)
                    pick["sell_price"] = round(qfq_sell, 2)
                    # 兜底记录的买价被修正为T+1开盘后, 10:30收益须随新买价重算, 否则展示仍用旧高估值
                    t30 = pick.get("t1_1030_price")
                    if isinstance(t30, (int, float)) and qfq_buy > 0:
                        pick["t1_1030_return"] = round((t30 / qfq_buy - 1) * 100, 2)
                    if oneword:
                        pick["t1_buyable"] = False  # 一字涨停开盘买不进, 真实收益仅作为对照
                # else: T+1 bar 拉不到(接口瞬时失败) → 保留已有值, 不销毁; 下次bar到位自动重算
                # T+1 日基准卖点 10:30 盘中价 → 前复权对齐当日收盘涨幅
                try:
                    grid = StockAPI.get_intraday_sell_grid(code, t1_str)
                    if grid and grid.get("close", 0) > 0:
                        # T+1当天盘中尚无收盘 qfq_sell: 用当日网格末价近似(最新交易日前复权系数≈1)
                        _apply_t1_grid(pick, grid, qfq_buy, qfq_sell if qfq_sell else grid.get("close"))
                except Exception:
                    pass
                # 只持久化算出了真实T+1的记录; 全部接口临时故障时不落盘半成品, 留待下次重试
                if isinstance(pick.get("t1_return"), (int, float)) or isinstance(pick.get("t1_1030_return"), (int, float)):
                    changed_dates.add(date_str)
        # 回填: 已算T+1但缺10:30价的老记录(仅近窗口, 更早的分钟数据源取不到, 不反复请求)
        for rec in records:
            date_str = rec.get("date", "")
            if not date_str:
                continue
            buy_dt = datetime.strptime(date_str, "%Y%m%d")
            t1_date = _next_trading_day(buy_dt + timedelta(days=1))
            if today.date() <= t1_date.date():
                continue
            if (today.date() - t1_date.date()).days > 120:
                continue
            t1_str = t1_date.strftime("%Y%m%d")
            for pick in rec.get("picks", []):
                if not isinstance(pick.get("t1_return"), (int, float)):
                    continue
                if isinstance(pick.get("t1_1030_return"), (int, float)):
                    continue
                qfq_buy = pick.get("qfq_buy_price") or pick.get("price")
                qfq_sell = pick.get("sell_price")
                if not qfq_buy or not qfq_sell:
                    continue
                try:
                    grid = StockAPI.get_intraday_sell_grid(pick.get("code", ""), t1_str)
                    if grid and grid.get("close", 0) > 0:
                        _apply_t1_grid(pick, grid, float(qfq_buy), float(qfq_sell))
                        changed_dates.add(date_str)
                except Exception:
                    pass
        # 持久化: 算出的T+1回写本地, 避免每次刷新对历史推荐重复查询行情
        for rec in records:
            date_str = rec.get("date", "")
            if date_str not in changed_dates:
                continue
            try:
                with open(os.path.join(RECOMMEND_DIR, f"{date_str}.json"), "w", encoding="utf-8") as f:
                    json.dump(rec, f, ensure_ascii=False, indent=2, default=str)
            except Exception:
                pass
        return records

    def _render_prev_day_disposition(records):
        """今日无推荐时: 说明上一推荐日主推在断板止盈+时间止损5日纪律下的处置与持仓建议."""
        today_str = datetime.now().strftime("%Y%m%d")
        prev = None
        for r in records:  # records 时间正序(旧→新), 取日期 < 今日的最新一条
            if r.get("date") and r.get("date") < today_str and r.get("picks"):
                prev = r
        if not prev:
            return
        d = prev["date"]
        disp = f"{d[:4]}-{d[4:6]}-{d[6:8]}"
        try:
            from sim_t5 import _load_main_backup, _local_latest_date
            mb = _load_main_backup(_local_latest_date())
        except Exception:
            return
        cells = []
        for rk in ("主推",):                     # 备用轨已关闭
            for row in mb.get(rk, {}).get("detail", []):
                if row.get("日期") != disp:
                    continue
                if row.get("状态") in ("空仓", "待买入", "数据缺失", "预算不足1手"):
                    continue
                nm = str(row.get("股票", "")).split(" (")[0]
                act = row.get("操作", "") or ""
                cells.append(f'{rk} <b>{nm}</b> {row.get("状态","")} · {act}（{row.get("收益","")}）')
        if not cells:
            return
        st.markdown(
            f'<div style="background:#0d1117;border:1px solid #2a2d3e;border-radius:8px;padding:8px 12px;margin:6px 0 8px 0;">'
            f'<span style="color:#ffd600;font-weight:600;">📌 {disp} 推荐处置（今日无新推荐）</span>'
            f'<div style="margin-top:4px;font-size:0.85rem;"><span style="color:#495670;">断板止盈+时间止损5日: </span>{"；".join(cells)}</div>'
            f'<div style="color:#8892b0;font-size:0.75rem;margin-top:4px;">'
            f'连板未断/未破5日线继续持有，断板或持满5日收盘卖出换股；今日无新推荐 → 无新买入 → 空仓过夜。</div>'
            f'</div>', unsafe_allow_html=True)

    def _render_three_track_overview():
        """三策略模拟总览(2026-09-01): 主推 T5纪律重放历史推荐(备用轨已关) + 龙头live仓.
        表格化, 一眼看推进(平仓/持仓/待买)与模拟总收益(已实现+浮动)."""
        try:
            from sim_t5 import three_track_overview, _local_latest_date
            ov = three_track_overview()
            _end = _local_latest_date()
            asof_str = f"{_end[:4]}-{_end[4:6]}-{_end[6:]}"
        except Exception as e:
            st.caption(f"⚠️ 三策略总览加载失败: {type(e).__name__} {str(e)[:80]}")
            return
        if not ov:
            return
        rows = []
        for k in ("主推", "龙头"):          # 备用轨已关闭
            v = ov.get(k) or {}
            realized = float(v.get("realized", 0) or 0)
            float_pnl = float(v.get("float", 0) or 0)
            n_c = int(v.get("n_closed", 0) or 0)
            n_w = int(v.get("n_win", 0) or 0)
            rows.append({"策略": k,
                         "已实现": realized, "浮动": float_pnl,
                         "模拟总收益": realized + float_pnl,
                         "已平仓/赢": f"{n_w}/{n_c}" if n_c else "—",
                         "持仓": int(v.get("n_open", 0) or 0),
                         "待买": int(v.get("pending", 0) or 0),
                         "未买": int(v.get("n_unbuy", 0) or 0) + int(v.get("n_noqty", 0) or 0)})
        df = pd.DataFrame(rows)

        def _money_color(v):
            if not isinstance(v, (int, float)):
                return ""
            if v < 0:
                return "color:#00c853;font-weight:600;"
            if v > 0:
                return "color:#ff1744;font-weight:600;"
            return ""

        styled = (df.style
                  .map(_money_color, subset=["已实现", "浮动", "模拟总收益"])
                  .format({"已实现": "¥{:+,.0f}", "浮动": "¥{:+,.0f}",
                           "模拟总收益": "¥{:+,.0f}"}))
        _d = ov.get("龙头") or {}
        _dc = int(_d.get("n_closed", 0) or 0)
        _dtot = float(_d.get("total", 0) or 0)
        _dnote = f"龙头: 龙头战法live仓({_dc}笔已平仓, 模拟累计{'¥{:+,.0f}'.format(_dtot)})"
        st.markdown('<div class="section-title" style="margin-top:8px;">📊 三策略模拟总览</div>',
                    unsafe_allow_html=True)
        st.dataframe(styled, width='stretch', hide_index=True)

        # ── 今日操作提醒: 买/持/卖 一句到位(何时入场 / 为何持有 / 何时卖) ──
        def _alert_icon(kind, text):
            cls = {"buy": "#00d4ff", "hold": "#ffd600", "sell": "#ff1744"}.get(kind, "#ccd6f6")
            lab = {"buy": "买入", "hold": "持有", "sell": "卖出/警示"}[kind]
            return (f'<div style="margin:2px 0;font-size:0.85rem;"><span style="color:{cls};'
                    f'font-weight:700;">{lab}</span> <span>{text}</span></div>')
        def _d8y(_s):
            _s = str(_s or "")
            return f"{_s[:4]}-{_s[4:6]}-{_s[6:8]}" if len(_s) == 8 and _s.isdigit() else ""
        _alerts = []
        for _k in ("主推", "龙头"):
            _v = ov.get(_k) or {}
            for _pp in (_v.get("pending_pos") or []):
                _bd = _d8y(_pp.get("entry"))
                # 直接写入场日期(不用"今日/明日"相对词; 盘中行情库未刷到入场日时 entry 即今天)
                _buy_txt = f"{_bd} 开盘买入" if _bd else "待定(行情刷新后结算)"
                _alerts.append(_alert_icon("buy",
                    f'{_k} {_pp.get("name","")}({_pp.get("code","")}): {_buy_txt}'))
            for _op in (_v.get("open_pos") or []):
                _r = _op.get("reason", "") or ""
                _kind = "sell" if ("时间止损" in _r or "破5日线" in _r or "断板" in _r or "收盘卖" in _r) else "hold"
                _alerts.append(_alert_icon(_kind,
                    f'{_k} {_op.get("name","")}({_op.get("code","")}) 持{_op.get("days",0)}日 · {_r}'))
        if _alerts:
            st.markdown(
                '<div style="background:#0d1117;border:1px solid #2a2d3e;border-radius:8px;'
                'padding:8px 12px;margin:6px 0 8px 0;">'
                '<div style="color:#ffd600;font-weight:600;">📌 操作提醒</div>'
                + "".join(_alerts) + '</div>', unsafe_allow_html=True)

        # ── 逐笔明细: 每策略 已平仓(买卖点+收益) 与 持仓(入场价+现价+浮动+持有理由) ──
        for k in ("主推", "龙头"):
            v = ov.get(k) or {}
            trades = v.get("trades") or []
            open_pos = v.get("open_pos") or []
            if not trades and not open_pos:
                continue
            with st.expander(f"📋 {k} 逐笔明细({len(trades)}平仓 / {len(open_pos)}持仓)", expanded=False):
                def _tc(v):   # 红涨绿跌: ± 字符串按正负上色
                    if isinstance(v, str):
                        m = re.search(r"[+-]\d", v)
                        if m:
                            return ("color:#ff1744;font-weight:600;" if not m.group(0).startswith("-")
                                    else "color:#00c853;font-weight:600;")
                    return ""
                if open_pos:
                    odf = pd.DataFrame(open_pos)
                    odf["pnl"] = pd.to_numeric(odf.get("pnl", 0), errors="coerce").fillna(0)
                    oshow = pd.DataFrame({
                        "名称": odf["name"], "入场日": odf["entry"], "入场价": odf["entry_px"],
                        "现价(最新收盘)": odf["mark"], "持有日": odf.get("days", 0),
                        "浮动¥": odf["pnl"].map(lambda x: f"¥{x:+,.0f}"),
                        "持有理由": odf.get("reason", "")})
                    st.markdown(
                        f'<div style="margin:6px 0 2px 0;color:#ffd600;">'
                        f'<span style="font-size:1.05rem;font-weight:800;">持仓</span>'
                        f'<span style="font-size:0.85rem;font-weight:600;">({len(open_pos)}笔 · 按{asof_str}收盘浮动)</span>'
                        f'</div>', unsafe_allow_html=True)
                    st.dataframe(oshow.style.map(_tc, subset=["浮动¥"]), width='stretch', hide_index=True)
                if trades:
                    tdf = pd.DataFrame(trades)
                    tdf["ret_pct"] = pd.to_numeric(tdf.get("ret_pct", 0), errors="coerce").fillna(0)
                    tdf["pnl"] = pd.to_numeric(tdf.get("pnl", 0), errors="coerce").fillna(0)
                    # 已平仓按出场日期降序(最新平仓在最上); 出场缺失行排最后.
                    if "exit" in tdf.columns:
                        def _dint(_x):
                            _s = str(_x or "").replace("-", "").replace("/", "")
                            return int(_s) if _s.isdigit() else 0
                        tdf["_dk"] = tdf["exit"].map(_dint)
                        tdf = tdf.sort_values("_dk", ascending=False).drop(columns=["_dk"])
                    show = pd.DataFrame({
                        "名称": tdf["name"], "入场": tdf["entry"], "出场": tdf["exit"],
                        "持有日": tdf.get("days", ""),
                        "收益%": tdf["ret_pct"].map(lambda x: f"{x:+.2f}%"),
                        "盈亏¥": tdf["pnl"].map(lambda x: f"¥{x:+,.0f}"),
                        "卖出原因": tdf.get("reason", tdf.get("tag", ""))})
                    st.markdown(f'<div style="color:#495670;font-size:0.75rem;margin:10px 0 2px 0;">已平仓({len(trades)}笔 · 全量, 出场日降序)</div>',
                                unsafe_allow_html=True)
                    st.dataframe(show.style.map(_tc, subset=["收益%", "盈亏¥"]), width='stretch', hide_index=True)
        st.caption("主推: 以龙头断板止盈+时间止损5日纪律重放历史推荐(备用轨已于2026-09-01关闭)；"
                   f"{_dnote}；"
                   "每笔¥6,000独立本金、整手、含佣金(万2.5)/印花税(0.05%)/过户费(万0.1)；"
                   "持仓期内再次推荐→提示持有(不重复开仓)，卖出(断板/时间止损)后记该段总收益；"
                   "待买=信号已出未到入场日；跳过=一字板/停牌买不进或¥6,000买不起1手；"
                   "买入=次日开盘；持有=连板未断/未破5日线继续(盘中风险/回撤保护提示见操作列)；卖出=断板或时间止损收盘卖。"
                   "⚠️ 龙头纪律已过slot仿真(两窗口月+7%左右)但首页历史不足1月样本薄, 方向不保证收益。")

    # ── 今日推荐: 进入页面加载本地最新一次扫描结果并显示 ──
    result = _render_recommendation_block()

    # ── 历史推荐记录(只读本地, 不联网): 供"无推荐时的上一日处置"查上一信号日 ──
    # 旧 T+1 联网补算(_enrich_rec_t1, 每次整页重跑都要拉行情/盘中网格, 是慢源)已移除;
    # 处置/收益一律走 T5(_load_main_backup), 与卡片/总览同口径.
    rec_history = _load_rec_history(days=30)
    if result and not result.get("main_pick"):
        _render_prev_day_disposition(rec_history)

    # ── Agent辩论回测结果展示 ──
    if st.session_state.agent_bt:
        bt = st.session_state.agent_bt
        if bt.get("status") == "ok":
            mode = "增量" if st.session_state.agent_bt_incremental else "全量"
            ret = bt.get("total_return_pct", 0)
            wr = bt.get("win_rate", 0)
            r_cls = "pos" if ret > 0 else "neg"
            st.markdown(f'<div style="background:#0d1117;border:1px solid #1a1d2e;border-radius:8px;padding:10px 14px;margin:8px 0;">'
                        f'<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:4px;">'
                        f'<span style="color:#ffd600;font-weight:600;">🤖 Agent辩论 {mode}回测</span>'
                        f'<span style="color:#8892b0;font-size:0.75rem;">{bt.get("date_range","")} · {bt.get("trading_days",0)}个交易日 · {st.session_state.get("agent_bt_time","")}</span>'
                        f'</div>'
                        f'<div style="display:flex;gap:16px;margin-top:6px;flex-wrap:wrap;font-size:0.85rem;">'
                        f'<span>收益率: <b class="{r_cls}">{ret:+.2f}%</b></span>'
                        f'<span>胜率: <b style="color:#64ffda;">{wr:.1f}%</b></span>'
                        f'<span>交易: {bt.get("sell_count",0)}笔</span>'
                        f'<span>平均收益: {"{:+}".format(bt.get("avg_return",0))}%</span>'
                        f'<span style="color:#8892b0;">{bt.get("start_capital"):,.0f} → {bt.get("final_value"):,.0f}</span>'
                        f'</div></div>', unsafe_allow_html=True)
        else:
            st.caption(f"⚠️ 回测失败: {bt.get('status', '未知错误')}")

    # ── 历史推荐记录（T5纪律重放: 断板止盈+时间止损5日, 与顶部卡片/三策略总览同口径, 非机械T+1）──
    from sim_t5 import _load_main_backup, _local_latest_date, _dragon_track
    _asof = _local_latest_date()
    _mb = _load_main_backup(_asof)
    if _mb and _mb["主推"]["detail"]:      # 备用轨已关闭
        st.markdown('<div class="section-title" style="margin-top:8px;">📋 推荐记录</div>', unsafe_allow_html=True)
        total_r = _mb["主推"]["n_closed"]
        wins = _mb["主推"]["n_win"]
        role_sum = {"主推": (_mb["主推"]["n_closed"], _mb["主推"]["n_win"], _mb["主推"]["total"])}
        _dr = _dragon_track(_asof)      # 龙头同口径推进重放(幂等)
        role_sum["龙头"] = (_dr["n_closed"], _dr["n_win"], _dr["total"])
        if total_r > 0:
            def _wr(t, w):
                if not t:
                    return "—"
                rate = w / t * 100
                return f'<span class="{"pos" if rate >= 50 else "neg"}">{w}/{t} ({rate:.1f}%)</span>'
            def _role_sum(role, t, w, pnl):
                cls = "pos" if pnl >= 0 else "neg"
                return (f'<div style="margin:2px 0;"><span style="color:#64ffda;">{role}</span>'
                        f'<span style="color:#495670;"> 胜率 {_wr(t, w)}</span>'
                        f'<span style="color:#495670;"> | 累计盈利(每笔¥6,000): '
                        f'<b class="{cls}">¥{pnl:+,.2f}</b></span></div>')
            st.markdown(
                f'<div style="font-size:0.85rem;">'
                f'<div style="color:#495670;margin:2px 0;">总胜率(平仓口径): <span style="color:#64ffda;">{wins}/{total_r} ({wins/total_r*100:.1f}%)</span></div>'
                f'{_role_sum("主推", *role_sum["主推"])}'
                f'{_role_sum("龙头", *role_sum["龙头"])}'
                f'</div>', unsafe_allow_html=True)
            st.markdown('<div style="color:#495670;font-size:0.72rem;">※ 口径 = 交易段生命周期（与顶部卡片、三策略总览同口径，非T+1机械卖；备用轨已关闭）：行"日期"=信号日；T日信号 → 次日开盘买入（买入执行日在"开盘买入成交"行单独记录，行日期=实际买入日）；持仓期内该股再次推荐 → 提示"持有(未开新仓)"，不重复加仓；断板或持满5日收盘卖出换股，记该段总收益；平仓后再推荐才开新段。每笔独立¥6,000本金(不滚入)，整手，含佣金(万2.5)/印花税(0.05%)/过户费(万0.1)；一字板/停牌买不进、待买入、预算不足1手不计收益；持仓按最新收盘浮动计入。回撤/盘中纪律：浮盈自持仓最高收盘回撤≥8%提示止盈保护，已破5日线则次日不涨停收盘离场，持满4日提示明日时间止损（详见各持仓"操作"列）。</div>', unsafe_allow_html=True)
        with st.expander("📋 推荐/推进明细（断板止盈+时间止损5日重放）", expanded=True):
            def _render_role_table(title, color, rows, state_key, btn_key):
                if not rows:
                    return
                # 推荐记录按日期降序(最新在前); 明细是全量逐笔, 盈亏正负都可见.
                # 同日期内按状态优先级: 待买入(计划)最上, 其后才排开盘买入等已发生行(计划/成交一目了然).
                def _row_key(r):
                    d = str(r.get("日期", "")).replace("-", "")
                    d = int(d) if d.isdigit() else 0
                    st_txt = str(r.get("状态", ""))
                    rank = 0 if st_txt.startswith("待买入") else 1
                    return (-d, rank)
                rows = sorted(rows, key=_row_key)
                total = len(rows)
                df = pd.DataFrame(rows).drop(columns=["角色"])
                # 红涨绿跌: 收益/累计盈利 按正负号上色
                def _sign_color(v):
                    if not isinstance(v, str):
                        return ""
                    if ("待" in v or "未到" in v or "一字板" in v or "停牌" in v
                            or "空仓" in v or "数据缺失" in v
                            or v.strip() == "—" or v.strip() == "⏸️"):
                        return ""
                    m = re.search(r"[+-]\d", v)
                    if not m:
                        return ""
                    if m.group(0).startswith("-"):
                        return "color:#00c853;font-weight:600;"   # 绿 = 下跌
                    return "color:#ff1744;font-weight:600;"       # 红 = 上涨
                styled = df.style.map(_sign_color, subset=["收益", "累计盈利"])
                st.markdown(f'<div style="color:{color};font-weight:600;margin:6px 0 2px 0;">📌 {title}（{total}条）</div>', unsafe_allow_html=True)
                # 纯前端展开：默认显示前10条，点击"展示更多"用JS展开剩余行，不触发服务端全页刷新
                st.dataframe(styled, width='stretch', hide_index=True, max_rows=10)
            _render_role_table("主推记录", "#ffd600", _mb["主推"]["detail"], "rec_detail_main_show_all", "rec_detail_main_more_btn")
            # 龙头推荐记录: 信号日→次日开盘买入→断板/持满5日收盘卖, 每仓独立¥10,000, 最多5仓
            _render_role_table("龙头推荐记录", "#00d4ff", _dr["detail"], "rec_detail_dragon_show_all", "rec_detail_dragon_more_btn")


    # ── 三策略模拟总览(2026-09-01): 主推/龙头 推进+模拟总收益 一览(备用轨已关) ──
    _render_three_track_overview()

    # ── 策略信号蒸馏 + Agent 辩论 ──
    st.markdown('<div class="section-title">🧠 策略信号蒸馏 · Agent辩论</div>', unsafe_allow_html=True)

    # 加载缓存
    distill_text = load_latest()
    debate_cache = load_debate_cache()

    # 自动运行状态提示
    auto_status = ""
    if debate_cache and debate_cache.get("time_str"):
        auto_status = f"⏰ 最近更新: {debate_cache['time_str']}"
    if distill_text and not auto_status:
        auto_status = f"📄 蒸馏数据已就绪"
    if auto_status:
        st.markdown(f'<div style="color:#64ffda;font-size:0.75rem;margin-bottom:6px;">{auto_status}</div>',
                    unsafe_allow_html=True)

    # ── 1. 多策略共振 ──
    from distiller import get_bullish_stocks
    raw_consensus = get_bullish_stocks(min_signals=1)
    if raw_consensus:
        st.markdown(f'<div style="color:#ffd600;font-size:0.9rem;margin-top:4px;">'
                    f'🔔 按行情筛选的策略信号（{len(raw_consensus)}只, 单策略样本外胜率≥52%即可, 展示前3）</div>',
                    unsafe_allow_html=True)
        for s in raw_consensus[:3]:
            strat_str = ", ".join(s.get("strategies", []))[:60]
            st.markdown(
                f'<div style="display:flex;align-items:center;gap:8px;'
                f'background:#0d1117;border:1px solid #1a1d2e;border-radius:6px;'
                f'padding:6px 10px;margin:3px 0;">'
                f'<span style="font-weight:600;color:#ccd6f6;">{s["name"]}({s["code"]})</span>'
                f'<span style="color:#ff1744;font-weight:600;">{s["signal_count"]}个策略</span>'
                f'<span style="color:#8892b0;font-size:0.75rem;">[{strat_str}]</span>'
                f'</div>',
                unsafe_allow_html=True)

    # ── 2. 单一推荐（辩论共识 + 各别Agent推荐）──
    if debate_cache:
        consensus = debate_cache.get("consensus_buys", [])
        split = debate_cache.get("split_verdicts", [])

        if consensus:
            st.markdown(f'<div style="color:#ffd600;font-size:0.9rem;margin-top:4px;">'
                        f'🟢 各策略独立达标推荐 ({len(consensus)}只, 展示前3)</div>',
                        unsafe_allow_html=True)
            for item in consensus[:3]:
                agents_str = " · ".join(item["agents"])
                tag = "🟢强信号" if item.get("consensus") == "high" else "🟡达标信号"
                t1_html = ""
                if item.get("t1_avg"):
                    t1_cls = "pos" if item["t1_avg"] >= 0 else "neg"
                    t1_html = (f'<span style="font-size:0.75rem;color:#8892b0;">'
                               f'预期T+1 <b class="{t1_cls}">{item["t1_avg"]:+.2f}%</b> '
                               f'胜率{item.get("t1_win",0):.0f}%</span>')
                st.markdown(
                    f'<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;'
                    f'background:#0d1117;border:1px solid #1a1d2e;border-radius:6px;'
                    f'padding:6px 10px;margin:3px 0;">'
                    f'<span style="font-weight:600;">{item["name"]}({item["code"]})</span>'
                    f'<span style="font-size:0.8rem;color:{"#00c853" if item.get("consensus")=="high" else "#ffd600"};">{tag}</span>'
                    f'<span style="font-size:0.75rem;color:#8892b0;">{agents_str}</span>'
                    f'<span style="font-size:0.75rem;color:#64ffda;">置信度{item.get("confidence",0):.0f}%</span>'
                    f'{t1_html}'
                    f'</div>', unsafe_allow_html=True)

        if split:
            st.markdown(f'<div style="color:#64b5f6;font-size:0.85rem;margin-top:4px;">'
                        f'🔵 单一推荐（{len(split)}只各别Agent推荐, 展示前3）</div>',
                        unsafe_allow_html=True)
            for item in split[:3]:
                agents_str = " · ".join(item["agents"])
                st.markdown(
                    f'<span style="font-size:0.8rem;margin:2px 8px 2px 0;display:inline-block;">'
                    f'{item["name"]}({item["code"]}) {agents_str}</span>',
                    unsafe_allow_html=True)

    # ── 3. 最终交易计划 ──
    if debate_cache and debate_cache.get("final_plan"):
        plan_time = debate_cache.get("time_str", "未知")
        with st.expander(f"🏆 最终交易计划（{plan_time}）"):
            st.caption(f"生成日期: {plan_time} | 各策略独立达标信号, 以历史胜率/预期收益排序, 不要求共识")
            st.code(debate_cache["final_plan"], language="text")

    # ── 辩论推荐历史（自动记录每日推荐 + T+1回填） ──
    DEBATE_PICKS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "debate_picks")
    os.makedirs(DEBATE_PICKS_DIR, exist_ok=True)

    def _save_debate_picks():
        """将今日辩论共识推荐保存到历史记录"""
        if not debate_cache:
            return
        today = datetime.now().strftime("%Y%m%d")
        path = os.path.join(DEBATE_PICKS_DIR, f"{today}.json")
        if os.path.exists(path):
            return
        from stock_universe import is_eligible
        from debate_engine import MAX_DEBATE_PICKS

        def _strong(c):
            # 质控已在辩论引擎内完成(卡片按 walk-forward allowed 过滤, 单策略胜率>=52%即达标);
            # 共识/置信度仅作展示, 不再作放行条件
            return True

        consensus = [c for c in debate_cache.get("consensus_buys", [])
                     if is_eligible(c.get("code"), c.get("name"), c.get("price", 0))
                     and _strong(c)]
        # 封顶: 只保存最强的3~5只, 防旧缓存进程超发
        consensus.sort(key=lambda c: (len(c.get("agents", [])), float(c.get("confidence", 0) or 0)),
                       reverse=True)
        consensus = consensus[:MAX_DEBATE_PICKS]
        split = [s for s in debate_cache.get("split_verdicts", [])
                 if is_eligible(s.get("code"), s.get("name"), s.get("price", 0))]
        if not consensus and not split:
            # 空仓日也要落盘记录, 历史里明确展示"建议空仓"而非静默
            regime = debate_cache.get("regime") or {}
            record = {
                "date": today,
                "time_str": debate_cache.get("time_str", ""),
                "consensus_buys": [],
                "split_verdicts": [],
                "hold": "大盘深度破位，建议空仓观望" if regime.get("skip") else "无强信号，建议观望",
            }
            with open(path, "w", encoding="utf-8") as f:
                json.dump(record, f, ensure_ascii=False, indent=2, default=str)
            return
        try:
            qq = StockAPI.get_realtime_quotes()
        except:
            qq = None
        def _get_price(code):
            if qq is not None:
                rr = qq[qq["code"] == code]
                if not rr.empty:
                    return round(float(rr["price"].iloc[0]), 2)
            return 0
        record = {
            "date": today,
            "time_str": debate_cache.get("time_str", ""),
            "consensus_buys": [{"name": c["name"].strip("│ "), "code": c["code"],
                                "agents": c.get("agents", []),
                                "consensus": c.get("consensus", "mid"),
                                "confidence": c.get("confidence", 0),
                                "price": _get_price(c["code"]),
                                "t1_win": c.get("t1_win", 0),
                                "t1_avg": c.get("t1_avg", 0)} for c in consensus],
            "split_verdicts": [{"name": s["name"].strip("│ "), "code": s["code"],
                                "agents": s.get("agents", []),
                                "price": _get_price(s["code"])} for s in split],
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(record, f, ensure_ascii=False, indent=2, default=str)

    def _load_debate_picks_history(days=30):
        records = []
        if not os.path.isdir(DEBATE_PICKS_DIR):
            return records
        for fname in sorted(os.listdir(DEBATE_PICKS_DIR), reverse=True)[:days]:
            if fname.endswith(".json"):
                path = os.path.join(DEBATE_PICKS_DIR, fname)
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        records.append(json.load(f))
                except Exception:
                    pass
        return records

    def _enrich_debate_picks(records):
        today = datetime.now()
        changed_dates = set()
        cleaned_dates = set()  # 残留 null 被清理的日期, 需回写文件
        for rec in records:
            date_str = rec.get("date", "")
            if not date_str:
                continue
            buy_dt = datetime.strptime(date_str, "%Y%m%d")
            t1_date = _next_trading_day(buy_dt + timedelta(days=1))
            if today.date() < t1_date.date():
                continue
            t1_str = t1_date.strftime("%Y%m%d")

            def _on_fail(item):
                # 算不出T+1: 若确认停牌(最新K线早于T+1日)则打标不再重试; 否则不落null, 下次加载自动重试
                try:
                    # 探测窗口从T+1前30天开始, 覆盖停牌前最后K线
                    probe_start = (t1_date - timedelta(days=30)).strftime("%Y%m%d")
                    probe = StockAPI.get_historical_data(item["code"], probe_start, datetime.now().strftime("%Y%m%d"))
                    if probe is not None and not probe.empty:
                        last_date = probe["date"].max()
                        if pd.to_datetime(t1_str) > last_date:
                            item["t1_status"] = "suspended"
                            item["t1_last_date"] = last_date.strftime("%Y-%m-%d")
                            changed_dates.add(date_str)
                            return
                except Exception:
                    pass
                if "t1_actual_return" in item and item["t1_actual_return"] is None:
                    cleaned_dates.add(date_str)
                item.pop("t1_actual_return", None)
                item.pop("t1_close", None)

            all_stocks = rec.get("consensus_buys", []) + rec.get("split_verdicts", [])
            for item in all_stocks:
                # 已算出或已确认停牌(无T+1数据)则跳过; null/缺失视为未算, 允许下次重试
                if isinstance(item.get("t1_actual_return"), (int, float)):
                    continue
                if item.get("t1_status") == "suspended":
                    continue
                code = item["code"]
                try:
                    hist = StockAPI.get_historical_data(code, date_str, t1_str, adjust="qfq")
                    if hist is not None and len(hist) >= 2:
                        buy_row = hist[hist["date"] == pd.to_datetime(date_str)]
                        sell_row = hist[hist["date"] == pd.to_datetime(t1_str)]
                        if not buy_row.empty and not sell_row.empty:
                            qfq_buy = float(buy_row["close"].iloc[0])
                            qfq_sell = float(sell_row["close"].iloc[0])
                            if qfq_buy > 0:
                                item["t1_actual_return"] = round((qfq_sell / qfq_buy - 1) * 100, 2)
                                item["t1_close"] = round(qfq_sell, 2)
                                changed_dates.add(date_str)
                                continue
                    buy_price = float(item.get("price", 0) or 0)
                    hist2 = StockAPI.get_historical_data(code, t1_str, t1_str)
                    if buy_price > 0 and hist2 is not None and not hist2.empty:
                        actual_close = float(hist2["close"].iloc[-1])
                        item["t1_actual_return"] = round((actual_close / buy_price - 1) * 100, 2)
                        item["t1_close"] = round(actual_close, 2)
                        changed_dates.add(date_str)
                    else:
                        _on_fail(item)
                except Exception:
                    _on_fail(item)
        # 持久化: 将算出的T+1回写文件, 避免每次刷新重算导致掉数据; 顺带清理残留 null
        for rec in records:
            date_str = rec.get("date", "")
            if date_str not in changed_dates and date_str not in cleaned_dates:
                continue
            try:
                with open(os.path.join(DEBATE_PICKS_DIR, f"{date_str}.json"), "w", encoding="utf-8") as f:
                    json.dump(rec, f, ensure_ascii=False, indent=2, default=str)
            except Exception:
                pass
        return records

    # 保存今日推荐
    _save_debate_picks()

    # 加载并展示历史
    debate_history = _load_debate_picks_history(days=30)
    debate_history = _enrich_debate_picks(debate_history)

    today_str = datetime.now().strftime("%Y%m%d")
    all_history = []
    for rec in debate_history:
        all_items = rec.get("consensus_buys", [])  # 只统计强信号推荐, split_verdicts不计入历史
        label = "今日推荐" if rec.get("date", "") >= today_str else ""
        for item in all_items:
            item["_date"] = rec["date"]
            item["_label"] = label
        all_history.append(rec)

    st.markdown('<div class="section-title" style="margin-top:8px;">📈 辩论推荐历史 · T+1表现</div>', unsafe_allow_html=True)

    total_recommend = 0
    total_wins = 0
    limit_down_cnt = 0    # 次日大面(≤-9%)
    ret_sum = 0.0
    ret_n = 0
    hold_cnt = 0          # 建议空仓天数
    total_pnl = 0.0
    detail_rows = []
    for rec in all_history:
        date_str = rec.get("date", "")
        disp_date = f"{date_str[:4]}-{date_str[4:6]}-{date_str[6:8]}"
        is_today = date_str >= today_str
        items = rec.get("consensus_buys", [])
        n_items = len(items)  # 当日推荐只数, ¥5000按日等权分
        if not items:
            # 空仓日: 引擎无推荐, 明确展示原因而不是静默隐藏
            hold = rec.get("hold")
            if hold:
                hold_cnt += 1
                detail_rows.append({
                    "日期": disp_date,
                    "股票": f"⏸️ {hold}",
                    "类型": "空仓",
                    "价格": "—",
                    "T+1": "—",
                    "": "⏸️",
                })
            continue
        for item in items:  # 只统计强信号(3~5只), 弱单推不计入
            if item.get("t1_status") == "suspended":
                last = item.get("t1_last_date", "")
                r_disp = f"停牌({last[5:]})" if last else "停牌"
                icon = "⏸️"
            else:
                t1_ret = item.get("t1_actual_return")
                if t1_ret is not None:
                    total_recommend += 1
                    if t1_ret > 0:
                        total_wins += 1
                    if t1_ret <= -9:
                        limit_down_cnt += 1
                    ret_sum += t1_ret
                    ret_n += 1
                    # 真实模拟: 每日¥5000按当日N只等权, T收盘买→T+1收盘卖, 整手含费
                    t1_close = item.get("t1_close")
                    if n_items and isinstance(t1_close, (int, float)) and t1_close > 0:
                        sim = _sim_trade(t1_close / (1 + t1_ret / 100.0), t1_close, SIM_DAILY / n_items)
                        if sim:
                            total_pnl += sim[0]
                    r_disp = f"{t1_ret:+.2f}%"
                    icon = "✅" if t1_ret > 0 else "❌"
                elif is_today:
                    r_disp = "待更新"
                    icon = "🆕"
                else:
                    r_disp = "待更新"
                    icon = "⏳"
            tag = "🟢强信号" if item.get("consensus") == "high" else "🟡达标信号" if item.get("consensus") else "🔵单一推荐"
            price = item.get("price", 0)
            detail_rows.append({
                "日期": disp_date, "股票": f'{item.get("name","")} ({item.get("code","")})',
                "类型": tag, "价格": f"{price:.2f}" if price else "—", "T+1": r_disp, "": icon,
            })

    if detail_rows:
        sorted_rows = sorted(detail_rows, key=lambda x: x["日期"], reverse=True)
        if hold_cnt > 0:
            st.markdown(
                f'<div style="color:#8892b0;font-size:0.85rem;margin:2px 0 6px 0;">'
                f'⏸️ 其中 <b style="color:#ffd666">{hold_cnt}</b> 天建议空仓观望（大盘深度破位/无强信号），不计入胜率</div>',
                unsafe_allow_html=True,
            )
        if total_recommend > 0:
            win_rate = total_wins / total_recommend * 100
            avg_ret = ret_sum / ret_n if ret_n else 0
            c1, c2, c3, c4 = st.columns(4)
            with c1: st.markdown(metric_card("总推荐", total_recommend), unsafe_allow_html=True)
            with c2: st.markdown(metric_card("上涨", f'<span class="pos">{total_wins}</span>'), unsafe_allow_html=True)
            with c3: st.markdown(metric_card("下跌", f'<span class="neg">{total_recommend - total_wins}</span>'), unsafe_allow_html=True)
            with c4: st.markdown(metric_card("胜率", f'<span class="pos">{win_rate:.1f}%</span>'), unsafe_allow_html=True)
            c5, c6, c7 = st.columns(3)
            with c5: st.markdown(metric_card("平均T+1收益", f'<span class="{"pos" if avg_ret>=0 else "neg"}">{avg_ret:+.2f}%</span>'), unsafe_allow_html=True)
            with c6: st.markdown(metric_card("累计收益", f'<span class="{"pos" if total_pnl>=0 else "neg"}">¥{total_pnl:+,.2f}</span>'), unsafe_allow_html=True)
            with c7: st.markdown(metric_card("次日大面(≤-9%)", f'<span class="neg">{limit_down_cnt}</span>'), unsafe_allow_html=True)
            st.markdown('<div style="color:#495670;font-size:0.72rem;">※ 累计收益 = 每日¥5,000按当日N只推荐等权模拟：T日收盘买→T+1收盘卖，整手，含佣金(万2.5)/印花税(0.05%)/过户费(万0.1)；空仓日不计</div>', unsafe_allow_html=True)
        with st.expander("📋 辩论推荐明细（含T+1实际收益）", expanded=True):
            if sorted_rows:     # 与首页其他表格同款 st.dataframe 主题样式(红涨绿跌)
                def _deb_sign_color(v):
                    if not isinstance(v, str):
                        return ""
                    if v.strip() in ("", "—") or "待更新" in v or "停牌" in v:
                        return ""
                    m = re.search(r"[+-]\d", v)
                    if not m:
                        return ""
                    if m.group(0).startswith("-"):
                        return "color:#00c853;font-weight:600;"   # 绿 = 下跌
                    return "color:#ff1744;font-weight:600;"       # 红 = 上涨
                _ddf = pd.DataFrame(sorted_rows)
                _dcols = [c for c in ("T+1",) if c in _ddf.columns]
                _dsty = _ddf.style.map(_deb_sign_color, subset=_dcols) if _dcols else _ddf.style
                st.dataframe(_dsty, width='stretch', hide_index=True, max_rows=10)
    else:
        st.info("⏳ 暂无历史记录，今日收盘后自动保存，明日开始展示T+1表现")

    # ── 5. 策略卡片详情 ──
    st.markdown('<div class="section-title" style="margin-top:8px;">📄 策略卡片详情</div>', unsafe_allow_html=True)
    if distill_text:
        card_blocks = distill_text.split("┌────")
        if len(card_blocks) > 1:
            strategy_names = []
            for block in card_blocks[1:]:
                for line in block.split("\n"):
                    if "策略:" in line:
                        name = line.split("策略:")[-1].strip()
                        strategy_names.append(name)
                        break
            with st.expander("查看策略卡片"):
                selected = st.selectbox("选择策略", strategy_names, key="distill_strat_sel")
                if selected:
                    card_text = get_strategy_card(selected)
                    if card_text:
                        st.code(card_text, language="text")
                        st.download_button("📥 下载此卡片", card_text, f"{selected}_卡片.txt",
                                           width='stretch')
    else:
        st.info("💡 蒸馏数据由后台自动刷新生成（收盘后每小时重跑），当前暂无可用结果。")


def _send_close_brief():
    """收盘后: 先跑完整流水线扫描(background_scan + 龙头扫描), 再发首页简报邮件.
    与盘中槽位一致; 扫描在独立线程执行, 这里等其完成后(带超时)再发简报,
    保证简报基于最新收盘行情. 重扫受 recommender 早盘主选粘性约束."""
    try:
        background_scan(force=True)   # 收盘重扫: 每日推荐+top10缓存+指数回填, 受早盘粘性约束
        _dragon_scan_once()           # 同步龙头扫描(自带锁, 与槽位一致)
    except Exception:
        pass
    # 等待收盘重扫线程完成(至多 ~150s, 与卡死自愈阈值一致), 避免简报早于扫描落盘
    try:
        import time as _t
        _deadline = _t.time() + 150
        while _SCAN_REGISTRY.get("running") and _t.time() < _deadline:
            _t.sleep(0.5)
    except Exception:
        pass
    try:
        import mailer
        mailer.try_send_close_brief()
    except Exception:
        pass


def _catchup_close_brief():
    """启动补发: 交易日内已收盘且今日简报未发过 → 补发一次."""
    try:
        if not is_trading_day(datetime.now()):
            return
        cfg = load_config()
        if not cfg.get("enabled", True) or not cfg.get("generate_report", True):
            return
        if datetime.now().strftime("%H:%M") >= cfg.get("market_close", "15:05"):
            import mailer
            mailer.try_send_close_brief()
    except Exception:
        pass


def main():
    st.markdown(CSS, unsafe_allow_html=True)
    # 仅保留首页：启动直接展示首页, 刷新后自动回到首页（其余菜单已停用入口）
    render_sidebar()
    render_home()
    st.markdown('<div class="footer">QuantTrader v2.0 · 数据来源: AKShare · 仅供学习研究 · 不构成投资建议</div>', unsafe_allow_html=True)

def _dragon_scan_once():
    """盘中扫描槽位顺带跑龙头扫描(实时成交额排名+涨停过滤), 写入龙头live仓; 失败静默。

    修复: 此前 scan_dragon 从未接入调度回调, 导致龙头仓自 8/31 手动跑过一次后
    长期停摆、再无新仓位(首页龙头胜率样本薄、收益失真)。现挂到 on_scan 槽位每日自动扫描。
    """
    import threading
    _lock = getattr(_dragon_scan_once, "_lock", None)
    if _lock is None:
        _lock = threading.Lock()
        _dragon_scan_once._lock = _lock
    if not _lock.acquire(blocking=False):
        return  # 已有扫描在跑, 跳过本次, 避免并发写 store
    try:
        import dragon_strategy as D
        D.scan_dragon()
    except Exception:
        pass
    finally:
        _lock.release()


def _scan_with_dragon():
    """原 background_scan + 龙头扫描(修复龙头9/3后停摆)."""
    try:
        background_scan()
    except Exception:
        pass
    _dragon_scan_once()


if __name__ == "__main__":
    # ── 启动初始化(原版逻辑): 定时调度引擎 + 盘中自动扫描回调
    #    + 收盘模拟盘/简报回调 + 后台"回测→蒸馏→辩论→缓存"自动刷新
    scheduler.start()
    scheduler.set_callback("on_scan", _scan_with_dragon)
    scheduler.set_callback("on_paper_trading", paper_engine.daily_run)
    scheduler.set_callback("on_report", _send_close_brief)
    _catchup_close_brief()
    # 行情库自动补库守护(2026-09-07): 收盘后自动把当日bar入库; 盘中/重启后若发现缺此前已收盘交易日
    # (上次刷新被杀/服务停摆)立即后台追补 → 首页重放自然推进, 不再出现"昨日已该结算仍待买入"。
    try:
        from build_market_bars import start_bars_guard
        start_bars_guard()
    except Exception:
        pass
    start_auto_refresh(interval_seconds=3600)
    st.serve(main, port=8501)
