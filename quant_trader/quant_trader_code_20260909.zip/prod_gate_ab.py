# -*- coding: utf-8 -*-
"""
prod_gate_ab.py — 生产宇宙 A/B: 现行 in-sample 门槛(strategies_for_regime) vs 无门槛

回答: 生产 allowed 硬门槛(读 strategy_backtest.json, asof=昨日)在热门板块成分池上,
相对"任一策略信号即入池"是增信还是负贡献? 决定是否放开 allowed。

规格(与 walk-forward 一致的无泄漏骨架):
  - 宇宙 = 今日热门板块成分池(复刻 recommender: 噪声排除/count≥8/强度top5/成分top30), 137只;
  - 收益 = D+1 开盘买入→D+1 收盘卖出(open 真实口径), 一字开盘买不进过滤, 扣 0.20% 成本;
  - 逐日 D: gate_arm = 当日档位 gate 集合命中任一策略信号的股票池;
            nogate_arm = 任一策略信号的股票池(无门槛);
  - 配对 bootstrap 1 万次 → 均值差 90%CI + P(差>0); 逐档位; NAV/maxDD/Sharpe。
  - 披露: in-sample 门槛是"今日刷新(asof=昨日)的固定门槛回放历史", 非逐日 walk-forward 刷新。

预注册判定:
  #1 gate 胜: mean(gate) ≥ mean(nogate)+0.2pp 且 bootstrap 90%CI 下界>0 → "门槛增信, 保留"
  #2 否则(含负值/不显著): "门槛不增信, 建议放开 allowed" — 再给逐档位明细供判断。
输出: data/ranker_experiment/prod_gate_ab.json
"""
import json
import os
import sys
from collections import defaultdict

import numpy as np
import pandas as pd

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

from concurrent.futures import ThreadPoolExecutor, as_completed

from stock_api import StockAPI
from experiment_common import fetch_hist_cached, hist_window, load_index_regimes
from strategy_backtest import _prev_trading_day, strategies_for_regime
from sector_pool_walkforward import (
    _build_hot_sector_universe, _bootstrap_diff, _nav_stats, _stats,
    COST, WARMUP, BOOT_N, SEED,
)

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "data", "ranker_experiment", "prod_gate_ab.json")
REGIMES = ["strong", "normal", "weak", "crash"]


def run(lookback_days=400, asof=None, hot_sectors=5, cost=COST):
    if asof is None:
        asof = _prev_trading_day()
    asof_ts = pd.Timestamp(asof).normalize()
    print(f"生产宇宙 A/B(门槛vs无门槛): top{hot_sectors}板块 | 窗口{lookback_days} | asof={asof_ts.date()} | 扣{cost}%")

    codes, hot = _build_hot_sector_universe(max_sectors=hot_sectors)
    if not codes:
        print("热门板块接口失败/空池"); return None
    print(f"宇宙 {len(codes)} 只 | " + "、".join(s.get("name", "") for s in hot))

    regimes, idx = load_index_regimes(lookback_days, asof)
    if idx is None:
        print("指数不足"); return None

    start_str, end_str = hist_window(asof_ts, lookback_days)
    hist_cache = {}

    def _pass(cands, workers):
        got = {}
        with ThreadPoolExecutor(max_workers=workers) as ex:
            fs = {ex.submit(fetch_hist_cached, c, start_str, end_str, asof): c for c in cands}
            for f in as_completed(fs):
                try:
                    h = f.result()
                except Exception:
                    h = None
                if h is not None and len(h) >= 30:
                    got[fs[f]] = h
        return got

    hist_cache.update(_pass(codes, 8))
    for backoff in (15, 45, 120):
        missing = [c for c in codes if c not in hist_cache]
        if not missing:
            break
        print(f"缺失 {len(missing)}, 退避 {backoff}s...")
        import time
        time.sleep(backoff)
        hist_cache.update(_pass(missing, 6))
    print(f"个股历史 {len(hist_cache)}/{len(codes)}")

    # 现行 in-sample 门槛(生产口径): 每档位允许策略集
    gate_map = {r: set(strategies_for_regime(r)) for r in REGIMES}
    print("生产门槛(每档位 allowed 策略数): " + ", ".join(f"{r}={len(gate_map[r])}" for r in REGIMES))

    from strategies import list_strategies, get_strategy
    strategies = [n for n in list_strategies() if n != "组合策略·投票系统"]

    # day_map: date -> [(code, open_ret, strategies_set)]
    day_map = defaultdict(list)
    for sname in strategies:
        try:
            stg = get_strategy(sname)
        except Exception:
            continue
        if stg is None:
            continue
        for code, hist in hist_cache.items():
            try:
                sdf = stg.generate_signals(hist.copy())
            except Exception:
                continue
            if "signal" not in sdf.columns:
                continue
            sig = sdf["signal"].astype(float).values
            closes = hist["close"].astype(float).values
            opens = hist["open"].astype(float).values
            highs = hist["high"].astype(float).values
            lows = hist["low"].astype(float).values
            dates = hist["date"].values
            n = len(sig)
            for i in range(WARMUP, n - 1):
                if sig[i] <= 0 or closes[i] <= 0 or opens[i + 1] <= 0:
                    continue
                d = pd.Timestamp(dates[i]).normalize()
                if d not in regimes:
                    continue
                o = closes[i + 1] / opens[i + 1] - 1
                oneword = (highs[i + 1] - lows[i + 1]) < 0.03 and opens[i + 1] >= highs[i + 1] - 0.005
                if oneword:
                    continue
                day_map[d].append((code, o * 100, sname))
    print(f"信号日 {len(day_map)} | 信号条数 {sum(len(v) for v in day_map.values())}")

    daily = {"gate": {}, "nogate": {}}
    for d in sorted(day_map.keys()):
        rg = regimes[d]
        gset = gate_map.get(rg, set())
        per_stock = {}
        for code, o, sname in day_map[d]:
            a = per_stock.setdefault(code, {"s": set(), "o": o})
            a["s"].add(sname)
        p_gate = [v["o"] for v in per_stock.values() if v["s"] & gset]
        p_nogate = [v["o"] for v in per_stock.values()]
        daily["gate"][d] = (float(np.mean(p_gate)) - cost) if p_gate else 0.0
        daily["nogate"][d] = (float(np.mean(p_nogate)) - cost) if p_nogate else 0.0

    result = {"meta": {"asof": asof_ts.strftime("%Y%m%d"), "universe": "hot_sector",
                       "stocks": len(hist_cache), "cost": cost, "hot_sectors": hot_sectors,
                       "gate_source": "strategies_for_regime(asof=昨日, open口径)",
                       "note": "in-sample门槛固定回放历史(非逐日刷新), 披露方向=高估门槛"}, "daily": {}}
    for arm in daily:
        vals = list(daily[arm].values())
        result[arm] = {**_stats(vals), **_nav_stats({i: v for i, v in enumerate(vals)})}
        result["daily"][arm] = {str(k.date()): round(v, 3) for k, v in daily[arm].items()}

    dk = sorted(set(daily["gate"]) | set(daily["nogate"]))
    g = [daily["gate"].get(d, 0.0) for d in dk]
    ng = [daily["nogate"].get(d, 0.0) for d in dk]
    m, lo, hi, p = _bootstrap_diff(g, ng)
    result["comparison"] = {"gate_minus_nogate_pp": m, "ci90": [lo, hi], "p_gt0": p}

    # 逐档位
    reg = {}
    for r in REGIMES:
        gd = [daily["gate"].get(d, 0.0) for d in dk if regimes.get(d) == r]
        nd = [daily["nogate"].get(d, 0.0) for d in dk if regimes.get(d) == r]
        row = {"days": len(gd), "gate_mean": round(float(np.mean(gd)), 3) if gd else None,
               "nogate_mean": round(float(np.mean(nd)), 3) if nd else None}
        if gd and nd:
            mm, loo, hii, pp = _bootstrap_diff(gd, nd)
            row["gate_minus_nogate_pp"] = mm
            row["ci90"] = [loo, hii]
            row["p_gt0"] = pp
        reg[r] = row
    result["per_regime"] = reg

    # 预注册判定
    v1 = bool(m >= 0.2 and lo > 0)
    result["verdict"] = {
        "#1_gate_wins": v1,
        "rule": "gate ≥ nogate+0.2pp 且 90%CI下界>0 → 门槛增信保留; 否则建议放开 allowed",
        "conclusion": "门槛增信, 保留 allowed" if v1 else "门槛不增信, 建议放开 allowed(逐档位见明细)",
    }

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print("\n全窗口(已扣成本):")
    for arm in ("gate", "nogate"):
        r = result[arm]
        print(f"  {arm:<7} mean={r['mean']:+.3f}% win={r['win_rate']}% | maxDD={r['maxDD']:+.1f}% "
              f"sharpe={r['sharpe']} cum={r['cum_pct']:+.1f}% n={r['n']}")
    c = result["comparison"]
    print(f"\ngate−nogate: {c['gate_minus_nogate_pp']:+.3f}pp CI90[{c['ci90'][0]:+.3f},{c['ci90'][1]:+.3f}] P(>0)={c['p_gt0']}")
    print("\n逐档位:")
    for r, row in result["per_regime"].items():
        print(f"  {r:<6} days={row['days']:>3} gate={str(row.get('gate_mean')):>8} "
              f"nogate={str(row.get('nogate_mean')):>8} | gate-nogate={row.get('gate_minus_nogate_pp','—')}")
    print(f"\n判定 #1: {result['verdict']['#1_gate_wins']} → {result['verdict']['conclusion']}")
    print(f"结果 → {OUT}")
    return result


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--lookback-days", type=int, default=400)
    ap.add_argument("--asof", default=None)
    ap.add_argument("--hot-sectors", type=int, default=5)
    args = ap.parse_args()
    run(lookback_days=args.lookback_days, asof=args.asof, hot_sectors=args.hot_sectors)
