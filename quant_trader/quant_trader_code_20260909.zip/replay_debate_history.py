"""用修改后的辩论引擎回放 2026-07-10 → 今天 的推荐历史。

模型: "前收市回放" (无未来函数). 历史辩论多在前一日收盘后/当日开盘前运行,
因此对每个目标交易日 D:
  1. 取 D 之前最后一版蒸馏快照 (日期严格早于 D) 作为当日策略卡片
  2. 用上证指数截断到 D 之前 (不含 D) 的收盘数据算当日大盘档位(regime)
  3. 以这些卡片 + regime 跑完整辩论(含修改后的杂毛硬剔除门槛)
  4. 将 consensus_buys 落盘到 data/debate_picks/{D}.json (同现有 schema)

T+1 实际收益由 app 加载时 _enrich_debate_picks 自动补齐, 本脚本不写。
运行前会把现有 debate_picks 备份到 data/debate_picks_backup_20260810/。
"""
import os
import sys
import json
import glob
import shutil
import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

from debate_engine import DebateAgent, DebateModerator, AGENT_ROLES, _parse_card_text  # noqa: E402
from stock_api import StockAPI  # noqa: E402
from recommender import index_regime  # noqa: E402

DATA_DIR = os.path.join(ROOT, "data")
DISTILLED_DIR = os.path.join(DATA_DIR, "distilled")
PICKS_DIR = os.path.join(DATA_DIR, "debate_picks")
BACKUP_DIR = os.path.join(DATA_DIR, "debate_picks_backup_20260810")

START = "20260710"
END = "20260810"


def parse_cards_from_file(path):
    with open(path, encoding="utf-8") as f:
        text = f.read()
    cards = []
    for block in text.split("┌────")[1:]:
        block = "┌────" + block
        parsed = _parse_card_text(block)
        if parsed and parsed.get("name"):
            cards.append(parsed)
    return cards


def snapshot_before(day, all_snapshots, inclusive=False):
    """取最后一版蒸馏快照. inclusive=False 用日期严格早于 day (D 开盘前可见);
    inclusive=True 允许含 day 当日 (仅用于"今天"的最后一次回放, 无未来函数问题)."""
    pool = [s for s in all_snapshots if s["day"] <= day] if inclusive else [s for s in all_snapshots if s["day"] < day]
    return pool[-1]["path"] if pool else None


def regime_before(day, index_df):
    """用 D 之前(不含 D) 的指数收盘算大盘档位, 避免未来函数"""
    if index_df is None:
        return None
    sub = index_df[index_df["date"] < pd.to_datetime(day)]
    if len(sub) < 25:
        return None
    return index_regime(sub)


def trading_days(index_df, start, end):
    if index_df is None:
        return []
    days = index_df[(index_df["date"] >= pd.to_datetime(start))
                    & (index_df["date"] <= pd.to_datetime(end))]
    return [d.strftime("%Y%m%d") for d in sorted(days["date"].unique())]


def main():
    # 1. 备份现有历史
    os.makedirs(BACKUP_DIR, exist_ok=True)
    existing = sorted(glob.glob(os.path.join(PICKS_DIR, "*.json")))
    copied = 0
    for p in existing:
        name = os.path.basename(p)
        dst = os.path.join(BACKUP_DIR, name)
        if not os.path.exists(dst):
            shutil.copy2(p, dst)
            copied += 1
    print(f"[1/3] 备份现有历史 {copied}/{len(existing)} 个文件 → {BACKUP_DIR}")

    # 2. 交易日历 + 大盘指数 + 蒸馏快照索引(一次收集, 各日取 D 之前最后一版)
    index_df = StockAPI.get_index_historical_data("sh000001", days=160)
    days = trading_days(index_df, START, END)
    if not days:
        print("获取交易日历失败, 中止")
        return
    all_snapshots = []
    for p in sorted(glob.glob(os.path.join(DISTILLED_DIR, "distilled_*.txt"))):
        base = os.path.basename(p)
        all_snapshots.append({"day": base.split("_")[1], "path": p})
    print(f"[2/3] 回放 {len(days)} 个交易日: {days[0]} → {days[-1]}")

    # 3. 逐日回放
    n_cards_total = 0
    n_picks_total = 0
    for i, day in enumerate(days, 1):
        # 今天用当日最新快照(实时数据), 历史日严格用 D 之前数据(无未来函数)
        snap = snapshot_before(day, all_snapshots, inclusive=(day == days[-1]))
        if not snap:
            print(f"    {day}: ⚠️ 无蒸馏快照, 跳过")
            continue
        cards = parse_cards_from_file(snap)
        regime = regime_before(day, index_df)
        n_cards_total += len(cards)

        # 与 run_debate() 一致: 大盘深度破位 → 空仓观望, 当日不生成推荐
        hold = None
        if regime and regime.get("skip"):
            consensus = []
            hold = "大盘深度破位，建议空仓观望"
        else:
            # 注: 卡片的 regime 策略过滤依赖 strategy_backtest.json(随时间滚动),
            # 无法还原历史当日的回测结果, 故回放按全部卡片辩论(regime=None),
            # 只保留"深度破位空仓"这一可复现的大盘门控。
            agents = [DebateAgent(name, cfg) for name, cfg in AGENT_ROLES.items()]
            mod = DebateModerator(agents)
            result = mod.run_debate(regime=None, cards=cards)
            if not result:
                print(f"    {day}: ⚠️ 无卡片可辩, 跳过")
                continue
            consensus = []
            for it in result.get("consensus_buys", []):
                consensus.append({
                    "name": str(it.get("name", "")).strip("│ "),
                    "code": it.get("code", ""),
                    "agents": it.get("agents", []),
                    "consensus": it.get("consensus", "mid"),
                    "confidence": round(float(np.mean(it.get("confidences", [0]))), 1) if it.get("confidences") else 0,
                    "price": round(float(it.get("price", 0) or 0), 2),
                    "t1_win": round(float(it.get("t1_win", 0) or 0), 1),
                    "t1_avg": round(float(it.get("t1_avg", 0) or 0), 2),
                })
            if not consensus:
                hold = "无强信号，建议观望"
        record = {
            "date": day,
            "time_str": f"{day[:4]}-{day[4:6]}-{day[6:]} 15:00:00",
            "consensus_buys": consensus,
            "split_verdicts": [],
        }
        if hold:
            record["hold"] = hold
        out = os.path.join(PICKS_DIR, f"{day}.json")
        with open(out, "w", encoding="utf-8") as f:
            json.dump(record, f, ensure_ascii=False, indent=2, default=str)
        n_picks_total += len(consensus)
        level = (regime or {}).get("level", "-")
        picks_str = ", ".join(f"{c['name']}({c['code']}){c['consensus']}" for c in consensus) or "(空仓)"
        print(f"    {day} [{level}] 卡片{len(cards)} 推荐{len(consensus)}: {picks_str}")

    print(f"[3/3] 完成: 共 {len(days)} 日, 卡片总数 {n_cards_total}, 推荐总数 {n_picks_total}")


if __name__ == "__main__":
    main()
