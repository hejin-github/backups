# -*- coding: utf-8 -*-
"""
Stage3 稳健性: 主实验结论(按行情切换 ranker)的方向是否稳健

敏感性扫描(每个给 PASS/FAIL = 方向与主实验一致, 允许幅度变、不允许符号反转):
  B 更大样本: 400交易日×300只 (需先 python experiment_common.py --trade-days 400 --sample-limit 300 --out-name 400x300)
  C 50/50 切分(替代 60/40)
  R 滚动 20 日重估 ranker map(最贴近部署: D 日只用 date<D 的近 20 个交易日)
  G gap_days>5 停牌恢复剔除开关
  L limit_up_close 涨停一字剔除开关
  K 成本档位 {0,10,20,30}bp
输出: data/ranker_experiment/sensitivity.json
"""
import argparse
import json
import os
import sys

import numpy as np
import pandas as pd

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

from ranker_regime_experiment import (REGIMES, RANKERS, DEFAULT_RANKER, pick_day,
                                      _stats, _nav_metrics, _bootstrap_ci)

BASE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(BASE, "data", "ranker_experiment")
DEFAULT_CSV = os.path.join(OUT_DIR, "candidates.csv")
BIG_CSV = os.path.join(OUT_DIR, "candidates_400x300.csv")

TRAIN_FRAC = 0.6
BOOT_N = 10000


def load(csv):
    df = pd.read_csv(csv, dtype={"date": str, "code": str})
    df["date"] = df["date"].astype(str)
    return df


def precompute_day_ret(day_groups):
    """day -> {ranker: top1 毛ret} 一次性算好, 供各扫描复用."""
    out = {}
    for d, grp in day_groups.items():
        if grp is None or grp.empty:
            out[d] = {rk: 0.0 for rk in RANKERS}
            continue
        out[d] = {rk: (pick_day(grp, rk) or [0.0])[0] for rk in RANKERS}
    return out


def _split_days(all_days, frac):
    split_at = all_days[int(len(all_days) * frac)]
    return [d for d in all_days if d < split_at], [d for d in all_days if d >= split_at]


def _train_map(train_days, d_regime, day_ret):
    """训练段每档位选 ranker(护栏同主实验) → {regime: ranker}"""
    best = {}
    for regime in REGIMES:
        if regime == "crash":
            best[regime] = "skip"
            continue
        tdays = sum(1 for d in train_days if d_regime[d] == regime)
        cands = []
        for rk in RANKERS:
            rets = [day_ret[d][rk] for d in train_days
                    if d_regime[d] == regime and day_ret[d][rk] != 0]
            if len(rets) >= 30:
                cands.append((rk, _stats(rets)))
        if tdays < 15 or not cands:
            best[regime] = DEFAULT_RANKER
            continue
        b = max(cands, key=lambda x: x[1]["mean"])
        best[regime] = b[0] if b[1]["win_rate"] >= 50.0 else DEFAULT_RANKER
    return best


def eval_map(test_days, d_regime, day_ret, rank_map, cost):
    """按 rank_map 取每日 top1 净收益序列 + 毛均值. crash 日一律空仓(与生产 skip 门一致)."""
    vals = []
    for d in test_days:
        rg = d_regime.get(d, "crash")
        rk = rank_map.get(rg, "skip")
        vals.append(day_ret[d][rk] if rg != "crash" and rk != "skip" else 0.0)
    gross = np.array(vals)
    net = np.where(gross != 0, gross - cost, 0.0)
    return gross, net


def rolling_map(all_days, d_regime, day_ret, window=20):
    """对每个 D, 只用 date<D 的近 window 个交易日估计 ranker map(部署最贴近)."""
    maps = {}
    for ix, d in enumerate(all_days):
        win = all_days[max(0, ix - window):ix]
        if len(win) < 10:
            maps[d] = {r: DEFAULT_RANKER for r in REGIMES}
            continue
        maps[d] = _train_map(win, d_regime, day_ret)
    return maps


def run(csv=DEFAULT_CSV, train_frac=TRAIN_FRAC, cost=0.20, roll_window=20):
    df = load(csv)
    d_regime = dict(zip(df["date"], df["regime"]))
    day_groups = {d: g for d, g in df.groupby("date")}
    all_days = sorted(day_groups.keys())
    train_days, test_days = _split_days(all_days, train_frac)
    day_ret = precompute_day_ret(day_groups)
    print(f"候选行 {len(df)} | 日期 {len(all_days)} | 训练{len(train_days)} 测试{len(test_days)}")

    main_map = _train_map(train_days, d_regime, day_ret)
    _, a_net = eval_map(test_days, d_regime, day_ret, {r: DEFAULT_RANKER for r in REGIMES}, cost)
    _, c_net = eval_map(test_days, d_regime, day_ret, main_map, cost)
    main_diff = float(c_net.mean() - a_net.mean())
    print(f"主实验方向: C净均值-A净均值 = {main_diff:+.3f}pp (符号=主结论方向)")

    sweeps = {}
    sign = np.sign(main_diff)

    def _verdict(cur_diff):
        return "PASS" if np.sign(cur_diff) == sign else "FAIL"

    # ── C 50/50 切分 ──
    tr2, te2 = _split_days(all_days, 0.5)
    m2 = _train_map(tr2, d_regime, day_ret)
    _, a2 = eval_map(te2, d_regime, day_ret, {r: DEFAULT_RANKER for r in REGIMES}, cost)
    _, c2 = eval_map(te2, d_regime, day_ret, m2, cost)
    d2 = float(c2.mean() - a2.mean())
    sweeps["50_50_split"] = {"diff_pp": round(d2, 4), "verdict": _verdict(d2),
                             "C_map": m2}
    print(f"50/50: diff {d2:+.3f}pp [{_verdict(d2)}]")

    # ── R 滚动 20 日重估 ──
    rmaps = rolling_map(all_days, d_regime, day_ret, roll_window)
    rgross = np.array([day_ret[d][rmaps[d].get(d_regime.get(d), "skip")]
                       if rmaps[d].get(d_regime.get(d)) != "skip" else 0.0 for d in test_days])
    rnet = np.where(rgross != 0, rgross - cost, 0.0)
    dr = float(rnet.mean() - a_net.mean())
    sweeps[f"rolling_{roll_window}d"] = {"diff_pp": round(dr, 4), "verdict": _verdict(dr),
                                         "note": "证据不足的档位自动回退R_twr"}
    print(f"滚动{roll_window}日: diff {dr:+.3f}pp [{_verdict(dr)}]")

    # ── G 停牌恢复剔除(gap_days>5) ──
    dfg = df[df["gap_days"] <= 5]
    dg = {d: g for d, g in dfg.groupby("date")}
    ag = {d: {rk: 0.0 for rk in RANKERS} for d in all_days}
    for d, grp in dg.items():
        if grp is None or grp.empty:
            continue
        ag[d] = {rk: (pick_day(grp, rk) or [0.0])[0] for rk in RANKERS}
    _, a_g = eval_map(test_days, d_regime, ag, {r: DEFAULT_RANKER for r in REGIMES}, cost)
    _, c_g = eval_map(test_days, d_regime, ag, main_map, cost)
    dg_ = float(c_g.mean() - a_g.mean())
    sweeps["gap_gt5_excluded"] = {"diff_pp": round(dg_, 4), "verdict": _verdict(dg_),
                                  "rows": int(len(dfg))}
    print(f"剔除停牌: diff {dg_:+.3f}pp [{_verdict(dg_)}]")

    # ── L 涨停一字剔除(limit_up_close==1) ──
    dfl = df[df["limit_up_close"] != 1]
    dl_ = {d: g for d, g in dfl.groupby("date")}
    al = {d: {rk: 0.0 for rk in RANKERS} for d in all_days}
    for d, grp in dl_.items():
        if grp is None or grp.empty:
            continue
        al[d] = {rk: (pick_day(grp, rk) or [0.0])[0] for rk in RANKERS}
    _, a_l = eval_map(test_days, d_regime, al, {r: DEFAULT_RANKER for r in REGIMES}, cost)
    _, c_l = eval_map(test_days, d_regime, al, main_map, cost)
    dl2 = float(c_l.mean() - a_l.mean())
    sweeps["limit_up_excluded"] = {"diff_pp": round(dl2, 4), "verdict": _verdict(dl2),
                                   "rows": int(len(dfl))}
    print(f"剔除涨停一字: diff {dl2:+.3f}pp [{_verdict(dl2)}]")

    # ── K 成本档位 ──
    for bp in (0, 10, 20, 30):
        ct = bp / 100.0
        _, a_n = eval_map(test_days, d_regime, day_ret, {r: DEFAULT_RANKER for r in REGIMES}, ct)
        _, c_n = eval_map(test_days, d_regime, day_ret, main_map, ct)
        dk = float(c_n.mean() - a_n.mean())
        sweeps[f"cost_{bp}bp"] = {"diff_pp": round(dk, 4), "verdict": _verdict(dk)}
    print("成本档位: " + ", ".join(f"{bp}bp:{sweeps[f'cost_{bp}bp']['diff_pp']:+.3f}"
                                   for bp in (0, 10, 20, 30)))

    # ── B_global 全局单一最佳 ranker(实验次要发现) vs A 现R_twr, 同过滤稳健性 ──
    def _global_best_train(tr_days, dr):
        gb, gbm = DEFAULT_RANKER, -1e9
        for rk in RANKERS:
            ar = [dr[d][rk] for d in tr_days if d_regime[d] != "crash" and dr[d][rk] != 0]
            m = float(np.mean(ar)) if ar else -1e9
            if m > gbm:
                gb, gbm = rk, m
        return gb

    def _b_vs_a(dfx, frac):
        dg = {d: g for d, g in dfx.groupby("date")}
        dr = precompute_day_ret(dg)
        tr, te = _split_days(sorted(dg.keys()), frac)
        gb = _global_best_train(tr, dr)
        mp = {r: gb for r in REGIMES}
        _, an = eval_map(te, d_regime, dr, {r: DEFAULT_RANKER for r in REGIMES}, cost)
        _, bn = eval_map(te, d_regime, dr, mp, cost)
        return float(bn.mean() - an.mean()), gb, len(te)

    def _b_verdict(d):  # 方向须与主库同号(+ 表示 B 优于 A)
        return "PASS" if d > 0 else "FAIL"

    b_main, gb_main, _ = _b_vs_a(df, train_frac)
    b50, gb50, _ = _b_vs_a(df, 0.5)
    b_gap, gb_gap, _ = _b_vs_a(df[df["gap_days"] <= 5], train_frac)
    b_lim, gb_lim, _ = _b_vs_a(df[df["limit_up_close"] != 1], train_frac)
    sweeps["B_global_vs_A_主库"] = {"diff_pp": round(b_main, 4), "B_ranker": gb_main,
                                    "verdict": _b_verdict(b_main)}
    sweeps["B_global_vs_A_50_50"] = {"diff_pp": round(b50, 4), "B_ranker": gb50,
                                     "verdict": _b_verdict(b50)}
    sweeps["B_global_vs_A_剔除停牌"] = {"diff_pp": round(b_gap, 4), "B_ranker": gb_gap,
                                       "verdict": _b_verdict(b_gap)}
    sweeps["B_global_vs_A_剔除涨停一字"] = {"diff_pp": round(b_lim, 4), "B_ranker": gb_lim,
                                          "verdict": _b_verdict(b_lim),
                                          "note": "方向反转→表观优势来自买不进的涨停一字板"}
    print(f"B全局最佳 vs A: 主库{b_main:+.3f} 50/50:{b50:+.3f} 剔停牌:{b_gap:+.3f} 剔涨停:{b_lim:+.3f}")

    # ── B 更大样本(400日×300只, 需预建库) ──
    if os.path.exists(BIG_CSV):
        dfb = load(BIG_CSV)
        d_reg_b = dict(zip(dfb["date"], dfb["regime"]))
        dg_b = {d: g for d, g in dfb.groupby("date")}
        all_b = sorted(dg_b.keys())
        tr_b, te_b = _split_days(all_b, train_frac)
        dr_b = precompute_day_ret(dg_b)
        map_b = _train_map(tr_b, d_reg_b, dr_b)
        _, a_b = eval_map(te_b, d_reg_b, dr_b, {r: DEFAULT_RANKER for r in REGIMES}, cost)
        _, c_b = eval_map(te_b, d_reg_b, dr_b, map_b, cost)
        db = float(c_b.mean() - a_b.mean())
        sweeps["400x300"] = {"diff_pp": round(db, 4), "verdict": _verdict(db),
                             "C_map": map_b, "rows": int(len(dfb))}
        print(f"400×300: diff {db:+.3f}pp [{_verdict(db)}]")
    else:
        sweeps["400x300"] = {"skipped": True, "note": "需先 python experiment_common.py --trade-days 400 --sample-limit 300 --out-name 400x300"}
        print("400×300: 库未建, 跳过 (可后用 --out-name 400x300 补建)")

    rule5 = all(s.get("verdict", "PASS") == "PASS" for s in sweeps.values())
    res = {"main": {"diff_pp": round(main_diff, 4), "sign": int(sign)},
           "sweeps": sweeps,
           "rule5_direction_stable": bool(rule5),
           "note": "方向允许幅度变, 不允许符号反转"}
    os.makedirs(OUT_DIR, exist_ok=True)
    with open(os.path.join(OUT_DIR, "sensitivity.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)
    print(f"\nrule#5 方向稳健: {'PASS' if rule5 else 'FAIL'} → {os.path.join(OUT_DIR, 'sensitivity.json')}")
    return res


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default=DEFAULT_CSV)
    ap.add_argument("--train-frac", type=float, default=TRAIN_FRAC)
    ap.add_argument("--cost", type=float, default=0.20)
    ap.add_argument("--roll-window", type=int, default=20)
    args = ap.parse_args()
    run(csv=args.csv, train_frac=args.train_frac, cost=args.cost, roll_window=args.roll_window)
