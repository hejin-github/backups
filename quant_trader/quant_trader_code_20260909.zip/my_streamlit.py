# -*- coding: utf-8 -*-
"""
Streamlit 兼容层 —— 基于标准库 http.server 的轻量 Web 渲染框架。

作用：让 app.py 以 `import my_streamlit as st` 替换 `import streamlit as st`，
其余 st.* 调用几乎零改动即可运行在原生 http.server 上，彻底剥离 Streamlit。
- 每个 GET/POST 请求重新执行一次 main()，输出纯 HTML（无 iframe / websocket / 组件开销）
- 按钮通过 URL `__act` 参数触发；表单控件值保存在进程级 session_state，URL 参数恢复
- 表格支持 max_rows 前端折叠展开（纯 JS，不触发服务端刷新）——解决"展开剩余记录全页刷新"问题

用法：
    import my_streamlit as st
    def main():
        st.markdown("<h1>hi</h1>", unsafe_allow_html=True)
    if __name__ == "__main__":
        st.serve(main, port=8501)
"""
import http.server
import time
import urllib.parse
import html as _html
import re
import base64
import threading
import traceback
import webbrowser
from contextlib import contextmanager
from datetime import date, datetime

# ─────────────────────────── 请求上下文 ───────────────────────────
_CTX = {
    "query": {},        # GET/POST 合并参数 {name: value(末个)}
    "path": "/",
    "action": None,     # 当前触发的按钮 key（来自 __act）
    "action_used": False,
    "in_sidebar": False,
    "rerun_round": 0,
}

# ─────────────────────────── 会话状态（进程级，等价 streamlit.session_state） ───────────────────────────
class _SessionState(dict):
    def __getattr__(self, k):
        try:
            return self[k]
        except KeyError:
            raise AttributeError(f"session_state has no attribute '{k}'")

    def __setattr__(self, k, v):
        self[k] = v

session_state = _SessionState()
session_state.setdefault("page", "首页")

# ─────────────────────────── 查询参数（等价 streamlit.query_params） ───────────────────────────
class _QueryParams:
    def __getitem__(self, k):
        return _CTX["query"].get(k, "")

    def get(self, k, d=None):
        return _CTX["query"].get(k, d)

    def __contains__(self, k):
        return k in _CTX["query"]

    def __setitem__(self, k, v):
        pass  # 赋值忽略：URL 由页面链接决定

    def __str__(self):
        return str(_CTX["query"])

query_params = _QueryParams()

# ─────────────────────────── 渲染缓冲 ───────────────────────────
_MAIN_BUF = []   # 主内容区
_SIDE_BUF = []   # 侧边栏

def _cur_buf():
    return _SIDE_BUF if _CTX["in_sidebar"] else _MAIN_BUF


# 容器渲染路由：with col/tab/expander 期间 st.* 内容进入对应面板缓冲；
# 组容器(columns/tabs/expander)在创建点放占位 marker，渲染结束时统一替换为实际 HTML。
_BUF_STACK = []   # 活动面板缓冲栈
_PENDING = []     # 待渲染的组容器（按创建顺序记录，倒序 finalize 先处理嵌套内层）


def _cur_target():
    """当前内容的目标缓冲：活动面板优先，否则主/侧边栏缓冲。"""
    return _BUF_STACK[-1] if _BUF_STACK else _cur_buf()


class _Pending:
    """布局组容器基类：创建时在目标缓冲插入占位，finalize 时替换为 _html()。"""

    def __init__(self, target):
        self.target = target
        self.marker = object()
        target.append(self.marker)
        _PENDING.append(self)
        self._done = False

    def _html(self):
        raise NotImplementedError

    def finalize(self):
        if self._done:
            return
        self._done = True
        buf = self.target
        for i, x in enumerate(buf):
            if x is self.marker:
                buf[i:i + 1] = [self._html()]
                return


def _flush_pending():
    """渲染结束时按创建逆序组装所有组容器（先处理嵌套内层）。"""
    for p in reversed(_PENDING):
        p.finalize()
    _PENDING.clear()

# ─────────────────────────── 控制流异常 ───────────────────────────
class _Rerun(Exception):
    pass

class _Stop(Exception):
    pass

# ─────────────────────────── HTML 工具 ───────────────────────────
_uid_counter = [0]

def _uid():
    _uid_counter[0] += 1
    return f"u{_uid_counter[0]}"

def _esc(s):
    return _html.escape(str(s))

def _auto_key(label):
    """由 label 生成稳定的控件 key（避免每次请求变化）。"""
    key = re.sub(r"\s+", "_", str(label))
    key = re.sub(r"[^\w\u4e00-\u9fff-]", "", key)
    return key or _uid()

def _md_to_html(text):
    """轻量 Markdown → HTML（覆盖项目内使用到的语法子集）。"""
    t = str(text)
    t = _html.escape(t)
    t = re.sub(r"```(\w+)?\n(.*?)```", r"<pre class='st-code'><code>\2</code></pre>", t, flags=re.S)
    t = re.sub(r"`([^`]+)`", r"<code>\1</code>", t)
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"\*(.+?)\*", r"<i>\1</i>", t)
    t = re.sub(r"^#{1,6}\s*(.+)$", r"<h3>\1</h3>", t, flags=re.M)
    t = re.sub(r"^[-*]\s+", "• ", t, flags=re.M)
    t = t.replace("\n", "<br>")
    return t

def _fmt(obj):
    if obj is None:
        return ""
    if hasattr(obj, "to_html"):  # DataFrame / Styler
        try:
            return obj.to_html(escape=False, index=False)
        except Exception:
            return _esc(str(obj))
    return _esc(str(obj))

# ─────────────────────────── 容器类 ───────────────────────────
class _Container:
    """页面元素容器：主 st / sidebar / 列 / tab 面板共用。"""

    def __init__(self):
        self.buf = []

    # ---- 内部 ----
    def _add(self, s):
        self.buf.append(s)

    def _flush_to(self, parent):
        parent.buf.append("".join(self.buf))
        self.buf = []

    # ---- 展示类 ----
    def markdown(self, text, unsafe_allow_html=False, **kw):
        if unsafe_allow_html:
            self._add(str(text))
        else:
            self._add(_md_to_html(text))

    def write(self, obj, **kw):
        self._add(_fmt(obj))

    def caption(self, text, **kw):
        self._add(f"<div class='st-caption'>{_esc(text)}</div>")

    def code(self, text, language="python", **kw):
        self._add(f"<pre class='st-code'><code>{_esc(text)}</code></pre>")

    def info(self, text, unsafe_allow_html=False, **kw):
        self._add(f"<div class='st-callout st-info'>{text if unsafe_allow_html else _esc(text)}</div>")

    def warning(self, text, unsafe_allow_html=False, **kw):
        self._add(f"<div class='st-callout st-warning'>{text if unsafe_allow_html else _esc(text)}</div>")

    def error(self, text, unsafe_allow_html=False, **kw):
        self._add(f"<div class='st-callout st-error'>{text if unsafe_allow_html else _esc(text)}</div>")

    def success(self, text, unsafe_allow_html=False, **kw):
        self._add(f"<div class='st-callout st-success'>{text if unsafe_allow_html else _esc(text)}</div>")

    def toast(self, msg, icon=None, **kw):
        pass  # HTTP 一次性渲染，无 toast 语义

    def metric(self, label, value, **kw):
        self._add(f"<div class='metric-card'><div class='metric-value'>{_esc(value)}</div>"
                  f"<div class='metric-label'>{_esc(label)}</div></div>")

    def dataframe(self, data, width=None, height=None, hide_index=False, max_rows=None, **kw):
        if data is None:
            return
        try:
            is_styler = type(data).__name__ == "Styler"
            if is_styler:
                if hide_index:
                    data = data.hide(axis="index")
                n = len(data.data)
                table_html = data.to_html(escape=False)
            else:
                n = len(data)
                table_html = data.to_html(escape=False, index=not hide_index)
        except Exception:
            self._add(f"<pre>{_esc(str(data))}</pre>")
            return
        if max_rows and n > max_rows:
            uid = "tbl_" + _uid()
            self._add(f"<div class='st-table-wrap' id='{uid}'>")
            self._add(f"<style>#{uid} tbody tr:nth-child(n+{max_rows + 1}) {{display:none;}}</style>")
            self._add(table_html)
            self._add(f"<button type='button' class='st-show-more' "
                      f"onclick='stShowMore(this,{max_rows})'>展示更多（剩余 {n - max_rows} 条）</button>")
            self._add("</div>")
        else:
            self._add(f"<div class='st-table-wrap'>{table_html}</div>")

    def plotly_chart(self, fig, width=None, use_container_width=False, **kw):
        if fig is None:
            return
        try:
            h = fig.to_html(full_html=False, include_plotlyjs=False, config={"displaylogo": False})
            self._add(h)
        except Exception:
            pass

    def download_button(self, label, data, file_name=None, mime=None, width=None, **kw):
        mime = mime or "text/plain"
        try:
            if isinstance(data, str):
                b64 = base64.b64encode(data.encode("utf-8")).decode("ascii")
            else:
                b64 = base64.b64encode(bytes(data)).decode("ascii")
        except Exception:
            b64 = ""
        self._add(f"<a class='st-download' href='data:{mime};base64,{b64}' "
                  f"download='{_esc(file_name or 'download.txt')}'>{_esc(label)}</a>")

    # ---- 布局类 ----
    def columns(self, spec):
        return _Columns(self, spec)

    def tabs(self, labels):
        return _Tabs(self, labels)

    def expander(self, label, expanded=False):
        return _Expander(label, expanded)

    @contextmanager
    def spinner(self, text=None):
        # HTTP 同步渲染：耗时期间浏览器等待，无需前端提示
        yield

    def progress(self, value=0.0, text=None):
        return _Progress()

    @contextmanager
    def sidebar(self):
        prev = _CTX["in_sidebar"]
        _CTX["in_sidebar"] = True
        try:
            yield self
        finally:
            _CTX["in_sidebar"] = prev

    # ---- 交互类 ----
    def button(self, label, key=None, width=None, type="secondary", **kw):
        k = key or ("btn_" + _auto_key(label))
        if not _CTX["action_used"] and _CTX["action"] == k:
            _CTX["action_used"] = True
            return True
        cls = "st-btn primary" if type == "primary" else "st-btn"
        parts = [f"<form method='get' action='' class='st-form' style='display:inline-block;margin:2px 6px 6px 0;'>"]
        for kk, vv in _CTX["query"].items():
            if kk == "__act":
                continue
            parts.append(f"<input type='hidden' name='{_esc(kk)}' value='{_esc(vv)}'>")
        parts.append(f"<input type='hidden' name='__act' value='{_esc(k)}'>")
        parts.append(f"<button type='submit' class='{cls}'>{_esc(label)}</button></form>")
        self._add("".join(parts))
        return False

    def selectbox(self, label, options, index=0, key=None, format_func=None, **kw):
        k = key or ("sb_" + _auto_key(label))
        if k in _CTX["query"]:
            session_state[k] = _CTX["query"][k]
        elif k not in session_state:
            session_state[k] = str(index if index < len(options) else 0)
        cur = None
        raw = str(session_state.get(k, "0"))
        if raw.isdigit() and int(raw) < len(options):
            cur = options[int(raw)]
        else:
            for o in options:
                if str(o) == raw:
                    cur = o
                    break
        if cur is None:
            idx = index if index < len(options) else 0
            cur = options[idx]
            session_state[k] = str(idx)
        cur_idx = options.index(cur)
        parts = ["<form method='get' action='' class='st-form st-select-wrap'>"]
        for kk, vv in _CTX["query"].items():
            if kk in ("__act", k):
                continue
            parts.append(f"<input type='hidden' name='{_esc(kk)}' value='{_esc(vv)}'>")
        parts.append(f"<label class='st-lbl'>{_esc(label)}</label>")
        parts.append(f"<select name='{_esc(k)}' class='st-select' onchange='this.form.submit()'>")
        for i, o in enumerate(options):
            d = format_func(o) if format_func else str(o)
            sel = " selected" if i == cur_idx else ""
            parts.append(f"<option value='{i}'{sel}>{_esc(d)}</option>")
        parts.append("</select></form>")
        self._add("".join(parts))
        return cur

    def text_input(self, label, value="", key=None, placeholder=None, help=None, **kw):
        k = key or ("ti_" + _auto_key(label))
        if k in _CTX["query"]:
            session_state[k] = _CTX["query"][k]
        elif k not in session_state:
            session_state[k] = str(value)
        cur = str(session_state.get(k, value))
        parts = ["<form method='get' action='' class='st-form st-input-wrap'>"]
        for kk, vv in _CTX["query"].items():
            if kk in ("__act", k):
                continue
            parts.append(f"<input type='hidden' name='{_esc(kk)}' value='{_esc(vv)}'>")
        parts.append(f"<label class='st-lbl'>{_esc(label)}</label>")
        parts.append(f"<input type='text' name='{_esc(k)}' value='{_esc(cur)}' "
                     f"placeholder='{_esc(placeholder or '')}' class='st-input'>")
        parts.append("</form>")
        self._add("".join(parts))
        return cur

    def number_input(self, label, min_value=None, max_value=None, value=None, step=None, key=None, format=None, **kw):
        k = key or ("ni_" + _auto_key(label))
        if k in _CTX["query"]:
            session_state[k] = _CTX["query"][k]
        elif k not in session_state:
            session_state[k] = str(value if value is not None else 0)
        raw = session_state.get(k, value if value is not None else 0)
        try:
            if isinstance(value, int) or format == "%d":
                cur = int(float(str(raw)))
            else:
                cur = float(str(raw))
        except Exception:
            cur = value if value is not None else 0
        attrs = ""
        if step is not None:
            attrs += f" step='{step}'"
        if min_value is not None:
            attrs += f" min='{min_value}'"
        if max_value is not None:
            attrs += f" max='{max_value}'"
        parts = ["<form method='get' action='' class='st-form st-input-wrap'>"]
        for kk, vv in _CTX["query"].items():
            if kk in ("__act", k):
                continue
            parts.append(f"<input type='hidden' name='{_esc(kk)}' value='{_esc(vv)}'>")
        parts.append(f"<label class='st-lbl'>{_esc(label)}</label>")
        parts.append(f"<input type='number' name='{_esc(k)}' value='{cur}'{attrs} class='st-input' "
                     f"onchange='this.form.submit()'>")
        parts.append("</form>")
        self._add("".join(parts))
        return cur

    def date_input(self, label, value=None, key=None, **kw):
        k = key or ("di_" + _auto_key(label))
        if k in _CTX["query"]:
            session_state[k] = _CTX["query"][k]
        elif k not in session_state:
            v = value or date.today()
            session_state[k] = v.strftime("%Y-%m-%d") if hasattr(v, "strftime") else str(v)
        raw = session_state.get(k, "")
        try:
            cur = datetime.strptime(str(raw)[:10], "%Y-%m-%d").date()
        except Exception:
            cur = value or date.today()
        parts = ["<form method='get' action='' class='st-form st-input-wrap'>"]
        for kk, vv in _CTX["query"].items():
            if kk in ("__act", k):
                continue
            parts.append(f"<input type='hidden' name='{_esc(kk)}' value='{_esc(vv)}'>")
        parts.append(f"<label class='st-lbl'>{_esc(label)}</label>")
        parts.append(f"<input type='date' name='{_esc(k)}' value='{cur.isoformat()}' class='st-input' "
                     f"onchange='this.form.submit()'>")
        parts.append("</form>")
        self._add("".join(parts))
        return cur

    def slider(self, label, min_value=0.0, max_value=100.0, value=None, step=None, key=None, format=None, **kw):
        k = key or ("sl_" + _auto_key(label))
        if k in _CTX["query"]:
            session_state[k] = _CTX["query"][k]
        elif k not in session_state:
            session_state[k] = str(value if value is not None else min_value)
        raw = session_state.get(k, value if value is not None else min_value)
        try:
            if isinstance(value, int):
                cur = int(float(str(raw)))
            else:
                cur = float(str(raw))
        except Exception:
            cur = value if value is not None else min_value
        lo, hi = float(min_value), float(max_value)
        cur = min(max(cur, lo), hi)
        step_a = f" step='{step}'" if step is not None else ""
        parts = ["<form method='get' action='' class='st-form st-slider-wrap'>"]
        for kk, vv in _CTX["query"].items():
            if kk in ("__act", k):
                continue
            parts.append(f"<input type='hidden' name='{_esc(kk)}' value='{_esc(vv)}'>")
        parts.append(f"<label class='st-lbl'>{_esc(label)}：<output class='st-slider-out'>{cur}</output></label>")
        parts.append(f"<input type='range' name='{_esc(k)}' min='{lo}' max='{hi}' value='{cur}'{step_a} "
                     f"class='st-slider' oninput='this.form.querySelector(\".st-slider-out\").value=this.value' "
                     f"onchange='this.form.submit()'>")
        parts.append("</form>")
        self._add("".join(parts))
        return cur

    def checkbox(self, label, value=False, key=None, **kw):
        return self._check_impl(label, value, key, "cb_")

    def toggle(self, label, value=False, key=None, **kw):
        return self._check_impl(label, value, key, "tg_")

    def _check_impl(self, label, value, key, prefix):
        k = key or (prefix + _auto_key(label))
        if k in _CTX["query"]:
            session_state[k] = _CTX["query"][k]
        elif k not in session_state:
            session_state[k] = "on" if value else "off"
        checked = session_state.get(k) in ("on", "true", "1")
        parts = ["<form method='get' action='' class='st-form st-check-wrap'>"]
        for kk, vv in _CTX["query"].items():
            if kk in ("__act", k):
                continue
            parts.append(f"<input type='hidden' name='{_esc(kk)}' value='{_esc(vv)}'>")
        parts.append(f"<input type='hidden' name='{_esc(k)}' value='off'>")
        parts.append(f"<label class='st-check'><input type='checkbox' name='{_esc(k)}' value='on' "
                     f"onchange='this.form.submit()'{' checked' if checked else ''}> {_esc(label)}</label>")
        parts.append("</form>")
        self._add("".join(parts))
        return checked

    def radio(self, label, options, index=0, key=None, **kw):
        cur_page = _CTX["query"].get("p") or session_state.get("page", "首页")
        cur = None
        for o in options:
            s = str(o)
            name = s.split(" ", 1)[1] if " " in s else s
            if name == cur_page:
                cur = o
                break
        if cur is None:
            idx = index if index < len(options) else 0
            cur = options[idx]
        parts = ["<nav class='st-nav'>"]
        for o in options:
            s = str(o)
            name = s.split(" ", 1)[1] if " " in s else s
            cls = " active" if o == cur else ""
            href = "/?p=" + urllib.parse.quote(name)
            parts.append(f"<a class='st-nav-link{cls}' href='{href}'>{_esc(s)}</a>")
        parts.append("</nav>")
        self._add("".join(parts))
        return cur

    # ---- 控制流 ----
    def stop(self):
        raise _Stop()

    def rerun(self):
        raise _Rerun()

    def empty(self):
        return self


class _Progress:
    def progress(self, value=0.0, text=None):
        return self

    def empty(self):
        return self


class _Expander(_Pending):
    """折叠区：内容写在 self.buf，渲染结束在创建点组装 <details>。"""

    def __init__(self, label, expanded=False):
        super().__init__(_cur_target())
        self.label = label
        self.expanded = expanded
        self.buf = []

    def __enter__(self):
        _BUF_STACK.append(self.buf)
        return self

    def __exit__(self, *a):
        _BUF_STACK.pop()
        return False

    def _html(self):
        open_attr = " open" if self.expanded else ""
        return (f"<details class='st-expander'{open_attr}><summary class='st-expander-summary'>{_esc(self.label)}</summary>"
                f"<div class='st-expander-body'>{''.join(self.buf)}</div></details>")


class _Column(_Container):
    """列容器：`with col:` 进入期间，全局 st.* 内容写入本列缓冲。"""

    def __init__(self, group, idx):
        super().__init__()
        self.group = group
        self.idx = idx

    def __enter__(self):
        _BUF_STACK.append(self.buf)
        return self

    def __exit__(self, *a):
        _BUF_STACK.pop()
        return False


class _Columns(_Pending):
    """多列组：创建点放占位，渲染结束按比例生成 CSS grid。"""

    def __init__(self, parent, spec):
        self.parent = parent
        if isinstance(spec, (int, float)):
            self.ratios = [1] * int(spec)
        else:
            self.ratios = [float(r) if r else 1.0 for r in spec]
        self.cols = [_Column(self, i) for i in range(len(self.ratios))]
        self._in_ctx = False
        super().__init__(_cur_target())

    def __iter__(self):
        return iter(self.cols)

    def __getitem__(self, i):
        return self.cols[i]

    def __len__(self):
        return len(self.cols)

    def __enter__(self):
        self._in_ctx = True
        return self.cols

    def __exit__(self, *a):
        self._in_ctx = False
        return False

    def _html(self):
        grid = " ".join(f"{r}fr" for r in self.ratios)
        parts = [f"<div class='st-cols' style='grid-template-columns:{grid};'>"]
        for c in self.cols:
            parts.append(f"<div class='st-col'>{''.join(c.buf)}</div>")
        parts.append("</div>")
        return "".join(parts)


class _Tab(_Container):
    """Tab 面板容器：`with tab:` 进入期间，全局 st.* 内容写入本面板缓冲。"""

    def __init__(self, group, idx):
        super().__init__()
        self.group = group
        self.idx = idx

    def __enter__(self):
        _BUF_STACK.append(self.buf)
        return self

    def __exit__(self, *a):
        _BUF_STACK.pop()
        return False


class _Tabs(_Pending):
    """标签页组：创建点放占位，渲染结束组装 tab 头 + 面板。"""

    def __init__(self, parent, labels):
        self.parent = parent
        self.labels = [str(l) for l in labels]
        self.panels = [_Tab(self, i) for i in range(len(self.labels))]
        self._in_ctx = False
        super().__init__(_cur_target())

    def __iter__(self):
        return iter(self.panels)

    def __getitem__(self, i):
        return self.panels[i]

    def __len__(self):
        return len(self.panels)

    def __enter__(self):
        self._in_ctx = True
        return self.panels

    def __exit__(self, *a):
        self._in_ctx = False
        return False

    def _html(self):
        uid = "tabs_" + _uid()
        parts = [f"<div class='st-tabs' id='{uid}'>", "<div class='st-tab-head'>"]
        for i, lab in enumerate(self.labels):
            cls = " active" if i == 0 else ""
            parts.append(f"<button type='button' class='st-tab-btn{cls}' data-i='{i}' "
                         f"onclick='stTab(this,{i},\"{uid}\")'>{_esc(lab)}</button>")
        parts.append("</div><div class='st-tab-panels'>")
        for i, p in enumerate(self.panels):
            cls = " active" if i == 0 else ""
            parts.append(f"<div class='st-tab-panel{cls}' data-i='{i}'>{''.join(p.buf)}</div>")
        parts.append("</div></div>")
        return "".join(parts)


# ─────────────────────────── 主 st 对象 ───────────────────────────
class _St(_Container):
    """主容器：所有方法输出到当前活动缓冲（面板 → 侧边栏 → 主内容区）。"""

    def _add(self, s):
        if _BUF_STACK:
            _BUF_STACK[-1].append(s)
        else:
            _cur_buf().append(s)

    @property
    def sidebar(self):
        return _SidebarCtx()

    @property
    def session_state(self):
        return session_state

    @property
    def query_params(self):
        return query_params

    def set_page_config(self, **kw):
        pass  # 无操作


class _SidebarCtx:
    def __enter__(self):
        _CTX["in_sidebar"] = True
        return st

    def __exit__(self, *a):
        _CTX["in_sidebar"] = False


st = _St()


def __getattr__(name):
    """让 `import my_streamlit as st` 后可直接使用 st.markdown / st.button 等。
    模块内已有同名属性（serve / session_state / query_params 等）优先。"""
    return getattr(st, name)


# ─────────────────────────── 页面组装 ───────────────────────────
PAGE_TITLE = "QuantTrader 量化交易系统"

PAGE_CSS = r"""
* { box-sizing: border-box; }
html, body { margin:0; padding:0; background:#0b0e17; color:#ccd6f6; font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif; font-size:16px; }
a { color:#00d4ff; text-decoration:none; }
a:hover { text-decoration:underline; }
::-webkit-scrollbar { width:6px; height:6px; }
::-webkit-scrollbar-track { background:#0f1220; }
::-webkit-scrollbar-thumb { background:#2a2d3e; border-radius:3px; }
::-webkit-scrollbar-thumb:hover { background:#3a3d4e; }

/* 布局 */
.app-shell { display:flex; min-height:100vh; }
.sidebar { width:250px; flex:0 0 250px; background:#0f1220; border-right:1px solid #1a1d2e; padding:0 0 1.75rem 0; position:sticky; top:0; height:100vh; overflow-y:auto; }
.main { flex:1 1 auto; min-width:0; padding:1.2rem 1.6rem 3rem 1.6rem; max-width:1600px; }

/* 侧边栏导航 */
.st-nav { display:flex; flex-direction:column; gap:2px; padding:0 8px; }
.st-nav-link { padding:7px 14px; border-radius:6px; font-size:0.72rem; color:#ffffff; transition:all .15s; }
.st-nav-link:hover { background:rgba(0,212,255,.08); text-decoration:none; }
.st-nav-link.active { background:linear-gradient(135deg,rgba(0,212,255,.18),rgba(123,47,247,.14)); color:#00d4ff; font-weight:600; border-right:2px solid #00d4ff; }

/* 应用内通用类（沿用原 app.py CSS 中页面内联 HTML 依赖的类） */
.main-title { font-size:2rem; font-weight:700; background:linear-gradient(135deg,#00d4ff,#7b2ff7); -webkit-background-clip:text; -webkit-text-fill-color:transparent; margin-bottom:.1rem; letter-spacing:-.5px; }
.sub-title { font-size:.85rem; color:#8892b0; margin-bottom:1.5rem; }
.section-title { font-size:1.1rem; font-weight:600; color:#ccd6f6; border-left:3px solid #00d4ff; padding-left:12px; margin:1.2rem 0 .8rem 0; }
.card { background:linear-gradient(135deg,#151829,#1a1d2e); border-radius:10px; padding:1.2rem; border:1px solid #222538; margin-bottom:.8rem; transition:border-color .2s; }
.card:hover { border-color:#2a2d3e; }
.metric-card { background:linear-gradient(135deg,#151829,#1a1d2e); border-radius:8px; padding:.6rem .8rem; border:1px solid #222538; text-align:center; transition:border-color .2s; }
.metric-card:hover { border-color:#00d4ff44; }
.metric-value { font-size:1.4rem; font-weight:700; color:#00d4ff; letter-spacing:-.3px; }
.metric-value.small { font-size:1rem; }
.metric-label { font-size:.65rem; color:#8892b0; text-transform:uppercase; letter-spacing:.5px; }
.pos { color:#ff1744 !important; } .neg { color:#00c853 !important; }
.pos-bg { background:rgba(255,23,68,.12); color:#ff1744; padding:1px 6px; border-radius:4px; font-weight:600; }
.neg-bg { background:rgba(0,200,83,.12); color:#00c853; padding:1px 6px; border-radius:4px; font-weight:600; }
.strategy-card { background:linear-gradient(135deg,#151829,#1a1d2e); border:1px solid #222538; border-radius:10px; padding:1rem; margin-bottom:.8rem; transition:all .2s; }
.strategy-card:hover { border-color:#00d4ff; transform:translateY(-1px); box-shadow:0 4px 16px rgba(0,212,255,.06); }
.strategy-name { font-size:1rem; font-weight:600; color:#ccd6f6; }
.strategy-author { font-size:.75rem; color:#00d4ff; }
.signal-buy { background:rgba(255,23,68,.12); color:#ff1744; padding:2px 8px; border-radius:4px; font-size:.7rem; font-weight:600; }
.signal-sell { background:rgba(0,200,83,.12); color:#00c853; padding:2px 8px; border-radius:4px; font-size:.7rem; font-weight:600; }
.footer { text-align:center; color:#3a3d4e; font-size:.7rem; padding:2rem 0 .5rem 0; border-top:1px solid #1a1d2e; margin-top:3rem; }
.alert-4 { border-left:4px solid #ff1744; background:rgba(255,23,68,.06); }
.alert-3 { border-left:4px solid #00c853; background:rgba(0,200,83,.06); }
.alert-2 { border-left:4px solid #ffd600; background:rgba(255,214,0,.06); }
.alert-1 { border-left:4px solid #00d4ff; background:rgba(0,212,255,.06); }
.tag { display:inline-block; padding:1px 8px; border-radius:10px; font-size:.65rem; font-weight:600; }
.tag-buy { background:rgba(255,23,68,.15); color:#ff1744; border:1px solid rgba(255,23,68,.3); }
.tag-agent { background:rgba(123,47,247,.15); color:#b388ff; border:1px solid rgba(123,47,247,.3); }
.tag-sell { background:rgba(0,200,83,.15); color:#00c853; border:1px solid rgba(0,200,83,.3); }
.tier-card { background:linear-gradient(135deg,#151829,#1a1d2e); border:1px solid #222538; border-radius:12px; padding:1.2rem; margin-bottom:1rem; position:relative; overflow:hidden; }
.tier-card::before { content:""; position:absolute; top:0; left:0; width:4px; height:100%; }
.tier-card.tier-1w::before { background:linear-gradient(180deg,#ff1744,#ff6d00); }
.tier-card.tier-5k::before { background:linear-gradient(180deg,#ffd600,#ff9100); }
.tier-card.tier-2k::before { background:linear-gradient(180deg,#00d4ff,#7b2ff7); }
.tier-name { font-size:1.1rem; font-weight:700; color:#ccd6f6; }
.tier-amount { font-size:.8rem; color:#8892b0; }
.stock-chip { display:inline-flex; align-items:center; gap:4px; background:rgba(0,212,255,.08); border:1px solid rgba(0,212,255,.2); border-radius:6px; padding:3px 10px; font-size:.8rem; color:#ccd6f6; }
.reason-box { background:rgba(0,212,255,.04); border:1px solid rgba(0,212,255,.1); border-radius:8px; padding:.8rem; font-size:.8rem; color:#8892b0; line-height:1.6; }

/* 表格 */
.st-table-wrap { overflow-x:auto; border:1px solid #1a1d2e; border-radius:8px; margin:.4rem 0 .8rem 0; }
.st-table-wrap table { border-collapse:collapse; width:100%; font-size:.8rem; }
.st-table-wrap th { background:#1a1d2e !important; color:#8892b0 !important; font-weight:600; padding:6px 10px; text-align:left; white-space:nowrap; }
.st-table-wrap td { background:#0f1220 !important; color:#ccd6f6 !important; border-bottom:1px solid #1a1d2e; padding:5px 10px; white-space:nowrap; }
.st-table-wrap tr:hover td { background:#151829 !important; }
.st-show-more { display:block; width:100%; margin:0; padding:8px; background:#151829; border:none; border-top:1px solid #1a1d2e; color:#00d4ff; font-size:.85rem; cursor:pointer; border-radius:0 0 8px 8px; }
.st-show-more:hover { background:#1a1d2e; }

/* 按钮 */
.st-btn { background:linear-gradient(135deg,#1a1d2e,#1f2235); border:1px solid #2a2d3e; color:#ccd6f6; border-radius:8px; font-size:.85rem; padding:7px 16px; cursor:pointer; transition:all .2s; }
.st-btn:hover { border-color:#00d4ff; color:#00d4ff; transform:translateY(-1px); box-shadow:0 4px 12px rgba(0,212,255,.15); }
.st-btn.primary { background:linear-gradient(135deg,#00d4ff,#0090cc); border:none; color:#0b0e17; font-weight:600; }
.st-btn.primary:hover { box-shadow:0 4px 16px rgba(0,212,255,.3); }

/* 表单控件 */
.st-form { margin:2px 8px 6px 0; display:inline-block; vertical-align:top; }
.st-lbl { display:inline-block; color:#8892b0; font-size:.8rem; margin-right:4px; }
.st-select, .st-input { background:#1a1d2e; border:1px solid #2a2d3e; border-radius:8px; color:#e0e0e0; font-size:.9rem; padding:6px 10px; }
.st-select:focus, .st-input:focus { outline:none; border-color:#00d4ff; box-shadow:0 0 0 1px #00d4ff44; }
.st-slider { width:180px; vertical-align:middle; accent-color:#00d4ff; }
.st-slider-out { color:#00d4ff; font-weight:600; }
.st-check { color:#ccd6f6; font-size:.9rem; cursor:pointer; display:inline-flex; align-items:center; gap:6px; }
.st-check input { accent-color:#00d4ff; width:16px; height:16px; }

/* 标签页 */
.st-tabs { margin:.6rem 0 1rem 0; }
.st-tab-head { display:flex; gap:0; border-bottom:1px solid #1a1d2e; flex-wrap:wrap; }
.st-tab-btn { background:transparent; border:none; padding:10px 20px; font-size:.85rem; color:#8892b0; cursor:pointer; transition:all .15s; border-bottom:2px solid transparent; }
.st-tab-btn:hover { color:#ccd6f6; background:rgba(0,212,255,.04); }
.st-tab-btn.active { color:#00d4ff; border-bottom:2px solid #00d4ff; }
.st-tab-panel { display:none; padding:1rem 0; }
.st-tab-panel.active { display:block; }

/* 折叠区 */
.st-expander { border:1px solid #1a1d2e; border-radius:8px; margin:.4rem 0 .8rem 0; background:#0f1220; }
.st-expander-summary { padding:10px 14px; cursor:pointer; color:#ccd6f6; font-weight:600; font-size:.9rem; list-style:none; }
.st-expander-summary::-webkit-details-marker { display:none; }
.st-expander-summary::before { content:"▸ "; color:#00d4ff; }
details[open] > .st-expander-summary::before { content:"▾ "; }
.st-expander-body { padding:0 14px 12px 14px; }

/* 提示框 / 辅助 */
.st-callout { border-radius:8px; padding:10px 14px; margin:.4rem 0 .8rem 0; font-size:.85rem; line-height:1.6; }
.st-info { background:rgba(0,212,255,.08); border-left:4px solid #00d4ff; color:#ccd6f6; }
.st-warning { background:rgba(255,214,0,.08); border-left:4px solid #ffd600; color:#ccd6f6; }
.st-error { background:rgba(255,23,68,.08); border-left:4px solid #ff1744; color:#ff8a9e; }
.st-success { background:rgba(0,200,83,.08); border-left:4px solid #00c853; color:#ccd6f6; }
.st-caption { color:#8892b0; font-size:.75rem; margin:.2rem 0 .6rem 0; }
.st-code { background:#0f1220; border:1px solid #1a1d2e; border-radius:8px; padding:12px; color:#7ee787; font-size:.8rem; overflow-x:auto; line-height:1.5; white-space:pre-wrap; word-break:break-all; }
.st-download { display:inline-block; background:linear-gradient(135deg,#1a1d2e,#1f2235); border:1px solid #2a2d3e; color:#ccd6f6; border-radius:8px; font-size:.85rem; padding:7px 16px; margin:2px 6px 6px 0; transition:all .2s; }
.st-download:hover { border-color:#00d4ff; color:#00d4ff; text-decoration:none; transform:translateY(-1px); }

/* 多列 */
.st-cols { display:grid; gap:12px; margin:.2rem 0 .6rem 0; }
.st-col { min-width:0; }

/* 详情页 */
.detail-back { margin-bottom:1rem; }
"""

PAGE_JS = r"""
function stTab(btn, i, uid) {
  var root = document.getElementById(uid);
  if (!root) return;
  var btns = root.querySelectorAll('.st-tab-btn');
  var panels = root.querySelectorAll('.st-tab-panel');
  btns.forEach(function(b){ b.classList.remove('active'); });
  panels.forEach(function(p){ p.classList.remove('active'); });
  btn.classList.add('active');
  if (panels[i]) panels[i].classList.add('active');
}
function stShowMore(btn, n) {
  var wrap = btn.closest('.st-table-wrap');
  if (!wrap) return;
  var rows = wrap.querySelectorAll('tbody tr');
  for (var i = n; i < rows.length; i++) rows[i].style.display = 'table-row';
  btn.style.display = 'none';
}
"""


def _extract_styles(html_text):
    """把 <style> 块提取出来（提升到 <head>），保持内容区干净。"""
    styles = re.findall(r"<style>.*?</style>", html_text, flags=re.S)
    cleaned = re.sub(r"<style>.*?</style>", "", html_text, flags=re.S)
    return cleaned, "".join(styles)


def _assemble_html():
    main_html = "".join(_MAIN_BUF)
    side_html = "".join(_SIDE_BUF)
    # 左侧 sidebar 区按 14px 基准等效缩放：rem × 0.875，把字号/spacing 还原到原 14px 视觉
    side_html = re.sub(
        r'(?<=[\s:;,(])(\d+(?:\.\d+)?)rem',
        lambda m: f"{round(float(m.group(1)) * 0.875, 3)}rem",
        side_html,
    )
    cleaned, inline_styles = _extract_styles(main_html)
    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{_esc(PAGE_TITLE)}</title>
<script src="https://cdn.plot.ly/plotly-2.32.0.min.js" charset="utf-8"></script>
<style>{PAGE_CSS}</style>
<style>{inline_styles}</style>
</head>
<body>
<div class="app-shell">
  <aside class="sidebar">{side_html}</aside>
  <main class="main">{cleaned}</main>
</div>
<script>{PAGE_JS}</script>
</body>
</html>"""


# ─────────────────────────── HTTP 服务器 ───────────────────────────
_MAIN_FUNC = None

# ─────────────────────────── 页面渲染缓存 ───────────────────────────
# 纯展示页面(无按钮 action)在 TTL 内直接返回缓存 HTML，导航/刷新秒回；
# 带 action(POST/按钮)的请求处理后清空缓存，保证交互状态即时更新。
_PAGE_CACHE = {}
_PAGE_CACHE_LOCK = threading.Lock()
_PAGE_TTL = 60.0


def _page_cache_key(qs):
    parts = []
    for k in sorted(qs):
        if k == "__act":
            continue
        parts.append(f"{k}={qs[k]}")
    return "&".join(parts)


class _Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # 静默

    def _send(self, code, body, ctype="text/html; charset=utf-8"):
        try:
            if isinstance(body, str):
                body = body.encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except Exception:
            pass

    def _parse_form(self, body_bytes):
        qs = {}
        try:
            text = body_bytes.decode("utf-8", errors="replace")
        except Exception:
            text = ""
        for k, v in urllib.parse.parse_qs(text, keep_blank_values=True).items():
            qs[k] = v[-1]
        return qs

    def _dispatch(self):
        try:
            parsed = urllib.parse.urlparse(self.path)
            qs = {}
            for k, v in urllib.parse.parse_qs(parsed.query, keep_blank_values=True).items():
                qs[k] = v[-1]
            if self.command == "POST":
                try:
                    length = int(self.headers.get("Content-Length") or 0)
                except ValueError:
                    length = 0
                body = self.rfile.read(length) if length > 0 else b""
                for k, v in self._parse_form(body).items():
                    qs[k] = v

            # ── 设置请求上下文 ──
            _CTX["query"] = qs
            _CTX["path"] = parsed.path
            _CTX["action"] = qs.get("__act")
            _CTX["action_used"] = False
            _CTX["in_sidebar"] = False
            if "p" in qs:
                session_state["page"] = qs["p"]
            elif "page" in qs:
                session_state["page"] = qs["page"]
            elif "page" not in session_state:
                session_state["page"] = "首页"

            # ── 页面缓存：非交互请求在 TTL 内直接返回上次渲染结果 ──
            is_interactive = bool(qs.get("__act")) or self.command == "POST"
            ckey = _page_cache_key(qs)
            if not is_interactive:
                with _PAGE_CACHE_LOCK:
                    hit = _PAGE_CACHE.get(ckey)
                if hit is not None and time.time() - hit[0] < _PAGE_TTL:
                    self._send(200, hit[1])
                    return

            # ── 渲染（支持 st.rerun 重试一次）──
            html_text = ""
            for _round in range(2):
                _MAIN_BUF.clear()
                _SIDE_BUF.clear()
                _BUF_STACK.clear()
                _PENDING.clear()
                _CTX["rerun_round"] = _round
                try:
                    if _MAIN_FUNC is None:
                        raise RuntimeError("main() 未注册，请调用 st.serve(main) 启动")
                    _MAIN_FUNC()
                    _flush_pending()
                    html_text = _assemble_html()
                    break
                except _Rerun:
                    _CTX["action_used"] = True  # 防止按钮重复触发
                    continue
                except _Stop:
                    _flush_pending()
                    html_text = _assemble_html()
                    break
                except Exception:
                    _flush_pending()
                    tb = traceback.format_exc()
                    html_text = f"<pre class='st-code'>{_esc(tb)}</pre>"
                    break

            # 交互请求 → 页面状态可能变化，清空缓存；纯展示请求 → 写入缓存
            if is_interactive:
                with _PAGE_CACHE_LOCK:
                    _PAGE_CACHE.clear()
            else:
                with _PAGE_CACHE_LOCK:
                    if len(_PAGE_CACHE) > 200:
                        _PAGE_CACHE.clear()
                    _PAGE_CACHE[ckey] = (time.time(), html_text)
            self._send(200, html_text)
        except Exception:
            tb = traceback.format_exc()
            self._send(500, f"<pre>{_esc(tb)}</pre>")

    def do_GET(self):
        self._dispatch()

    def do_POST(self):
        self._dispatch()


def serve(main_func, host="0.0.0.0", port=8501, open_browser=True):
    """启动轻量 Web 服务（替代 `streamlit run app.py`）。"""
    global _MAIN_FUNC
    _MAIN_FUNC = main_func
    server = http.server.ThreadingHTTPServer((host, port), _Handler)
    url = f"http://localhost:{port}"
    print(f"QuantTrader 已启动: {url}")
    if open_browser:
        # 后台延时打开默认浏览器（不阻塞 serve_forever；异常静默，如无头环境）
        def _open_browser():
            time.sleep(1.5)
            try:
                webbrowser.open(url)
            except Exception:
                pass
        threading.Thread(target=_open_browser, daemon=True).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n服务已停止")
    finally:
        server.server_close()
