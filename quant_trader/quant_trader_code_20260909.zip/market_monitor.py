"""
市场监控模块 - 60秒间隔巡检，4级警报系统
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import threading
import time as time_module
from stock_api import StockAPI


ALERT_LEVELS = {
    "black_swan": {"name": "黑天鹅", "icon": "🚨", "color": "#ff1744", "priority": 4},
    "opportunity": {"name": "机会", "icon": "🎯", "color": "#00c853", "priority": 3},
    "warning": {"name": "警告", "icon": "⚠️", "color": "#ffd600", "priority": 2},
    "info": {"name": "信息", "icon": "ℹ️", "color": "#00d4ff", "priority": 1},
}


class MarketMonitor:
    """市场监控器"""

    def __init__(self):
        self.alerts = []
        self._last_prices = {}
        self._running = False
        self._thread = None
        self._lock = threading.Lock()

    def check_black_swan(self, df):
        """检查黑天鹅事件"""
        alerts = []
        if df.empty:
            return alerts
        avg_change = df["change_pct"].mean()
        down_stocks = df[df["change_pct"] < -9.5]
        if len(down_stocks) >= 5:
            alerts.append({
                "level": "black_swan",
                "title": f"批量跌停预警：{len(down_stocks)}只个股跌幅≥9.5%",
                "detail": f"市场平均涨幅: {avg_change:.2f}%",
                "stocks": down_stocks[["code","name","change_pct"]].head(10).to_dict("records"),
                "time": datetime.now(),
            })
        if avg_change < -3:
            alerts.append({
                "level": "black_swan",
                "title": f"市场暴跌预警：全市场平均跌幅 {avg_change:.2f}%",
                "detail": "市场出现系统性下跌，请注意风险",
                "time": datetime.now(),
            })
        return alerts

    def check_opportunity(self, df):
        """检查机会信号"""
        alerts = []
        if df.empty:
            return alerts
        up_stocks = df[df["change_pct"] > 9.5]
        if len(up_stocks) >= 10:
            alerts.append({
                "level": "opportunity",
                "title": f"批量涨停：{len(up_stocks)}只个股涨停",
                "detail": "市场情绪亢奋，关注板块持续性",
                "stocks": up_stocks[["code","name","change_pct"]].head(10).to_dict("records"),
                "time": datetime.now(),
            })
        hot_sectors = df[df["change_pct"] > 5]
        if not hot_sectors.empty:
            alerts.append({
                "level": "opportunity",
                "title": f"强势个股涌现：{len(hot_sectors)}只涨幅超5%",
                "detail": "市场赚钱效应明显",
                "time": datetime.now(),
            })
        return alerts

    def check_warning(self, df):
        """检查警告信号"""
        alerts = []
        if df.empty:
            return alerts
        volume_surge = df[
            (df["volume_ratio"].notna() if "volume_ratio" in df.columns else True) &
            (df["change_pct"] < -5)
        ] if "volume_ratio" in df.columns else df[df["change_pct"] < -5]
        if not volume_surge.empty:
            alerts.append({
                "level": "warning",
                "title": f"{len(volume_surge)}只个股放量下跌",
                "detail": "注意风险，可能有大资金出逃",
                "time": datetime.now(),
            })
        return alerts

    def check_info(self, df):
        """检查信息信号"""
        alerts = []
        if df.empty:
            return alerts
        turnover_active = df[df["turnover"] > 10] if "turnover" in df.columns else pd.DataFrame()
        if not turnover_active.empty:
            alerts.append({
                "level": "info",
                "title": f"{len(turnover_active)}只个股换手率超10%",
                "detail": "交易活跃，关注主力资金动向",
                "time": datetime.now(),
            })
        return alerts

    def scan(self):
        """执行一次全面扫描"""
        self.alerts = []
        try:
            df = StockAPI.get_realtime_quotes()
            if df.empty:
                return
            self.alerts.extend(self.check_black_swan(df))
            self.alerts.extend(self.check_opportunity(df))
            self.alerts.extend(self.check_warning(df))
            self.alerts.extend(self.check_info(df))
            self.alerts.sort(key=lambda x: ALERT_LEVELS[x["level"]]["priority"], reverse=True)
        except Exception:
            pass
        return self.alerts

    def start_auto_scan(self, interval=60, callback=None):
        """启动自动扫描"""
        if self._running:
            return
        self._running = True

        def _run():
            while self._running:
                try:
                    alerts = self.scan()
                    if callback and alerts:
                        callback(alerts)
                except Exception:
                    pass
                for _ in range(interval):
                    if not self._running:
                        break
                    time_module.sleep(1)

        self._thread = threading.Thread(target=_run, daemon=True)
        self._thread.start()

    def stop_auto_scan(self):
        """停止自动扫描"""
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)

    def get_recent_alerts(self, limit=50):
        """获取最近的警报"""
        with self._lock:
            return sorted(self.alerts, key=lambda x: x["time"], reverse=True)[:limit]


# 全局单例
monitor = MarketMonitor()
