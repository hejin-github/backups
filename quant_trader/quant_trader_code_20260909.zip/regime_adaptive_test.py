# -*- coding: utf-8 -*-
"""
实验: 根据行情选择贴合的策略 → 再选股 → 回测, 对比 T+1 胜率/收益可否提升

方法(切分样本外, 避免前视泄漏):
  1. 全市场采样 top-by-amount 股票, 拉 320 日历史 + 上证指数历史(逐日档位)
  2. 每个策略逐股跑信号序列, 每个 signal>0 记一笔 T+1 收益, 归入当日档位
  3. 切分: 训练集=前 60% 交易日 → 统计每个策略各档位 T+1 胜率/均值,
     按生产门槛(样本≥30, 胜率≥52%, 均值>0)决定各档位 allowed 策略集
  4. 测试集=后 40% 交易日, 三组对比:
       A 全策略(现状): 所有策略信号
       B 按行情选策略(样本外): 仅当日档位 allowed 策略的信号
       C 生产配置(样本内泄漏): 用全样本统计选 allowed(即当前 App 实际用配置)
  5. 附加"每日选股"对照: 每组内按该股过去20日T+1胜率排名取当日最高, 模拟实际选股
输出: 分档位对比表 + 汇总 + data/regime_adaptive_result.json
"""
import json
import os
import sys
import numpy as np
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

from stock_api import StockAPI
from stock_universe import filter_universe
from strategies import list_strategies, get_strategy
from strategy_backtest import REGIMES, _classify_regime

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "regime_adaptive_result.json")

TRAIN_FRAC = 0.6        # 训练集占比(前60%交易日)
MIN_TOTAL = 30          # 门槛: 某档位样本下限
MIN_WIN = 52.0          # 门槛: 某档位胜率下限(%)
MIN_AVG = 0.0           # 门槛: 某档位平均T+1收益下限(%)
TOP_N_DAILY = 1         # 每日选股数


def _load_index_regimes(lookback_days=320):
    """上证逐日档位: 优先腾讯实时, 失败回退本地缓存 data/market_index/sh000001.json.
    返回 (regimes: {date: level}, first_date) 或 (None, None).
    """
    idx = None
    try:
        idx = StockAPI.get_index_historical_data("sh000001", days=lookback_days)
    except Exception:
        idx = None
    if idx is None or len(idx) < 30:
        try:
            from index_guide import load_sh_raw
            raw = load_sh_raw()
            dates, closes = raw.get("dates", []), raw.get("closes", [])
            if len(dates) >= 30:
                df = pd.DataFrame({"date": pd.to_datetime(dates), "close": closes})
                df = df.sort_values("date").reset_index(drop=True)
                idx = df
        except Exception:
            idx = None
    if idx is None or len(idx) < 30:
        return None, None
    idx = idx.sort_values("date").reset_index(drop=True)
    idx["date"] = pd.to_datetime(idx["date"])
    idx["ma20"] = idx["close"].rolling(20).mean()
    regimes = {}
    for _, row in idx.iterrows():
        if pd.isna(row["ma20"]):
            continue
        regimes[row["date"].normalize()] = _classify_regime(float(row["close"]), float(row["ma20"]))
    return regimes, idx["date"].iloc[0]


def _fetch_hist(code, start_str, end_str):
    try:
        h = StockAPI.get_historical_data(code, start_str, end_str)
        if h is not None and len(h) >= 30:
            h = h.sort_values("date").reset_index(drop=True)
            h["date"] = pd.to_datetime(h["date"])
            return code, h
    except Exception:
        pass
    return code, None


def _daily_t1_win_rate(hist, idx):
    """该股第 idx 个bar(不含)之前的20日 T+1 胜率. 样本<8 返回 None"""
    if idx < 9:
        return None
    lo = max(0, idx - 20)
    wins, tot = 0, 0
    for i in range(lo, idx):
        b, s = float(hist["close"].iloc[i]), float(hist["close"].iloc[i + 1])
        if b > 0:
            tot += 1
            if s / b - 1 > 0:
                wins += 1
    if tot < 8:
        return None
    return wins / tot


def run(sample_limit=200, lookback_days=320):
    quotes = StockAPI.get_realtime_quotes()
    if quotes is None or quotes.empty:
        return None
    quotes = filter_universe(quotes)
    sort_col = "amount" if "amount" in quotes.columns else "price"
    quotes = quotes.sort_values(sort_col, ascending=False)
    sample = quotes.head(sample_limit)

    # ── 指数档位(每日): 网络优先, 回退本地缓存 ──
    regimes, idx_first = _load_index_regimes(lookback_days)
    if regimes is None:
        print("指数数据不足")
        return None
    # 个股窗口对齐指数窗口(留 ~25 日缓冲给 MA20 + 信号预热)
    end = datetime.now()
    buf = timedelta(days=25)
    start_str = (idx_first - buf).strftime("%Y%m%d")
    end_str = end.strftime("%Y%m%d")
    print(f"指数档位日数: {len(regimes)} | 起点 {idx_first} | 个股窗口 {start_str}~{end_str}")

    # ── 个股历史 ──
    hist_cache = {}
    with ThreadPoolExecutor(max_workers=8) as ex:
        fs = {ex.submit(_fetch_hist, c, start_str, end_str): c for c in sample["code"].tolist()}
        for f in as_completed(fs):
            try:
                c, h = f.result()
                if h is not None:
                    hist_cache[c] = h
            except Exception:
                pass

    # ── 信号 + T+1 收益 + 当日档位 ──
    strategy_names = [n for n in list_strategies() if n != "组合策略·投票系统"]
    # records[sname] = list of (regime, ret, trailing_win_rate)
    records = {s: [] for s in strategy_names}

    for sname in strategy_names:
        try:
            stg = get_strategy(sname)
        except Exception:
            continue
        if stg is None:
            continue
        for code, hist in hist_cache.items():
            try:
                sdf = stg.generate_signals(hist.copy())
            except Exception:
                continue
            if "signal" not in sdf.columns:
                continue
            sig = sdf["signal"].astype(float).values
            closes = hist["close"].astype(float).values
            dates = hist["date"].values
            n = len(sig)
            for i in range(20, n - 1):
                if sig[i] <= 0 or closes[i] <= 0:
                    continue
                d = pd.Timestamp(dates[i]).normalize()
                regime = regimes.get(d)
                if regime is None:
                    continue
                ret = (closes[i + 1] / closes[i] - 1) * 100
                twr = _daily_t1_win_rate(hist, i)
                records[sname].append((d, regime, ret, twr))

    # ── 交易日列表 + 切分 ──
    trade_days = sorted({d for srec in records.values() for d, *_ in srec})
    if len(trade_days) < 40:
        print(f"交易日样本过少: {len(trade_days)}")
        return None
    split_at = trade_days[int(len(trade_days) * TRAIN_FRAC)]
    train_days = {d for d in trade_days if d < split_at}
    test_days = [d for d in trade_days if d >= split_at]

    # ── 训练集: 各策略各档位统计 → allowed ──
    train_bucket = {s: {r: [] for r in REGIMES} for s in strategy_names}
    for s, recs in records.items():
        for d, r, ret, _tw in recs:
            if d in train_days:
                train_bucket[s][r].append(ret)

    def _allowed_from(bucket, srec=None):
        """按门槛从 bucket 计算各档位 allowed 策略名列表(按均值降序)"""
        allowed = {r: [] for r in REGIMES}
        for s in bucket:
            for r in REGIMES:
                rets = bucket[s][r]
                t = len(rets)
                if t < MIN_TOTAL:
                    continue
                wr = sum(1 for x in rets if x > 0) / t * 100
                avg = float(np.mean(rets))
                if wr >= MIN_WIN and avg > MIN_AVG:
                    allowed[r].append((s, avg))
        for r in REGIMES:
            allowed[r].sort(key=lambda x: -x[1])
            allowed[r] = [x[0] for x in allowed[r]]
        return allowed

    allowed_train = _allowed_from(train_bucket)          # 样本外 B
    allowed_full = _allowed_from({s: {r: [x[2] for x in records[s] if x[1] == r]
                                      for r in REGIMES} for s in records})  # 全样本 C(泄漏)

    print("\n=== 训练集选出的各档位策略(样本外) ===")
    for r in REGIMES:
        print(f"  {r:<6}: {', '.join(allowed_train[r]) if allowed_train[r] else '(空)'}")
    print("\n=== 全样本选出的各档位策略(生产配置C, 泄漏) ===")
    for r in REGIMES:
        print(f"  {r:<6}: {', '.join(allowed_full[r]) if allowed_full[r] else '(空)'}")

    # ── 测试集评估 ──
    # 每组记录 (strategy, regime, ret, trailing_win_rate)
    def _eval(allowed_map):
        """allowed_map: {regime: [strategy...]} 或 None=全策略"""
        buckets = {r: [] for r in REGIMES}
        daily_picks = {r: [] for r in REGIMES}   # 每日选股 top-N 的 T+1 收益
        per_day = {d: {r: [] for r in REGIMES} for d in test_days}
        for s, recs in records.items():
            for d, r, ret, tw in recs:
                if d not in test_days:
                    continue
                if allowed_map is not None and s not in allowed_map.get(r, []):
                    continue
                buckets[r].append(ret)
                per_day[d][r].append((s, ret, tw))
        for d in test_days:
            for r in REGIMES:
                pool = per_day[d][r]
                if not pool:
                    continue
                # 按该股过去20日T+1胜率选股(降序), 缺省按策略顺序
                ranked = sorted(pool, key=lambda x: (x[2] is not None, x[2] if x[2] is not None else -1), reverse=True)
                for _, ret, _tw in ranked[:TOP_N_DAILY]:
                    daily_picks[r].append(ret)
        return buckets, daily_picks

    def _agg(name, buckets, daily_picks):
        print(f"\n=== {name} ===")
        all_ret = []
        all_pick = []
        rows = {}
        for r in REGIMES:
            rets = buckets[r]
            t = len(rets)
            wr = round(sum(1 for x in rets if x > 0) / t * 100, 1) if t else 0.0
            avg = round(float(np.mean(rets)), 3) if t else 0.0
            pk = daily_picks[r]
            pt = len(pk)
            pwr = round(sum(1 for x in pk if x > 0) / pt * 100, 1) if pt else 0.0
            pavg = round(float(np.mean(pk)), 3) if pt else 0.0
            rows[r] = {"signal_total": t, "signal_win": wr, "signal_avg": avg,
                       "pick_total": pt, "pick_win": pwr, "pick_avg": pavg}
            print(f"  {r:<6} t={t:>5} 胜率{wr:>6.1f}% 均值{avg:>+7.3f}% | "
                  f"每日选股{pt:>4} 胜率{pwr:>6.1f}% 均值{pavg:>+7.3f}%")
            all_ret.extend(rets)
            all_pick.extend(pk)
        t = len(all_ret)
        wr = round(sum(1 for x in all_ret if x > 0) / t * 100, 1) if t else 0.0
        avg = round(float(np.mean(all_ret)), 3) if t else 0.0
        pt = len(all_pick)
        pwr = round(sum(1 for x in all_pick if x > 0) / pt * 100, 1) if pt else 0.0
        pavg = round(float(np.mean(all_pick)), 3) if pt else 0.0
        rows["_ALL"] = {"signal_total": t, "signal_win": wr, "signal_avg": avg,
                        "pick_total": pt, "pick_win": pwr, "pick_avg": pavg}
        print(f"  汇总    信号{t:>5} 胜率{wr:>6.1f}% 均值{avg:>+7.3f}% | "
              f"每日选股{pt:>4} 胜率{pwr:>6.1f}% 均值{pavg:>+7.3f}%")
        return rows

    ba, da = _eval(None)                 # A 全策略
    bb, db = _eval(allowed_train)        # B 按行情选(样本外)
    bc, dc = _eval(allowed_full)         # C 生产配置(泄漏)

    res = {
        "train_days": len(train_days), "test_days": len(test_days),
        "stocks": len(hist_cache), "strategies": len(strategy_names),
        "thresholds": {"min_total": MIN_TOTAL, "min_win": MIN_WIN, "min_avg": MIN_AVG},
        "allowed_train": allowed_train, "allowed_full": allowed_full,
        "A_all": _agg("A 全策略(现状)", ba, da),
        "B_regime_adaptive": _agg("B 按行情选策略(样本外)", bb, db),
        "C_production_config": _agg("C 生产配置(样本内泄漏)", bc, dc),
    }
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)
    print(f"\n结果已保存: {OUT}")
    return res


if __name__ == "__main__":
    run(sample_limit=200, lookback_days=320)
