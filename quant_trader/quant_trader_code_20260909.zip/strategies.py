"""
交易策略模块
内置13个策略 + 1个组合策略投票系统
每个策略实现 generate_signals(df) 方法
"""
import pandas as pd
import numpy as np
from enum import Enum


class Signal(Enum):
    HOLD = 0
    BUY = 1
    SELL = -1
    STRONG_BUY = 2
    STRONG_SELL = -2


class BaseStrategy:
    name = "基础策略"
    description = "策略说明"
    author = ""
    params = {}

    def generate_signals(self, df):
        raise NotImplementedError

    def add_indicators(self, df):
        df = df.copy()
        for period in [5, 10, 20, 30, 60, 120]:
            df[f"ma{period}"] = df["close"].rolling(window=period).mean()
        for period in [5, 10, 20]:
            df[f"vol_ma{period}"] = df["volume"].rolling(window=period).mean()
        ema12 = df["close"].ewm(span=12, adjust=False).mean()
        ema26 = df["close"].ewm(span=26, adjust=False).mean()
        df["macd_diff"] = ema12 - ema26
        df["macd_dea"] = df["macd_diff"].ewm(span=9, adjust=False).mean()
        df["macd_bar"] = 2 * (df["macd_diff"] - df["macd_dea"])
        delta = df["close"].diff()
        gain = delta.where(delta > 0, 0).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / (loss + 1e-10)
        df["rsi"] = 100 - (100 / (1 + rs))
        low_9 = df["low"].rolling(9).min()
        high_9 = df["high"].rolling(9).max()
        rsv = (df["close"] - low_9) / (high_9 - low_9 + 1e-10) * 100
        df["kdj_k"] = rsv.ewm(com=2, adjust=False).mean()
        df["kdj_d"] = df["kdj_k"].ewm(com=2, adjust=False).mean()
        df["kdj_j"] = 3 * df["kdj_k"] - 2 * df["kdj_d"]
        df["boll_mid"] = df["close"].rolling(20).mean()
        std20 = df["close"].rolling(20).std()
        df["boll_up"] = df["boll_mid"] + 2 * std20
        df["boll_down"] = df["boll_mid"] - 2 * std20
        tr = pd.concat([
            df["high"] - df["low"],
            (df["high"] - df["close"].shift(1)).abs(),
            (df["low"] - df["close"].shift(1)).abs(),
        ], axis=1).max(axis=1)
        df["atr"] = tr.rolling(14).mean()
        obv = (df["volume"] * np.sign(df["close"].diff()).fillna(0)).cumsum()
        df["obv"] = obv
        df["obv_ma"] = obv.rolling(20).mean()
        df["consec_up"] = (df["close"] > df["close"].shift(1)).astype(int)
        df["consec_down"] = (df["close"] < df["close"].shift(1)).astype(int)
        df["consec_up"] = df["consec_up"] * (df["consec_up"].groupby(
            (df["consec_up"] == 0).cumsum()).cumsum())
        df["consec_down"] = df["consec_down"] * (df["consec_down"].groupby(
            (df["consec_down"] == 0).cumsum()).cumsum())
        return df


# ==================== 1. 乔帮主·低吸反弹 ====================

class QiaoBangZhu(BaseStrategy):
    name = "乔帮主·低吸反弹"
    description = "基于乔帮主「低吸」理念：在价格回调至MA60附近，伴随MACD底背离和成交量萎缩时买入，反弹至压力位卖出。"
    author = "乔帮主"
    params = {"支撑均线": "MA60", "底背离周期": "MACD日线级别", "成交量条件": "缩量至MA60以下", "止损": "跌破MA60的3%"}

    def generate_signals(self, df):
        df = self.add_indicators(df)
        df["signal"] = Signal.HOLD.value
        for i in range(61, len(df)):
            near_ma60 = abs(df["close"].iloc[i] / df["ma60"].iloc[i] - 1) < 0.02
            price_low = df["low"].iloc[i] < df["low"].iloc[i-1] < df["low"].iloc[i-2]
            macd_rising = df["macd_diff"].iloc[i] > df["macd_diff"].iloc[i-1] > df["macd_diff"].iloc[i-2]
            divergence = price_low and macd_rising
            vol_shrink = df["volume"].iloc[i] < df["vol_ma20"].iloc[i] * 0.7
            rsi_low = df["rsi"].iloc[i] < 45
            if near_ma60 and (divergence or rsi_low) and vol_shrink:
                df.loc[df.index[i], "signal"] = Signal.BUY.value
            above_ma20 = df["close"].iloc[i] > df["ma20"].iloc[i]
            vol_surge = df["volume"].iloc[i] > df["vol_ma5"].iloc[i] * 1.5
            rsi_high = df["rsi"].iloc[i] > 70
            break_ma60 = df["close"].iloc[i] < df["ma60"].iloc[i] * 0.97
            if (above_ma20 and (vol_surge or rsi_high)) or break_ma60:
                df.loc[df.index[i], "signal"] = Signal.SELL.value
        return df


# ==================== 2. 一瞬流光·趋势跟踪 ====================

class YiShunLiuGuang(BaseStrategy):
    name = "一瞬流光·趋势跟踪"
    description = "追随强势趋势：价格站稳MA20/MA60之上，均线多头排列时买入，趋势破坏时卖出。"
    author = "一瞬流光"
    params = {"入场均线": "MA20金叉MA60", "持仓逻辑": "趋势不变不离场", "止损": "MA20或入场价的-5%"}

    def generate_signals(self, df):
        df = self.add_indicators(df)
        df["signal"] = Signal.HOLD.value
        df["golden_cross"] = (df["ma20"] > df["ma60"]) & (df["ma20"].shift(1) <= df["ma60"].shift(1))
        df["death_cross"] = (df["ma20"] < df["ma60"]) & (df["ma20"].shift(1) >= df["ma60"].shift(1))
        for i in range(61, len(df)):
            bull = df["ma5"].iloc[i] > df["ma10"].iloc[i] > df["ma20"].iloc[i] > df["ma60"].iloc[i]
            above_ma20 = df["close"].iloc[i] > df["ma20"].iloc[i]
            vol_ok = df["volume"].iloc[i] > df["vol_ma5"].iloc[i] * 0.8
            if bull and above_ma20 and vol_ok and df["golden_cross"].iloc[i]:
                df.loc[df.index[i], "signal"] = Signal.BUY.value
            if df["death_cross"].iloc[i] or df["close"].iloc[i] < df["ma20"].iloc[i] * 0.98 or df["rsi"].iloc[i] > 80:
                df.loc[df.index[i], "signal"] = Signal.SELL.value
        return df


# ==================== 3. 炒股养家·情绪接力 ====================

class ChaoGuYangJia(BaseStrategy):
    name = "炒股养家·情绪接力"
    description = "跟随市场情绪周期：在情绪启动初期（量价齐升）介入，情绪高潮时退出。"
    author = "炒股养家"
    params = {"情绪指标": "成交量/换手率变化", "入场时机": "情绪启动初期", "风控": "情绪退潮立即离场"}

    def generate_signals(self, df):
        df = self.add_indicators(df)
        df["signal"] = Signal.HOLD.value
        df["volume_ratio"] = df["volume"] / df["vol_ma5"]
        for i in range(21, len(df)):
            vol_boom = df["volume_ratio"].iloc[i] > 1.8
            breakout = df["close"].iloc[i] > df["close"].iloc[i-20:i].max() * 0.98
            good_gain = 2 < df.get("change_pct", pd.Series(0)).iloc[i] < 9.5 if "change_pct" in df.columns else True
            macd_bull = df["macd_diff"].iloc[i] > df["macd_dea"].iloc[i]
            if vol_boom and breakout and good_gain and macd_bull:
                df.loc[df.index[i], "signal"] = Signal.BUY.value
            vol_fade = df["volume_ratio"].iloc[i] < 1.0
            below_ma5 = df["close"].iloc[i] < df["ma5"].iloc[i]
            vol_dump = df["volume"].iloc[i] > df["vol_ma5"].iloc[i] * 1.5 and df["close"].iloc[i] < df["close"].iloc[i-1]
            if (vol_fade and below_ma5) or vol_dump:
                df.loc[df.index[i], "signal"] = Signal.SELL.value
        return df


# ==================== 4. 退学炒股·逆势交易 ====================

class TuiXueChaoGu(BaseStrategy):
    name = "退学炒股·逆势交易"
    description = "人弃我取，人取我予。恐慌大跌+缩量+超卖时买入，亢奋大涨+放量+超买时卖出。"
    author = "退学炒股"
    params = {"买入信号": "恐慌抛售后缩量企稳", "卖出信号": "亢奋追涨后放量滞涨", "风控": "反向波动3%止损"}

    def generate_signals(self, df):
        df = self.add_indicators(df)
        df["signal"] = Signal.HOLD.value
        df["boll_pos"] = ((df["close"] - df["boll_down"]) / (df["boll_up"] - df["boll_down"] + 1e-10))
        for i in range(21, len(df)):
            big_drop = df.get("change_pct", pd.Series(0)).iloc[i] < -3 if "change_pct" in df.columns else False
            consec = df["consec_down"].iloc[i] >= 3 and df["close"].iloc[i] / df["close"].iloc[i-3] - 1 < -0.05
            vol_extreme = df["volume"].iloc[i] < df["vol_ma20"].iloc[i] * 0.5
            touch_lower = df["close"].iloc[i] <= df["boll_down"].iloc[i] * 1.01
            rsi_os = df["rsi"].iloc[i] < 25
            kdj_os = df["kdj_j"].iloc[i] < 0
            buys = sum([(big_drop or consec), vol_extreme, touch_lower, rsi_os or kdj_os])
            if buys >= 3:
                df.loc[df.index[i], "signal"] = Signal.BUY.value
            big_up = df.get("change_pct", pd.Series(0)).iloc[i] > 5 if "change_pct" in df.columns else False
            consec_u = df["consec_up"].iloc[i] >= 5
            vol_surge = df["volume"].iloc[i] > df["vol_ma20"].iloc[i] * 3
            touch_upper = df["close"].iloc[i] >= df["boll_up"].iloc[i] * 0.99
            rsi_ob = df["rsi"].iloc[i] > 75
            kdj_ob = df["kdj_j"].iloc[i] > 100
            sells = sum([(big_up or consec_u), vol_surge, touch_upper, rsi_ob or kdj_ob])
            if sells >= 3:
                df.loc[df.index[i], "signal"] = Signal.SELL.value
        return df


# ==================== 5. 涨停打板·短线博弈 ====================

class DaBan(BaseStrategy):
    name = "涨停打板·短线博弈"
    description = "追击首次放量涨停（非一字板），博弈次日高开溢价。高风险策略。"
    author = "市场打板客"
    params = {"买入条件": "首次涨停（非一字板）", "涨停特征": "涨幅≥9.8%，有成交量", "风控": "炸板立即止损，次日低开3%止损"}

    def generate_signals(self, df):
        df = self.add_indicators(df)
        df["signal"] = Signal.HOLD.value
        if "change_pct" in df.columns:
            df["is_limit"] = df["change_pct"] >= 9.8
        else:
            df["is_limit"] = df["close"] >= df["close"].shift(1) * 1.098
        df["limit_vol"] = df["is_limit"] & (df["volume"] > df["vol_ma5"] * 1.2)
        df["first_limit"] = df["limit_vol"] & (~df["is_limit"].shift(1).fillna(False).astype(bool))
        in_pos = False
        for i in range(1, len(df)):
            if df["first_limit"].iloc[i]:
                df.loc[df.index[i], "signal"] = Signal.BUY.value
                in_pos = True
            elif in_pos:
                df.loc[df.index[i], "signal"] = Signal.SELL.value
                in_pos = False
        return df


# ==================== 6. 龙头战法·强者恒强 ====================

class LongTou(BaseStrategy):
    name = "龙头战法·强者恒强"
    description = "识别板块龙头，在龙头首次回调至MA20支撑时买入，跟随主升浪。"
    author = "市场游资"
    params = {"选股标准": "板块内相对强度最高", "买入时机": "龙头首次回调至MA20", "风控": "跌破MA60离场"}

    def generate_signals(self, df):
        df = self.add_indicators(df)
        df["signal"] = Signal.HOLD.value
        df["rs_ratio"] = df.get("change_pct", df["close"].pct_change()*100).rolling(20).mean()
        df["price_pos"] = ((df["close"] - df["low"].rolling(60).min()) /
                           (df["high"].rolling(60).max() - df["low"].rolling(60).min() + 1e-10))
        for i in range(61, len(df)):
            between_ma = df["ma20"].iloc[i] * 0.98 < df["close"].iloc[i] < df["ma10"].iloc[i]
            strong = df["rs_ratio"].iloc[i-5:i].mean() > 1
            vol_shrink = df["volume"].iloc[i] < df["vol_ma10"].iloc[i]
            above_mid = df["close"].iloc[i] > df["boll_mid"].iloc[i]
            if between_ma and strong and vol_shrink and above_mid:
                df.loc[df.index[i], "signal"] = Signal.BUY.value
            if df["close"].iloc[i] < df["ma60"].iloc[i] or df["close"].iloc[i] / df["ma20"].iloc[i] - 1 > 0.2:
                df.loc[df.index[i], "signal"] = Signal.SELL.value
        return df


# ==================== 7. 幻方量化·多因子改进 ====================

class HuanFang(BaseStrategy):
    name = "幻方量化·多因子改进"
    description = "从动量(25%)、质量(20%)、估值(20%)、情绪(20%)、技术(15%)五维度综合评分。≥60分买入，≤35分卖出。"
    author = "幻方量化（改进版）"
    params = {"评分阈值": "买入≥60分，卖出≤35分", "风控": "单笔止损-5%，连亏2次暂停"}

    def generate_signals(self, df):
        df = self.add_indicators(df)
        df["signal"] = Signal.HOLD.value
        df["factor_score"] = 50.0
        for i in range(21, len(df)):
            ms = 0
            if i >= 20:
                r = (df["close"].iloc[i] / df["close"].iloc[i-20] - 1) * 100
                ms += 15 if r > 10 else 12 if r > 5 else 8 if r > 0 else 5 if r > -5 else 2
            ms += 10 if df["close"].iloc[i] > df["ma5"].iloc[i] else 5 if df["close"].iloc[i] > df["ma10"].iloc[i] else 2
            ms = min(ms, 25)
            qs = 0
            if df["ma10"].iloc[i] > df["ma20"].iloc[i] > df["ma60"].iloc[i]:
                qs += 12
            elif df["ma10"].iloc[i] > df["ma20"].iloc[i]:
                qs += 8
            else:
                qs += 4
            if "change_pct" in df.columns:
                v = df["change_pct"].iloc[i-10:i].std()
                qs += 8 if v < 3 else 5 if v < 5 else 2
            qs = min(qs, 20)
            bp = ((df["close"].iloc[i] - df["boll_down"].iloc[i]) /
                  (df["boll_up"].iloc[i] - df["boll_down"].iloc[i] + 1e-10))
            vs = 15 if bp < 0.2 else 12 if bp < 0.4 else 8 if bp < 0.6 else 5 if bp < 0.8 else 2
            vs += 5 if df["rsi"].iloc[i] < 30 else 3 if df["rsi"].iloc[i] < 45 else 0
            vs = min(vs, 20)
            ss = 0
            vr = df["volume"].iloc[i] / df["vol_ma5"].iloc[i]
            ss += 8 if 0.8 <= vr <= 1.5 else 4 if vr > 2 else 2
            if "change_pct" in df.columns:
                cp = df["change_pct"].iloc[i]
                ss += 7 if 1 < cp < 5 else 4 if cp > 5 else 3 if -2 < cp <= 1 else 1
            ss += 5 if 20 < df["kdj_j"].iloc[i] < 80 else 3 if df["kdj_j"].iloc[i] < 20 else 1
            ss = min(ss, 20)
            ts = 0
            ts += 5 if df["macd_diff"].iloc[i] > df["macd_dea"].iloc[i] else 2
            if df["macd_diff"].iloc[i] > df["macd_dea"].iloc[i] and df["macd_bar"].iloc[i] > df["macd_bar"].iloc[i-1]:
                ts += 3
            above = sum([df["close"].iloc[i] > df[f"ma{p}"].iloc[i] for p in [5, 10, 20]])
            ts += above * 2
            ts = min(ts, 15)
            total = ms + qs + vs + ss + ts
            df.loc[df.index[i], "factor_score"] = total
            if total >= 60:
                df.loc[df.index[i], "signal"] = Signal.BUY.value
            elif total <= 35:
                df.loc[df.index[i], "signal"] = Signal.SELL.value
        return df


# ==================== 8. 幻方量化·动态多因子 ====================

class HuanFangDynamic(BaseStrategy):
    name = "幻方量化·动态多因子"
    description = "动态多因子版本：通过IC分析动态调整因子权重，适应不同市场环境。"
    author = "幻方量化（动态版）"
    params = {"因子池": "动量/均线/波动率/RSI/量价/MACD/KDJ", "权重调整": "基于近期IC值"}

    def generate_signals(self, df):
        from factor_lib import compute_all_factors
        df = self.add_indicators(df)
        df["signal"] = Signal.HOLD.value
        df["factor_score"] = 50.0
        factors = compute_all_factors(df)
        weights = {
            "动量": 0.18, "均线": 0.14, "波动率": 0.08, "布林带": 0.12,
            "RSI": 0.10, "量价": 0.10, "MACD": 0.10, "KDJ": 0.08,
            "量价配合": 0.10,
        }
        for i in range(60, len(df)):
            score = 50
            for fname, w in weights.items():
                if fname in factors.columns and i > 0:
                    fv = factors[fname].iloc[i]
                    if pd.notna(fv):
                        norm = max(0, min(100, (fv + 100) / 2))
                        score += (norm - 50) * w
            df.loc[df.index[i], "factor_score"] = min(100, max(0, score))
            if score >= 62:
                df.loc[df.index[i], "signal"] = Signal.BUY.value
            elif score <= 33:
                df.loc[df.index[i], "signal"] = Signal.SELL.value
        return df


# ==================== 9. 尾盘选股·尾盘动量 ====================

class WeiPan(BaseStrategy):
    name = "尾盘选股·尾盘动量"
    description = "尾盘放量拉升+全天强势，捕捉尾盘资金抢筹信号，次日高开概率大。"
    author = "尾盘战法"
    params = {"尾盘特征": "尾盘30分钟放量拉升", "全天要求": "涨幅2-5%，成交量活跃", "风控": "次日低开3%止损"}

    def generate_signals(self, df):
        df = self.add_indicators(df)
        df["signal"] = Signal.HOLD.value
        for i in range(21, len(df)):
            if "change_pct" not in df.columns:
                continue
            cp = df["change_pct"].iloc[i]
            vol_ratio = df["volume"].iloc[i] / df["vol_ma5"].iloc[i] if df["vol_ma5"].iloc[i] > 0 else 1
            day_range = (df["high"].iloc[i] - df["low"].iloc[i]) / df["close"].iloc[i] * 100
            price_pos = (df["close"].iloc[i] - df["low"].iloc[i]) / (df["high"].iloc[i] - df["low"].iloc[i] + 1e-10)
            is_tail_raid = (2 < cp < 7 and vol_ratio > 1.3 and
                            price_pos > 0.7 and day_range > 2 and
                            df["close"].iloc[i] > df["ma5"].iloc[i])
            if is_tail_raid:
                df.loc[df.index[i], "signal"] = Signal.BUY.value
            if cp < -3 or cp > 9:
                df.loc[df.index[i], "signal"] = Signal.SELL.value
        return df


# ==================== 10. 92科比·首板挖掘 ====================

class KeBi(BaseStrategy):
    name = "92科比·首板挖掘"
    description = "早盘首板+板块效应：量价配合完美的首板，配合板块联动，胜率更高。"
    author = "92科比"
    params = {"选股": "早盘首板+板块效应", "风控": "炸板即走，不恋战"}

    def generate_signals(self, df):
        df = self.add_indicators(df)
        df["signal"] = Signal.HOLD.value
        if "change_pct" in df.columns:
            df["is_limit"] = df["change_pct"] >= 9.5
        else:
            df["is_limit"] = df["close"] >= df["close"].shift(1) * 1.095
        df["vol_surge"] = df["volume"] > df["vol_ma5"] * 1.5
        df["not_prev_limit"] = (~df["is_limit"].shift(1).fillna(False).astype(bool))
        half_pos = len(df) // 2
        for i in range(1, len(df)):
            if (df["is_limit"].iloc[i] and df["vol_surge"].iloc[i] and
                    df["not_prev_limit"].iloc[i] and i < half_pos):
                df.loc[df.index[i], "signal"] = Signal.BUY.value
        in_pos = False
        for i in range(len(df)):
            if df["signal"].iloc[i] == Signal.BUY.value:
                in_pos = True
            elif in_pos:
                df.loc[df.index[i], "signal"] = Signal.SELL.value
                in_pos = False
        return df


# ==================== 11. 陈小群·龙头二波 ====================

class ChenXiaoQun(BaseStrategy):
    name = "陈小群·龙头二波"
    description = "第一波上涨后缩量回调至关键支撑，确认二波启动时介入。吃最肥的第二波。"
    author = "陈小群"
    params = {"第一波": "放量上攻", "回调": "缩量回踩MA20/MA60", "二波启动": "放量突破前高"}

    def generate_signals(self, df):
        df = self.add_indicators(df)
        df["signal"] = Signal.HOLD.value
        df["ret_20"] = df["close"].pct_change(20)
        df["ret_5"] = df["close"].pct_change(5)
        df["vol_ratio_20"] = df["volume"] / df["vol_ma20"]
        for i in range(61, len(df)):
            wave1 = df["ret_20"].iloc[i-20:i].max() > 0.2 if i >= 20 else False
            pullback_ma20 = df["ma20"].iloc[i] * 0.97 < df["close"].iloc[i] < df["ma20"].iloc[i] * 1.03
            vol_shrink = df["vol_ratio_20"].iloc[i] < 0.8
            re_break = (df["close"].iloc[i] > df["close"].iloc[i-5:i].max() and
                        df["volume"].iloc[i] > df["vol_ma5"].iloc[i] * 1.3)
            if wave1 and pullback_ma20 and vol_shrink and re_break:
                df.loc[df.index[i], "signal"] = Signal.BUY.value
            if df["close"].iloc[i] < df["ma60"].iloc[i] or df["rsi"].iloc[i] > 80:
                df.loc[df.index[i], "signal"] = Signal.SELL.value
        return df


# ==================== 12. 著名刺客·分歧转一致 ====================

class ZhuMingCiKe(BaseStrategy):
    name = "著名刺客·分歧转一致"
    description = "放量分歧→缩量转一致：多空分歧后，多方重新掌控盘面的关键节点介入。"
    author = "著名刺客"
    params = {"分歧": "放量宽幅震荡", "转一致": "缩量中阳线/阳线", "介入": "确认转一致当日"}

    def generate_signals(self, df):
        df = self.add_indicators(df)
        df["signal"] = Signal.HOLD.value
        for i in range(5, len(df)):
            if "change_pct" not in df.columns:
                continue
            fz_vol = df["volume"].iloc[i-2] > df["vol_ma5"].iloc[i-2] * 1.5 if i >= 2 else False
            fz_range = df["high"].iloc[i-2] - df["low"].iloc[i-2] > df["close"].iloc[i-2] * 0.04 if i >= 2 else False
            fenqi = fz_vol and fz_range
            zy_vol = df["volume"].iloc[i] < df["vol_ma5"].iloc[i] * 1.1
            zy_price = 1 < df["change_pct"].iloc[i] < 6
            above_ma5 = df["close"].iloc[i] > df["ma5"].iloc[i]
            if fenqi and zy_vol and zy_price and above_ma5:
                df.loc[df.index[i], "signal"] = Signal.BUY.value
            if df["change_pct"].iloc[i] < -4:
                df.loc[df.index[i], "signal"] = Signal.SELL.value
        return df


# ==================== 13. 缠论·分型中枢 ====================

class ChanLun(BaseStrategy):
    name = "缠论·分型中枢"
    description = "基于缠论的顶底分型识别+中枢区间判断。底分型成立+脱离中枢下沿时买入，顶分型成立+触及中枢上沿时卖出。"
    author = "缠论"
    params = {"分型识别": "顶分型/底分型", "中枢": "连续三段重叠区间", "买卖点": "第三类买卖点"}

    def generate_signals(self, df):
        df = self.add_indicators(df)
        df["signal"] = Signal.HOLD.value
        df["top_fractal"] = False
        df["bottom_fractal"] = False
        # 【修复未来函数】顶底分型确认需要滞后2根K线
        # 在第i天遍历时，确认第(i-2)天是否为分型（用到i-4~i的数据，均已知）
        for i in range(4, len(df)):
            bar = i - 2  # 被确认的K线位置
            df.loc[df.index[bar], "top_fractal"] = (
                df["high"].iloc[bar] > df["high"].iloc[bar-1] and
                df["high"].iloc[bar] > df["high"].iloc[bar+1] and
                df["high"].iloc[bar-1] > df["high"].iloc[bar-2] and
                df["high"].iloc[bar+1] > df["high"].iloc[bar+2]
            )
            df.loc[df.index[bar], "bottom_fractal"] = (
                df["low"].iloc[bar] < df["low"].iloc[bar-1] and
                df["low"].iloc[bar] < df["low"].iloc[bar+1] and
                df["low"].iloc[bar-1] < df["low"].iloc[bar-2] and
                df["low"].iloc[bar+1] < df["low"].iloc[bar+2]
            )
        bottoms = df[df["bottom_fractal"]].index.tolist()
        tops = df[df["top_fractal"]].index.tolist()
        if len(bottoms) >= 3:
            recent_bottoms = df.loc[bottoms[-3:], "low"].values
            zhong_shu_low = min(recent_bottoms)
            zhong_shu_high = max(recent_bottoms)
        else:
            zhong_shu_low = df["low"].rolling(20).min().iloc[-1]
            zhong_shu_high = df["high"].rolling(20).max().iloc[-1]
        # 【修复未来函数】分型已滞后2天确认，信号也对应滞后：在第i天用第(i-2)天的分型
        for i in range(4, len(df)):
            if (df["bottom_fractal"].iloc[i-2] and
                    df["close"].iloc[i] > zhong_shu_high and
                    df["volume"].iloc[i] > df["vol_ma10"].iloc[i] * 0.8):
                df.loc[df.index[i], "signal"] = Signal.BUY.value
            if (df["top_fractal"].iloc[i-2] and
                    df["close"].iloc[i] < zhong_shu_low):
                df.loc[df.index[i], "signal"] = Signal.SELL.value
        return df


# ==================== 14. 野人·低吸战法 ====================

class YeaRenDiXi(BaseStrategy):
    name = "野人·低吸战法"
    description = "基于野人低吸理念：在价格回踩20日线、情绪冰点、成交量萎缩时低吸买入，反弹至压力位卖出。要求盈亏比3:1以上。"
    author = "全能的野人"
    params = {"支撑均线": "MA20", "成交量条件": "缩量至MA均量70%以下", "止损": "5-8%强制止损", "盈亏比": "3:1"}

    def generate_signals(self, df):
        df = self.add_indicators(df)
        df["signal"] = Signal.HOLD.value
        for i in range(21, len(df)):
            near_ma20 = abs(df["close"].iloc[i] / df["ma20"].iloc[i] - 1) < 0.025
            vol_shrink = df["volume"].iloc[i] < df["vol_ma20"].iloc[i] * 0.7
            rsi_low = df["rsi"].iloc[i] < 45
            big_drop = df.get("change_pct", pd.Series(0)).iloc[i] < -2.5 if "change_pct" in df.columns else False
            consec = df["consec_down"].iloc[i] >= 2
            if near_ma20 and vol_shrink and (rsi_low or big_drop or consec):
                df.loc[df.index[i], "signal"] = Signal.BUY.value
            above_ma20 = df["close"].iloc[i] > df["ma10"].iloc[i]
            vol_surge = df["volume"].iloc[i] > df["vol_ma5"].iloc[i] * 1.4
            rsi_high = df["rsi"].iloc[i] > 70
            break_ma60 = df["close"].iloc[i] < df["ma60"].iloc[i] * 0.97
            if (above_ma20 and (vol_surge or rsi_high)) or break_ma60:
                df.loc[df.index[i], "signal"] = Signal.SELL.value
        return df


# ==================== 15. 野人·二次回踩 ====================

class YeaRenErCiHuiCai(BaseStrategy):
    name = "野人·二次回踩"
    description = "底部长时间横盘→出现首板→回调至10/20日线缩量企稳后二次回踩买点。高位龙头调整2-3天回踩5-10日线也可低吸。"
    author = "全能的野人"
    params = {"形态": "底部横盘→首板→回踩均线", "买入": "缩量回踩10/20日线", "卖出": "放量上攻或连板断板"}

    def generate_signals(self, df):
        df = self.add_indicators(df)
        df["signal"] = Signal.HOLD.value
        df["is_limit"] = df.get("change_pct", pd.Series(0)) >= 9.5 if "change_pct" in df.columns else df["close"] >= df["close"].shift(1) * 1.095
        for i in range(41, len(df)):
            has_shouban = df["is_limit"].iloc[i-20:i].sum() >= 1 if i >= 20 else False
            near_ma10 = abs(df["close"].iloc[i] / df["ma10"].iloc[i] - 1) < 0.02
            near_ma20 = abs(df["close"].iloc[i] / df["ma20"].iloc[i] - 1) < 0.02
            vol_shrink = df["volume"].iloc[i] < df["vol_ma10"].iloc[i] * 0.7
            price_back = df["close"].iloc[i] < df["close"].iloc[i-1] and df["close"].iloc[i-1] < df["close"].iloc[i-2]
            back_3days = df["close"].iloc[i] / df["close"].iloc[max(0,i-3)] - 1 < -0.02 if i >= 3 else False
            if has_shouban and (near_ma10 or near_ma20) and vol_shrink and back_3days:
                df.loc[df.index[i], "signal"] = Signal.BUY.value
            vol_surge = df["volume"].iloc[i] > df["vol_ma5"].iloc[i] * 1.3
            up_gain = df.get("change_pct", pd.Series(0)).iloc[i] > 3 if "change_pct" in df.columns else False
            break_low = df["close"].iloc[i] < df["ma20"].iloc[i] * 0.95
            if (vol_surge and up_gain) or break_low:
                df.loc[df.index[i], "signal"] = Signal.SELL.value
        return df


# ==================== 16. 野人·强更强 ====================

class YeaRenQiangGengQiang(BaseStrategy):
    name = "野人·强更强"
    description = "首板缩量→次日高开直接拉板(强更强)，不给低吸机会。如果高开后1分钟不封板即为弱。本策略在日线级别识别强更强模式。"
    author = "全能的野人"
    params = {"首板条件": "放量涨停", "次日预期": "高开缩量板", "弱势信号": "高开低走放量"}

    def generate_signals(self, df):
        df = self.add_indicators(df)
        df["signal"] = Signal.HOLD.value
        if "change_pct" in df.columns:
            df["is_limit"] = df["change_pct"] >= 9.5
        else:
            df["is_limit"] = df["close"] >= df["close"].shift(1) * 1.095
        df["prev_limit"] = df["is_limit"].shift(1).fillna(False)
        df["high_open"] = df["open"] > df["close"].shift(1) * 1.03
        df["gap_up"] = df["open"] > df["close"].shift(1) * 1.02
        for i in range(2, len(df)):
            if df["is_limit"].iloc[i] and df["prev_limit"].iloc[i]:
                limit_day = df["close"].iloc[i-1] / df["close"].iloc[i-2] - 1 >= 0.095
                vol_ok = df["volume"].iloc[i] < df["vol_ma5"].iloc[i] * 1.1
                if limit_day and vol_ok and df["gap_up"].iloc[i]:
                    df.loc[df.index[i], "signal"] = Signal.BUY.value
            if df["signal"].iloc[i] != Signal.BUY.value and df["prev_limit"].iloc[i] and df["high_open"].iloc[i]:
                high_then_low = df["close"].iloc[i] < df["open"].iloc[i] * 0.97
                if high_then_low:
                    df.loc[df.index[i], "signal"] = Signal.SELL.value
        return df


# ==================== 17. 奥数老师·尾盘量化 ====================

class AoshuWeiPan(BaseStrategy):
    name = "奥数老师·尾盘量化"
    description = "14:50尾盘选股买入(缩量回调至10日线的阴线)，次日10:00满仓卖出。完全机械操作，不看板块不打板，三年如一日的机械化交易。"
    author = "奥数老师"
    params = {"买入": "14:50尾盘阴线+缩量+回踩10日线", "卖出": "次日10:00出清", "仓位": "每日满仓"}

    def generate_signals(self, df):
        df = self.add_indicators(df)
        df["signal"] = Signal.HOLD.value
        for i in range(11, len(df)):
            is_yin = df["close"].iloc[i] < df["open"].iloc[i]
            near_ma10 = abs(df["close"].iloc[i] / df["ma10"].iloc[i] - 1) < 0.02
            vol_shrink = df["volume"].iloc[i] < df["vol_ma5"].iloc[i] * 0.85
            has_baoliang = df["volume"].iloc[i-10:i].max() > df["vol_ma20"].iloc[i] * 1.5 if i >= 10 else False
            distance = df["close"].iloc[i] / df["ma10"].iloc[i]
            not_too_high = distance < 1.08
            if is_yin and near_ma10 and vol_shrink and has_baoliang and not_too_high:
                df.loc[df.index[i], "signal"] = Signal.BUY.value
            if df["signal"].iloc[i] == Signal.HOLD.value and df["signal"].iloc[i-1] > 0:
                df.loc[df.index[i], "signal"] = Signal.SELL.value
        return df


# ==================== 18. 大毛哥·2B接力 ====================

class DaMao2BJieLi(BaseStrategy):
    name = "大毛哥·2B接力"
    description = "2板接力模式：寻找连板股在第2个涨停板介入。要求'又粗又长'(K线实体大+成交量放大)，5/10日线上支撑有效。"
    author = "大毛哥"
    params = {"模式": "2B接力", "量价": "又粗又长(K线大+量大)", "支撑": "5/10日线上方"}

    def generate_signals(self, df):
        df = self.add_indicators(df)
        df["signal"] = Signal.HOLD.value
        if "change_pct" in df.columns:
            df["is_limit"] = df["change_pct"] >= 9.5
        else:
            df["is_limit"] = df["close"] >= df["close"].shift(1) * 1.095
        df["body_len"] = (df["close"] - df["open"]).abs()
        df["body_ratio"] = df["body_len"] / (df["high"] - df["low"] + 1e-10)
        for i in range(3, len(df)):
            limit_today = df["is_limit"].iloc[i]
            prev_limit = df["is_limit"].iloc[i-1] and i >= 1
            limit_2days = df["is_limit"].iloc[i-1] and df["is_limit"].iloc[i-2] and i >= 2
            if not limit_today:
                continue
            is_2b = (prev_limit and not df["is_limit"].iloc[i-2]) if i >= 2 else prev_limit
            if not is_2b:
                continue
            fat_body = df["body_ratio"].iloc[i] > 0.6
            big_vol = df["volume"].iloc[i] > df["vol_ma5"].iloc[i] * 1.2
            above_ma5 = df["close"].iloc[i] > df["ma5"].iloc[i]
            above_ma10 = df["close"].iloc[i] > df["ma10"].iloc[i]
            if big_vol and above_ma5 and above_ma10:
                df.loc[df.index[i], "signal"] = Signal.BUY.value
            limit_break = not df["is_limit"].iloc[i] and df["is_limit"].iloc[i-1]
            if limit_break:
                df.loc[df.index[i], "signal"] = Signal.SELL.value
        return df


# ==================== 19. 陈小群·首板战法 ====================

class ChenXiaoQunShouBan(BaseStrategy):
    name = "陈小群·首板战法"
    description = "首板战法：热点板块前排首板，7-8个点关注9个点以上参与。前期有妖股/龙头基因的更好。回封板(炸板换手后再次回封)也可参与。"
    author = "陈小群"
    params = {"目标": "板块前排首板", "条件": "前期有龙头基因", "回封": "炸板换手后回封可参与"}

    def generate_signals(self, df):
        df = self.add_indicators(df)
        df["signal"] = Signal.HOLD.value
        if "change_pct" in df.columns:
            df["is_limit"] = df["change_pct"] >= 9.5
        else:
            df["is_limit"] = df["close"] >= df["close"].shift(1) * 1.095
        df["not_prev_limit"] = (~df["is_limit"].shift(1).fillna(False).astype(bool))
        df["past_glory"] = False
        for i in range(min(120, len(df))):
            window = df["is_limit"].iloc[max(0,i-40):i]
            df.loc[df.index[i], "past_glory"] = window.sum() >= 3 if not window.empty else False
        for i in range(1, len(df)):
            shouban = df["is_limit"].iloc[i] and df["not_prev_limit"].iloc[i]
            big_vol = df["volume"].iloc[i] > df["vol_ma5"].iloc[i] * 1.5
            glory = df["past_glory"].iloc[i]
            huifeng = df["is_limit"].iloc[i] and df["high"].iloc[i] > df["open"].iloc[i] * 1.08 and df["volume"].iloc[i] > df["vol_ma5"].iloc[i] * 2.0
            if shouban and (big_vol and glory):
                df.loc[df.index[i], "signal"] = Signal.BUY.value
            elif shouban and huifeng:
                df.loc[df.index[i], "signal"] = Signal.BUY.value
            elif shouban and big_vol:
                df.loc[df.index[i], "signal"] = Signal.BUY.value
        in_pos = False
        for i in range(len(df)):
            if df["signal"].iloc[i] == Signal.BUY.value:
                in_pos = True
            elif in_pos:
                df.loc[df.index[i], "signal"] = Signal.SELL.value
                in_pos = False
        return df


# ==================== 20. 醉酒大佬·放量长上影 ====================

class ZuiJiuDaLa(BaseStrategy):
    name = "醉酒大佬·放量长上影"
    description = "放量长上影选股：长期横盘/上涨初期出现放量长上影，近期有涨停回调后底部承接强。市值100亿内一进二模式。大盘环境要求3000家上涨才买入。"
    author = "醉酒大佬"
    params = {"选股": "放量长上影", "环境": "3000家上涨", "一进二": "市值100亿内+15天内有涨停"}

    def generate_signals(self, df):
        df = self.add_indicators(df)
        df["signal"] = Signal.HOLD.value
        df["shangying"] = df["high"] - df[["close", "open"]].max(axis=1)
        df["shiti"] = (df["close"] - df["open"]).abs()
        df["shangying_ratio"] = df["shangying"] / (df["shiti"] + 1e-10)
        if "change_pct" in df.columns:
            df["is_limit"] = df["change_pct"] >= 9.5
        else:
            df["is_limit"] = df["close"] >= df["close"].shift(1) * 1.095
        for i in range(21, len(df)):
            has_shangying = df["shangying_ratio"].iloc[i] > 2.0 and df["shangying"].iloc[i] > df["close"].iloc[i] * 0.03
            big_vol = df["volume"].iloc[i] > df["vol_ma20"].iloc[i] * 1.5
            hengpan = df["close"].iloc[i-20:i].std() / df["close"].iloc[i] < 0.08
            recent_limit = df["is_limit"].iloc[max(0,i-15):i].sum() >= 1
            not_high = df["close"].iloc[i] < df["ma60"].iloc[i] * 1.3
            if has_shangying and big_vol and (hengnan or recent_limit) and not_high:
                df.loc[df.index[i], "signal"] = Signal.BUY.value
            change = df.get("change_pct", pd.Series(0)).iloc[i] if "change_pct" in df.columns else 0
            if change < -3 or df["close"].iloc[i] < df["ma20"].iloc[i] * 0.95:
                df.loc[df.index[i], "signal"] = Signal.SELL.value
        return df


# ==================== 21. 摇头哥·三模式 ====================

class YaoTouSanMoShi(BaseStrategy):
    name = "摇头哥·三模式"
    description = "短线只做三件事：1)早盘首板(北京炒妖式首板) 2)低位二进三连板 3)高位龙头(7-8板)。龙头首次出现快速上影时做补涨首板。"
    author = "摇头哥"
    params = {"模式1": "早盘首板", "模式2": "低位二进三", "模式3": "高位龙头", "补涨": "龙头分歧做补涨首板"}

    def generate_signals(self, df):
        df = self.add_indicators(df)
        df["signal"] = Signal.HOLD.value
        if "change_pct" in df.columns:
            df["is_limit"] = df["change_pct"] >= 9.5
        else:
            df["is_limit"] = df["close"] >= df["close"].shift(1) * 1.095
        for i in range(11, len(df)):
            shouban = df["is_limit"].iloc[i] and (not df["is_limit"].shift(1).fillna(False).iloc[i])
            erjin3 = df["is_limit"].iloc[i] and df["is_limit"].iloc[i-1] and i >= 1
            gaowei = df["is_limit"].iloc[i-5:i].sum() >= 4 if i >= 5 else False
            if shouban:
                df.loc[df.index[i], "signal"] = Signal.BUY.value
            elif erjin3:
                fat_vol = df["volume"].iloc[i] > df["vol_ma5"].iloc[i] * 1.2
                if fat_vol:
                    df.loc[df.index[i], "signal"] = Signal.BUY.value
            elif gaowei and df["is_limit"].iloc[i]:
                first_gap = df["high"].iloc[i] - df["close"].iloc[i] > df["close"].iloc[i] * 0.05
                if first_gap:
                    df.loc[df.index[i], "signal"] = Signal.BUY.value
        in_pos = False
        for i in range(len(df)):
            if df["signal"].iloc[i] == Signal.BUY.value:
                in_pos = True
            elif in_pos:
                df.loc[df.index[i], "signal"] = Signal.SELL.value
                in_pos = False
        return df


# ==================== 组合策略·投票系统 ====================

class CombinationStrategy(BaseStrategy):
    name = "组合策略·投票系统"
    description = "多策略加权投票：综合全部13个策略的信号，按权重投票决定最终买卖信号。"
    author = "系统集成"
    params = {"投票机制": "每个策略一票", "买入阈值": "超过50%策略看多", "加权方式": "可按历史胜率加权"}

    def __init__(self, strategies=None, weights=None):
        super().__init__()
        self.strategies = strategies or [
            QiaoBangZhu(), YiShunLiuGuang(), ChaoGuYangJia(),
            TuiXueChaoGu(), DaBan(), LongTou(), HuanFang(),
            HuanFangDynamic(), WeiPan(), KeBi(), ChenXiaoQun(),
            ZhuMingCiKe(), ChanLun(),
            YeaRenDiXi(), YeaRenErCiHuiCai(), YeaRenQiangGengQiang(),
            AoshuWeiPan(), DaMao2BJieLi(), ChenXiaoQunShouBan(),
            ZuiJiuDaLa(), YaoTouSanMoShi(),
        ]
        self.weights = weights or {s.name: 1.0 for s in self.strategies}
        self.params["子策略数量"] = len(self.strategies)

    def generate_signals(self, df):
        df = df.copy()
        df["signal"] = Signal.HOLD.value
        if "factor_score" not in df.columns:
            df["factor_score"] = 50.0
        votes = np.zeros(len(df))
        total_weight = sum(self.weights.values())
        for strategy in self.strategies:
            try:
                sdf = strategy.generate_signals(df.copy())
                w = self.weights.get(strategy.name, 1.0)
                for i in range(len(sdf)):
                    if sdf["signal"].iloc[i] > 0:
                        votes[i] += w
                    elif sdf["signal"].iloc[i] < 0:
                        votes[i] -= w
            except Exception:
                continue
        threshold = total_weight * 0.3
        for i in range(len(votes)):
            if votes[i] > threshold:
                df.loc[df.index[i], "signal"] = Signal.BUY.value
            elif votes[i] < -threshold:
                df.loc[df.index[i], "signal"] = Signal.SELL.value
        if "factor_score" in df.columns:
            hf = HuanFang()
            try:
                hdf = hf.generate_signals(df.copy())
                df["factor_score"] = hdf["factor_score"]
            except Exception:
                pass
        return df


# ==================== 策略注册表 ====================

ALL_STRATEGIES = {
    "乔帮主·低吸反弹": QiaoBangZhu,
    "一瞬流光·趋势跟踪": YiShunLiuGuang,
    "炒股养家·情绪接力": ChaoGuYangJia,
    "退学炒股·逆势交易": TuiXueChaoGu,
    "涨停打板·短线博弈": DaBan,
    "龙头战法·强者恒强": LongTou,
    "幻方量化·多因子改进": HuanFang,
    "幻方量化·动态多因子": HuanFangDynamic,
    "尾盘选股·尾盘动量": WeiPan,
    "92科比·首板挖掘": KeBi,
    "陈小群·龙头二波": ChenXiaoQun,
    "著名刺客·分歧转一致": ZhuMingCiKe,
    "缠论·分型中枢": ChanLun,
    "野人·低吸战法": YeaRenDiXi,
    "野人·二次回踩": YeaRenErCiHuiCai,
    "野人·强更强": YeaRenQiangGengQiang,
    "奥数老师·尾盘量化": AoshuWeiPan,
    "大毛哥·2B接力": DaMao2BJieLi,
    "陈小群·首板战法": ChenXiaoQunShouBan,
    "醉酒大佬·放量长上影": ZuiJiuDaLa,
    "摇头哥·三模式": YaoTouSanMoShi,
    "组合策略·投票系统": CombinationStrategy,
}


def get_strategy(name):
    cls = ALL_STRATEGIES.get(name)
    if cls is None:
        return None
    if cls == CombinationStrategy:
        return CombinationStrategy()
    return cls()


def list_strategies():
    return list(ALL_STRATEGIES.keys())
