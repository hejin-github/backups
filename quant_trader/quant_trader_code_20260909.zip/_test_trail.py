import sys
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')
import os
cand = [os.path.join('D:/', x, 'quant_trader') for x in os.listdir('D:/')
        if os.path.isdir(os.path.join('D:/', x, 'quant_trader'))]
p = cand[0]
sys.path.insert(0, p)
import dragon_strategy as D
import pandas as pd


def mk(dates, opens, closes, chg):
    return pd.DataFrame({'date': dates, 'open': opens, 'close': closes,
                         'high': closes, 'low': opens, 'change_pct': chg,
                         'amount': [20e8] * len(dates), 'turnover': [20] * len(dates)})


# A: 连涨3日(涨停)盈利~30%, 第4日断板(转trailing), 第5日从峰值回撤>8% → 移动止盈
dates = ['20260901', '20260902', '20260903', '20260904', '20260905']
h = mk(dates, [10, 11, 12.1, 13.31, 12.65], [11, 12.1, 13.31, 12.65, 11.5],
       [10, 10, 10, -5, -9])
o = D._recompute_pos({'entry_date': '20260901'}, h, '20260905', risk_rules=True)
print('A:', o['status'], o.get('tag'), 'days', o.get('days_held'), 'exit', o.get('exit_price'))

# B: 小赚断板(<10%) → 立即断板卖
h2 = mk(dates, [10, 11, 12, 13, 14], [11, 10.5, 9, 8, 7], [10, -4.5, -10, -11, -12])
o2 = D._recompute_pos({'entry_date': '20260901'}, h2, '20260905', risk_rules=True)
print('B:', o2['status'], o2.get('tag'), 'days', o2.get('days_held'))

# C: 大赚但断板当日仅小回撤(<8%) → 继续持仓(等回撤达标)
h3 = mk(['20260901', '20260902', '20260903', '20260904'],
        [10, 11, 12.1, 13.31], [11, 12.1, 13.31, 13.0], [10, 10, 10, -3])
o3 = D._recompute_pos({'entry_date': '20260901'}, h3, '20260904', risk_rules=True)
print('C:', o3['status'], o3.get('tag'), 'days', o3.get('days_held'))
