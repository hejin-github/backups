# -*- coding: utf-8 -*-
"""
Stage1 建库: 按行情自适应选股实验的数据层(一次性建库, 供 Stage2/Stage3 共享)

一次拉取: 上证指数(1001日, 截至上一交易日) + 全市场金额 top-N 股票历史 → 磁盘缓存
产出:
  data/history_cache/{code}_{start}_{end}.json   (asof + OHLCV 列表; 三个脚本共享, 限流只付一次)
  data/ranker_experiment/candidates.csv          (D,stock) 候选行 + ranker 信号 + T+1 收益
  data/ranker_experiment/regime_runs.json        (分析窗口内各档位连续区间)
  data/ranker_experiment/meta.json               (asof/窗口/阈值/去重口径)

方法(无前视泄漏, 与 replay_new_logic_test 同骨架):
  - asof = 上一交易日(绝不取 now, 排除当日未收盘 bar 与末根无 T+1)
  - 指数截止 asof; 分析窗口 = 倒数 trade_days 个交易日
  - 个股窗口 = 分析窗口首日 -90 日历日 ~ asof(预留策略预热 + allowed 种子桶)
  - allowed 集 = 前缀法: 对分析日 D, 只用 date<D 的信号按档位统计(样本≥30,胜率≥52%,均值>0)
  - 候选 = 分析日 D 被 ≥1 个 allowed 策略看多 且 当日有 T+1 数据的股票
用法:
  python experiment_common.py                          # 主 = 300交易日×200只
  python experiment_common.py --trade-days 400 --sample-limit 300   # 稳健性 = 400日×300只
"""
import argparse
import json
import os
import sys
from bisect import bisect_left
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

from stock_api import StockAPI
from stock_universe import filter_universe
from strategies import list_strategies, get_strategy
from strategy_backtest import REGIMES, _classify_regime, _prev_trading_day

BASE = os.path.dirname(os.path.abspath(__file__))
CACHE_DIR = os.environ.get("EXP_CACHE_DIR") or os.path.join(BASE, "data", "history_cache")
OUT_DIR = os.environ.get("EXP_OUT_DIR") or os.path.join(BASE, "data", "ranker_experiment")

MIN_TOTAL = 30
MIN_WIN = 52.0
MIN_AVG = 0.0
WARMUP = 20          # 每只股票信号起点(指标预热)
WARMUP_CAL = 90      # 分析窗口首日之前多拉 90 日历日 → 预热 + allowed 种子桶


# ───────────────────────── 指数/档位 ─────────────────────────

def _index_sina(lookback_days=1001):
    """新浪日K指数(sh000001, scale=240)回退. 返回 df[date,close] 或 None.
    腾讯 fqkline 端点偶发 501; 指数不复权无影响, 收盘点位同源."""
    import urllib.request
    try:
        dl = max(lookback_days, 500)
        url = ("https://quotes.sina.cn/cn/api/json_v2.php/CN_MarketDataService.getKLineData?"
               f"symbol=sh000001&scale=240&ma=no&datalen={dl}")
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0",
                                                  "Referer": "https://finance.sina.com.cn/"})
        arr = json.loads(urllib.request.urlopen(req, timeout=12).read().decode("utf-8"))
        if not arr:
            return None
        rows = [{"date": pd.to_datetime(r["day"]).normalize(), "close": float(r["close"])} for r in arr]
        df = pd.DataFrame(rows).sort_values("date").reset_index(drop=True)
        return df
    except Exception:
        return None


def load_index_regimes(lookback_days=1001, asof=None):
    """上证逐日档位(截至 asof)。返回 (regimes: {date->level}, idx_df[date,close,ma20,change_pct]) 或 (None,None)。
    腾讯优先, 失败回退新浪日K, 再回退本地 index_guide 缓存."""
    if asof is None:
        asof = _prev_trading_day()
    idx = None
    try:
        idx = StockAPI.get_index_historical_data("sh000001", days=lookback_days)
    except Exception:
        idx = None
    if idx is None or len(idx) < 30:
        idx = _index_sina(lookback_days)
    if idx is None or len(idx) < 30:
        try:
            from index_guide import load_sh_raw
            raw = load_sh_raw()
            dates, closes = raw.get("dates", []), raw.get("closes", [])
            if len(dates) >= 30:
                idx = pd.DataFrame({"date": pd.to_datetime(dates), "close": closes})
        except Exception:
            idx = None
    if idx is None or len(idx) < 30:
        return None, None
    idx = idx.sort_values("date").reset_index(drop=True)
    idx["date"] = pd.to_datetime(idx["date"]).dt.normalize()
    idx = idx[idx["date"] <= pd.Timestamp(asof)].reset_index(drop=True)
    if len(idx) < 30:
        return None, None
    idx["ma20"] = idx["close"].rolling(20).mean()
    idx = idx.dropna(subset=["ma20"]).reset_index(drop=True)
    regimes = {}
    for _, row in idx.iterrows():
        regimes[row["date"]] = _classify_regime(float(row["close"]), float(row["ma20"]))
    return regimes, idx


def regime_runs(days):
    """分析窗口内各档位连续区间: [{regime,start,end,days}]"""
    runs, cur, start = [], None, None
    for d in sorted(days):
        lvl = days[d]
        if lvl != cur:
            if cur is not None:
                runs.append({"regime": cur, "start": start.strftime("%Y%m%d"),
                             "end": prev.strftime("%Y%m%d"), "days": (prev - start).days + 1})
            cur, start = lvl, d
        prev = d
    if cur is not None:
        runs.append({"regime": cur, "start": start.strftime("%Y%m%d"),
                     "end": prev.strftime("%Y%m%d"), "days": (prev - start).days + 1})
    return runs


# ───────────────────────── 个股历史缓存 ─────────────────────────

def hist_window(asof, lookback_days):
    """统一股票历史请求窗口: 从 asof 回看 int(lookback_days*1.75) 日历日(≈留足指标预热).
    返回 (start_str, end_str)。所有脚本用同一函数+同一 lookback_days → 缓存 key 一致, 共享磁盘缓存。"""
    end = pd.Timestamp(asof).normalize()
    start = end - pd.Timedelta(days=int(lookback_days * 1.75))
    return start.strftime("%Y%m%d"), end.strftime("%Y%m%d")


def fetch_hist_cached(code, start_str, end_str, asof):
    """磁盘缓存个股历史(含 asof)。返回 DataFrame[date,open,close,high,low,volume,change_pct,amount] 或 None。"""
    os.makedirs(CACHE_DIR, exist_ok=True)
    path = os.path.join(CACHE_DIR, f"{code}_{start_str}_{end_str}.json")
    if os.path.exists(path):
        try:
            data = json.load(open(path, encoding="utf-8"))
            if data.get("asof") == pd.Timestamp(asof).strftime("%Y%m%d"):
                bars = data["bars"]
                df = pd.DataFrame(bars)
                df["date"] = pd.to_datetime(df["date"])
                df = df.sort_values("date").reset_index(drop=True)
                for col in ("open", "close", "high", "low", "volume", "change_pct", "amount"):
                    df[col] = pd.to_numeric(df[col], errors="coerce")
                return df
        except Exception:
            pass
    try:
        h = StockAPI.get_historical_data(code, start_str, end_str)
    except Exception:
        h = None
    if h is None or len(h) < 30:
        return None
    h = h.sort_values("date").reset_index(drop=True)
    h["date"] = pd.to_datetime(h["date"]).dt.normalize()
    if "change_pct" not in h.columns:
        h["change_pct"] = h["close"].pct_change().fillna(0) * 100
    if "amount" not in h.columns:
        h["amount"] = h["volume"] * h["close"]
    bars = h[["date", "open", "close", "high", "low", "volume", "change_pct", "amount"]].to_dict("records")
    for b in bars:
        b["date"] = b["date"].strftime("%Y%m%d")
    json.dump({"asof": pd.Timestamp(asof).strftime("%Y%m%d"),
               "start": start_str, "end": end_str, "bars": bars},
              open(path, "w", encoding="utf-8"), ensure_ascii=False)
    return h


# ───────────────────────── ranker 信号 ─────────────────────────

def _daily_t1_win_rate(closes, idx):
    """trailing 20 日 T+1 胜率(≤idx 的数据, 无前视)。样本<8 返回 None。"""
    if idx < 9:
        return None
    lo = max(0, idx - 20)
    wins, tot = 0, 0
    for i in range(lo, idx):
        b, s = closes[i], closes[i + 1]
        if b > 0:
            tot += 1
            if s / b - 1 > 0:
                wins += 1
    if tot < 8:
        return None
    return round(wins / tot, 4)


def _trailing_avg_ret(closes, idx, n):
    """trailing n 日 T+1 收益均值(≤idx)。"""
    lo = max(0, idx - n)
    vals = [closes[i + 1] / closes[i] - 1 for i in range(lo, idx) if closes[i] > 0]
    if not vals:
        return None
    return float(np.mean(vals)) * 100


# ───────────────────────── 主建库 ─────────────────────────

def build(asof=None, trade_days=300, sample_limit=200, index_days=1001, out_name=None):
    """out_name: 输出文件名前缀(如 '400x300' → candidates_400x300.csv); None=默认."""
    if asof is None:
        asof = _prev_trading_day()
    os.makedirs(OUT_DIR, exist_ok=True)
    suf = f"_{out_name}" if out_name else ""
    csv_path = os.path.join(OUT_DIR, f"candidates{suf}.csv")
    runs_path = os.path.join(OUT_DIR, f"regime_runs{suf}.json")
    meta_path = os.path.join(OUT_DIR, f"meta{suf}.json")

    # 1) 采样股票(今日全市场金额 top-N, 时点资格重判见候选行 eligible)
    quotes = StockAPI.get_realtime_quotes()
    if quotes is None or quotes.empty:
        print("实时行情为空, 无法采样")
        return None
    quotes = filter_universe(quotes)
    sort_col = "amount" if "amount" in quotes.columns else "price"
    quotes = quotes.sort_values(sort_col, ascending=False)
    sample = quotes.head(sample_limit)
    codes = sample["code"].astype(str).str.replace(r"\.(SH|SZ|BJ)$", "", regex=True).str.zfill(6).tolist()
    print(f"采样股票: {len(codes)} (金额 top{sample_limit})")

    # 2) 指数档位 + 分析窗口
    regimes, idx = load_index_regimes(index_days, asof)
    if idx is None:
        print("指数数据不足")
        return None
    idx_dates = idx["date"].tolist()
    idx_close = idx["close"].astype(float).tolist()
    dset = sorted(regimes.keys())           # 全量可用日(有 ma20)
    analysis_days = set(dset[-trade_days:])  # 分析窗口 = 倒数 trade_days 日
    print(f"指数档位日: {len(dset)} | 分析窗口: {len(analysis_days)} 日 "
          f"({dset[-trade_days].date()}~{dset[-1].date()})")

    # 3) 拉个股历史(磁盘缓存, 截至 asof; 腾讯偶发整块限流 → 多轮线程+退避)
    first_analysis = dset[-trade_days]
    start_dt = first_analysis - timedelta(days=WARMUP_CAL)
    start_str, end_str = start_dt.strftime("%Y%m%d"), pd.Timestamp(asof).strftime("%Y%m%d")
    hist_cache = {}

    def _fetch_pass(cands, workers):
        # fetch_hist_cached 直接返回 DataFrame(或 None), 不返回 (code, h) 元组;
        # 不能 c,h = f.result() 解包(会把列名解出来). 用 fs[f] 找回 code.
        got = {}
        with ThreadPoolExecutor(max_workers=workers) as ex:
            fs = {ex.submit(fetch_hist_cached, c, start_str, end_str, asof): c for c in cands}
            for f in as_completed(fs):
                try:
                    h = f.result()
                except Exception:
                    h = None
                if h is not None and len(h) >= 30:
                    got[fs[f]] = h
        return got

    hist_cache.update(_fetch_pass(codes, 8))
    for backoff in (15, 45, 120):       # 限流按时间恢复, 逐轮加长退避
        missing = [c for c in codes if c not in hist_cache]
        if not missing:
            break
        print(f"缺失 {len(missing)}, 退避 {backoff}s 后补拉...")
        import time
        time.sleep(backoff)
        hist_cache.update(_fetch_pass(missing, 6))
    print(f"个股历史: {len(hist_cache)}/{len(codes)}")

    # 4) 信号序列(每条: (D, code, strategy, i, ret, regime))
    strategy_names = [n for n in list_strategies() if n != "组合策略·投票系统"]
    raw = []  # (d, code, sname, i, ret, regime)
    for sname in strategy_names:
        try:
            stg = get_strategy(sname)
        except Exception:
            continue
        if stg is None:
            continue
        for code, hist in hist_cache.items():
            try:
                sdf = stg.generate_signals(hist.copy())
            except Exception:
                continue
            if "signal" not in sdf.columns:
                continue
            sig = sdf["signal"].astype(float).values
            closes = hist["close"].astype(float).values
            dates = hist["date"].values
            n = len(sig)
            for i in range(WARMUP, n - 1):
                s = sig[i]
                if not np.isfinite(s) or s <= 0 or closes[i] <= 0:
                    continue
                d = pd.Timestamp(dates[i]).normalize()
                regime = regimes.get(d)
                if regime is None:
                    continue
                raw.append((d, code, sname, i, (closes[i + 1] / closes[i] - 1) * 100, regime))
    print(f"信号总数: {len(raw)}")

    # 5) 逐日: 前缀 allowed → 候选 → 更新桶
    idx_ret = {}  # date -> 上证当日 T+1 %
    for pos, d in enumerate(idx_dates):
        if pos + 1 < len(idx_close):
            idx_ret[d] = (idx_close[pos + 1] / idx_close[pos] - 1) * 100

    bucket = {s: {r: [] for r in REGIMES} for s in strategy_names}

    def _allowed_now():
        out = {r: [] for r in REGIMES}
        for s in strategy_names:
            for r in REGIMES:
                rets = bucket[s][r]
                t = len(rets)
                if t < MIN_TOTAL:
                    continue
                wr = sum(1 for x in rets if x > 0) / t * 100
                avg = float(np.mean(rets))
                if wr >= MIN_WIN and avg > MIN_AVG:
                    out[r].append((s, avg))
        for r in REGIMES:
            out[r].sort(key=lambda x: -x[1])
            out[r] = [x[0] for x in out[r]]
        return out

    # 按日分组信号
    day_map = {}
    for d, code, sname, i, ret, regime in raw:
        day_map.setdefault(d, []).append((code, sname, i, ret, regime))

    rows = []
    n_allowed_days = 0
    for d in sorted(day_map.keys()):
        allowed = _allowed_now() if d in analysis_days else None
        if allowed is not None:
            n_allowed_days += 1
        grp = day_map[d]
        # 聚合 (code)-> 信息
        agg = {}
        for code, sname, i, ret, regime in grp:
            a = agg.setdefault(code, {"snames": set(), "i": i, "regime": regime, "ret": ret})
            a["snames"].add(sname)
        # 候选行(仅分析窗口内, 有 allowed)
        if allowed is not None:
            al = set(allowed.get(regimes[d], [])) if d in regimes else set()
            for code, a in agg.items():
                n_allowed = sum(1 for s in a["snames"] if s in al)
                if n_allowed < 1:
                    continue
                hist = hist_cache[code]
                i = a["i"]
                closes = hist["close"].astype(float).values
                opens = hist["open"].astype(float).values
                highs = hist["high"].astype(float).values
                chg = float(hist["change_pct"].iloc[i])
                amt = float(hist["amount"].iloc[i]) if "amount" in hist.columns else float(hist["volume"].iloc[i]) * closes[i]
                prev_pos = bisect_left(idx_dates, d)
                gap = 0
                if i > 0:
                    gap = prev_pos - bisect_left(idx_dates, pd.Timestamp(hist["date"].iloc[i - 1]).normalize()) - 1
                rows.append({
                    "date": pd.Timestamp(d).strftime("%Y%m%d"),
                    "code": code,
                    "regime": a["regime"],
                    "signal_count": len(a["snames"]),
                    "allowed_count": n_allowed,
                    "change_pct": round(chg, 2),
                    "amount": round(amt, 0),
                    "close": round(closes[i], 2),
                    "twr20": _daily_t1_win_rate(closes, i),
                    "avg20": _trailing_avg_ret(closes, i, 20),
                    "avg30": _trailing_avg_ret(closes, i, 30),
                    "ret": round(a["ret"], 4),
                    "ret_excess": round(a["ret"] - idx_ret.get(d, 0.0), 4),
                    "gap_days": gap,
                    "limit_up_close": int(closes[i] >= highs[i] * 0.999 and chg >= 9.5),
                    "eligible": int(closes[i] >= 3.0 and opens[i] > 0),
                })
        # 更新桶(date<D 语义: D 日信号不用于 D 日 allowed, 处理完 D 再入桶)
        for code, a in agg.items():
            for sname in a["snames"]:
                bucket[sname][a["regime"]].append(a["ret"])

    df = pd.DataFrame(rows)
    df.to_csv(csv_path, index=False, encoding="utf-8-sig")
    print(f"候选行: {len(df)} | 日期数(有 allowed): {n_allowed_days}")

    runs = regime_runs({d: regimes[d] for d in sorted(analysis_days)})
    with open(runs_path, "w", encoding="utf-8") as f:
        json.dump(runs, f, ensure_ascii=False, indent=2)
    print("各档位连续区间:")
    for r in runs:
        print(f"  {r['regime']:<6} {r['start']}~{r['end']} ({r['days']} 日)")

    meta = {
        "asof": pd.Timestamp(asof).strftime("%Y%m%d"),
        "trade_days": trade_days, "sample_limit": sample_limit,
        "stocks": len(hist_cache), "strategies": len(strategy_names),
        "candidates": len(df), "signal_total": len(raw),
        "window": {"start": start_str, "end": end_str, "first_analysis": first_analysis.strftime("%Y%m%d")},
        "thresholds": {"min_total": MIN_TOTAL, "min_win": MIN_WIN, "min_avg": MIN_AVG},
        "warmup": WARMUP,
        "note": "幸存者偏差: 今日 top-amount 回溯采样, 结果方向=高估",
    }
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)
    print(f"meta 已保存: {meta_path}")
    return df


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--trade-days", type=int, default=300)
    ap.add_argument("--sample-limit", type=int, default=200)
    ap.add_argument("--index-days", type=int, default=1001)
    ap.add_argument("--out-name", default=None)
    args = ap.parse_args()
    build(trade_days=args.trade_days, sample_limit=args.sample_limit,
          index_days=args.index_days, out_name=args.out_name)
