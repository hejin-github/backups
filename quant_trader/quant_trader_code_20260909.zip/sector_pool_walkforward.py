# -*- coding: utf-8 -*-
"""
sector_pool_walkforward.py — 板块池 walk-forward 样本外验证: 按行情切策略门控是否真有效

回答: sector_pool 样本内的"normal 甜点区/涨停打板全档正"在样本外(只用 date<D 数据选策略)是否成立?
方法(无未来函数):
  - 宇宙=生产扫描口径 top-300 by 成交额, asof=上一交易日; 共享 experiment_common 磁盘缓存;
  - 收益=真实 open 口径(D+1 开盘买入→D+1 收盘卖), 一字开盘买不进过滤, 扣 0.20% 成本;
  - 逐日 D(从小到大): 用 date<D 的增量计数器(总/胜/和)算档位门槛
      allowed[R] = 策略: trailing(R) 总数≥30 且 胜率≥52% 且 均值>0 (按均值降序)
    adaptive = allowed[regime(D)]; fixed = 全局(跨档)allowed; all = 不过滤;
    adaptive 空 → 回退 fixed(数据不足不切换);
  - 当日池收益 = 池内可买股票 open 均值 - 成本(无票=0);
  - 配对 bootstrap 1 万次 → 均值差 90% CI + P(差>0); 逐档位; NAV/maxDD/年化Sharpe。

预注册判定(全过才 SUPPORT 按行情切):
  #1 全窗口 mean(adaptive) ≥ mean(fixed)+0.2pp 且 ≥ mean(all)+0.2pp, bootstrap 90%CI 下界>0
  #2 逐档位: adaptive 与 fixed 不同的档 r, mean(adaptive|r) ≥ mean(fixed|r)+0.3pp 且 r 有≥15 pick日;
     不够15日的标"证据不足"(不判赢不判输)
  #3 风险: adaptive maxDD ≤ fixed+2pp 且 Sharpe ≥ fixed
输出: data/ranker_experiment/sector_pool_walkforward.json
"""
import json
import os
import sys
from bisect import bisect_left
from collections import defaultdict

import numpy as np
import pandas as pd

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

from stock_api import StockAPI
from stock_universe import filter_universe
from strategies import list_strategies, get_strategy
from experiment_common import fetch_hist_cached, hist_window, load_index_regimes
from strategy_backtest import _prev_trading_day

BASE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(BASE, "data", "ranker_experiment")
OUT = os.path.join(OUT_DIR, "sector_pool_walkforward.json")   # 全市场 top-N 成交额宇宙
OUT_PROD = os.path.join(OUT_DIR, "sector_pool_walkforward_prod.json")  # 生产热门板块成分宇宙
WARMUP = 20
COST = 0.20
MIN_TOTAL, MIN_WIN, MIN_AVG = 30, 52.0, 0.0
BOOT_N = 10000
SEED = 42
# 生产宇宙口径(与 recommender.py 保持一致): 排除噪声板块、count≥8、按当日强度降序取 top5、
# 每板块成分 filter_universe 后按成交额取 top30。实时接口无历史板块快照 → 用今日热门板块做固定宇宙。
MIN_SECTOR_COUNT = 8
MAX_STOCKS_PER_SECTOR = 30
_EXCLUDE_SECTOR_NAMES = ("次新", "ST", "退", "活跃", "新股", "预亏", "风险", "高送转", "昨日涨停")


def _build_hot_sector_universe(max_sectors=5):
    """复刻生产热门板块池: 返回 (codes, hot_sectors) 或 (None, None)."""
    sectors = StockAPI.get_industry_sectors()
    if sectors is None or sectors.empty:
        return None, None
    sectors = sectors[~sectors["name"].astype(str).str.contains("|".join(_EXCLUDE_SECTOR_NAMES), na=False)]
    sectors = sectors[sectors["count"] >= MIN_SECTOR_COUNT]
    if sectors.empty:
        return None, None
    sectors = sectors.sort_values("avg_change_pct", ascending=False)
    hot = [dict(s) for _, s in sectors.head(max_sectors).iterrows()]
    codes, seen = [], set()
    for sec in hot:
        members = StockAPI.get_industry_stocks(sec["code"])
        if members is None or members.empty:
            continue
        members = filter_universe(members)
        if members.empty:
            continue
        members = members.sort_values("amount", ascending=False).head(MAX_STOCKS_PER_SECTOR)
        for c in members["code"].astype(str).str.strip():
            if c not in seen:
                seen.add(c)
                codes.append(c)
    return codes, hot


def _stats(rets):
    if not rets:
        return None
    a = np.array(rets)
    wins, loss = a[a > 0], a[a <= 0]
    if len(wins) and len(loss):
        wl = float(wins.mean() / abs(loss.mean()))
    elif len(wins):
        wl = float("inf")
    else:
        wl = 0.0
    return {"n": len(a), "win_rate": round(100 * (a > 0).mean(), 1),
            "mean": round(float(a.mean()), 3), "std": round(float(a.std()), 3),
            "win_loss_ratio": round(wl, 2) if wl != float("inf") else 999.0}


def _bootstrap_diff(a, b, n=BOOT_N, seed=SEED):
    """a,b 同长日序列; 返回 均值差(pp) + 90%CI + P(差>0)."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(a), size=(n, len(a)))
    da, db = a[idx], b[idx]
    diffs = da.mean(axis=1) - db.mean(axis=1)
    lo = np.percentile(diffs, 5)
    hi = np.percentile(diffs, 95)
    return round(float(a.mean() - b.mean()), 3), round(float(lo), 3), round(float(hi), 3), \
        round(float((diffs > 0).mean()), 3)


def _nav_stats(daily):
    """daily: 逐日净收益%(已扣成本, 无票=0). 返回 maxDD/Sharpe/总NAV."""
    if not daily:
        return {"maxDD": 0.0, "sharpe": 0.0}
    v = np.array(list(daily.values()), float)
    navc = np.cumprod(1 + v / 100.0)
    peak = np.maximum.accumulate(navc)
    dd = float(((navc - peak) / peak * 100).min())
    sharpe = float(np.mean(v) / np.std(v) * np.sqrt(252)) if np.std(v) > 0 else 0.0
    return {"days": len(v), "maxDD": round(dd, 2), "sharpe": round(sharpe, 2),
            "cum_pct": round((navc[-1] - 1) * 100, 2)}


def run(sample_limit=300, lookback_days=400, asof=None, cost=COST, universe="amount", hot_sectors=5):
    if asof is None:
        asof = _prev_trading_day()
    asof_ts = pd.Timestamp(asof).normalize()
    if universe == "hot_sector":
        print(f"walk-forward 生产宇宙(热门板块成分): top{hot_sectors}板块×top{MAX_STOCKS_PER_SECTOR} | "
              f"窗口 {lookback_days} 交易日 | asof={asof_ts.date()} | 扣{cost}%")
        codes, hot = _build_hot_sector_universe(max_sectors=hot_sectors)
        if not codes:
            print("热门板块接口失败或空池"); return None
        print(f"热门板块({len(hot)}): " + "、".join(f"{s.get('name')}({s.get('avg_change_pct',0):+.2f}%)" for s in hot))
    else:
        print(f"walk-forward 板块池: top{sample_limit} | 窗口 {lookback_days} 交易日 | asof={asof_ts.date()} | 扣{cost}%")
        quotes = StockAPI.get_realtime_quotes()
        if quotes is None or quotes.empty:
            print("实时行情获取失败(腾讯网络?)"); return None
        quotes = filter_universe(quotes)
        sort_col = "amount" if "amount" in quotes.columns else "price"
        sample = quotes.sort_values(sort_col, ascending=False).head(sample_limit)
        codes = sample["code"].tolist()

    regimes, idx = load_index_regimes(lookback_days, asof)
    if idx is None:
        print("指数数据不足"); return None
    print(f"指数档位日: {len(regimes)}")

    start_str, end_str = hist_window(asof_ts, lookback_days)
    from concurrent.futures import ThreadPoolExecutor, as_completed
    hist_cache = {}

    def _pass(cands, workers):
        got = {}
        with ThreadPoolExecutor(max_workers=workers) as ex:
            fs = {ex.submit(fetch_hist_cached, c, start_str, end_str, asof): c for c in cands}
            for f in as_completed(fs):
                try:
                    h = f.result()
                except Exception:
                    h = None
                if h is not None and len(h) >= 30:
                    got[fs[f]] = h
        return got

    hist_cache.update(_pass(codes, 8))
    for backoff in (15, 45, 120):
        missing = [c for c in codes if c not in hist_cache]
        if not missing:
            break
        print(f"缺失 {len(missing)}, 退避 {backoff}s 补拉...")
        import time
        time.sleep(backoff)
        hist_cache.update(_pass(missing, 6))
    print(f"个股历史: {len(hist_cache)}/{len(codes)}")

    strategies = [n for n in list_strategies() if n != "组合策略·投票系统"]
    # 逐股逐策略 → 信号日 (date, open_ret, buyable)
    day_map = defaultdict(list)   # date -> [(sname, code, open_ret, buyable)]
    for sname in strategies:
        try:
            stg = get_strategy(sname)
        except Exception:
            continue
        if stg is None:
            continue
        for code, hist in hist_cache.items():
            try:
                sdf = stg.generate_signals(hist.copy())
            except Exception:
                continue
            if "signal" not in sdf.columns:
                continue
            sig = sdf["signal"].astype(float).values
            closes = hist["close"].astype(float).values
            opens = hist["open"].astype(float).values
            highs = hist["high"].astype(float).values
            lows = hist["low"].astype(float).values
            dates = hist["date"].values
            n = len(sig)
            for i in range(WARMUP, n - 1):
                if sig[i] <= 0 or closes[i] <= 0 or opens[i + 1] <= 0:
                    continue
                d = pd.Timestamp(dates[i]).normalize()
                if d not in regimes:
                    continue
                o = closes[i + 1] / opens[i + 1] - 1
                oneword = (highs[i + 1] - lows[i + 1]) < 0.03 and opens[i + 1] >= highs[i + 1] - 0.005
                day_map[d].append((sname, code, o * 100, not oneword))
    print(f"信号日: {len(day_map)} | 信号条数: {sum(len(v) for v in day_map.values())}")

    # 增量计数器(只用 date<D 的数据): trail_all[sname] 与 trail_rg[sname][regime]
    cnt_all, win_all, sum_all = defaultdict(int), defaultdict(int), defaultdict(float)
    cnt_rg, win_rg, sum_rg = {}, {}, {}
    for s in strategies:
        cnt_rg[s] = {r: 0 for r in ["strong", "normal", "weak", "crash"]}
        win_rg[s] = {r: 0 for r in ["strong", "normal", "weak", "crash"]}
        sum_rg[s] = {r: 0.0 for r in ["strong", "normal", "weak", "crash"]}

    def _allowed(d):
        """date<D 数据上的档位门槛. 返回 (adaptive_list, fixed_list)."""
        rg = regimes[d]
        adaptive, fixed = [], []
        for s in strategies:
            ta, tw, ts = cnt_all[s], win_all[s], sum_all[s]
            if ta >= MIN_TOTAL and 100 * tw / ta >= MIN_WIN and ts / ta > MIN_AVG:
                fixed.append((s, ts / ta))
            ra, rw, rs = cnt_rg[s][rg], win_rg[s][rg], sum_rg[s][rg]
            if ra >= MIN_TOTAL and 100 * rw / ra >= MIN_WIN and rs / ra > MIN_AVG:
                adaptive.append((s, rs / ra))
        fixed.sort(key=lambda x: -x[1]); adaptive.sort(key=lambda x: -x[1])
        return [x[0] for x in adaptive], [x[0] for x in fixed]

    daily = {"adaptive": {}, "fixed": {}, "all": {}}
    day_meta = {}  # date -> {regime, n_all, n_fixed, n_adaptive, fallback}
    for d in sorted(day_map.keys()):
        rg = regimes[d]
        grp = day_map[d]
        # 每股聚合: 可买信号 → (策略集合, open_ret)
        per_stock = {}
        for sname, code, o, buy in grp:
            if not buy:
                continue
            a = per_stock.setdefault(code, {"s": set(), "o": o})
            a["s"].add(sname)
        if not per_stock:
            for arm in daily:
                daily[arm][d] = 0.0
            continue

        adaptive_raw, fixed = _allowed(d)
        was_fallback = not adaptive_raw
        adaptive = adaptive_raw if adaptive_raw else fixed   # 数据不足回退
        set_all = {s for s, _, _, _ in grp}
        set_fixed = set(fixed)
        set_adaptive = set(adaptive)

        def _arm_pool(member_set):
            return [v["o"] for v in per_stock.values() if v["s"] & member_set]

        p_all = _arm_pool(set_all)
        p_fixed = _arm_pool(set_fixed)
        p_adaptive = _arm_pool(set_adaptive)
        daily["all"][d] = (float(np.mean(p_all)) - cost) if p_all else 0.0
        daily["fixed"][d] = (float(np.mean(p_fixed)) - cost) if p_fixed else 0.0
        daily["adaptive"][d] = (float(np.mean(p_adaptive)) - cost) if p_adaptive else 0.0
        day_meta[str(d.date())] = {"regime": rg, "n_all": len(p_all), "n_fixed": len(p_fixed),
                                   "n_adaptive": len(p_adaptive), "fallback": was_fallback}

        # 入桶(仅可买 open 收益; 供 D 之后的日期用)
        for sname, code, o, buy in grp:
            if not buy:
                continue
            cnt_all[sname] += 1; win_all[sname] += (o > 0); sum_all[sname] += o
            cnt_rg[sname][rg] += 1; win_rg[sname][rg] += (o > 0); sum_rg[sname][rg] += o

    # ── 结果 ──
    out_path = OUT_PROD if universe == "hot_sector" else OUT
    result = {"meta": {"asof": asof_ts.strftime("%Y%m%d"), "universe": universe,
                       "sample_limit": sample_limit, "hot_sectors": hot_sectors,
                       "lookback_days": lookback_days, "stocks": len(hist_cache),
                       "cost": cost, "thresholds": {"min_total": MIN_TOTAL, "min_win": MIN_WIN,
                                                    "min_avg": MIN_AVG},
                       "note": "真实open口径, 一字开盘买不进过滤, 逐日只用date<D选策略; "
                               "hot_sector宇宙=今日热门板块成分固定池(无历史板块快照, 披露方向=高估)"},
              "daily": {a: {str(k.date()): round(v, 3) for k, v in daily[a].items()} for a in daily},
              "day_meta": day_meta}
    for arm in daily:
        vals = list(daily[arm].values())
        result[arm] = {**_stats(vals), **_nav_stats({i: v for i, v in enumerate(vals)})}

    # 配对对比(全窗口含0日)
    comp = {}
    dk = sorted(set(daily["adaptive"]) | set(daily["fixed"]) | set(daily["all"]))
    for base in ("fixed", "all"):
        b = [daily[base].get(d, 0.0) for d in dk]
        a = [daily["adaptive"].get(d, 0.0) for d in dk]
        m, lo, hi, p = _bootstrap_diff(a, b)
        comp[f"vs_{base}"] = {"mean_diff_pp": m, "ci90": [lo, hi], "p_gt0": p}
    result["comparisons"] = comp

    # 逐档位
    reg_daily = {r: {"adaptive": [], "fixed": [], "all": [], "days": 0} for r in ["strong", "normal", "weak", "crash"]}
    for d in sorted(day_map.keys()):
        rg = regimes[d]
        reg_daily[rg]["days"] += 1
        for arm in daily:
            reg_daily[rg][arm].append(daily[arm].get(d, 0.0))
    result["per_regime"] = {}
    for rg, dd in reg_daily.items():
        row = {"days": dd["days"]}
        for arm in ("adaptive", "fixed", "all"):
            if dd[arm]:
                a = np.array(dd[arm])
                row[f"{arm}_mean"] = round(float(a.mean()), 3)
                row[f"{arm}_win"] = round(100 * (a > 0).mean(), 1)
        # adaptive vs fixed 在该档
        if dd["adaptive"] and dd["fixed"]:
            m, lo, hi, p = _bootstrap_diff(dd["adaptive"], dd["fixed"])
            row["adapt_minus_fixed"] = {"mean_pp": m, "ci90": [lo, hi], "p_gt0": p}
        result["per_regime"][rg] = row

    # 判定
    v = {}
    v["#1_net"] = bool(comp["vs_fixed"]["mean_diff_pp"] >= 0.2
                       and comp["vs_all"]["mean_diff_pp"] >= 0.2
                       and comp["vs_fixed"]["ci90"][0] > 0)
    v["#2_regime"] = "见明细"
    v["#3_risk"] = bool(result["adaptive"]["maxDD"] >= result["fixed"]["maxDD"] - 2
                        and result["adaptive"]["sharpe"] >= result["fixed"]["sharpe"])
    result["verdict"] = v

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    # 打印
    print("\n全窗口(含0日, 已扣成本):")
    for arm in ("adaptive", "fixed", "all"):
        r = result[arm]
        print(f"  {arm:<9} mean={r['mean']:+.3f}% win={r['win_rate']}% | maxDD={r['maxDD']:+.1f}% "
              f"sharpe={r['sharpe']} cum={r['cum_pct']:+.1f}% n={r['n']}")
    print("\n配对 bootstrap(adaptive − base):")
    for base in ("fixed", "all"):
        c = comp[f"vs_{base}"]
        print(f"  vs {base:<5} diff={c['mean_diff_pp']:+.3f}pp CI90[{c['ci90'][0]:+.3f},{c['ci90'][1]:+.3f}] P(diff>0)={c['p_gt0']}")
    print("\n逐档位(已扣成本):")
    for rg, row in result["per_regime"].items():
        print(f"  {rg:<6} days={row['days']:>3} adaptive={row.get('adaptive_mean','—'):>8} "
              f"fixed={row.get('fixed_mean','—'):>8} all={row.get('all_mean','—'):>8} | "
              f"adapt-fixed={row.get('adapt_minus_fixed',{}).get('mean_pp','—')}")
    print(f"\n判定: #1净收益={v['#1_net']} #3风险={v['#3_risk']} → "
          f"{'SUPPORT 按行情切' if v['#1_net'] and v['#3_risk'] else 'FAIL_不支持'}")
    print(f"结果 → {out_path}")
    return result


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--sample-limit", type=int, default=300)
    ap.add_argument("--lookback-days", type=int, default=400)
    ap.add_argument("--asof", default=None)
    ap.add_argument("--universe", choices=["amount", "hot_sector"], default="amount",
                    help="amount=全市场topN成交额; hot_sector=生产热门板块成分池")
    ap.add_argument("--hot-sectors", type=int, default=5)
    args = ap.parse_args()
    run(sample_limit=args.sample_limit, lookback_days=args.lookback_days, asof=args.asof,
        universe=args.universe, hot_sectors=args.hot_sectors)
