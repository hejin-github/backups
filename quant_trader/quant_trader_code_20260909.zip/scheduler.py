"""
定时启停调度模块
根据A股交易时段自动启动/停止后台扫描、市场监控、日报生成
"""
import json
import os
import threading
import time as time_module
from datetime import datetime, time as dtime, timedelta

try:
    import akshare as ak
    import pandas as pd
    _HAS_AK = True
except ImportError:
    _HAS_AK = False


# ── A股交易日历缓存（跳过周末和法定节假日） ──
_TRADE_CALENDAR_CACHE = None
_TRADE_CALENDAR_CACHE_YEAR = None
_TRADE_CAL_CACHE_TS = 0.0          # 最近一次尝试拉取时间戳（失败冷却用）
_TRADE_CAL_CACHE_LOCK = threading.Lock()


def _load_trade_calendar():
    """加载A股交易日历（带缓存+失败冷却），返回set[date]或None。

    成功则缓存当年数据(进程内一次下载)，失败则在冷却期内不再重复请求
    (新浪接口偶发超时/限流，若每次调用都重试会导致渲染期间反复网络请求)。"""
    global _TRADE_CALENDAR_CACHE, _TRADE_CALENDAR_CACHE_YEAR, _TRADE_CAL_CACHE_TS
    now = datetime.now()
    if _TRADE_CALENDAR_CACHE is not None and _TRADE_CALENDAR_CACHE_YEAR == now.year:
        return _TRADE_CALENDAR_CACHE
    if not _HAS_AK:
        return None
    # 失败冷却：10 分钟内不重复拉取，避免渲染中反复请求拖慢页面
    if time_module.time() - _TRADE_CAL_CACHE_TS < 600:
        return None
    with _TRADE_CAL_CACHE_LOCK:
        if _TRADE_CALENDAR_CACHE is not None and _TRADE_CALENDAR_CACHE_YEAR == now.year:
            return _TRADE_CALENDAR_CACHE
        _TRADE_CAL_CACHE_TS = time_module.time()
        try:
            df = ak.tool_trade_date_hist_sina()
            # 只保留当年
            dates = set()
            for d in df["trade_date"]:
                if hasattr(d, "year") and d.year == now.year:
                    dates.add(d if hasattr(d, "date") else d.date() if hasattr(d, "date") else d)
                elif str(d)[:4] == str(now.year):
                    from datetime import date as ddate
                    parts = str(d).split("-")
                    dates.add(ddate(int(parts[0]), int(parts[1]), int(parts[2])))
            if dates:  # 非空才写缓存
                _TRADE_CALENDAR_CACHE = dates
                _TRADE_CALENDAR_CACHE_YEAR = now.year
                return dates
            return None
        except Exception:
            return None

def is_trading_day(dt=None):
    """完整交易日判断：周末 + 法定节假日"""
    if dt is None:
        dt = datetime.now()
    if dt.weekday() >= 5:
        return False
    cal = _load_trade_calendar()
    if cal is not None:
        return dt.date() in cal
    return dt.weekday() < 5  # fallback

def _next_trading_day(from_dt):
    """从from_dt开始找下一个交易日（含当天）"""
    d = from_dt if isinstance(from_dt, datetime) else datetime.combine(from_dt, dtime(0, 0))
    for _ in range(14):  # max 14 days ahead
        if is_trading_day(d):
            return d
        d += timedelta(days=1)
    return d

# 默认交易时段
DEFAULT_SCHEDULE = {
    "enabled": True,
    "market_open": "09:25",      # 开盘启动扫描
    "market_close": "15:05",     # 收盘停止扫描
    "scan_interval": 180,        # 全策略扫描间隔(秒)
    "monitor_interval": 60,      # 行情监控间隔(秒)
    "generate_report": True,     # 收盘是否自动生成日报
    "weekdays_only": True,       # 仅工作日运行
    "morning_scan": True,        # 9:25开盘前预扫描
    "noon_break": False,         # 中午11:30-13:00是否暂停
    "afternoon_scan": True,      # 13:00午后重新扫描
    "hedge_auto_run": True,      # 9:15自动运行对冲组合回测
}

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "schedule_config.json")


def load_config():
    """加载调度配置"""
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                cfg = json.load(f)
                for k, v in DEFAULT_SCHEDULE.items():
                    cfg.setdefault(k, v)
                return cfg
        except Exception:
            pass
    return dict(DEFAULT_SCHEDULE)


def save_config(cfg):
    """保存调度配置"""
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def parse_time(t_str):
    """解析"HH:MM"字符串为dtime"""
    parts = t_str.strip().split(":")
    return dtime(int(parts[0]), int(parts[1]))


def is_trading_time(cfg=None):
    """判断当前是否在交易时段内"""
    if cfg is None:
        cfg = load_config()
    if not cfg.get("enabled", True):
        return True  # 未启用定时，默认可运行
    now = datetime.now()
    if not is_trading_day(now):
        return False
    open_t = parse_time(cfg.get("market_open", "09:25"))
    close_t = parse_time(cfg.get("market_close", "15:05"))
    current = dtime(now.hour, now.minute)
    in_session = open_t <= current <= close_t
    # 午休处理
    if in_session and cfg.get("noon_break", False):
        noon_start = dtime(11, 30)
        noon_end = dtime(13, 0)
        if noon_start <= current <= noon_end:
            return False
    return in_session


def time_until_next_open(cfg=None):
    """距离下次开盘的秒数（跳过周末和法定节假日）"""
    if cfg is None:
        cfg = load_config()
    now = datetime.now()
    open_t = parse_time(cfg.get("market_open", "09:25"))
    target = now.replace(hour=open_t.hour, minute=open_t.minute, second=0, microsecond=0)
    if now > target:
        target += timedelta(days=1)
    while not is_trading_day(target):
        target += timedelta(days=1)
    return (target - now).total_seconds()


def time_until_next_close(cfg=None):
    """距离下次收盘的秒数（跳过周末和法定节假日）"""
    if cfg is None:
        cfg = load_config()
    now = datetime.now()
    close_t = parse_time(cfg.get("market_close", "15:05"))
    target = now.replace(hour=close_t.hour, minute=close_t.minute, second=0, microsecond=0)
    if now > target:
        target += timedelta(days=1)
    while not is_trading_day(target):
        target += timedelta(days=1)
    return (target - now).total_seconds()


class SchedulerEngine:
    """定时启停调度引擎"""

    def __init__(self):
        self.config = load_config()
        self._running = False
        self._thread = None
        self._status = {
            "state": "stopped",           # running / stopped / waiting_for_open
            "market_open": False,          # 当前是否在交易时段
            "scan_active": False,          # 后台扫描是否激活
            "monitor_active": False,       # 行情监控是否激活
            "last_scan_time": None,
            "last_report_time": None,
            "next_event": "",              # 下一个事件描述
            "next_event_in": 0,            # 下一个事件等待秒数
            "schedule_today": [],          # 今日时间线
        }
        self._callbacks = {
            "on_market_open": None,
            "on_market_close": None,
            "on_scan": None,
            "on_report": None,
            "on_hedge_backtest": None,
            "on_paper_trading": None,
        }
        self._lock = threading.Lock()
        self._hedge_run_today = False
        # 交易日内固定自动扫描时点(其余由用户手动扫描)
        self._scan_slots = ["09:25", "10:00", "10:35", "14:00", "14:30"]
        self._scan_fired = {"date": "", "slots": set()}

    def set_callback(self, name, func):
        """设置回调"""
        if name in self._callbacks:
            self._callbacks[name] = func

    def get_status(self):
        """获取状态快照"""
        with self._lock:
            return dict(self._status)

    def update_config(self, updates):
        """更新配置"""
        self.config.update(updates)
        save_config(self.config)

    def get_today_timeline(self):
        """生成今日时间线"""
        cfg = self.config
        if not cfg.get("enabled", True):
            return [("全天", "定时启停未启用，持续运行")]
        now = datetime.now()
        if not is_trading_day(now):
            return [("全天", "非交易日，暂停运行")]
        tl = []
        open_t = cfg.get("market_open", "09:25")
        close_t = cfg.get("market_close", "15:05")
        tl.append((open_t, "🔔 开盘 — 启动扫描/监控"))
        for slot in self._scan_slots:
            if slot != open_t:
                tl.append((slot, "📡 自动扫描"))
        if cfg.get("noon_break", False):
            tl.append(("11:30", "⏸️ 午间休市暂停"))
            tl.append(("13:00", "▶️ 午后恢复运行"))
        tl.append((close_t, "⏹️ 收盘 — 停止扫描/生成日报"))
        if cfg.get("generate_report", True):
            after_close = close_t.split(":")
            after_min = str(int(after_close[1]) + 5)
            tl.append((f"{after_close[0]}:{after_min}", "📊 日报生成"))
        return tl

    def _run_loop(self):
        """调度主循环"""
        while self._running:
            try:
                cfg = self.config
                now = datetime.now()
                is_holiday = not is_trading_day(now)
                market_open = is_trading_time(cfg)

                with self._lock:
                    self._status["market_open"] = market_open
                    self._status["schedule_today"] = self.get_today_timeline()

                if is_holiday:
                    next_td = _next_trading_day(now + timedelta(days=1))
                    self._status["state"] = "holiday"
                    self._status["next_event"] = f"等待{next_td.strftime('%m-%d')}开盘"
                    self._status["next_event_in"] = time_until_next_open(cfg)
                    time_module.sleep(120)
                    continue

                if not cfg.get("enabled", True):
                    self._status["state"] = "running"
                    self._status["next_event"] = "定时未启用"
                    time_module.sleep(30)
                    continue

                current_time = dtime(now.hour, now.minute, now.second)
                open_t = parse_time(cfg.get("market_open", "09:25"))
                close_t = parse_time(cfg.get("market_close", "15:05"))

                if open_t <= current_time <= close_t:
                    # ── 交易时段 ──
                    with self._lock:
                        was_active = self._status["state"] == "running"
                        self._status["state"] = "running"
                        self._status["scan_active"] = True
                        self._status["monitor_active"] = True
                        self._status["next_event"] = f"收盘 {cfg['market_close']}"
                        self._status["next_event_in"] = int(time_until_next_close(cfg))
                    if not was_active:
                        self._fire("on_market_open")
                else:
                    # ── 非交易时段 ──
                    with self._lock:
                        was_active = self._status["state"] == "running"
                        self._status["state"] = "waiting_for_open"
                        self._status["scan_active"] = False
                        self._status["monitor_active"] = False
                        self._status["next_event"] = f"开盘 {cfg['market_open']}"
                        self._status["next_event_in"] = int(time_until_next_open(cfg))
                    if was_active:
                        self._fire("on_market_close")
                        if cfg.get("generate_report", True):
                            self._fire("on_report")
                        self._fire("on_paper_trading")

                # ── 9:15 对冲组合自动回测 ──
                if not is_weekend and cfg.get("hedge_auto_run", True):
                    # 新的一天重置标记
                    today_str = datetime.now().strftime("%Y%m%d")
                    if not hasattr(self, "_hedge_date") or self._hedge_date != today_str:
                        self._hedge_date = today_str
                        self._hedge_run_today = False
                    # 9:15-9:20 窗口触发
                    hedge_time = dtime(9, 15)
                    if not self._hedge_run_today and dtime(9, 15) <= current_time <= dtime(9, 30):
                        self._hedge_run_today = True
                        self._fire("on_hedge_backtest")

                # 定时自动扫描: 交易日内固定时点触发(9:25/10:00/10:35/14:00), 其余由用户手动扫描
                today_str = now.strftime("%Y%m%d")
                if self._scan_fired.get("date") != today_str:
                    self._scan_fired = {"date": today_str, "slots": set()}
                if market_open and cfg.get("enabled", True):
                    now_hms = now.strftime("%H:%M")
                    for slot in self._scan_slots:
                        if slot in self._scan_fired["slots"] or now_hms < slot:
                            continue
                        self._scan_fired["slots"].add(slot)
                        self._fire("on_scan")
                        with self._lock:
                            self._status["last_scan_time"] = datetime.now()

            except Exception:
                pass

            time_module.sleep(30)  # 每30秒检查一次

    def _fire(self, event):
        """触发回调"""
        cb = self._callbacks.get(event)
        if cb:
            try:
                cb()
            except Exception:
                pass

    def start(self):
        """启动调度引擎"""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()

    def stop(self):
        """停止调度引擎"""
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)

    def get_scan_slots(self):
        """当日定时扫描时点列表."""
        return list(self._scan_slots)

    def is_final_scan(self):
        """当前时间是否已到(或超过)当日最后一次定时扫描时点."""
        if not self._scan_slots:
            return True
        last = max(self._scan_slots)
        return datetime.now().strftime("%H:%M") >= last

    def is_scan_active(self):
        """后台扫描是否应激活"""
        return self._status.get("scan_active", False) or not self.config.get("enabled", True)

    def is_monitor_active(self):
        """行情监控是否应激活"""
        return self._status.get("monitor_active", False) or not self.config.get("enabled", True)


# 全局单例
scheduler = SchedulerEngine()
