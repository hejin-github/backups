"""
策略信号蒸馏器
将全市场策略扫描结果 + 历史胜率 → 结构化文本卡片
供 agent/LLM 推理时直接读取，无需重新跑代码
"""
import json, os, glob
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import defaultdict

DISTILL_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "distilled")
CACHE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "hedge_results")


def _compute_strategy_win_rates():
    """策略历史胜率: 优先使用离样本回测(strategy_backtest.json), 回退到对冲缓存"""
    result = {}
    bt_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "strategy_backtest.json")
    if os.path.exists(bt_path):
        try:
            with open(bt_path, "r", encoding="utf-8") as f:
                bt = json.load(f)
            for name, agg in bt.items():
                a = agg.get("all", {})
                t = a.get("total", 0)
                result[name] = {
                    "win_rate": round(a.get("win_rate", 0), 1),
                    "wins": int(round(t * a.get("win_rate", 0) / 100)),
                    "total": t,
                    "avg_return": a.get("avg_return", 0),
                }
        except Exception:
            result = {}

    stats = defaultdict(lambda: {"wins": 0, "total": 0, "returns": []})
    for fp in glob.glob(os.path.join(CACHE_DIR, "*.json")):
        try:
            with open(fp, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            continue
        for pos in data.get("positions", []):
            sigs = pos.get("signals", [])
            t1 = pos.get("t1_actual_return")
            if t1 is not None and isinstance(t1, (int, float)):
                for s in sigs[:5]:
                    stats[s]["total"] += 1
                    if t1 > 0:
                        stats[s]["wins"] += 1
                    stats[s]["returns"].append(t1)
    for name, st in stats.items():
        if name in result:
            continue  # 已由回测数据覆盖
        result[name] = {
            "win_rate": round(st["wins"] / st["total"] * 100, 1) if st["total"] > 0 else 0,
            "wins": st["wins"],
            "total": st["total"],
            "avg_return": round(np.mean(st["returns"]), 2) if st["returns"] else 0,
        }
    return result


def run_distill(sample_limit=None):
    """全量蒸馏：扫描全市场→生成策略卡片→写入 data/distilled/"""
    from stock_api import StockAPI
    from strategies import list_strategies, get_strategy, CombinationStrategy

    os.makedirs(DISTILL_DIR, exist_ok=True)

    from stock_universe import filter_universe, is_eligible
    quotes = StockAPI.get_realtime_quotes()
    if quotes is None or quotes.empty:
        return None
    quotes = filter_universe(quotes)

    today_str = datetime.now().strftime("%Y%m%d_%H%M")
    end = datetime.now().strftime("%Y%m%d")
    start = (datetime.now() - timedelta(days=120)).strftime("%Y%m%d")

    # 历史胜率
    win_rates = _compute_strategy_win_rates()

    # 获取所有策略（排除组合策略）
    all_strategy_names = [n for n in list_strategies() if n != "组合策略·投票系统"]
    # 只取用户指定的sample_limit
    sample = quotes.head(sample_limit) if sample_limit else quotes
    stock_list = [(row["code"], row["name"]) for _, row in sample.iterrows()]

    # 批量获取历史数据
    from stock_api import StockAPI as SA
    hist_cache = {}
    def _fetch(code):
        h = SA.get_historical_data(code, start, end)
        return code, h
    with ThreadPoolExecutor(max_workers=8) as ex:
        fs = {ex.submit(_fetch, c): c for c, _ in stock_list}
        for f in as_completed(fs):
            try:
                c, h = f.result()
                if h is not None and len(h) >= 30:
                    hist_cache[c] = h
            except Exception:
                pass

    # ── 对每个策略运行扫描 ──
    strategy_cards = []
    dividend_info = {}  # 全市场综合信息

    for sname in all_strategy_names:
        try:
            stg = get_strategy(sname)
            if stg is None:
                continue
        except Exception:
            continue

        buy_stocks = []
        sell_stocks = []
        scored = []

        for code, name in stock_list:
            hist = hist_cache.get(code)
            if hist is None:
                continue
            try:
                sdf = stg.generate_signals(hist.copy())
            except Exception:
                continue
            if "signal" not in sdf.columns:
                continue
            last_sig = sdf["signal"].iloc[-1]
            price = float(hist["close"].iloc[-1])
            change = float(hist.get("change_pct", pd.Series([0])).iloc[-1]) if "change_pct" in hist.columns else 0
            if not is_eligible(code, name, price):
                continue

            entry = {"code": code, "name": name, "price": price, "change_pct": change}

            # T+1历史表现
            t1_returns = []
            for j in range(max(1, len(hist) - 30), len(hist)):
                buy_p = hist["close"].iloc[j - 1]
                sell_p = hist["close"].iloc[j]
                if buy_p > 0:
                    t1_returns.append((sell_p / buy_p - 1) * 100)
            if t1_returns:
                entry["t1_win_rate"] = round(sum(1 for r in t1_returns if r > 0) / len(t1_returns) * 100, 1)
                entry["t1_avg"] = round(np.mean(t1_returns), 2)
            else:
                entry["t1_win_rate"] = 0
                entry["t1_avg"] = 0

            if last_sig > 0:
                buy_stocks.append(entry)
            elif last_sig < 0:
                sell_stocks.append(entry)

            # 幻方评分
            if "factor_score" in sdf.columns:
                fs_val = float(sdf["factor_score"].iloc[-1])
                if not np.isnan(fs_val):
                    scored.append((code, name, fs_val, price, change))

        # 排序
        buy_stocks.sort(key=lambda x: x.get("t1_avg", 0), reverse=True)
        sell_stocks.sort(key=lambda x: x.get("t1_avg", 0))
        scored.sort(key=lambda x: x[2], reverse=True)

        # 历史胜率
        wr_info = win_rates.get(sname, {"win_rate": 0, "wins": 0, "total": 0, "avg_return": 0})
        total_signals = len(buy_stocks) + len(sell_stocks)
        net_bias = len(buy_stocks) - len(sell_stocks)

        if net_bias > 0:
            market_judgment = f"偏多(看多{len(buy_stocks)}只看空{len(sell_stocks)}只)"
        elif net_bias < 0:
            market_judgment = f"偏空(看多{len(buy_stocks)}只看空{len(sell_stocks)}只)"
        else:
            market_judgment = f"中性(看多{len(buy_stocks)}只看空{len(sell_stocks)}只)"

        # 生成该策略的因子评分排名
        top_scored = scored[:5]
        top_scored_str = " | ".join(f"{n}({sc:.0f}分)" for _, n, sc, _, _ in top_scored) if top_scored else "无"

        # 生成当前信号详情
        buy_lines = []
        for s in buy_stocks[:8]:
            t1_tag = f"T+1胜率{s['t1_win_rate']}%均{s['t1_avg']:+.2f}%" if s["t1_win_rate"] > 0 else ""
            chg_tag = f"当日{s['change_pct']:+.2f}%" if s["change_pct"] != 0 else ""
            buy_lines.append(f"  ✅ {s['name']}({s['code']}) {s['price']:.2f} {chg_tag} {t1_tag}")

        sell_lines = []
        for s in sell_stocks[:5]:
            t1_tag = f"T+1胜率{s['t1_win_rate']}%均{s['t1_avg']:+.2f}%" if s["t1_win_rate"] > 0 else ""
            chg_tag = f"当日{s['change_pct']:+.2f}%" if s["change_pct"] != 0 else ""
            sell_lines.append(f"  ❌ {s['name']}({s['code']}) {s['price']:.2f} {chg_tag} {t1_tag}")

        # 构建卡片
        card_parts = []
        card_parts.append(f"┌{'─'*60}┐")
        card_parts.append(f"│  策略: {sname:<51}│")
        card_parts.append(f"│  作者: {stg.author:<51}│")
        card_parts.append(f"├{'─'*60}┤")
        card_parts.append(f"│  核心理念: {stg.description[:54]:<54}│")
        card_parts.append(f"│  参数: {str(stg.params)[:54]:<54}│")
        card_parts.append(f"├{'─'*60}┤")
        card_parts.append(f"│  📊 历史表现                                      │")
        card_parts.append(f"│    总推荐{wr_info['total']}次 胜率{wr_info['win_rate']}%  "
                          f"({wr_info['wins']}/{wr_info['total']})  "
                          f"平均T+1{wr_info['avg_return']:+.2f}%                │")
        card_parts.append(f"├{'─'*60}┤")

        if buy_lines:
            card_parts.append(f"│  📈 当前看多 ({len(buy_stocks)}只)                          │")
            for line in buy_lines[:5]:
                line = line[:58]
                card_parts.append(f"│{line:<59}│")
        else:
            card_parts.append(f"│  📈 当前看多: 无                                    │")

        if sell_lines:
            card_parts.append(f"│  📉 当前看空 ({len(sell_stocks)}只)                          │")
            for line in sell_lines[:3]:
                line = line[:58]
                card_parts.append(f"│{line:<59}│")
        else:
            card_parts.append(f"│  📉 当前看空: 无                                    │")

        card_parts.append(f"├{'─'*60}┤")
        card_parts.append(f"│  📊 综合评估                                         │")
        card_parts.append(f"│    信号总数: {total_signals:<3}  |  市场判断: {market_judgment:<22}│")
        card_parts.append(f"│    评分TOP: {top_scored_str[:50]:<50}│")
        card_parts.append(f"└{'─'*60}┘")
        card_parts.append("")

        strategy_cards.append("\n".join(card_parts))

    # ── 全市场综合 ──
    all_buy_count = sum(sum(1 for _ in s if "看多" in s and "当前" in s) for s in strategy_cards)
    total_cards = len(strategy_cards)
    date_str = datetime.now().strftime("%Y-%m-%d %H:%M")

    header = (
        f"╔{'═'*60}╗\n"
        f"║  QuantTrader 策略信号蒸馏报告                    ║\n"
        f"║  生成时间: {date_str:<42}║\n"
        f"║  策略数量: {total_cards:<2}个                                    ║\n"
        f"║  扫描股票: {len(hist_cache):<4}只                                  ║\n"
        f"╚{'═'*60}╝\n\n"
    )

    full_report = header + "\n".join(strategy_cards)

    # ── 写入文件 ──
    fname = f"distilled_{datetime.now().strftime('%Y%m%d_%H%M')}.txt"
    fpath = os.path.join(DISTILL_DIR, fname)
    with open(fpath, "w", encoding="utf-8") as f:
        f.write(full_report)

    # 同时写入 latest.txt 便于随时引用
    latest_path = os.path.join(DISTILL_DIR, "latest.txt")
    with open(latest_path, "w", encoding="utf-8") as f:
        f.write(full_report)

    return {
        "file": fpath,
        "latest": latest_path,
        "cards": len(strategy_cards),
        "stocks": len(hist_cache),
        "strategies": all_strategy_names,
        "summary": full_report,
    }


def load_latest():
    """读取最新的蒸馏报告"""
    latest_path = os.path.join(DISTILL_DIR, "latest.txt")
    if os.path.exists(latest_path):
        with open(latest_path, "r", encoding="utf-8") as f:
            return f.read()
    return None


def get_strategy_card(strategy_name):
    """从latest.txt中提取指定策略的卡片"""
    text = load_latest()
    if not text:
        return None
    lines = text.split("\n")
    in_card = False
    card_lines = []
    target = f"策略: {strategy_name}"
    for line in lines:
        if target in line:
            in_card = True
        if in_card:
            card_lines.append(line)
            if line.startswith("└") and "┘" in line:
                break
    return "\n".join(card_lines) if card_lines else None


def get_bullish_stocks(min_signals=1, require_allowed=True):
    """获取当前策略信号看多的股票。

    require_allowed=True(默认): 只统计"今日行情档位样本外胜率≥52% 且 均值>0"的
    allowed 策略信号 —— 策略对/胜率高则无需多策略共识, 单策略即可放行(宁缺毋滥);
    signal_count/strategies 仍保留作展示提示(几只策略同时看好)。
    require_allowed=False: 旧逻辑, 仅按 min_signals 计数放行。
    """
    text = load_latest()
    if not text:
        return []
    stock_signals = defaultdict(list)
    cards = text.split("┌────")
    for card in cards[1:]:
        lines = card.split("\n")
        sname = ""
        for line in lines:
            if "策略:" in line:
                # 卡片行格式 "│  策略: <name><填充>│" → 取 "│" 前的干净策略名
                # (否则尾部填充空格+边框字符会让 allowed 精确比较失败, 详见 _parse_card_text)
                sname = line.split("策略:")[-1].split("│")[0].strip()
                break
        if not sname:
            continue
        for line in lines:
            if "✅" in line:
                parts = line.split("✅")
                for p in parts[1:]:
                    p = p.strip()
                    code = ""
                    name = ""
                    if "(" in p and ")" in p:
                        name = p.split("(")[0].strip()
                        code = p.split("(")[1].split(")")[0].strip()
                    if code:
                        stock_signals[code].append({"strategy": sname, "name": name})

    allowed = None
    if require_allowed:
        try:
            from recommender import index_regime
            from strategy_backtest import strategies_for_regime
            regime = index_regime()
            if regime.get("skip"):
                return []  # 大盘深度破位 → 空仓观望(与辩论/每日推荐一致)
            level = regime.get("level")
            allowed = set(strategies_for_regime(level)) if level else set()
        except Exception:
            allowed = None
        if allowed is not None and not allowed:
            return []  # 当前档位无高胜率策略 → 空仓观望

    from stock_universe import is_eligible
    result = []
    for code, sigs in stock_signals.items():
        if require_allowed and allowed is not None:
            sigs = [s for s in sigs if s["strategy"] in allowed]
        if not sigs:
            continue
        if len(sigs) >= min_signals and is_eligible(code, sigs[0]["name"], 0):
            result.append({
                "code": code,
                "name": sigs[0]["name"],
                "signal_count": len(sigs),
                "strategies": [s["strategy"] for s in sigs],
            })
    result.sort(key=lambda x: x["signal_count"], reverse=True)
    return result


if __name__ == "__main__":
    result = run_distill(sample_limit=200)
    if result:
        print(f"蒸馏完成: {result['cards']}个策略, {result['stocks']}只股票")
        print(f"文件: {result['file']}")
        # 打印第一个策略卡片
        first_card = result["summary"].split("┌────")[1]
        print(first_card[:500])
    else:
        print("蒸馏失败")
