"""
Agent 策略辩论引擎
多角色 AI agent 从不同交易风格角度辩论策略信号，
动态交互后得出综合交易决策。

设计理念：
- 每个 agent 代表一种交易流派，有独立的策略池和"性格"
- 辩论分多轮：开题立论 → 互相驳斥 → 最终立场
- 论据全部基于真实量化数据（胜率、信号数、T+1收益）
- 最终由主持人加权合成交易计划

自动缓存: 结果保存到 data/debate_cache.json，app 启动时自动加载
"""
import re
import os
import json
import time
import threading
import numpy as np
from collections import defaultdict
from distiller import load_latest, get_strategy_card, get_bullish_stocks

# ── 缓存 ──
CACHE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
CACHE_FILE = os.path.join(CACHE_DIR, "debate_cache.json")

MAX_DEBATE_PICKS = 8  # 单日辩论推荐封顶数(各策略独立达标, 放宽至多策略露脸)

_DEBATE_CACHE = None
_LAST_CACHE_MTIME = 0


def save_cache(result):
    """将辩论结果保存到缓存文件（JSON）"""
    global _DEBATE_CACHE, _LAST_CACHE_MTIME
    os.makedirs(CACHE_DIR, exist_ok=True)
    cache = {
        "timestamp": time.time(),
        "time_str": time.strftime("%Y-%m-%d %H:%M:%S"),
        "consensus_buys": [],
        "split_verdicts": [],
        "final_plan": result.get("final_plan", ""),
        "regime": result.get("regime"),
    }
    for item in result.get("consensus_buys", []):
        cache["consensus_buys"].append({
            "name": item.get("name", ""),
            "code": item.get("code", ""),
            "agents": item.get("agents", []),
            "consensus": item.get("consensus", "mid"),
            "confidence": round(float(np.mean(item.get("confidences", [0]))), 1) if item.get("confidences") else 0,
            "price": round(float(item.get("price", 0) or 0), 2),
            "t1_win": round(float(item.get("t1_win", 0) or 0), 1),
            "t1_avg": round(float(item.get("t1_avg", 0) or 0), 2),
        })
    for item in result.get("split_verdicts", []):
        cache["split_verdicts"].append({
            "name": item.get("name", ""),
            "code": item.get("code", ""),
            "agents": item.get("agents", []),
        })
    # debate log
    cache["debate_log"] = [
        e if e[0] != "agent" else (e[0], e[1], e[2])
        for e in result.get("debate_log", [])
    ]
    with open(CACHE_FILE, "w", encoding="utf-8") as f:
        json.dump(cache, f, ensure_ascii=False, indent=2)
    _DEBATE_CACHE = cache
    _LAST_CACHE_MTIME = os.path.getmtime(CACHE_FILE)


def load_cache():
    """加载缓存的辩论结果"""
    global _DEBATE_CACHE, _LAST_CACHE_MTIME
    if not os.path.exists(CACHE_FILE):
        _DEBATE_CACHE = None
        return None
    try:
        mtime = os.path.getmtime(CACHE_FILE)
        if _DEBATE_CACHE is not None and mtime == _LAST_CACHE_MTIME:
            return _DEBATE_CACHE
        with open(CACHE_FILE, "r", encoding="utf-8") as f:
            _DEBATE_CACHE = json.load(f)
        _LAST_CACHE_MTIME = mtime
        return _DEBATE_CACHE
    except Exception:
        _DEBATE_CACHE = None
        return None


def auto_refresh():
    """自动运行 回测刷新(每日至多一次) → 蒸馏 → 辩论 → 缓存（后台线程调用）"""
    from distiller import run_distill
    try:
        # 先确保策略回测 json 是"截至上一交易日"的无泄漏版本, 再蒸馏(卡片胜率+allowed集才新鲜)
        from strategy_backtest import ensure_backtest_refreshed
        ensure_backtest_refreshed()
        distill_result = run_distill()
        if distill_result is None:
            return None
        result = run_debate()
        if result:
            save_cache(result)
            return result
    except Exception as e:
        print(f"[debate] auto_refresh error: {e}")
    return None


def start_auto_refresh(interval_seconds=3600):
    """启动后台自动刷新线程（每隔 interval_seconds 运行一次）"""
    def _loop():
        auto_refresh()
        while True:
            time.sleep(interval_seconds)
            auto_refresh()
    t = threading.Thread(target=_loop, daemon=True)
    t.start()
    return t


# ── Agent 角色配置 ──
AGENT_ROLES = {
    "低吸猎手": {
        "avatar": "🎣",
        "style": "左侧交易·低吸潜伏",
        "focus": ["野人·低吸战法", "野人·二次回踩", "乔帮主·低吸反弹",
                   "退学炒股·逆势交易", "醉酒大佬·放量长上影"],
        "personality": "耐心等待回调，追求高盈亏比，不追高",
        "description": "深信'买在分歧，卖在一致'。专攻回调至关键支撑位的缩量企稳形态，"
                       "追求高盈亏比（3:1以上），愿意接受较低胜率换取大回报空间。",
        "weight": 1.0,
    },
    "打板先锋": {
        "avatar": "⚡",
        "style": "右侧交易·涨停接力",
        "focus": ["野人·强更强", "大毛哥·2B接力", "陈小群·首板战法",
                   "摇头哥·三模式", "92科比·首板挖掘", "涨停打板·短线博弈"],
        "personality": "只做最强，只做涨停，讲究确定性",
        "description": "短线核心是'强更强'。只参与涨停股，行情好多做，行情差少做。"
                       "首板、2B接力、龙头二波，只做最确定的阶段。",
        "weight": 1.0,
    },
    "趋势追踪者": {
        "avatar": "📈",
        "style": "趋势跟踪·动量策略",
        "focus": ["一瞬流光·趋势跟踪", "炒股养家·情绪接力", "龙头战法·强者恒强",
                   "陈小群·龙头二波", "缠论·分型中枢"],
        "personality": "顺势而为，不测顶，趋势破即走",
        "description": "趋势是唯一的朋友。均线多头排列、情绪周期启动时介入，"
                       "趋势破坏或情绪退潮时果断离场，不贪最后一个铜板。",
        "weight": 1.0,
    },
    "量化军师": {
        "avatar": "🧮",
        "style": "量化分析·多因子评分",
        "focus": ["幻方量化·多因子改进", "幻方量化·动态多因子",
                   "奥数老师·尾盘量化", "尾盘选股·尾盘动量"],
        "personality": "数据说话，因子评分，概率思维",
        "description": "不看图形凭感觉，用多因子模型给每只股票打分。"
                       "因子评分+历史胜率+统计套利，用概率优势长期取胜。",
        "weight": 1.2,
    },
}


def _parse_card_text(text):
    """解析单张策略卡片的文本 → 结构化 dict"""
    result = {}
    lines = text.strip().split("\n")

    for line in lines:
        if "策略:" in line and "│" in line:
            result["name"] = line.split("策略:")[-1].split("│")[0].strip()
        if "作者:" in line and "│" in line:
            result["author"] = line.split("作者:")[-1].split("│")[0].strip()
        if "核心理念:" in line:
            result["description"] = line.split("核心理念:")[-1].split("│")[0].strip()
        if "总推荐" in line:
            m = re.search(r"总推荐(\d+)次\s+胜率([\d.]+)%", line)
            if m:
                result["total_signals"] = int(m.group(1))
                result["win_rate"] = float(m.group(2))
            mr = re.search(r"平均T\+1([+-]\d+\.\d+)%", line)
            if mr:
                result["avg_return"] = float(mr.group(1))

    # 解析看多列表
    buy_stocks = []
    sell_stocks = []
    in_buy = False
    in_sell = False

    for line in lines:
        if "当前看多" in line:
            in_buy = True
            in_sell = False
            m = re.search(r"看多(\d+)只", line)
            if m:
                result["buy_count"] = int(m.group(1))
            continue
        if "当前看空" in line:
            in_sell = True
            in_buy = False
            m = re.search(r"看空(\d+)只", line)
            if m:
                result["sell_count"] = int(m.group(1))
            continue
        if "综合评估" in line:
            in_buy = in_sell = False

        if in_buy and "✅" in line:
            parsed = _parse_stock_line(line)
            if parsed:
                buy_stocks.append(parsed)
        if in_sell and "❌" in line:
            parsed = _parse_stock_line(line)
            if parsed:
                sell_stocks.append(parsed)

    result["buy_stocks"] = buy_stocks
    result["sell_stocks"] = sell_stocks

    # 评分TOP
    for line in lines:
        if "评分TOP" in line and "│" in line:
            top_str = line.split("评分TOP:")[-1].split("│")[0].strip()
            if top_str and top_str != "无":
                result["top_scores"] = top_str

    return result


def _parse_stock_line(line):
    """解析如 '✅ 东方财富(300059) 24.56 当日-1.91% T+1胜率56.7%均+0.21%'"""
    try:
        # 去掉 emoji
        clean = line.replace("✅", "").replace("❌", "").strip()
        # 提取 名称(代码)
        m = re.match(r"([^(]+)\(([^)]+)\)\s+([\d.]+)", clean)
        if not m:
            return None
        name = m.group(1).strip()
        code = m.group(2).strip()
        price = float(m.group(3))

        # T+1胜率 和 均收益
        t1_win = None
        t1_avg = None
        chg = None

        wr_m = re.search(r"T\+1胜率([\d.]+)%", clean)
        if wr_m:
            t1_win = float(wr_m.group(1))

        avg_m = re.search(r"均([+-]\d+\.\d+)%", clean)
        if avg_m:
            t1_avg = float(avg_m.group(1))

        chg_m = re.search(r"当日([+-]\d+\.\d+)%", clean)
        if chg_m:
            chg = float(chg_m.group(1))

        return {
            "name": name, "code": code, "price": price,
            "change_pct": chg, "t1_win_rate": t1_win, "t1_avg": t1_avg,
        }
    except Exception:
        return None


def parse_all_cards():
    """解析 latest.txt 中所有策略卡片"""
    text = load_latest()
    if not text:
        return []

    cards = []
    # 按卡片分隔符拆分
    blocks = text.split("┌────")[1:]  # 跳过 header
    for block in blocks:
        block = "┌────" + block  # 恢复卡片头
        parsed = _parse_card_text(block)
        if parsed and parsed.get("name"):
            cards.append(parsed)

    return cards


# ── Agent 类 ──

class DebateAgent:
    """辩论 agent：每个 agent 代表一种交易风格"""

    def __init__(self, role_name, config):
        self.name = role_name
        self.avatar = config["avatar"]
        self.style = config["style"]
        self.focus = config["focus"]
        self.personality = config["personality"]
        self.description = config["description"]
        self.weight = config["weight"]

        # 辩论状态
        self.round1_picks = []   # 第一轮推荐
        self.round1_reasoning = ""
        self.round2_rebuttals = ""  # 第二轮反驳
        self.round2_adjustments = []  # 修正后的推荐
        self.final_picks = []  # 最终推荐
        self.final_summary = ""

    def analyze_market(self, all_cards):
        """分析所有策略卡片，提取本 agent 关注的策略信号"""
        my_cards = [c for c in all_cards if c.get("name") in self.focus]
        other_cards = [c for c in all_cards if c.get("name") not in self.focus]

        # 聚合本风格策略的推荐
        buy_pool = defaultdict(list)   # code -> [card_name, ...]
        sell_pool = defaultdict(list)

        for card in my_cards:
            for s in card.get("buy_stocks", []):
                code = s["code"]
                s["from_strategy"] = card["name"]
                buy_pool[code].append(s)
            for s in card.get("sell_stocks", []):
                code = s["code"]
                s["from_strategy"] = card["name"]
                sell_pool[code].append(s)

        # 全市场概况
        all_buy_stocks = defaultdict(list)
        all_sell_stocks = defaultdict(list)
        for card in all_cards:
            for s in card.get("buy_stocks", []):
                all_buy_stocks[s["code"]].append({
                    "strategy": card["name"],
                    "t1_win_rate": s.get("t1_win_rate"),
                    "t1_avg": s.get("t1_avg"),
                })
            for s in card.get("sell_stocks", []):
                all_sell_stocks[s["code"]].append({
                    "strategy": card["name"],
                    "t1_win_rate": s.get("t1_win_rate"),
                    "t1_avg": s.get("t1_avg"),
                })

        self._all_cards = all_cards
        self._my_cards = my_cards
        self._other_cards = other_cards
        self._buy_pool = dict(buy_pool)
        self._sell_pool = dict(sell_pool)
        self._all_buy_stocks = dict(all_buy_stocks)
        self._all_sell_stocks = dict(all_sell_stocks)

        return {
            "my_cards": my_cards,
            "buy_pool": dict(buy_pool),
            "sell_pool": dict(sell_pool),
        }

    def round1_opening(self):
        """第一轮：开题立论 - 提出本风格的初始推荐"""
        lines = []
        lines.append(f"【{self.avatar} {self.name}（{self.style}）】")
        lines.append(f"  \"{self.personality}\"")
        lines.append("")

        # 本风格活跃策略数
        active_cards = [c for c in self._my_cards
                        if c.get("buy_stocks") or c.get("sell_stocks")]
        lines.append(f"  📊 关注的 {len(self._my_cards)} 个策略中 "
                     f"{len(active_cards)} 个产生信号:")

        for card in self._my_cards:
            buys = len(card.get("buy_stocks", []))
            sells = len(card.get("sell_stocks", []))
            wr = card.get("win_rate", 0)
            icon = "🟢" if buys > sells else ("🔴" if sells > buys else "⚪")
            lines.append(f"    {icon} {card['name']}: 看多{buys}只看空{sells}只"
                         f"  |  历史胜率{wr}%")

        lines.append("")

        # 看多推荐
        if self._buy_pool:
            scored = []
            for code, signals in self._buy_pool.items():
                # 综合评分：策略数量 + 平均T+1胜率
                t1_wins = [s.get("t1_win_rate") or 50 for s in signals]
                t1_avgs = [s.get("t1_avg") or 0 for s in signals]
                confidence = min(len(signals) / len(self._my_cards) * 100, 100)
                score = np.mean(t1_wins) * 0.6 + np.mean(t1_avgs) * 10 + confidence * 0.3
                scored.append({
                    "code": code,
                    "name": signals[0]["name"],
                    "price": signals[0]["price"],
                    "signals": signals,
                    "strategies": len(signals),
                    "avg_t1_win": round(np.mean(t1_wins), 1),
                    "avg_t1_return": round(np.mean(t1_avgs), 2),
                    "confidence": round(confidence, 0),
                    "score": round(score, 1),
                })
            scored.sort(key=lambda x: x["score"], reverse=True)

            self.round1_picks = scored[:5]

            lines.append(f"  📗 推荐做多（共{len(scored)}只候选，按置信度排序）:")
            for s in self.round1_picks:
                lines.append(
                    f"    ✅ {s['name']}({s['code']}) ¥{s['price']:.2f} "
                    f"|  {s['strategies']}个策略看好 "
                    f"|  T+1胜率{s['avg_t1_win']}% 均{s['avg_t1_return']:+.2f}% "
                    f"|  置信度{s['confidence']:.0f}%")
        else:
            lines.append("  ⚠️ 本风格策略当前无看多信号，建议观望。")

        self.round1_reasoning = "\n".join(lines)
        return self.round1_reasoning

    def round2_rebuttal(self, other_agents):
        """第二轮：互相驳斥 - 针对其他 agent 的推荐提出异议"""
        lines = []
        lines.append(f"【{self.avatar} {self.name} 的反驳】")
        lines.append("")

        # 检查其他 agent 的推荐是否与本风格信号冲突
        for agent in other_agents:
            if not agent.round1_picks:
                continue

            conflict_found = False
            for pick in agent.round1_picks:
                code = pick["code"]
                # 检查这个票是否在本风格的卖出列表中
                if code in self._sell_pool:
                    sell_signals = self._sell_pool[code]
                    conflict_found = True
                    sell_strats = [s["from_strategy"] for s in sell_signals[:3]]
                    lines.append(
                        f"  ⚠️ {agent.avatar}{agent.name}推荐的 {pick['name']}({code}) "
                        f"与本风格信号冲突！"
                    )
                    lines.append(
                        f"     我关注的 {'/'.join(sell_strats)} 策略发出看空信号。"
                    )
                    # 如果有T+1数据，补充
                    if pick.get("avg_t1_win"):
                        lines.append(
                            f"     该票T+1胜率仅{pick['avg_t1_win']}%，"
                            f"均收益{pick.get('avg_t1_return', 0):+.2f}%，需谨慎。"
                        )

            if not conflict_found:
                # 没有直接冲突，但可以补充本风格的看法
                my_picks_codes = {p["code"] for p in self.round1_picks}
                their_picks_codes = {p["code"] for p in agent.round1_picks}
                overlap = my_picks_codes & their_picks_codes
                if overlap:
                    for code in overlap:
                        lines.append(
                            f"  🤝 与 {agent.avatar}{agent.name} 在 "
                            f"{next(p['name'] for p in self.round1_picks if p['code']==code)} 上达成共识！"
                        )

        # 风控提示：如果本风格看空强烈，但其他人看多
        massive_sell = [code for code, sigs in self._sell_pool.items()
                        if len(sigs) >= 2]
        if massive_sell:
            dangerous = []
            for code in massive_sell:
                for agent in other_agents:
                    for pick in agent.round1_picks:
                        if pick["code"] == code:
                            dangerous.append(pick)
                            break
            if dangerous:
                lines.append("")
                lines.append("  🚨 风险提示：以下股票被多个 agent 推荐但同时被本风格看空：")
                for d in dangerous[:3]:
                    lines.append(f"    ❌ {d['name']}({d['code']})")

        if len(lines) == 2:  # 只有header，没有实质内容
            lines.append(f"  ✅ 本风格与其他 agent 无显著冲突，维持原判。")

        self.round2_rebuttals = "\n".join(lines)
        return self.round2_rebuttals

    def round3_finalize(self, other_agents):
        """第三轮：最终立场 - 基于辩论结果调整推荐"""
        lines = []
        lines.append(f"【{self.avatar} {self.name} 最终立场】")

        # 融合推荐：各 agent 独立按自身风格打分，不依赖其他 agent 共识
        combined = {}

        for pick in self.round1_picks:
            code = pick["code"]
            combined[code] = {
                "code": code,
                "name": pick["name"],
                "price": pick["price"],
                "reason": f"本风格看好",
                "confidence": pick["confidence"],
                "score": pick["score"],
                "t1_win": pick.get("avg_t1_win", 0),
                "t1_avg": pick.get("avg_t1_return", 0),
                "consensus_agents": [],
            }

        # 排序并取 top（仅按本风格预期收益得分）
        self.final_picks = sorted(combined.values(),
                                  key=lambda x: x["score"], reverse=True)[:5]

        if self.final_picks:
            lines.append(f"  📋 最终推荐（共{len(combined)}只候选）:")
            for p in self.final_picks:
                consensus_tag = ""
                if p.get("consensus_agents"):
                    consensus_tag = f" 共识:{','.join(p['consensus_agents'])}"
                lines.append(
                    f"    {'🟢' if p['confidence'] >= 60 else '🟡'} "
                    f"{p['name']} | {p['reason']} "
                    f"| 置信度{p['confidence']:.0f}%{consensus_tag}"
                )
        else:
            lines.append("  ⏸️ 建议观望，等待更明确的信号。")

        self.final_summary = "\n".join(lines)
        return self.final_summary


# ── 辩论主持人 ──

class DebateModerator:
    """辩论主持人：控制辩论流程，合成最终交易计划"""

    def __init__(self, agents):
        self.agents = agents
        self.round = 0
        self.consensus_buys = []
        self.split_verdicts = []
        self.final_plan = ""

    def run_debate(self, regime=None, cards=None):
        """运行完整的辩论流程
        cards: 可选. 传入历史卡片列表时直接使用(用于历史回放), 缺省读取 latest.txt
        """
        from recommender import _LOW_BUY_STRATEGIES
        from strategy_backtest import strategies_for_regime
        all_cards = parse_all_cards() if cards is None else cards
        if not all_cards:
            return None

        # 大盘门控: 按行情档位用回测数据决定可参与的策略组(强市动量/弱市打板/首板等按数据)
        level = (regime or {}).get("level")
        allowed = strategies_for_regime(level) if level else []
        if allowed:
            allowed_set = set(allowed)
            all_cards = [c for c in all_cards if c.get("name") in allowed_set]
        elif regime and regime.get("weak_only"):
            # 弱势行情回退到低吸类策略
            all_cards = [c for c in all_cards if c.get("name") in _LOW_BUY_STRATEGIES]
        elif level:
            # 有明确档位但允许集为空(无样本外胜率≥52% 且 均值>0 的策略) → 空仓观望, 不强行用全策略
            return {
                "debate_log": [
                    ("system", "🛑 当前行情档位无高胜率策略(样本外胜率≥52% 且 均值>0), "
                               "本次辩论不生成推荐, 建议空仓观望。"),
                ],
                "consensus_buys": [],
                "split_verdicts": [],
                "final_plan": "🛑 空仓观望\n当前行情档位无可信策略信号。",
                "cards": [],
                "regime": regime,
            }
        # level 未知(如历史回放) → 维持全卡片辩论

        # ── 赛前分析 ──
        for agent in self.agents:
            agent.analyze_market(all_cards)

        debate_log = []
        self.round = 1

        # ── Round 1: 开题立论 ──
        r1_start = f"\n{'='*60}\n  📣 第一轮：开题立论\n{'='*60}\n"
        debate_log.append(("system", r1_start))

        for agent in self.agents:
            opening = agent.round1_opening()
            debate_log.append(("agent", agent.name, opening))

        # ── Round 2: 互相驳斥 ──
        r2_start = f"\n{'='*60}\n  ⚔️ 第二轮：互相驳斥\n{'='*60}\n"
        debate_log.append(("system", r2_start))
        self.round = 2

        for i, agent in enumerate(self.agents):
            others = [a for j, a in enumerate(self.agents) if j != i]
            rebuttal = agent.round2_rebuttal(others)
            debate_log.append(("agent", agent.name, rebuttal))

        # ── Round 3: 最终立场 ──
        r3_start = f"\n{'='*60}\n  🎯 第三轮：最终立场\n{'='*60}\n"
        debate_log.append(("system", r3_start))
        self.round = 3

        for i, agent in enumerate(self.agents):
            others = [a for j, a in enumerate(self.agents) if j != i]
            final = agent.round3_finalize(others)
            debate_log.append(("agent", agent.name, final))

        # ── 主持人合成 ──
        moderator_start = f"\n{'='*60}\n  🏆 主持人总结\n{'='*60}\n"
        debate_log.append(("system", moderator_start))
        summary = self._moderator_summary()
        debate_log.append(("system", summary))

        return {
            "debate_log": debate_log,
            "consensus_buys": self.consensus_buys,
            "split_verdicts": self.split_verdicts,
            "final_plan": summary,
            "cards": all_cards,
            "regime": regime,
        }

    def _moderator_summary(self):
        """各 Agent 独立选股：以自身历史胜率/预期收益说话，不要求跨 Agent 共识。

        不同行情适配不同策略 —— 每个 Agent(风格)独立产出达标信号，
        不再把多 Agent 撞同一只票当作质量信号。最终只保留
        历史 T+1 胜率≥52% 且 预期收益为正的信号，按 期望收益(均值×胜率) 排序。
        """
        from stock_universe import is_eligible

        agent_picks = []
        sidelined = [a for a in self.agents if not a.final_picks]

        for agent in self.agents:
            for pick in agent.final_picks:
                code = pick.get("code")
                if not code:
                    continue
                t1_win = float(pick.get("t1_win") or 0)
                t1_avg = float(pick.get("t1_avg") or 0)
                name = str(pick.get("name", "")).strip("│ ")
                price = float(pick.get("price", 0) or 0)
                # 以胜率说话：只保留 样本外胜率≥52% 且 预期T+1收益为正的信号
                if t1_win < 52 or t1_avg <= 0:
                    continue
                if not is_eligible(code, name, price):
                    continue
                if price < 3:
                    continue
                # 质量分级基于信号自身胜率/预期，与多少 Agent 推荐无关
                if t1_win >= 58 and t1_avg >= 1.0:
                    tag = "high"
                elif t1_win >= 55:
                    tag = "mid"
                else:
                    tag = "low"
                agent_picks.append({
                    "name": name, "code": code,
                    "agents": [agent.name],   # 仅标注发起策略, 不再拼多 Agent
                    "agent": agent.name,
                    "confidence": pick.get("confidence", 0),
                    "price": price,
                    "t1_win": round(t1_win, 1),
                    "t1_avg": round(t1_avg, 2),
                    "score": pick.get("score", 0),
                    "consensus": tag,
                })

        if not agent_picks:
            self.consensus_buys = []
            self.split_verdicts = []
            self.final_plan = (
                "🏆 辩论终局 · 综合交易计划\n\n"
                "  ⏸️ 当前各策略均未产出达标信号（历史胜率≥52% 且 预期T+1收益>0），建议观望。\n\n"
                "  📋 风险提示：\n"
                "   - 信号基于各策略历史胜率与预期收益, 不同行情适配不同策略\n"
                "   - 建议结合大盘环境和个人风险偏好使用"
            )
            return self.final_plan

        # 按期望收益(均值×胜率)排序 —— 真正"以胜率说话"
        def _exp(p):
            return p["t1_avg"] * (p["t1_win"] / 100.0)

        # 每个 Agent 至多保留 top3, 避免单策略霸屏, 兼顾"多策略各有露脸"
        per_agent = defaultdict(list)
        for p in agent_picks:
            per_agent[p["agent"]].append(p)
        trimmed = []
        for a, ps in per_agent.items():
            ps.sort(key=_exp, reverse=True)
            trimmed += ps[:3]
        trimmed.sort(key=_exp, reverse=True)

        # 同票去重(保留期望收益更高者), 不凑共识; 全局封顶放宽至多策略展示
        best_by_code = {}
        for p in trimmed:
            c = p["code"]
            if c not in best_by_code or _exp(p) > _exp(best_by_code[c]):
                best_by_code[c] = p
        self.consensus_buys = sorted(best_by_code.values(), key=_exp, reverse=True)[:MAX_DEBATE_PICKS]
        self.split_verdicts = []

        lines = [
            "🏆 辩论终局 · 综合交易计划\n",
            "  📌 各策略(Agent)独立选股, 仅纳入 历史胜率≥52% 且 预期T+1收益为正的信号,",
            "     按 期望收益(均值×胜率) 排序, 不要求多 Agent 共识。\n",
        ]
        for item in self.consensus_buys:
            tag = {"high": "🟢 强信号", "mid": "🟡 达标信号", "low": "🔵 弱信号"}.get(item["consensus"], "🔵 弱信号")
            t1_note = f"  预期T+1 {item['t1_avg']:+.2f}% 胜率{item['t1_win']:.0f}%"
            lines.append(
                f"  {tag}  {item['name']}({item['code']})\n"
                f"          策略: {item['agent']}\n"
                f"          置信度: {item['confidence']:.0f}%{t1_note}\n"
            )
        if sidelined:
            sidelined_str = ", ".join(f"{a.avatar}{a.name}" for a in sidelined)
            lines.append(f"  ⏸️ 观望: {sidelined_str} 暂未发现符合各自风格的入场机会\n")
        lines.append("\n  📋 风险提示:")
        lines.append("   - 信号基于各策略历史胜率与预期收益, 不同行情适配不同策略")
        lines.append("   - 建议结合大盘环境和个人风险偏好使用")

        self.final_plan = "\n".join(lines)
        return self.final_plan


# ── 便捷入口 ──

def run_debate():
    """一键运行完整辩论（带大盘门控: 深度破位→空仓观望, 弱势→按回测数据启用高胜率策略）"""
    from recommender import index_regime
    regime = index_regime()
    if regime.get("skip"):
        return {
            "debate_log": [
                ("system", "🛑 大盘深度破位，本次辩论不生成推荐，建议空仓观望。"),
                ("system", f"   {regime.get('desc', '')}"),
            ],
            "consensus_buys": [],
            "split_verdicts": [],
            "final_plan": "🛑 空仓观望\n" + regime.get("desc", ""),
            "cards": [],
            "regime": regime,
        }
    agents = [
        DebateAgent(name, config)
        for name, config in AGENT_ROLES.items()
    ]
    moderator = DebateModerator(agents)
    return moderator.run_debate(regime=regime)


def format_debate_html(debate_result):
    """将辩论结果格式化为 HTML，用于 Streamlit 渲染"""
    if not debate_result:
        return "<div style='color:#8892b0;'>无辩论数据，请先运行蒸馏。</div>"

    html_parts = []

    for entry in debate_result["debate_log"]:
        if entry[0] == "system":
            html_parts.append(
                f'<div style="color:#64ffda;font-weight:600;font-size:1.1rem;'
                f'margin:16px 0 8px 0;padding:8px 0;border-bottom:1px solid #1a1d2e;">'
                f'{entry[1]}</div>'
            )
        elif entry[0] == "agent":
            _, name, text = entry
            # 替换 \n 为 <br>
            text_html = text.replace("\n", "<br>")
            # 颜色编码
            colors = {
                "低吸猎手": "#00bcd4",
                "打板先锋": "#ffd600",
                "趋势追踪者": "#00c853",
                "量化军师": "#7c4dff",
            }
            color = colors.get(name, "#ccd6f6")
            html_parts.append(
                f'<div style="background:#0a0d1e;border-left:3px solid {color};'
                f'margin:8px 0;padding:12px 16px;border-radius:0 8px 8px 0;'
                f'font-size:0.85rem;line-height:1.6;color:#ccd6f6;">'
                f'{text_html}</div>'
            )

    # Final plan
    if debate_result.get("final_plan"):
        html_parts.append(
            f'<div style="background:#0d1117;border:2px solid #64ffda;'
            f'margin:16px 0;padding:16px;border-radius:8px;'
            f'font-size:0.9rem;line-height:1.6;">'
            f'<div style="color:#64ffda;font-weight:700;font-size:1rem;margin-bottom:8px;">'
            f'📋 最终交易计划</div>'
            f'<pre style="color:#ccd6f6;margin:0;font-family:monospace;white-space:pre-wrap;">'
            f'{debate_result["final_plan"]}</pre></div>'
        )

    return "\n".join(html_parts)


if __name__ == "__main__":
    result = run_debate()
    if result:
        print(format_debate_html(result))
    else:
        print("辩论失败：请先运行蒸馏（python distiller.py）")
