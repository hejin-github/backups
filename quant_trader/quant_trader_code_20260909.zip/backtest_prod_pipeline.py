# -*- coding: utf-8 -*-
"""生产流水线历史重放回测(无前视) — 2026-08-29

回答: 如果过去 N 个交易日就跑现在的 amount 宇宙流水线, 真实 T+1 战绩是多少?
(替代"再等2-3周看实盘"的前向测试 — 专业做法是把新流水线在历史上无泄漏地重放)

流水线逐日(D 升序)镜像生产 recommender.scan_daily_picks:
  宇宙    = 每日时点 top-150 成交额(在今日 top-300 采样池内按当日 amount 重排 → 时点宇宙, 无宇宙漂移)
  门控    = 生产 index_regime 大盘门控(strong/normal/weak 可扫, crash 空仓跳过)
  allowed = 前缀门控(每策略每档位只用 ≤D 的 T+1 样本, 样本≥30/胜率≥52%/均值>0;
          与生产用全样本 json 不同, 回测用保守无前视口径) + weak 无allowed时回退低吸策略集
  信号    = 生产同一批 _STRAT_INSTANCES(22个) generate_signals(因果, 与 experiment_common 同假设),
           D 日末根 signal>0 触发
  硬剔除  = recommender._hard_reject (pe_map=None → 估值校验空操作, 缺历史PE, 如实记录)
  评分    = recommender._quality_score (质量分, 生产排序唯一依据)
  选股    = recommender._pick_top_n(all, 5) → 主推/备用/候选 (全为"全市场"板块, 无跨板块约束)
  兑现    = 买入 T+1 开盘(真口径, 扣隔夜gap) → 卖出 T+1 收盘(2026-08-29卖点复核胜出)
  一字板  = T+1 开盘=最高(买不进) → 单独计数, 不计入战绩
  费用    = 佣金万2.5(最低¥5, 双边)/印花税0.05%(卖)/过户费万0.1(双边), 每笔¥5000本金整手(与 app._sim_trade 同口径)
对照    = 不门控(all 22 策略放开) — 检验"按行情选策略"门控是否真的加分(记忆: walkforward门控多次FAIL)
档位校正 = --rank-mode 三种选股排位对比(仅门控口径):
            quality     生产基线: 质量分降序(发现: 80-90档是陷阱, 主推69%落在该档)
            band78      静态校正: 70-80档优先于>=80档(基于全窗口发现, 样本内, 上界参考)
            walkforward 滚动校正: 每日用 <=D 的滚动 TRAILING_N 日 picks 各档 T+1 均值重估
                         最优档 → 该档候选优先(≥MIN_BAND_SAMPLES 样本), 无前视
                        ——这才是真正的无泄漏验证: 规则本身也是滚动重估的, 不利用未来

局限(如实记录, 不粉饰):
  ① 采样池=今日 top-300 成交额回溯采样 → 幸存者偏差(跌出池的股票缺失), 结果方向=高估
  ② 只重放 amount 腿(生产主源); 热门板块腿(实测≈0边)未含 → 生产并集的实际战绩应略差于本回测
  ③ 缺历史PE(估值校验/评分PE分量空操作) ④ 未含续选(已删除, 不影响) ⑤ 每日5只各押¥5000, 未做仓位约束
用法:
  python backtest_prod_pipeline.py [--trade-days 300] [--sample 300] [--force]
输出: data/prod_pipeline_backtest/replay_{asof}.json
"""
import argparse
import json
import os
import pickle
import sys
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime

import numpy as np
import pandas as pd

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

import recommender as R
from paper_trading import _STRAT_INSTANCES
from stock_api import StockAPI
from stock_universe import filter_universe
from experiment_common import _prev_trading_day, load_index_regimes

BASE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(BASE, "data", "prod_pipeline_backtest")
UNIVERSE_N = R.AMOUNT_UNIVERSE_N   # 生产 AMOUNT_UNIVERSE_N=150
MAX_PICKS = R.MAX_PICKS            # 生产 MAX_PICKS=5
WARMUP = 20
MIN_TOTAL, MIN_WIN, MIN_AVG = 30, 52.0, 0.0
COMM, STAMP, XFER = 0.00025, 0.0005, 0.00001
BUDGET = 5000.0
REGIMES = ["strong", "normal", "weak", "crash"]

# 档位校正参数
TRAILING_N = 20          # walkforward: 滚动重估窗口(交易日)
MIN_BAND_SAMPLES = 5     # walkforward: 档位至少样本数才参与最优档选择


# ───────────────────────── 大盘门控(生产 index_regime 逐日复刻) ─────────────────────────

def _prod_regime_map(idx):
    """生产 index_regime(ma20/ma20斜率/chg5 门控) 逐日档位.
    idx: df[date, close]. 返回 {date(normalize) -> level}."""
    closes = idx["close"].astype(float).values
    dates = idx["date"].values
    out = {}
    for t in range(40, len(closes)):
        ma20 = closes[t - 19:t + 1].mean()            # 最近20日(含当日)
        ma20_prev = closes[t - 39:t - 19].mean()      # 之前20日
        slope = (ma20 / ma20_prev - 1) * 100 if ma20_prev > 0 else 0
        c = closes[t]
        if c > ma20 * 1.01 and slope > -0.5:
            lvl = "strong"
        elif c > ma20:
            lvl = "normal"
        elif c > ma20 * 0.97:
            lvl = "weak"
        else:
            lvl = "crash"                              # 生产 skip → 当日空仓不推荐
        out[pd.Timestamp(dates[t]).normalize()] = lvl
    return out


# ───────────────────────── 采样池 + 历史 + 信号 ─────────────────────────

def _load_pool(sample_n):
    q = StockAPI.get_realtime_quotes()
    if q is None or q.empty:
        return None
    q = filter_universe(q)
    sort_col = "amount" if "amount" in q.columns else "price"
    q = q.sort_values(sort_col, ascending=False)
    return [{"code": str(r["code"]).strip().zfill(6), "name": str(r.get("name", ""))}
            for _, r in q.head(sample_n).iterrows()]


def _build_signal_index(pool, start_str, end_str, asof, force=False, cache_suffix=""):
    """拉历史(磁盘缓存) + 每股每策略 generate_signals 一次 → 磁盘 pickle 缓存.
    返回 {code: {"name":..., "hist": df, "sigs": {sname: ndarray}}}"""
    os.makedirs(OUT_DIR, exist_ok=True)
    cache_path = os.path.join(OUT_DIR, "signals_%s_%d%s.pkl" % (asof, len(pool), cache_suffix))
    if not force and os.path.exists(cache_path):
        try:
            with open(cache_path, "rb") as f:
                return pickle.load(f)
        except Exception:
            pass
    hist_cache = {}

    def _fetch_pass(cands, workers):
        got = {}
        with ThreadPoolExecutor(max_workers=workers) as ex:
            fs = {ex.submit(R._fetch_hist_cached, c["code"], start_str, end_str): c for c in cands}
            for f in as_completed(fs):
                try:
                    h = f.result()
                except Exception:
                    h = None
                if h is not None and len(h) >= 40:
                    got[fs[f]["code"]] = (fs[f]["name"], h)
        return got

    hist_cache.update(_fetch_pass(pool, 8))
    for backoff in (15, 45, 120):
        missing = [c for c in pool if c["code"] not in hist_cache]
        if not missing:
            break
        print("缺失 %d 只, 退避 %ds 补拉..." % (len(missing), backoff), flush=True)
        time.sleep(backoff)
        hist_cache.update(_fetch_pass(missing, 6))
    print("个股历史: %d/%d" % (len(hist_cache), len(pool)), flush=True)

    sigs = {}
    for code, (name, hist) in hist_cache.items():
        sd = {}
        for sname, stg in _STRAT_INSTANCES.items():
            try:
                sdf = stg.generate_signals(hist.copy())
                if "signal" in sdf.columns:
                    sd[sname] = sdf["signal"].astype(float).values
            except Exception:
                pass
        sigs[code] = {"name": name, "hist": hist, "sigs": sd}
    with open(cache_path, "wb") as f:
        pickle.dump(sigs, f)
    return sigs


def _load_fullmarket_sigs(uni, sig_dir):
    """全市场路径: bar存储(列式)→hist DataFrame + 信号缓存(每股pickle)→sigs.
    返回与 _build_signal_index 同结构 {code: {name, hist, sigs}}; degraded股不参与."""
    from market_universe import load_bars, _hist_from_bars
    sigs = {}
    for code in uni["umax"]:
        b = load_bars(code)
        if b is None or b.get("degraded"):
            continue
        sp = os.path.join(sig_dir, "%s.pkl" % code)
        if not os.path.exists(sp):
            continue
        try:
            with open(sp, "rb") as f:
                sd = pickle.load(f)
        except Exception:
            continue
        hist = _hist_from_bars(b)
        if hist is None or len(hist) < 30:
            continue
        sigs[code] = {"name": b.get("name", ""), "hist": hist, "sigs": sd}
    return sigs


# ───────────────────────── 费用/兑现 ─────────────────────────

def _net_pnl(buy, sell, budget=BUDGET):
    """整手含费净盈亏(与 app._sim_trade / analyze_sell_point 同口径)"""
    if buy <= 0 or sell <= 0:
        return None
    qty = int(budget / buy / 100) * 100
    if qty <= 0:
        return None
    cost, proceeds = qty * buy, qty * sell
    buy_fee = max(5.0, cost * COMM)
    sell_fee = max(5.0, proceeds * COMM) + proceeds * STAMP + proceeds * XFER
    return (proceeds - cost) - (buy_fee + sell_fee)


# ───────────────────────── 重放主循环 ─────────────────────────

def _band(q):
    """质量分档: hi=>=80(陷阱档) / mid=70-80(甜点档) / lo=<70"""
    return "hi" if q >= 80 else "mid" if q >= 70 else "lo"


def _select_picks(candidates, n, mode, band_stat=None):
    """三种选股排位(全部候选都是"全市场"板块, 无跨板块约束, 等价排序取前n)."""
    if mode == "quality":
        ordered = sorted(candidates, key=lambda x: x["quality_score"], reverse=True)
    elif mode == "band78":
        def k78(c):
            return (0, -c["quality_score"]) if _band(c["quality_score"]) == "mid" else \
                   (1, -c["quality_score"]) if _band(c["quality_score"]) == "lo" else \
                   (2, -c["quality_score"])
        ordered = sorted(candidates, key=k78)
    elif mode == "walkforward":
        prio = {"hi": 2, "mid": 1, "lo": 0}          # 缺样本时默认 lo<mid<hi(=质量序)
        if band_stat:
            best = max(band_stat, key=band_stat.get)
            prio = {b: (0 if b == best else 1) for b in prio}
        ordered = sorted(candidates,
                         key=lambda x: (prio.get(_band(x["quality_score"]), 9),
                                        -x["quality_score"]))
    else:
        ordered = sorted(candidates, key=lambda x: x["quality_score"], reverse=True)
    return ordered[:n]


def _trailing_band_stat(now_d, tracker):
    """walkforward 滚动档位重估: 取 date<now_d 的最近 TRAILING_N 个交易日的可交易picks,
    分档聚合 T+1 均值; 档样本≥MIN_BAND_SAMPLES 才参与最优档选择. tracker=[(date, band, ret)]."""
    ds = sorted({t[0] for t in tracker if t[0] < now_d})[-TRAILING_N:]
    if not ds:
        return None
    ds = set(ds)
    stat = {}
    for d, band, ret in tracker:
        if d in ds and ret is not None:
            stat.setdefault(band, []).append(ret)
    out = {}
    for band, rets in stat.items():
        if len(rets) >= MIN_BAND_SAMPLES:
            out[band] = float(np.mean(rets))
    return out or None


def _replay(sigs, regimes, analysis_days, gated, rank_mode="quality",
            screen_top=None, universe_n=None, raw_acc=None):
    """逐日重放。gated=True → 前缀门控(与生产一致); False → all 策略放开(对照).
    screen_top: {day: [codes降序]} 预计算点位宇宙(全市场路径); None → 采样池内按D日amount重排(旧路径).
    universe_n: 宇宙切片数(默认 UNIVERSE_N). raw_acc: list, 若给出则逐日累积 top-N 宇宙裸T+1均值(NOCOST)."""
    stocks_info = {}
    for code, si in sigs.items():
        hist = si["hist"]
        n = len(hist)
        dates = pd.to_datetime(hist["date"]).dt.normalize()
        stocks_info[code] = {
            "name": si["name"], "n": n,
            "dti": {pd.Timestamp(d): i for i, d in enumerate(dates)},
            "closes": hist["close"].astype(float).values,
            "opens": hist["open"].astype(float).values,
            "highs": hist["high"].astype(float).values,
            "lows": hist["low"].astype(float).values,
            "amounts": hist["amount"].astype(float).values if "amount" in hist.columns
                       else np.full(n, np.nan),
            "changes": hist["change_pct"].astype(float).values if "change_pct" in hist.columns
                        else np.zeros(n),
            "hist": hist, "sigs": si["sigs"],
        }

    # 逐日信号聚合(仅桶更新用: 每策略 D 日触发信号的 T+1 收益)
    day_map = defaultdict(list)
    for code, st in stocks_info.items():
        n, closes = st["n"], st["closes"]
        dates = st["hist"]["date"]
        for sname, sig in st["sigs"].items():
            if sig is None or len(sig) != n:
                continue
            hits = np.flatnonzero((sig > 0) & (closes > 0))
            for i in hits:
                if i < WARMUP or i + 1 >= n:
                    continue
                d = pd.Timestamp(dates.iloc[i]).normalize()
                day_map[d].append((code, sname, (closes[i + 1] / closes[i] - 1) * 100))

    bucket = {s: {r: [] for r in REGIMES} for s in _STRAT_INSTANCES}

    def _allowed_now(regime):
        out = []
        for s in _STRAT_INSTANCES:
            rets = bucket[s][regime]
            t = len(rets)
            if t < MIN_TOTAL:
                continue
            wr = sum(1 for x in rets if x > 0) / t * 100
            avg = float(np.mean(rets))
            if wr >= MIN_WIN and avg > MIN_AVG:
                out.append(s)
        return out

    rows, stats = [], {"n_days": 0, "skip_crash": 0, "no_allowed_days": 0, "tail_dropped": 0,
                       "oneword": 0}
    tracker = []   # walkforward 档位重估: (date, band, ret) 按天追加, 只用 date<D 无前视
    for d in sorted(analysis_days):
        regime = regimes.get(d)
        stats["n_days"] += 1
        if regime is None:
            continue
        if regime == "crash":
            stats["skip_crash"] += 1
            for code, sname, ret in day_map.get(d, []):
                bucket[sname][regime].append(ret)
            continue

        allowed = _allowed_now(regime) if gated else list(_STRAT_INSTANCES)
        if regime == "weak" and not allowed:
            allowed = list(R._LOW_BUY_STRATEGIES)
        if not allowed:
            stats["no_allowed_days"] += 1

        # 时点宇宙: sample=池内按D日amount重排top-N(旧路径); fullmarket=预计算点位top-N切片
        un = universe_n or UNIVERSE_N
        if screen_top is not None:
            amt = {}
            dkey = d.strftime("%Y%m%d")   # 宇宙索引键=字符串日期
            for code in screen_top.get(dkey, [])[:un]:
                st = stocks_info.get(code)
                if st is None:
                    continue
                i = st["dti"].get(d)
                if i is None:
                    continue
                amt[code] = (0.0, i)
        else:
            amt = {}
            for code, st in stocks_info.items():
                i = st["dti"].get(d)
                if i is None:
                    continue
                a = st["amounts"][i]
                if np.isfinite(a) and a > 0:
                    amt[code] = (a, i)
        universe = dict(amt)
        # 宇宙级裸边(NOCOST): top-N 内所有标的 T+1 开盘→收盘 均值(不带策略/费用)
        if raw_acc is not None:
            _raw = []
            for code, (_a, i) in universe.items():
                st = stocks_info[code]
                if i + 1 >= st["n"]:
                    continue
                o = st["opens"][i + 1]
                c = st["closes"][i + 1]
                if o is not None and o > 0 and c is not None and c > 0:
                    _raw.append((c / o - 1) * 100)
            if _raw:
                raw_acc.append(float(np.mean(_raw)))

        candidates = []
        for code, (a, i) in universe.items():
            st = stocks_info[code]
            sig = st["sigs"]
            triggered = [s for s in allowed if sig.get(s) is not None and i < len(sig[s])
                         and sig[s][i] > 0]
            if not triggered:
                continue
            if i + 1 >= st["n"]:          # 尾部日 T+1 未完成(最后一分析日)
                stats["tail_dropped"] += 1
                continue
            price = float(st["closes"][i])
            chg = float(st["changes"][i])
            hist_D = st["hist"].iloc[:i + 1]
            row = {"code": code, "name": st["name"], "price": price, "change_pct": chg}
            if R._hard_reject(st["name"], price, hist_D, row, None):
                continue
            q = R._quality_score(hist_D, chg, row, None, code)
            candidates.append({"code": code, "name": st["name"], "quality_score": q,
                               "strategies": triggered, "signal_count": len(triggered)})
        band_stat = _trailing_band_stat(d, tracker) if rank_mode == "walkforward" else None
        picks = _select_picks(candidates, MAX_PICKS, rank_mode, band_stat)

        today_track = []
        for rank, p in enumerate(picks):
            i = amt[p["code"]][1]
            st = stocks_info[p["code"]]
            buy, sell = st["opens"][i + 1], st["closes"][i + 1]
            oneword = (st["highs"][i + 1] - st["lows"][i + 1]) < 0.03 and \
                st["opens"][i + 1] >= st["highs"][i + 1] - 0.005
            if oneword:
                stats["oneword"] += 1
            ret = (sell / buy - 1) * 100 if buy > 0 else None
            rows.append({"date": pd.Timestamp(d).strftime("%Y%m%d"), "regime": regime,
                         "rank": rank + 1, "code": p["code"], "name": p["name"],
                         "quality": p["quality_score"], "buy": round(buy, 2), "sell": round(sell, 2),
                         "ret": round(ret, 3) if ret is not None else None,
                         "oneword": bool(oneword), "pnl": _net_pnl(buy, sell)})
            if not oneword and ret is not None:
                today_track.append((d, _band(p["quality_score"]), ret))
        tracker.extend(today_track)

        # 桶更新(处理完 D 再入桶 → 无前视)
        for code, sname, ret in day_map.get(d, []):
            bucket[sname][regime].append(ret)

    return rows, stats


def _agg(sub):
    trad = [r for r in sub if not r["oneword"] and r["ret"] is not None]
    if not trad:
        return {"n": 0}
    rets = [r["ret"] for r in trad]
    pnls = [r["pnl"] for r in trad if r["pnl"] is not None]
    return {
        "n": len(trad),
        "win_pct": round(sum(1 for x in rets if x > 0) / len(rets) * 100, 1),
        "mean_ret": round(sum(rets) / len(rets), 3),
        "median_ret": round(float(np.median(rets)), 3),
        "net_pnl": round(sum(pnls), 0) if pnls else None,
        "mean_net": round(sum(pnls) / len(pnls), 0) if pnls else None,
    }


def _summarize(rows, label, stats=None):
    out = {"label": label}
    if stats is not None:
        out["stats"] = stats
    trad = [r for r in rows if not r["oneword"] and r["ret"] is not None]
    out["any_top5"] = _agg(rows)
    for rank, role in ((1, "主推"), (2, "备用"), (3, "候选3"), (4, "候选4"), (5, "候选5")):
        out[role] = _agg([r for r in rows if r["rank"] == rank])
    # 按当日档位(主推/备用)
    for reg in REGIMES:
        sub = [r for r in trad if r["regime"] == reg]
        if sub:
            out["regime_%s" % reg] = _agg(sub)
    oneword_list = [f'{r["date"]} {r["name"]}({r["code"]})' for r in rows if r["oneword"]]
    out["oneword_list"] = oneword_list
    return out


SIG_DIR = os.path.join(BASE, "data", "market_signals")
GRID_NS = (150, 300, 500)
GRID_SCREENS = ("amount", "turnover")


def _analysis_days(regimes, trade_days, offset):
    all_days = sorted(regimes.keys())
    return set(all_days[len(all_days) - trade_days - offset: len(all_days) - offset])


def _summ_cells(s):
    cells = []
    for role in ("主推", "备用", "any_top5"):
        a = s[role]
        cells.append("%d/%s%%/%+.3f%%/%+.0f" % (a["n"], a["win_pct"], a["mean_ret"],
                                                 a["net_pnl"] or 0) if a["n"] else "-")
    return cells


def _raw_stat(raw_acc):
    if not raw_acc:
        return {"n": 0}
    return {"n": len(raw_acc),
            "mean_ret": round(sum(raw_acc) / len(raw_acc), 3),
            "win_pct": round(sum(1 for x in raw_acc if x > 0) / len(raw_acc) * 100, 1),
            "median_ret": round(float(np.median(raw_acc)), 3)}


def _run_fullmarket(args, asof_s, regimes, idx, res):
    """全市场诚实宇宙: 网格(两窗口×N×screen×st_mode) 或 单组合. res: 输出dict."""
    suf = ""
    if args.price_mode != "point":
        suf += "_%s" % args.price_mode
    if args.st_mode != "today":
        suf += "_ptst"
    up = os.path.join(OUT_DIR, "universe_%s%s.pkl" % (asof_s, suf))
    if not os.path.exists(up):
        print("宇宙索引不存在:", up)
        print("请先: python market_universe.py [--price-mode %s] [--st-mode %s]" % (args.price_mode, args.st_mode))
        return
    with open(up, "rb") as f:
        uni = pickle.load(f)
    t0 = time.time()
    sigs = _load_fullmarket_sigs(uni, SIG_DIR)
    print("全市场信号加载: %d 只 (umax %d), %.1fs" % (len(sigs), len(uni["umax"]), time.time() - t0))

    offsets = (0, 300) if args.grid else (args.offset,)
    combos = [(s, n) for s in GRID_SCREENS for n in GRID_NS] if args.grid \
        else [(args.screen, args.universe_n or UNIVERSE_N)]

    print("\n===== 全市场诚实宇宙回测 (price_mode=%s st_mode=%s) =====" % (args.price_mode, args.st_mode))
    for off in offsets:
        analysis_days = _analysis_days(regimes, args.trade_days, off)
        wstart = pd.Timestamp(min(analysis_days)).strftime("%Y-%m-%d")
        wend = pd.Timestamp(max(analysis_days)).strftime("%Y-%m-%d")
        print("\n-- 窗口[%s~%s] (%d交易日, off=%d) --" % (wstart, wend, len(analysis_days), off))
        print("  %-16s | 主推 n/胜率/均值/净          | 备用 n/胜率/均值/净          | any_top5 n/胜率/均值/净     | 宇宙裸边NOCOST")
        for screen, N in combos:
            screen_top = uni["%s_top" % screen]
            raw_acc = []
            rows, stats = _replay(sigs, regimes, analysis_days, True, rank_mode="quality",
                                  screen_top=screen_top, universe_n=N, raw_acc=raw_acc)
            s = _summarize(rows, "%s=N%d" % (screen, N), stats)
            cells = _summ_cells(s)
            raw = _raw_stat(raw_acc)
            raw_s = "%d/%+.3f%%/%s%%" % (raw["n"], raw["mean_ret"], raw["win_pct"]) if raw["n"] else "-"
            key = "FM_off%d_%s_n%d" % (off, screen, N)
            res[key] = s
            res[key + "_rows"] = rows
            res[key + "_raw"] = raw
            print("  %-16s | %-24s | %-24s | %-24s | %s" % (
                "%s=n%d" % (screen, N), cells[0], cells[1], cells[2], raw_s))
    res["fullmarket_meta"] = {"price_mode": args.price_mode, "st_mode": args.st_mode,
                              "grid": bool(args.grid), "diag": uni.get("diag")}


def _run_sample(args, asof, asof_s, regimes, analysis_days, idx, res):
    """旧采样池路径(幸存者偏差对照)."""
    from experiment_common import hist_window
    pool = _load_pool(args.sample)
    if pool is None:
        print("实时行情为空, 无法采样")
        return
    print("采样池: %d 只 (今日 top-%d 成交额, 幸存者偏差→高估, 如实记录)" % (len(pool), args.sample))
    start_str, end_str = hist_window(asof, args.hist_days)
    print("历史窗口:", start_str, "~", end_str, flush=True)
    t0 = time.time()
    sigs = _build_signal_index(pool, start_str, end_str, asof_s, force=args.force,
                               cache_suffix="_h%d_o%d" % (args.hist_days, args.offset))
    print("信号索引构建: %.1fs (%d 只)" % (time.time() - t0, len(sigs)), flush=True)

    for mode, mlabel in (("quality", "门控·质量基线"), ("band78", "门控·静态70-80优先"),
                         ("walkforward", "门控·滚动档位")):
        rows, stats = _replay(sigs, regimes, analysis_days, True, rank_mode=mode)
        res[mlabel] = _summarize(rows, mlabel, stats)
        res[mlabel + "_rows"] = rows
    rows, stats = _replay(sigs, regimes, analysis_days, False)
    res["不门控(对照)"] = _summarize(rows, "不门控(对照)", stats)
    res["不门控(对照)_rows"] = rows

    print("\n===== 生产流水线重放回测 (%s) =====" % label_safe(res["window"]["start"]))
    print("指数买入持有(同窗口): %+.2f%%" % res["index_buy_hold_pct"])
    print("\n%--22s | 主推 n/胜率/均值/净 | 备用 n/胜率/均值/净 | 5只合计 n/胜率/均值/净" % "-" * 0)
    for label in ("门控·质量基线", "门控·静态70-80优先", "门控·滚动档位", "不门控(对照)"):
        s = res[label]
        st = s["stats"]
        cells = _summ_cells(s)
        print("  %-14s %-12s | %-13s | %-20s" % (s["label"], cells[0], cells[1], cells[2]))
        print("    (分析日 %d, 空仓skip %d, 无allowed日 %d, 尾部丢弃 %d, 一字板 %d)"
              % (st["n_days"], st["skip_crash"], st["no_allowed_days"], st["tail_dropped"], st["oneword"]))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--trade-days", type=int, default=300)
    ap.add_argument("--sample", type=int, default=300)
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--offset", type=int, default=0, help="分析窗口向前平移交易日数(第二段样本外)")
    ap.add_argument("--hist-days", type=int, default=300, help="sample路径历史窗口长度")
    ap.add_argument("--universe", choices=("sample", "fullmarket"), default="sample")
    ap.add_argument("--screen", choices=("amount", "turnover"), default="amount")
    ap.add_argument("--universe-n", type=int, default=0, help="宇宙切片数, 0=生产AMOUNT_UNIVERSE_N")
    ap.add_argument("--price-mode", choices=("point", "today"), default="point")
    ap.add_argument("--st-mode", choices=("today", "point"), default="today",
                    help="today=今日名ST/退代理剔除(mirror生产, 重引入退市幸存者偏差); "
                         "point=退市股按其bar历史参与排序(退市前可交易, 诚实口径)")
    ap.add_argument("--grid", action="store_true", help="跑全网格: 两窗口×N{150,300,500}×两屏")
    args = ap.parse_args()

    asof = _prev_trading_day()
    asof_s = pd.Timestamp(asof).strftime("%Y%m%d")
    print("asof =", asof_s, "| 交易日数 =", args.trade_days,
          "| offset =", args.offset, "| 宇宙 =", args.universe,
          "| 模式 =", "%s/%s" % (args.price_mode, args.st_mode))

    _, idx = load_index_regimes(1001, asof)
    if idx is None or len(idx) < 40:
        print("指数数据不足")
        return
    regimes = _prod_regime_map(idx)
    analysis_days = _analysis_days(regimes, args.trade_days, args.offset)
    print("分析窗口: %s ~ %s (%d 交易日)"
          % (pd.Timestamp(min(analysis_days)).strftime("%Y-%m-%d"),
             pd.Timestamp(max(analysis_days)).strftime("%Y-%m-%d"), len(analysis_days)))

    # 上证对照(窗口内买入持有)
    idx_closes = idx.sort_values("date").reset_index(drop=True)["close"].astype(float).values
    idx_in = idx_closes[len(idx_closes) - args.trade_days - 40: len(idx_closes) - 40]
    idx_bh = (idx_in[-1] / idx_in[0] - 1) * 100 if idx_in[0] > 0 else None

    res = {"asof": asof_s, "trade_days": args.trade_days, "sample": args.sample,
           "offset": args.offset, "universe": args.universe,
           "window": {"start": pd.Timestamp(min(analysis_days)).strftime("%Y%m%d"),
                      "end": pd.Timestamp(max(analysis_days)).strftime("%Y%m%d")},
           "index_buy_hold_pct": round(idx_bh, 2) if idx_bh is not None else None}

    if args.universe == "fullmarket":
        _run_fullmarket(args, asof_s, regimes, idx, res)
    else:
        _run_sample(args, asof, asof_s, regimes, analysis_days, idx, res)

    os.makedirs(OUT_DIR, exist_ok=True)
    out_path = os.path.join(OUT_DIR, "replay_%s.json" % asof_s)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=1, default=str)
    print("\n结果已存:", out_path)


def label_safe(s):
    return "%s-%s-%s" % (s[:4], s[4:6], s[6:8])


if __name__ == "__main__":
    main()
