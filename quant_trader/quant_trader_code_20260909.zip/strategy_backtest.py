"""
策略离样本回测 — 分行情档位统计每个策略的 T+1 胜率/均值

用途: 替换 hedge_results 仅 22 个样本的噪声统计, 为"按行情档位启用策略"提供数据依据。
方法: 对全市场(选样本)每只股票跑每个策略的完整信号序列, 每个 signal>0 的日子记一笔
      T+1 收益(次日收盘/当日收盘-1), 按当日上证指数档位(strong/normal/weak/crash)分桶。
输出: data/strategy_backtest.json

注意: 个股停牌导致的跨日收益未剔除, 仅作筛选参考, 不代表真实可成交收益。
"""
import json
import os
import numpy as np
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta

from stock_api import StockAPI
from stock_universe import filter_universe
from strategies import list_strategies

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "strategy_backtest.json")
REGIMES = ["strong", "normal", "weak", "crash"]


def _classify_regime(close, ma20):
    if close > ma20 * 1.01:
        return "strong"
    if close > ma20:
        return "normal"
    if close > ma20 * 0.97:
        return "weak"
    return "crash"


def _prev_trading_day(dt=None):
    """最近一个已完成交易日(严格早于 dt), 用作 asof 数据截止日(无前视泄漏)."""
    from scheduler import is_trading_day
    if dt is None:
        dt = datetime.now()
    d = dt - timedelta(days=1)
    for _ in range(14):
        if is_trading_day(d):
            return d
        d -= timedelta(days=1)
    return dt - timedelta(days=1)


def _load_index_for_regime(asof, lookback_days=320):
    """上证逐日档位数据(截至 asof): 腾讯接口优先, 失败回退本地缓存
    data/market_index/sh000001.json(天然截至昨日, 同样无泄漏). 返回 df[date, close, ma20] 或 None."""
    idx = None
    try:
        idx = StockAPI.get_index_historical_data("sh000001", days=lookback_days)
    except Exception:
        idx = None
    if idx is None or len(idx) < 30:
        try:
            from index_guide import load_sh_raw
            raw = load_sh_raw()
            dates, closes = raw.get("dates", []), raw.get("closes", [])
            if len(dates) >= 30:
                idx = pd.DataFrame({"date": pd.to_datetime(dates), "close": closes})
        except Exception:
            idx = None
    if idx is None or len(idx) < 30:
        return None
    idx = idx.sort_values("date").reset_index(drop=True)
    idx["date"] = pd.to_datetime(idx["date"])
    idx = idx[idx["date"].dt.normalize() <= pd.Timestamp(asof)]
    if len(idx) < 30:
        return None
    idx["ma20"] = idx["close"].rolling(20).mean()
    return idx


def run_backtest(sample_limit=300, lookback_days=400, asof=None):
    """asof: 数据截止日(缺省=上一交易日). 指数/个股都截至 asof, 排除当日未收盘bar → 消除前视泄漏.
    lookback_days=400: 与 sector_pool/experiment 共用同一 hist_window → 共享磁盘缓存(限流只付一次, 口径一致)."""
    from strategies import get_strategy
    from experiment_common import fetch_hist_cached, hist_window  # lazy import 防循环依赖
    if asof is None:
        asof = _prev_trading_day()
    asof_ts = pd.Timestamp(asof).normalize()

    quotes = StockAPI.get_realtime_quotes()
    if quotes is None or quotes.empty:
        return None
    quotes = filter_universe(quotes)
    sort_col = "amount" if "amount" in quotes.columns else "price"
    quotes = quotes.sort_values(sort_col, ascending=False)
    sample = quotes.head(sample_limit)

    start_str, end_str = hist_window(asof_ts, lookback_days)

    # 指数档位(每日, 截至 asof)
    idx = _load_index_for_regime(asof_ts, lookback_days)
    if idx is None:
        print("指数数据不足")
        return None
    regimes = {}
    for _, row in idx.iterrows():
        if pd.isna(row["ma20"]):
            continue
        regimes[row["date"].normalize()] = _classify_regime(float(row["close"]), float(row["ma20"]))

    # 拉个股历史(共享磁盘缓存; 腾讯偶发整块限流 → 多轮线程+退避)
    codes = sample["code"].tolist()
    hist_cache = {}

    def _fetch_pass(cands, workers):
        got = {}
        with ThreadPoolExecutor(max_workers=workers) as ex:
            fs = {ex.submit(fetch_hist_cached, c, start_str, end_str, asof): c for c in cands}
            for f in as_completed(fs):
                try:
                    h = f.result()
                except Exception:
                    h = None
                if h is not None and len(h) >= 30:
                    got[fs[f]] = h
        return got

    hist_cache.update(_fetch_pass(codes, 8))
    for backoff in (15, 45, 120):
        missing = [c for c in codes if c not in hist_cache]
        if not missing:
            break
        print(f"缺失 {len(missing)}, 退避 {backoff}s 补拉...")
        import time
        time.sleep(backoff)
        hist_cache.update(_fetch_pass(missing, 6))

    strategy_names = [n for n in list_strategies() if n != "组合策略·投票系统"]
    buckets = {s: {r: [] for r in REGIMES} for s in strategy_names}

    for sname in strategy_names:
        try:
            stg = get_strategy(sname)
        except Exception:
            continue
        if stg is None:
            continue
        for code, hist in hist_cache.items():
            try:
                sdf = stg.generate_signals(hist.copy())
            except Exception:
                continue
            if "signal" not in sdf.columns:
                continue
            sig = sdf["signal"].astype(float).values
            closes = hist["close"].astype(float).values
            opens = hist["open"].astype(float).values
            dates = hist["date"].values
            n = len(sig)
            for i in range(20, n - 1):
                if sig[i] <= 0 or closes[i] <= 0:
                    continue
                d = pd.Timestamp(dates[i]).normalize()
                regime = regimes.get(d)
                if regime is None:
                    continue
                # T+1 真实可捕获收益 = D+1 开盘买入 → D+1 收盘卖出(扣隔夜高开 gap)。
                # 旧口径 closes[i+1]/closes[i] 假设按 D 收盘价买入(信号在收盘才产生, 买不到),
                # 对涨停打板类(隔夜高开 3~9%)系统性高估(实证 000603 +10.02%→真实+0.03%)。
                if opens[i + 1] > 0:
                    buckets[sname][regime].append((closes[i + 1] / opens[i + 1] - 1) * 100)

    # 聚合输出
    output = {}
    for sname in strategy_names:
        agg = {"regimes": {}}
        all_rets = []
        for r in REGIMES:
            rets = buckets[sname][r]
            t = len(rets)
            agg["regimes"][r] = {
                "total": t,
                "win_rate": round(sum(1 for x in rets if x > 0) / t * 100, 1) if t else 0,
                "avg_return": round(float(np.mean(rets)), 3) if t else 0,
            }
            all_rets.extend(rets)
        t = len(all_rets)
        agg["all"] = {
            "total": t,
            "win_rate": round(sum(1 for x in all_rets if x > 0) / t * 100, 1) if t else 0,
            "avg_return": round(float(np.mean(all_rets)), 3) if t else 0,
        }
        output[sname] = agg

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    print(f"回测完成: {len(hist_cache)} 只股票 × {len(strategy_names)} 策略 → {OUT}")
    print("收益口径: D+1 开盘买入→D+1 收盘卖出 (已修正, 旧版为 D 收盘→D+1 收盘, 高估隔夜gap)")
    print(f"{'策略':<20}{'信号':>6}{'胜率':>8}{'均值':>8} | strong/normal/weak/crash 胜率(信号数)")
    for sname, agg in sorted(output.items(), key=lambda x: -x[1]["all"]["total"]):
        a = agg["all"]
        if a["total"] == 0:
            continue
        wr_line = " ".join(
            f"{agg['regimes'][r]['win_rate']:.0f}({agg['regimes'][r]['total']})" for r in REGIMES
        )
        print(f"{sname:<20}{a['total']:>6}{a['win_rate']:>7.1f}%{a['avg_return']:>+8.3f} | {wr_line}")
    return output


def load_backtest():
    """读取 data/strategy_backtest.json, 无则返回 None"""
    if not os.path.exists(OUT):
        return None
    try:
        with open(OUT, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def strategies_for_regime(regime, min_total=30, min_win=0.52, min_avg=0.0):
    """按行情档位返回可启用策略(按该档位内平均T+1收益降序)。
    数据依据 strategy_backtest.json; 无数据时返回空列表, 调用方需回退。
    """
    bt = load_backtest()
    if not bt:
        return []
    out = []
    for name, agg in bt.items():
        r = agg.get("regimes", {}).get(regime, {})
        t = r.get("total", 0)
        if t < min_total:
            continue
        if r.get("win_rate", 0) < min_win * 100:
            continue
        if r.get("avg_return", 0) <= min_avg:
            continue
        out.append((name, r.get("avg_return", 0)))
    out.sort(key=lambda x: -x[1])
    return [n for n, _ in out]


META_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "strategy_backtest_meta.json")


def _load_meta():
    try:
        with open(META_FILE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_meta(m):
    os.makedirs(os.path.dirname(META_FILE), exist_ok=True)
    with open(META_FILE, "w", encoding="utf-8") as f:
        json.dump(m, f, ensure_ascii=False, indent=2)


def ensure_backtest_refreshed(asof=None):
    """每日至多一次: 重新生成 strategy_backtest.json(截至上一交易日), 消除前视泄漏.
    哨兵仿 index_guide.backfill_sh_history 的 last_check_date 模式; 非致命."""
    today = datetime.now().strftime("%Y%m%d")
    meta = _load_meta()
    if meta.get("generated_date") == today:
        return meta
    try:
        if asof is None:
            asof = _prev_trading_day()
        out = run_backtest(sample_limit=300, lookback_days=400, asof=asof)
        meta = {"generated_date": today,
                "asof": pd.Timestamp(asof).strftime("%Y%m%d"),
                "ok": bool(out)}
        _save_meta(meta)
        print(f"[strategy_backtest] refreshed asof={meta['asof']}")
    except Exception as e:
        print(f"[strategy_backtest] refresh error: {e}")
    return meta


if __name__ == "__main__":
    run_backtest(sample_limit=300)
