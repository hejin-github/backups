# -*- coding: utf-8 -*-
"""
邮件通知模块(QQ SMTP):
1) 定时扫描触发信号 → 信号邮件(当日 首推/备用 + 决策辅助).
   规则: 有主推/备用的扫描才算"触发"; 只要与上次已发送的推荐(主推/备用代码)不同就发,
   相同则不重复发 —— 上午空仓没发、下午扫出推荐时会发, 当日多次扫描推荐变了也会发.
2) 当日最后一次定时扫描(14:00)仍无主推/备用 → 确认空仓 → 空仓邮件(每天至多一封,
   且当日已发过信号邮件则不重复空仓邮件). 空仓 = 无操作观望.
3) 收盘 → 首页简报(首页信息简洁文本总结, 每天至多一封).

配置读取 data/mail_config.json: {smtp_host, smtp_port, user, auth_code, to}
"""
import json
import os
import smtplib
from datetime import datetime, timedelta
from email.header import Header
from email.mime.text import MIMEText

from index_guide import load_sh_history, load_sector_index_latest, build_guidance
from scheduler import is_trading_day
from stock_api import StockAPI

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MAIL_CONFIG = os.path.join(BASE_DIR, "data", "mail_config.json")
SIGNAL_LAST = os.path.join(BASE_DIR, "data", "mail_signal_last.json")
SIGNAL_TODAY = os.path.join(BASE_DIR, "data", "mail_signal_sent.txt")  # 当日是否发过信号邮件
EMPTY_MARK = os.path.join(BASE_DIR, "data", "mail_empty_sent.txt")       # 当日空仓邮件标记
CLOSE_MARK = os.path.join(BASE_DIR, "data", "mail_close_sent.txt")
SELL_MARK = os.path.join(BASE_DIR, "data", "mail_sell_sent.txt")         # 当日卖出提醒标记
SELL_EVENT_STATE = os.path.join(BASE_DIR, "data", "mail_sell_event_sent.json")  # {code: date} 盘中纪律卖出事件当日已发
REC_DIR = os.path.join(BASE_DIR, "data", "recommendations")
PICKS_DIR = os.path.join(BASE_DIR, "data", "daily_picks")

CARD = "background:#1a1d2e;border:1px solid #2a2d3e;border-radius:8px;padding:12px 14px;margin:10px 0;"
POS = "#ff5252"      # A股 红=涨
NEG = "#26a69a"      # A股 绿=跌
FLAT = "#8892b0"
ACCENT = "#00d4ff"


def _load_mail_config():
    try:
        with open(MAIL_CONFIG, encoding="utf-8") as f:
            cfg = json.load(f)
        if cfg.get("user") and cfg.get("auth_code"):
            return cfg
    except Exception:
        pass
    return None


def _send(subject, html):
    """同步发送 HTML 邮件(调用方应为后台线程). 成功返回 True."""
    cfg = _load_mail_config()
    if not cfg:
        return False
    to = cfg.get("to") or cfg.get("user")
    msg = MIMEText(html, "html", "utf-8")
    msg["Subject"] = Header(subject, "utf-8")
    msg["From"] = cfg["user"]
    msg["To"] = to
    try:
        with smtplib.SMTP_SSL(cfg.get("smtp_host", "smtp.qq.com"), int(cfg.get("smtp_port", 465)), timeout=30) as s:
            s.login(cfg["user"], cfg["auth_code"])
            s.sendmail(cfg["user"], [to], msg.as_string())
        return True
    except Exception:
        return False


def _today():
    return datetime.now().strftime("%Y%m%d")


def _marked(mark_file):
    try:
        with open(mark_file, encoding="utf-8") as f:
            return f.read().strip() == _today()
    except Exception:
        return False


def _mark(mark_file):
    try:
        with open(mark_file, "w", encoding="utf-8") as f:
            f.write(_today())
    except Exception:
        pass


def _pick_signature(result):
    """信号特征: (日期, 主推代码). 备用轨已关闭: 只认主推, 无主推(空仓) → None."""
    main = (result.get("main_pick") or {}).get("code") or ""
    if not main:
        return None
    return (str(result.get("date") or _today()), str(main))


def _load_last_signal():
    try:
        with open(SIGNAL_LAST, encoding="utf-8") as f:
            d = json.load(f)
        return tuple(d.get("sig", []))
    except Exception:
        return None


def _save_last_signal(sig):
    try:
        os.makedirs(os.path.dirname(SIGNAL_LAST), exist_ok=True)
        with open(SIGNAL_LAST, "w", encoding="utf-8") as f:
            json.dump({"sig": list(sig), "sent_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")},
                      f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def _cls(v):
    """收益类颜色: 涨红跌绿."""
    if v is None:
        return FLAT
    return POS if v > 0 else NEG if v < 0 else FLAT


def _pick_line(pick, role):
    exp = pick.get("expected_return")
    win = pick.get("win_rate")
    strs = "、".join(pick.get("strategies") or [])
    line = (f"<b>{role}</b> {pick.get('name','')} <span style='color:{FLAT}'>{pick.get('code','')}</span>"
            f" · {pick.get('sector','-')} · 收盘 {pick.get('price','-')}")
    if exp is not None:
        line += f" · 预期 <span style='color:{_cls(exp)}'>{exp:+.2f}%</span>"
    if win is not None:
        line += f" · 胜率 {win:.0f}%"
    if strs:
        line += f"<br><span style='color:{FLAT};font-size:0.85em;'>策略：{strs}</span>"
    return f"<div style='margin:4px 0;line-height:1.6;'>{line}</div>"


def _reason_html(pick, result):
    """推荐理由卡片: 把"为什么选它"讲清楚(触发策略/信号数/质量分/预期收益/胜率/板块/行情环境)."""
    strs = pick.get("strategies") or []
    sig_n = pick.get("signal_count")
    q = pick.get("quality_score")
    exp = pick.get("expected_return")
    win = pick.get("win_rate")
    sector = pick.get("sector") or "-"
    regime = result.get("regime") or {}
    regime_txt = regime.get("desc") or regime.get("level") or "-"
    items = []
    if strs:
        items.append("触发策略：" + "、".join(strs) + (f"（信号数 {sig_n}）" if isinstance(sig_n, (int, float)) else ""))
    q_txt = f"{q:.0f}" if isinstance(q, (int, float)) else "-"
    exp_txt = f"{exp:+.2f}%" if isinstance(exp, (int, float)) else "-"
    win_txt = f"{win:.0f}%" if isinstance(win, (int, float)) else "-"
    items.append(f"质量分 {q_txt}　预期收益 {exp_txt}　历史胜率 {win_txt}")
    items.append(f"所属板块：{sector}")
    items.append(f"行情环境：{regime_txt}")
    # 当日最强板块作市场背景
    secs = result.get("sectors") or []
    if secs:
        s0 = secs[0]
        st = s0.get("strength", 0)
        items.append(f"市场背景：最强板块 {s0.get('name','')} 强度 {st:+.2f}%（领涨 {s0.get('lead_name','-')} {s0.get('lead_change_pct',0):+.2f}%）")
    body = "".join(f"<div style='margin:3px 0;color:{FLAT};line-height:1.7;'>· {it}</div>" for it in items)
    return f"""
    <div style='{CARD}'>
      <div style='font-weight:700;margin-bottom:6px;'>📝 推荐理由</div>
      {body}
    </div>"""


def _guidance_html():
    sh = load_sh_history()
    sh_sig = sh[max(sh)] if sh else None
    sector = load_sector_index_latest()
    g = build_guidance(sh_sig, sector)
    lines = []
    if sh_sig:
        ds = max(sh)
        above = "站上MA20" if sh_sig.get("above_ma20") else "跌破MA20"
        ret = sh_sig.get("ret_pct")
        ret_txt = f"{ret:+.2f}%" if ret is not None else "-"
        lines.append(f"上证指数(<span style='color:{FLAT}'>{ds[:4]}-{ds[4:6]}-{ds[6:]}</span>): "
                     f"{above} · 当日 {ret_txt} · <span style='color:{POS if ret is not None and ret >= 0 else NEG}'>{g['sh'].split('→')[-1]}</span>")
    else:
        lines.append("上证数据缺失(待扫描补齐)")
    if sector:
        d = sector.get("direction")
        sc = POS if d == "up" else NEG if d == "down" else FLAT
        arrow = "升" if d == "up" else "降" if d == "down" else "平"
        stale = " <span style='color:#4a5568;font-size:0.85em;'>(非当日快照)</span>" if sector.get("stale") else ""
        sec_names = "、".join(s.get("name", "") for s in sector.get("sectors", [])) or "-"
        lines.append(f"板块指数({sec_names}): <span style='color:{sc}'>{arrow} {sector.get('chg_pct', 0):+.2f}%</span>"
                     f" · 成分{sector.get('n_constituents','-')}只{stale}")
    gcls = POS if g.get("comb_cls") == "pos" else NEG if g.get("comb_cls") == "neg" else FLAT
    lines.append(f"综合建议: <span style='color:{gcls};font-weight:600;'>{g['comb']}</span>")
    return "".join(f"<div style='margin:2px 0;'>{ln}</div>" for ln in lines)


def build_signal_html(result):
    """信号邮件正文: 简洁文本摘要(首页信息总结, 无表格)."""
    date = str(result.get("date") or _today())
    scanned = result.get("scanned_at", "")
    regime = result.get("regime") or {}
    regime_txt = regime.get("desc", "-")
    head = f"""
    <div style='font-size:1.5em;font-weight:700;color:{ACCENT};'>📡 选股信号</div>
    <div style='color:{FLAT};margin:4px 0 12px;'>{date[:4]}-{date[4:6]}-{date[6:]} · 扫描产出时间 {scanned or '未知'} · {regime_txt}</div>"""

    picks = []           # 备用轨已关闭: 邮件只列主推
    if result.get("main_pick"):
        picks.append(_pick_line(result["main_pick"], "主推"))
    if not picks:
        picks.append("<div style='margin:4px 0;color:#4a5568;'>当日无主推（空仓观望）</div>")
    picks_html = f"""
    <div style='{CARD}'>
      <div style='font-weight:700;margin-bottom:6px;'>🎯 今日关注</div>
      {''.join(picks)}
    </div>"""

    sectors = result.get("sectors") or []
    if sectors:
        secs = []
        for s in sectors[:5]:
            st = s.get("strength", 0)
            lead = s.get("lead_name", "-")
            lead_cp = s.get("lead_change_pct")
            lead_cp_txt = f"{lead_cp:+.2f}%" if lead_cp is not None else ""
            secs.append(f"{s.get('name','')} <span style='color:{_cls(st)}'>({st:+.2f})</span> · 领涨 {lead} {lead_cp_txt}")
        sec_html = f"""
        <div style='{CARD}'>
          <div style='font-weight:700;margin-bottom:6px;'>🔥 强势板块</div>
          <div style='color:{FLAT};line-height:1.7;'>{"<br>".join(secs)}</div>
        </div>"""
    else:
        sec_html = ""

    guide_html = f"""
    <div style='{CARD}'>
      <div style='font-weight:700;margin-bottom:6px;'>🧭 决策辅助</div>
      {_guidance_html()}
    </div>"""

    footer = f"<div style='color:{FLAT};font-size:0.82em;margin-top:14px;'>本邮件由量化交易系统自动发送 · 数据仅供研究参考，不构成投资建议</div>"
    reason_html = _reason_html(result["main_pick"], result) if result.get("main_pick") else ""
    return _wrap(f"{head}{picks_html}{reason_html}{sec_html}{guide_html}{footer}")


def _prev_trading_day(d):
    """d 的上一个交易日."""
    d = d - timedelta(days=1)
    for _ in range(14):
        if is_trading_day(d):
            return d
        d -= timedelta(days=1)
    return d


def _date_picks(date_str):
    """某日推荐列表(带 role). 该日空仓/无记录 → None."""
    for base in (REC_DIR, PICKS_DIR):
        p = os.path.join(base, f"{date_str}.json")
        if not os.path.exists(p):
            continue
        try:
            with open(p, encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            return None
        if data.get("picks"):
            return data["picks"]
        picks = []       # 备用轨已关闭: 只取主推
        pk = data.get("main_pick")
        if pk:
            item = dict(pk)
            item["role"] = "主推"
            picks.append(item)
        return picks if picks else None
    return None


def _fmt(ds):
    return f"{ds[:4]}-{ds[4:6]}-{ds[6:]}"


def _scanned_at(date_str):
    """该日扫描产出时点(优先 daily_picks.scanned_at, 其次 recommendations.time)."""
    for base in (PICKS_DIR, REC_DIR):
        p = os.path.join(base, f"{date_str}.json")
        if not os.path.exists(p):
            continue
        try:
            with open(p, encoding="utf-8") as f:
                data = json.load(f)
            t = data.get("scanned_at") or data.get("time")
            if t:
                return t
        except Exception:
            pass
    return None


def build_close_brief_text():
    """收盘简报: 纯文字版(行情 / 板块 / 今日买入 / 今日卖出 / 历史仅昨今)."""
    today = datetime.now()
    ds = today.strftime("%Y%m%d")
    L = [f"📊 收盘简报 {today.strftime('%Y-%m-%d')}", "=" * 26, ""]

    # ── 行情 ──
    L.append("【行情】")
    sh = load_sh_history()
    if sh:
        d = sh[max(sh)]
        above = "站上MA20" if d.get("above_ma20") else "跌破MA20"
        ret = d.get("ret_pct")
        ret_txt = f"{ret:+.2f}%" if ret is not None else "-"
        L.append(f"上证指数  {d.get('close', 0):.2f}  {ret_txt}  {above}")
    else:
        L.append("上证指数  数据缺失")
    L.append("")

    # ── 板块(今日强势) ──
    L.append("【板块】")
    secs = []
    try:
        with open(os.path.join(PICKS_DIR, f"{ds}.json"), encoding="utf-8") as f:
            dp = json.load(f)
        secs = dp.get("sectors") or []
    except Exception:
        secs = []
    if secs:
        for s in secs[:5]:
            cp = s.get("lead_change_pct")
            st = s.get("strength", 0)
            if cp is not None:
                L.append(f"{s.get('name', '')}  强度{st:+.2f}  领涨 {s.get('lead_name', '-')} ({cp:+.2f}%)")
            else:
                L.append(f"{s.get('name', '')}  强度{st:+.2f}  领涨 {s.get('lead_name', '-')}")
    else:
        L.append("无强势板块数据")
    L.append("")

    # ── 今日买入 ──
    scanned = _scanned_at(ds)
    scan_tag = f"{scanned} 扫描产出 · " if scanned else ""
    L.append(f"【今日买入】({scan_tag}买入即持仓, 明日10:30卖出)")
    today_picks = _date_picks(ds)
    if today_picks:
        for p in today_picks:
            exp = p.get("expected_return")
            win = p.get("win_rate")
            price = p.get("price")
            exp_txt = f"{exp:+.2f}%" if exp is not None else "-"
            win_txt = f"{win:.0f}%" if win is not None else "-"
            price_txt = f"  收盘{price:.2f}" if isinstance(price, (int, float)) else ""
            L.append(f"{p.get('role', '—')}  {p.get('name', '')} {p.get('code', '')}  {p.get('sector', '-')}{price_txt}  预期{exp_txt}  胜率{win_txt}")
    else:
        L.append("无 —— 今日空仓")
    L.append("")

    # ── 今日卖出(昨日持仓 T+1@10:30) ──
    prev = _prev_trading_day(today)
    prev_str = prev.strftime("%Y%m%d")
    L.append("【今日卖出】(昨日持仓 T+1@10:30)")
    prev_picks = _date_picks(prev_str)
    if prev_picks:
        for p in prev_picks:
            t1 = p.get("t1_1030_return")
            if t1 is None:
                t1 = p.get("t1_return")
            t1_txt = f"{t1:+.2f}%" if isinstance(t1, (int, float)) else "待更新"
            L.append(f"{p.get('role', '—')}  {p.get('name', '')} {p.get('code', '')}  T+1 实际 {t1_txt}")
    else:
        L.append(f"无 —— 昨日({_fmt(prev_str)})空仓, 无持仓待卖")
    L.append("")

    # ── 历史记录(仅昨今) ──
    L.append("【历史记录】(仅昨今)")
    if prev_picks:
        parts = []
        for p in prev_picks:
            t1 = p.get("t1_1030_return")
            if t1 is None:
                t1 = p.get("t1_return")
            parts.append(f"{p.get('name', '')} {p.get('code', '')} ({f'{t1:+.2f}%' if isinstance(t1, (int, float)) else '待更新'})")
        L.append(f"{_fmt(prev_str)}  买入 {'、'.join(parts)}")
    else:
        L.append(f"{_fmt(prev_str)}  空仓, 无操作")
    if today_picks:
        L.append(f"{_fmt(ds)}  买入 {'、'.join(p.get('name', '') for p in today_picks)} (待明日10:30卖出)")
    else:
        L.append(f"{_fmt(ds)}  空仓, 无操作")
    L.append("")
    L.append("—— 本简报由量化交易系统自动生成 ——")
    return "\n".join(L)


def _wrap(body):
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"></head>
<body style="margin:0;padding:16px;background:#0e1117;color:#e6e6e6;font-family:'Microsoft YaHei',sans-serif;font-size:14px;max-width:640px;">
{body}
</body></html>"""


# ---------- 对外入口 ----------

def try_send_signal_email(result):
    """定时扫描触发信号时调用. 空仓/与上次已发送推荐相同/无配置 → 跳过; 成功才记录已发."""
    if not _load_mail_config():
        return False
    sig = _pick_signature(result)
    if sig is None:
        return False  # 空仓(无主推)不发送
    if _load_last_signal() == sig:
        return False  # 与上次已发送的推荐相同, 不重复发
    subject = f"[量化] 选股信号 {_today()[:4]}-{_today()[4:6]}-{_today()[6:]}"
    ok = _send(subject, build_signal_html(result))
    if ok:
        _save_last_signal(sig)
        _mark(SIGNAL_TODAY)
    return ok


def build_empty_html(result):
    """空仓邮件正文: 当日确认无推荐, 无操作观望."""
    date = str(result.get("date") or _today())
    regime = result.get("regime") or {}
    regime_txt = regime.get("desc", "-")
    head = f"""
    <div style='font-size:1.5em;font-weight:700;color:{ACCENT};'>🏳️ 今日空仓 · 无操作观望</div>
    <div style='color:{FLAT};margin:4px 0 14px;'>{date[:4]}-{date[4:6]}-{date[6:]} · 当日最后一次定时扫描确认 · {regime_txt}</div>"""
    body = f"""
    <div style='{CARD}'>
      <div style='font-weight:700;margin-bottom:8px;'>ℹ️ 说明</div>
      <div>当日无符合条件的主推标的，系统判定 <span style='color:{FLAT};font-weight:600;'>空仓观望</span>。
           空仓视为无操作，不参与胜率统计。若盘中后续扫描出现信号，系统会自动再发选股信号邮件。</div>
    </div>"""
    guide_html = f"""
    <div style='{CARD}'>
      <div style='font-weight:700;margin-bottom:8px;'>🧭 决策辅助</div>
      {_guidance_html()}
    </div>"""
    footer = f"<div style='color:{FLAT};font-size:0.82em;margin-top:14px;'>本邮件由量化交易系统自动发送 · 数据仅供研究参考，不构成投资建议</div>"
    return _wrap(f"{head}{body}{guide_html}{footer}")


def try_send_empty_email(result):
    """当日最后一次定时扫描确认空仓时调用. 当日已发信号邮件/已发空仓邮件/无配置 → 跳过."""
    if not _load_mail_config():
        return False
    if _marked(SIGNAL_TODAY):
        return False  # 当日有过推荐(发过信号邮件), 不是空仓
    if _marked(EMPTY_MARK):
        return False
    subject = f"[量化] 空仓观望 {_today()[:4]}-{_today()[4:6]}-{_today()[6:]}"
    ok = _send(subject, build_empty_html(result))
    if ok:
        _mark(EMPTY_MARK)
    return ok


def build_sell_html():
    """卖出提醒正文: 今日需卖出昨日持仓(T+1到期). 无持仓可卖返回 None."""
    today = datetime.now()
    ds = today.strftime("%Y%m%d")
    prev = _prev_trading_day(today)
    prev_str = prev.strftime("%Y%m%d")
    picks = _date_picks(prev_str)
    if not picks:
        return None
    head = f"""
    <div style='font-size:1.5em;font-weight:700;color:#ff9800;'>📕 今日卖出提醒</div>
    <div style='color:{FLAT};margin:4px 0 12px;'>{_fmt(ds)} · 昨日({_fmt(prev_str)})持仓 T+1 到期 · 共 {len(picks)} 只</div>"""
    rows = []
    for p in picks:
        exp = p.get("expected_return")
        win = p.get("win_rate")
        price = p.get("price")
        exp_txt = f"{exp:+.2f}%" if isinstance(exp, (int, float)) else "-"
        win_txt = f"{win:.0f}%" if isinstance(win, (int, float)) else "-"
        price_txt = f" · 昨收 {price:.2f}" if isinstance(price, (int, float)) else ""
        rows.append(
            f"<div style='margin:4px 0;line-height:1.6;'>"
            f"<b>{p.get('role', '—')}</b> {p.get('name', '')} "
            f"<span style='color:{FLAT}'>{p.get('code', '')}</span> · {p.get('sector', '-')}"
            f"{price_txt} · 预期 {exp_txt} · 胜率 {win_txt}</div>"
        )
    body = f"""
    <div style='{CARD}'>
      <div style='font-weight:700;margin-bottom:6px;'>🎯 今日待卖出（T+1 纪律）</div>
      {''.join(rows)}
    </div>"""
    note = f"""
    <div style='{CARD}'>
      <div style='font-weight:700;margin-bottom:6px;'>ℹ️ 卖出口径</div>
      <div style='color:{FLAT};line-height:1.7;'>卖出价优先取 T+1 收盘价（历史回测胜率更高），10:30 盘中价仅作参考。
      盘中若<b>连板中断</b>或<b>持满时间止损</b>，将<b>另发一封「盘中卖出信号」邮件</b>即时提醒，并按当日收盘价结算；否则继续持有至纪律触发。
      以上为模拟回放，非真实成交。</div>
    </div>"""
    footer = f"<div style='color:{FLAT};font-size:0.82em;margin-top:14px;'>本邮件由量化交易系统自动发送 · 数据仅供研究参考，不构成投资建议</div>"
    return _wrap(f"{head}{body}{note}{footer}")


def try_send_sell_email():
    """今日有昨日持仓T+1到期则发卖出提醒(每日至多一封). 无持仓可卖/无配置/已发过 → 跳过."""
    if not _load_mail_config():
        return False
    if _marked(SELL_MARK):
        return False
    html = build_sell_html()
    if not html:
        return False  # 昨日空仓, 无持仓可卖
    subject = f"[量化] 今日卖出提醒 {_today()[:4]}-{_today()[4:6]}-{_today()[6:]}"
    ok = _send(subject, html)
    if ok:
        _mark(SELL_MARK)
    return ok


def _load_event_state():
    try:
        if os.path.exists(SELL_EVENT_STATE):
            with open(SELL_EVENT_STATE, encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def _save_event_state(state):
    try:
        with open(SELL_EVENT_STATE, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False)
    except Exception:
        pass


def build_sell_event_html(item):
    """盘中纪律卖出事件正文: 单只标的触发 连板中断 / 时间止损."""
    ds = datetime.now().strftime("%Y-%m-%d")
    price = item.get("price")
    pnl = item.get("pnl")
    price_txt = f"{price:.2f}" if isinstance(price, (int, float)) else "—"
    pnl_txt = f"¥{pnl:+,.0f}" if isinstance(pnl, (int, float)) else "—"
    pnl_cls = "pos" if isinstance(pnl, (int, float)) and pnl >= 0 else "neg"
    head = f"""
    <div style='font-size:1.5em;font-weight:700;color:#ff9800;'>📕 盘中卖出信号</div>
    <div style='color:{FLAT};margin:4px 0 12px;'>{ds} · 纪律触发 · 按当日收盘价结算（模拟回放）</div>"""
    body = f"""
    <div style='{CARD}'>
      <div style='margin:4px 0;line-height:1.7;'>
        <span style='color:#ff9800;font-weight:600;'>{item.get('role', '—')}</span>
        <b>{item.get('name', '')}</b> <span style='color:{FLAT}'>{item.get('code', '')}</span><br>
        触发原因：<b style='color:#ff9800;'>{item.get('why', '')}</b><br>
        现价 {price_txt} · 浮动 <b class='{pnl_cls}'>{pnl_txt}</b>
      </div>
    </div>"""
    note = f"""
    <div style='{CARD}'>
      <div style='color:{FLAT};line-height:1.7;'>该标的已触发 T5 卖出纪律（连板中断或持满时间止损），
      系统将于当日收盘按收盘价结算卖出。以上为模拟回放，非真实成交。</div>
    </div>"""
    footer = f"<div style='color:{FLAT};font-size:0.82em;margin-top:14px;'>本邮件由量化交易系统自动发送 · 数据仅供研究参考，不构成投资建议</div>"
    return _wrap(f"{head}{body}{note}{footer}")


def try_send_sell_event_email(item):
    """盘中纪律卖出事件预警: 同一标的当日首次触发才发(去重), 无配置/无代码跳过."""
    if not _load_mail_config():
        return False
    today = datetime.now().strftime("%Y%m%d")
    code = str(item.get("code", ""))
    if not code:
        return False
    state = _load_event_state()
    if state.get(code) == today:
        return False
    ok = _send(f"[量化] 盘中卖出信号 {item.get('name', '')}({code}) · {item.get('why', '')}",
               build_sell_event_html(item))
    if ok:
        state[code] = today
        _save_event_state(state)
    return ok


def _send_text(subject, text):
    """同步发送纯文本邮件(调用方应为后台线程). 成功返回 True."""
    cfg = _load_mail_config()
    if not cfg:
        return False
    to = cfg.get("to") or cfg.get("user")
    msg = MIMEText(text, "plain", "utf-8")
    msg["Subject"] = Header(subject, "utf-8")
    msg["From"] = cfg["user"]
    msg["To"] = to
    try:
        with smtplib.SMTP_SSL(cfg.get("smtp_host", "smtp.qq.com"), int(cfg.get("smtp_port", 465)), timeout=30) as s:
            s.login(cfg["user"], cfg["auth_code"])
            s.sendmail(cfg["user"], [to], msg.as_string())
        return True
    except Exception:
        return False


def try_send_close_brief():
    """收盘后调用(纯文字版简报). 已发送过/无配置则跳过; 成功才打标记.
    收盘前已由 app._send_close_brief 跑完整流水线重扫, 此处直接基于最新 daily_picks 生成简报."""
    if not _load_mail_config():
        return False
    if _marked(CLOSE_MARK):
        return False
    subject = f"[量化] 收盘简报 {_today()[:4]}-{_today()[4:6]}-{_today()[6:]}"
    ok = _send_text(subject, build_close_brief_text())
    if ok:
        _mark(CLOSE_MARK)
    return ok


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "test":
        ok = try_send_close_brief()
        print("close brief sent:", ok)
    elif len(sys.argv) > 1 and sys.argv[1] == "text":
        print(build_close_brief_text())
    else:
        import json as _json
        picks_path = os.path.join(PICKS_DIR, f"{_today()}.json")
        if os.path.exists(picks_path):
            with open(picks_path, encoding="utf-8") as f:
                r = _json.load(f)
            print(build_signal_html(r))
