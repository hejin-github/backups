# -*- coding: utf-8 -*-
import os, sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
p = [os.path.join('D:/', x, 'quant_trader') for x in os.listdir('D:/')
     if os.path.isdir(os.path.join('D:/', x, 'quant_trader'))][0]
sys.path.insert(0, p)
import sim_t5 as S


def main_stats(asof, risk, thr):
    S.MAIN_WINRATE_MIN = thr
    r = S._load_main_backup(asof, risk_rules=risk)
    tr = r["主推"]["trades"]            # 仅含已平仓段(开仓段在 open_pos, 不在此列)
    n = len(tr)
    pnls = [float(t.get("pnl") or 0) for t in tr]
    wins = [x for x in pnls if x > 0]
    loss = [x for x in pnls if x <= 0]
    wr = (len(wins) / n * 100) if n else 0
    tot = sum(pnls)
    ml = min(pnls) if pnls else 0
    aw = (sum(wins) / len(wins)) if wins else 0
    al = (sum(loss) / len(loss)) if loss else 0
    return n, len(wins), wr, tot, ml, aw, al


asof = S._local_latest_date()
print("asof =", asof)
print(f"{'scenario':<26}{'risk':<6}{'winThr':<8}{'n':<4}{'win%':<7}{'total':<10}{'maxLoss':<9}{'avgWin':<8}{'avgLoss'}")
for label, risk, thr in [
    ("baseline(noStop/noFilter)", False, None),
    ("+stopLoss(risk)",           True,  None),
    ("+winFilter(52)",            False, 52),
    ("B+C(stop+win52)",           True,  52),
]:
    n, w, wr, tot, ml, aw, al = main_stats(asof, risk, thr)
    print(f"{label:<26}{str(risk):<6}{str(thr):<8}{n:<4}{wr:<7.1f}{tot:<10.1f}{ml:<9.1f}{aw:<8.1f}{al:.1f}")

print("\n--- win_rate threshold sensitivity (risk_rules=True) ---")
for thr in [None, 48, 50, 52, 54, 55, 60]:
    n, w, wr, tot, ml, aw, al = main_stats(asof, True, thr)
    print(f"winThr={str(thr):<5} n={n:<3} win%={wr:<6.1f} total={tot:<9.1f} maxLoss={ml:.1f}")

print("\n--- 龙头 live 仓 (asof) ---")
dr = S._dragon_track(asof)
dt = dr.get("trades", [])
dp = [float(t.get("pnl") or t.get("ret") or 0) for t in dt if t.get("exit_price") is not None]
print(f"closed={len(dp)} win={len([x for x in dp if x>0])} total={sum(dp):.1f} (8/31老仓; 9/3后扫描已接入调度, 待本机网络补新仓)")
