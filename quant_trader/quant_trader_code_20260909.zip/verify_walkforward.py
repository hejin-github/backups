"""Task #11 验证: walk-forward 无泄漏刷新 + 单策略质控 + 辩论共识展示化 + 回归"""
import sys
sys.stdout.reconfigure(encoding="utf-8")
import json, os

print("=" * 60)
print("1) strategy_backtest_meta.json")
meta_path = "data/strategy_backtest_meta.json"
print(json.load(open(meta_path, encoding="utf-8")) if os.path.exists(meta_path) else "MISSING")

print("=" * 60)
print("2) ensure_backtest_refreshed() → 应 no-op(generated_date==today)")
from strategy_backtest import ensure_backtest_refreshed
m = ensure_backtest_refreshed()
print("  meta:", m)

print("=" * 60)
print("3) 各档位 allowed 集 strategies_for_regime(应≈实验B)")
from strategy_backtest import strategies_for_regime
expect = {
    "strong": ["龙头战法", "摇头哥", "涨停打板", "炒股养家", "缠论"],
    "normal": ["摇头哥", "涨停打板"],
    "weak": ["摇头哥", "龙头战法", "涨停打板", "退学炒股"],
    "crash": ["退学炒股", "乔帮主低吸"],
}
for lvl in ["strong", "normal", "weak", "crash"]:
    got = strategies_for_regime(lvl)
    mark = "≈OK" if set(got) == set(expect[lvl]) else "≠实验B"
    print(f"  {lvl}: {got}  {mark}")

print("=" * 60)
print("4) 回归: strategy_backtest.json 顶层结构未变")
bt = json.load(open("data/strategy_backtest.json", encoding="utf-8"))
keys = list(bt.keys())
s = keys[0]
print(f"  策略数={len(keys)} 示例[{s}] keys={list(bt[s].keys())} "
      f"regimes={list(bt[s]['regimes'].keys())} all={list(bt[s]['all'].keys())}")

print("=" * 60)
print("5) 共振 → 按行情单策略质控")
from recommender import index_regime
regime = index_regime()
lvl = regime.get("level")
print(f"  今日 index_regime.level={lvl}  desc={regime.get('desc')}")
allowed = set(strategies_for_regime(lvl))
print(f"  allowed 集: {sorted(allowed)}")
from distiller import run_distill, get_bullish_stocks
res = run_distill(sample_limit=100)
print(f"  蒸馏: {res['cards']}策略 {res['stocks']}只" if res else "  蒸馏失败")
buys = get_bullish_stocks(min_signals=1)
print(f"  get_bullish_stocks(min_signals=1): {len(buys)}只")
for b in buys[:10]:
    hit = sum(1 for s in b["strategies"] if s in allowed)
    print(f"    {b['name']}({b['code']}) 信号={b['signal_count']} "
          f"策略={b['strategies']} allowed命中={hit}")
single = [b for b in buys if b["signal_count"] == 1]
viol = [b for b in buys if not any(s in allowed for s in b["strategies"])]
print(f"  单策略信号股: {len(single)}; 违禁(无allowed信号)股: {len(viol)}")
if single:
    print(f"  单策略示例: {single[0]['name']}({single[0]['code']}) "
          f"策略={single[0]['strategies']}")

print("=" * 60)
print("6) 辩论 → 单agent推荐应保留, 共识仅作标签")
from debate_engine import run_debate
out = run_debate()
print(f"  regime.level={out['regime'] and out['regime'].get('level')}  "
      f"cards={len(out.get('cards', []))}  consensus_buys={len(out['consensus_buys'])}")
for c in out["consensus_buys"]:
    print(f"    {c['name']}({c['code']}) consensus={c.get('consensus')} "
          f"agents={c.get('agent_count')} score={c.get('score_sum'):.0f}")
tags = sorted(set(c.get("consensus") for c in out["consensus_buys"]))
print("  标签分布:", tags)
single_agent = [c for c in out["consensus_buys"] if c.get("agent_count", 0) < 2]
print(f"  单agent(agent_count<2)推荐数: {len(single_agent)}")
print("=" * 60)
print("VERIFY DONE")
